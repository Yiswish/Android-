// Downloads the images that the Lovable site hosts (lock-screen / home pictures) into mobile/public/assets.
// Usage: APP_URL=https://your-published-site node mobile/fetch-assets.mjs   (skipped if APP_URL is empty)
import fs from 'node:fs';
import path from 'node:path';

const base = (process.env.APP_URL ?? '').replace(/\/$/, '');
const dir = 'src/assets';
const out = 'mobile/public/assets';
fs.mkdirSync(out, { recursive: true });
if (!base) { console.log('APP_URL not set: lock/home pictures will be left out (gradient only).'); process.exit(0); }
for (const f of fs.readdirSync(dir).filter((n) => n.endsWith('.asset.json'))) {
  const j = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
  try {
    const res = await fetch(base + j.url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    fs.writeFileSync(path.join(out, j.original_filename), Buffer.from(await res.arrayBuffer()));
    console.log('downloaded', j.original_filename);
  } catch (e) { console.log('could not download', j.original_filename, String(e)); }
}
