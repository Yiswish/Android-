// The AI checks run on the phone and call Gemini / Groq directly with the keys typed in API Keys.
import { judgeLook, judgeLookBatch, judgeFinal, judgeBody, checkAiKeyHealth } from '../../src/lib/aiLook.server';

type Any = any; // eslint-disable-line @typescript-eslint/no-explicit-any
const NO_KEY = { ok: false as const, error: 'Add a free Gemini key (or a Groq key) under API Keys to use the AI check.' };
const hasKeys = (keys?: string[]) => Array.isArray(keys) && keys.some((k) => k && k.trim());

export const judgeLookServer = async ({ data }: { data: Any }) => {
  if (!hasKeys(data.personalKeys)) return NO_KEY;
  return judgeLook(data.image, '', data.start ?? 0, data.personalKeys, data.examples ?? []);
};

export const judgeLookBatchServer = async ({ data }: { data: Any }) => {
  if (!hasKeys(data.personalKeys)) return NO_KEY;
  return { ok: true as const, results: await judgeLookBatch(data.images, data.start ?? 0, data.personalKeys, data.examples ?? []) };
};

export const judgeFinalServer = async ({ data }: { data: Any }) => {
  if (!hasKeys(data.personalKeys)) return NO_KEY;
  const { image, start, personalKeys, ...input } = data;
  return judgeFinal(image, input, start ?? 0, personalKeys);
};

export const judgeBodyServer = async ({ data }: { data: Any }) => {
  if (!hasKeys(data.personalKeys)) return NO_KEY;
  return judgeBody(data.image, data.start ?? 0, data.personalKeys, data.examples ?? []);
};

export const checkAiKeysServer = async ({ data }: { data: Any }) => {
  if (!hasKeys(data?.personalKeys)) return NO_KEY;
  return { ok: true as const, report: await checkAiKeyHealth(data.personalKeys) };
};
