// Owner locks only exist on the shared website. In the app every key you type is yours and always allowed.
export const getKeyLocks = async () => ({ gemini: false, serpapi: false, serper: false, pexels: false, unsplash: false });
export const getKeyOwner = async () => ({ owner: false });
export const setKeyLock = async (_input?: unknown) => ({ ok: true });
