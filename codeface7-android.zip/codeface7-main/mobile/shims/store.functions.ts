// Everything is stored on the phone (IndexedDB via src/lib/localStore.ts). db.ts already writes there first,
// so the cloud calls become no-ops and photos are kept inside the saved record as data URLs.
import { localAll, localPut } from '../../src/lib/localStore';

type Any = any; // eslint-disable-line @typescript-eslint/no-explicit-any
const ok = async (_input?: Any) => ({ ok: true });

export const storeImageServer = async ({ data }: { data: { key: string; dataUrl: string } }) => ({ url: data.dataUrl });
export const saveAnalysisServer = ok;
export const updateAnalysisServer = ok;
export const loadAnalysesServer = async (): Promise<Any[]> => [];
export const saveRatingServer = ok;
export const loadRatingsServer = async (): Promise<Any[]> => [];
export const loadFavouritesServer = async (): Promise<Any[]> => [];
export const saveFavouritesServer = ok;
export const clearFavouritesServer = async () => ({ ok: true });
export const resetEverythingServer = async () => ({ ok: true });

/** Soft delete: drop the stored photos (frees space), keep scores and ratings for taste learning. */
export const softDeleteAnalysesServer = async ({ data }: { data: { ids?: string[]; all?: boolean } }) => {
  const rows = await localAll<Any>('analyses');
  const targets = data.all ? rows : rows.filter((r) => data.ids?.includes(r.id));
  for (const r of targets) await localPut('analyses', r.id, { ...r, imageUrl: '', thumbUrl: undefined, deletedAt: Date.now() });
  return { ok: true };
};
