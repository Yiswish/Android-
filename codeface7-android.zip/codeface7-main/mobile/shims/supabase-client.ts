// No cloud sign-in in the app (owner sign-in is a website-only feature).
export const supabase = {
  auth: {
    getSession: async () => ({ data: { session: null } }),
    onAuthStateChange: (_callback: unknown) => ({ data: { subscription: { unsubscribe: () => {} } } }),
    signOut: async () => ({ error: null }),
    setSession: async (_tokens: unknown) => ({ error: null }),
  },
};
