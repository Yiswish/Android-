export const lovable = {
  auth: {
    signInWithOAuth: async (_provider: string, _opts?: unknown) => ({ error: new Error('Owner sign-in is only available on the website.') }),
  },
};
