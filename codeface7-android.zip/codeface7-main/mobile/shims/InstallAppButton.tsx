// Already an installed app: no "Download app" button.
export default function InstallAppButton() {
  return null;
}
