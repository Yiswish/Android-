// The app has no server, so "server functions" are plain functions: useServerFn just returns the function.
export const useServerFn = <T>(fn: T): T => fn;
