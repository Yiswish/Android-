// Image search runs on the phone: the provider chain is called directly (native HTTP has no CORS limits).
import { searchChain } from '../../src/lib/search.providers';

export type { Provider, FallbackReason } from '../../src/lib/search.providers';
export { isFaceQuery } from '../../src/lib/search.providers';

type SearchInput = Parameters<typeof searchChain>[0];
type SearchKeys = Parameters<typeof searchChain>[1];

export const searchImagesServer = async ({ data }: { data: SearchInput & { personalKey?: string; personalKeys?: SearchKeys } }) => {
  const { personalKey, personalKeys, ...input } = data;
  const keys = { ...personalKeys, ...(personalKey ? { serpapi: personalKey } : {}) } as SearchKeys;
  return searchChain(input as SearchInput, keys);
};
