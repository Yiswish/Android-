// Entry point of the Android app. Same screens, logic and styles as the website; no server, no router.
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { App as NativeApp } from '@capacitor/app';
import '../src/styles.css';
import AestheticsApp from '@/components/AestheticsApp';
import FingerprintLock from '@/components/FingerprintLock';
import ErrorBoundary from '@/components/ErrorBoundary';
import { Toaster } from '@/components/ui/sonner';

// Android back button: close an open dialog, else use the app's own Back, else send the app to the background.
void NativeApp.addListener('backButton', () => {
  if (document.querySelector('[role="dialog"], [role="alertdialog"]')) {
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    return;
  }
  const back = document.querySelector<HTMLButtonElement>('button[aria-label="Back"]:not([disabled])');
  if (back) { back.click(); return; }
  void NativeApp.minimizeApp();
});

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary label="Aesthetics">
      <FingerprintLock>
        <AestheticsApp />
      </FingerprintLock>
    </ErrorBoundary>
    <Toaster />
  </StrictMode>,
);
