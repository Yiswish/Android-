// Builds the website's front end as a plain single-page app for the Android (Capacitor) wrapper.
// The web build (vite.config.ts / Lovable) is untouched. Server-only code is swapped for on-device versions in mobile/shims.
import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const src = path.join(root, 'src');
const shim = (f: string) => path.join(root, 'mobile', 'shims', f);

// "*.asset.json" files point at images hosted by Lovable. In the app they are read from /assets/<file> (downloaded at build time).
function localAssetJson(): Plugin {
  const PREFIX = '\0assetjson:';
  return {
    name: 'local-asset-json',
    enforce: 'pre',
    async resolveId(source, importer, options) {
      if (!source.endsWith('.asset.json')) return null;
      const r = await this.resolve(source, importer, { ...options, skipSelf: true });
      return r ? PREFIX + r.id : null;
    },
    load(id) {
      if (!id.startsWith(PREFIX)) return null;
      const json = JSON.parse(fs.readFileSync(id.slice(PREFIX.length), 'utf8')) as { original_filename: string };
      return `export default ${JSON.stringify({ ...json, url: `/assets/${json.original_filename}` })};`;
    },
  };
}

export default defineConfig({
  root: path.join(root, 'mobile'),
  base: './',
  publicDir: path.join(root, 'mobile', 'public'),
  plugins: [localAssetJson(), react(), tailwindcss()],
  define: {
    'process.env': '{}',
    'import.meta.env.VITE_MOBILE': '"1"',
  },
  resolve: {
    alias: [
      { find: /^(?:\.\/|@\/lib\/)store\.functions$/, replacement: shim('store.functions.ts') },
      { find: /^(?:\.\/|@\/lib\/)aiLook\.functions$/, replacement: shim('aiLook.functions.ts') },
      { find: /^(?:\.\/|@\/lib\/)search\.functions$/, replacement: shim('search.functions.ts') },
      { find: /^(?:\.\/|@\/lib\/)keySettings\.functions$/, replacement: shim('keySettings.functions.ts') },
      { find: /^@tanstack\/react-start$/, replacement: shim('react-start.ts') },
      { find: /^@\/integrations\/supabase\/client$/, replacement: shim('supabase-client.ts') },
      { find: /^@\/integrations\/lovable$/, replacement: shim('lovable.ts') },
      { find: /^(?:@\/components\/|\.\/)InstallAppButton$/, replacement: shim('InstallAppButton.tsx') },
      { find: /^@\/(.*)$/, replacement: `${src}/$1` },
    ],
    dedupe: ['react', 'react-dom'],
  },
  build: {
    outDir: path.join(root, 'dist-mobile'),
    emptyOutDir: true,
    target: 'es2022',
    chunkSizeWarningLimit: 4000,
  },
});
