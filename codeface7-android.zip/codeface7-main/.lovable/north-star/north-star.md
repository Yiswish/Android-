<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

People get an attractiveness read on the photos they care about

## Metric

Photos with a finished analysis result shown each week
