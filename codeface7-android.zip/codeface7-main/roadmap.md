# v3
- [ ] Keep Draw grid only, add Best row swipe-delete/hold-rate, and remove global section swiping; verify gestures.
- [ ] Finish AI key health and five-face taste quiz: verify screens, rating flow, and save changes.
- [x] Repair Gemini model/settings recovery and Groq vision-model 404 fallback; 19 targeted tests pass. Real photo measurement finishes and Retry AI check is available.
- [ ] Verify successful live AI recovery — blocked: no Gemini/Groq keys available in this preview and built-in AI reports exhausted credits.
- [x] Add Discover for You: AI-first reference matching, new portrait searches, immediate ratings, and honest confidence; ranking tests and desktop/mobile checked.
- [ ] Verify a live personalized discovery run — blocked: preview has no rated AI references; needs three, including an 80+ rating.
- [x] Rebuild from v2 with fresh Cloud tables and photo storage; faces mosaic on home + lock screen.
- [x] First AI check: step-by-step, a bit more thinking. Way-off re-check: strong thinking capped at 10 s per pass.
- [ ] Re-add search keys (SerpAPI, Serper, Pexels, Unsplash, Gemini) — blocked: needs the owner's keys.

# Current face and history updates
- [ ] Remove expression from scores, taste features and visible breakdowns.
- [x] Replace star controls with precise sliders and connect corrections to face AI learning.
- [x] Add user and AI Attractive/Cute/Beautiful labels with No/Partly/Yes per category (overlap allowed).
- [x] Add plus/minus photo-count controls beside each Best search name.
- [x] Repair history deletion (deletes now stick even when a save is still running); not yet tried hands-on with saved photos.

# Project import
- [x] Finish clickable photo names that search young portraits; click-to-search verified in the app.
- [x] Set Find the best photo counts per name (up to 300 each), add automatic all-photo AI mode and manual checks on any result; per-name controls and a lower-ranked AI check verified. Named portrait accuracy remains dependent on live search providers; fallback images are not identity matches.
- [x] Remove the entire PickTok section and both navigation entries; desktop/mobile navigation verified, 9 tests pass.
- [x] Import the uploaded project into this app with its data tables.
- [x] Add search and AI keys (saved by the owner).

# Lean results page
- [x] Speed up bounded searches (4 at once), synchronize photo/AI counts, show a live agent view (steps, photo tiles, scores, leader, log); 163 tests pass. Live run with real keys not yet verified.
- [x] Keep Search's young-portrait default; Best now searches age-neutral portraits.
- [x] Add Back controls across screens and keep known search labels above photos; real search labels and mobile navigation verified, 35 targeted tests pass. Older scans without search context remain unnamed.
- [x] Improve Compare: clearer labels, add/clear actions, disabled slider until 2 items, keyboard-operable slider, sticky matrix columns, no duplicate card grid; 5 tests pass.
- [x] Add a Download app button (PWA install prompt with manual-install fallback).
- [x] Make Your weighted score the single main result number and keep the mix collapsed; saved-result weight changes verified in the app.
- [x] Improve analysis reliability by rejecting damaged meshes/crop passes and retaining each face's original expression/pose association; geometry tests pass, no recalibration claimed.
- [x] Remove redundant numbers (raw formula, weighted mix list, AI key/pass counters, face-type score, taste averages) and explain the overall in plain words.
- [x] Move Save-to-folder to the bottom of the results page.

# Multi-picture analysis
- [x] Make completed photo thumbnails open their existing full analysis without rescanning.
- [x] Run multiple pictures concurrently with per-picture progress and separately saved results.
- [ ] Verify multi-upload, stopping queued work, and opening completed results.

# Key settings
- [ ] Resolve the current personal API key entry problem without bypassing owner locks.
- [ ] Make colour, text size and reduced motion apply across the existing app and verify on mobile.
- [x] Resolve public replacement safely with personal visitor keys; shared credentials stay unchanged.
- [ ] Add owner sign-in; establish the owner's identity after the owner signs in (no account exists yet).
- [x] Finish session-only Gemini and SerpAPI replacement and request handling; personal SerpAPI search verified with a real key.
- [x] Add the API Keys button and replacement form beside Search; desktop and narrow-screen form checked.
- [x] Test owner-only locking and personal replacement permissions (39 targeted tests pass).
- [ ] Verify owner lock/unlock through the app after the owner signs in and receives the owner role; blocked by no owner account yet.
# Drag to Compare
- [x] Fix the broken import so the app builds again.
- [x] Show the drag (ghost photo + "Drop here to compare" area) on screen, touch and mouse.
- [x] Drag photos from History and "Find the best" results; no tab slide or History select while dragging.
- [ ] Hands-on drag check on a real phone (no saved photos in the fresh database to test with yet).

# More search keys
- [x] Add Serper, Pexels and Unsplash keys (personal + shared SERPER_API_KEY / PEXELS_API_KEY / UNSPLASH_ACCESS_KEY) and use them in search after SerpAPI.

# Continue Best page
- [x] Search age-neutral portraits in Best while preserving Search behavior.
- [x] Finish checking the simplified Best layout and requested AI check count: 41 targeted tests pass; mobile/desktop checked; real 3-of-3 AI run and results retained after tab switching/reload verified.

# Photo actions and search context
- [x] Hold analysed photos to show all original detected mesh dots; release restores the picture without opening photo actions. Real 478-point portrait checked on mobile-sized results and full-screen views; 51 targeted tests pass. Older scans without original mesh coordinates need a fresh scan.
- [x] Add shared image-click actions for attached-name or entered-name searches, without face identification or replacing existing image actions; mobile live-candidate and entered-name search verified, 32 targeted tests pass.
- [x] Add shared literal context to Best searches and retain it with the last run; outgoing query and tab/reload retention verified on mobile, desktop checked. Search-provider accuracy is not guaranteed and no model training is claimed.

# Gemini + batching
- [x] Put the new picture on the lock and home screens.
- [x] Gemini keys first, Groq (Llama 4 Maverick) kept as backup.
- [x] Best section: 4 photos per AI request + 15 requests/minute pacing.
- [ ] Live Gemini check — blocked: needs the owner's Gemini key.
