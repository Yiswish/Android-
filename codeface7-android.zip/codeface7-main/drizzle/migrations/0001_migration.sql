CREATE TABLE IF NOT EXISTS public.analyses (
  id text PRIMARY KEY, image_id text NOT NULL, image_url text NOT NULL, thumb_url text,
  source text NOT NULL, overall_score real NOT NULL, scoring_version integer NOT NULL DEFAULT 1,
  metrics jsonb NOT NULL, result jsonb NOT NULL, "timestamp" bigint NOT NULL, deleted_at bigint);
CREATE INDEX IF NOT EXISTS analyses_timestamp_idx ON public.analyses("timestamp");
CREATE INDEX IF NOT EXISTS analyses_image_id_idx ON public.analyses(image_id);
CREATE TABLE IF NOT EXISTS public.star_ratings (id serial PRIMARY KEY, image_id text NOT NULL, rating real NOT NULL, "timestamp" bigint NOT NULL, categories text[]);
CREATE INDEX IF NOT EXISTS star_ratings_image_id_idx ON public.star_ratings(image_id);
CREATE TABLE IF NOT EXISTS public.favourite_rankings (image_id text PRIMARY KEY, strength real NOT NULL, comparisons integer NOT NULL DEFAULT 0, wins integer NOT NULL DEFAULT 0, updated_at bigint NOT NULL);
GRANT ALL ON public.analyses, public.star_ratings, public.favourite_rankings TO service_role;
GRANT USAGE, SELECT ON SEQUENCE public.star_ratings_id_seq TO service_role;
ALTER TABLE public.analyses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.star_ratings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.favourite_rankings ENABLE ROW LEVEL SECURITY;
CREATE TABLE IF NOT EXISTS public.user_roles (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE, role text NOT NULL CHECK (role IN ('owner')), UNIQUE(user_id,role));
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Read own role" ON public.user_roles;
CREATE POLICY "Read own role" ON public.user_roles FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE TABLE IF NOT EXISTS public.api_key_locks (provider text PRIMARY KEY, locked boolean NOT NULL DEFAULT false);
GRANT SELECT ON public.api_key_locks TO anon, authenticated;
GRANT INSERT, UPDATE ON public.api_key_locks TO authenticated;
GRANT ALL ON public.api_key_locks TO service_role;
ALTER TABLE public.api_key_locks ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Read lock status" ON public.api_key_locks;
DROP POLICY IF EXISTS "Owner inserts locks" ON public.api_key_locks;
DROP POLICY IF EXISTS "Owner changes locks" ON public.api_key_locks;
CREATE POLICY "Read lock status" ON public.api_key_locks FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Owner inserts locks" ON public.api_key_locks FOR INSERT TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'owner'));
CREATE POLICY "Owner changes locks" ON public.api_key_locks FOR UPDATE TO authenticated USING (EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'owner')) WITH CHECK (EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'owner'));