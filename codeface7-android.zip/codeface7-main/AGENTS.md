<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Face geometry (`src/lib/faceGeometry.ts`), skin & age (`src/lib/skin.ts`) and image/overall scoring (`src/lib/scoring.ts`) are pure, deterministic, unit-tested functions; landmarks are frontalised on the fitted 3D symmetry plane before 2D measurement, and all scores use smooth curves with confidence shrinkage — never hard caps — so one flaw can't collapse a score.
- Image loads and model loads are wrapped in timeouts (`withTimeout` in faceDetection.ts) so a stalled network never freezes the app.
- External images are read through `/api/public/image-proxy` so canvas pixels and the mesh model can access them (CORS).
- The main app renders client-only (`ClientOnly` in `src/routes/index.tsx`) because it relies on canvas, IndexedDB and WASM.
- Multi-photo analysis uses a bounded browser-side worker pool and per-photo states; stopping prevents queued photos from starting while in-flight photos finish, avoiding unbounded AI requests.
- Completed batch photo thumbnails and result links open the existing AnalysisResult through the same onOpen callback; never start analysis from these controls, avoiding repeat scans.
- Screen transitions share an in-app back stack that skips transient analysis screens; search labels travel with images and saved result JSON, and PhotoHeading renders them above photos without inferring identities. Why: returning preserves search/results context and names survive reopening saved scans.

- Subdirectories have their own `AGENTS.md` (e.g. `src/lib/AGENTS.md`: search providers + secret handling); read it before changing files there.
- Hold-photo overlays use stored image-space mesh points, never frontalised points or guesses; release restores the photo. Why: accurate alignment.

- Scoring design rules (overall formula, AI look check, face groups, skin, expression) live in `src/lib/AGENTS.md`.

## Measured vs guessed (keep honest)
- MEASURED: pose invariance of raw residuals; ≤2.8-point pose swing on real meshes; grayscale invariance; dist_* vs clean gap (python FaceMesh landmarks, 19 controls — see README table).
- GUESSED / UNCALIBRATED: every σ multiplier, harmony weights, skin τ/k, skin confidence terms, expressionLoad weights, mouth/jaw σ and power (−2), lip σ. `darkFraction` / `obstructionScale` in skin.ts were tuned on the same 19 controls (a fit, not a validation).
- Calibration against the `public/_verify` test photos is intentionally NOT part of the current work (owner's decision); nothing in this repo claims a fresh calibration after the metric removals.
- NOT VERIFIED: aged-face drop ≥15 on a real aged face; smiling vs neutral pair on real data; anything on the web Face Landmarker (blendshapes, pose matrix).
- Never claim calibration that was not measured. Label guesses in code comments and here.

- "Matches your taste" (preferenceEngine.ts) is kernel regression over the user's star ratings (metrics + overall + expression/mouth-jaw/alignment groups) and is displayed beside, never blended into, the geometric score.
- UI copy: the score is "how closely this face matches the measured proportion, symmetry and skin-detail model", never a verdict on a person. Mesh-based symmetry is a lower bound (the mesh regularises faces).
- The results ring computes the personal weighted score reactively from user preferences without overwriting stored overall scores; its mix is collapsed and has no duplicate headline number. Why: personal weights must update the primary result without destroying the original analysis.
- Taste v3 blends the kernel with a weighted ridge regression on z-features; the kernel/ridge share is picked by leave-one-out each rebuild, and favourite-test results nudge ratings both ways. Why: the old correlation trend was crude and favourites only lifted 4–5★ photos.
- "Way off" button (`judgeFinal`): a separate final analyst gets the photo, the AI score + notes and the measurement scores, makes 3 passes and its median becomes ONLY the overall; the AI look score is never changed. Why: owner's rule — the AI score is right, Way off is for the overall only.
- AI keys: Gemini keys (GEMINI_API_KEY, GEMINI_API_KEY_2 …) are tried first, Groq keys (GROQ_API_KEY …) next, then the built-in AI (`aiKeys.ts`, `aiLook.server.ts`); personal keys share one list and are told apart by the `gsk_` Groq prefix. The browser rotates the start key with a localStorage counter. Why: owner moved to Gemini but keeps Groq as a backup.
- AI look requests from a tab pass a 15-per-minute limiter, and the Best section groups up to 4 photos into one Gemini request (`aiBatching.ts`, `judgeLookBatch`); photos a batch misses fall back to single checks. Why: free Gemini keys allow ~15 requests per minute.
- Taste kernel weights each rating by recency (half-life `TASTE_HALF_LIFE`, guessed); `suggestNextToRate` ranks unrated scans by lowest kernel coverage. Why: taste drifts, and novel photos teach the model fastest.
- Saved analyses and ratings live in Lovable Cloud tables `analyses` / `star_ratings` / `favourite_rankings`, reached only through server functions with the admin client (no sign-in). Why: matches the original single-user app.
- Preferred face type is a separate guessed-ratio match in `src/lib/faceType.ts`, shown beside (never blended into) the face score. Why: it works before any star ratings exist.
- Key settings use tab-memory personal overrides in POST bodies, never shared-secret replacement or browser persistence; owner locks are enforced on every personal request through authenticated roles and RLS. Why: public visitors cannot compromise shared credentials.
- Owner roles are provisioned only for the verified requesting owner after sign-in, never for the first registrant. Why: first-signup ownership can be hijacked on a public app.
- Photo-quality metrics (lighting, composition, sharpness, contrast, processing) are still computed but never shown and never scored (FACE_SHARE=1, PHOTO_SHARE=0, METRIC_KEYS = face metrics only). Why: owner ruled them irrelevant to the score; old stored overalls are left untouched.
- Find the best uses injected search/measure/AI, per-query photo limits, bounded pagination/workers and top-only or all-photo AI with quota stops. Manual AI uses analysisAi and updates the same saved ID. Why: independent name counts and bounded paid calls without repeat scans.
