// Minimal service worker: present so Android/Chrome offers "Install app".
// It does no caching — every request goes straight to the network, so the
// app always behaves exactly like the website.
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (event) => event.waitUntil(self.clients.claim()));
self.addEventListener("fetch", (event) => {
  event.respondWith(fetch(event.request));
});
