#!/usr/bin/env python3
"""
Fallback calibration extractor (use when no browser is available).

Writes public/_verify/landmarks.json in the same shape public/_verify/dump.html
produces, using MediaPipe's legacy Python FaceMesh (refine_landmarks=True →
468 mesh + 10 iris points). That is the same mesh family as the web Face
Landmarker but NOT the identical model, and it returns no blendshapes and no
facial transformation matrix (those fields are left empty: expression load is
then 0 and pose comes from the mirror-Procrustes frame). Prefer dump.html when
you can; label any numbers from this script as "python FaceMesh".

  pip install "mediapipe==0.10.14" "numpy<2" opencv-python-headless
  python3 tools/extract_landmarks.py            # → public/_verify/landmarks.json
"""
import glob, json, os, sys
import cv2
import mediapipe as mp

root = os.path.join(os.path.dirname(__file__), '..', 'public', '_verify')
out = {}
fm = mp.solutions.face_mesh.FaceMesh(static_image_mode=True, max_num_faces=1, refine_landmarks=True, min_detection_confidence=0.3)
for path in sorted(glob.glob(os.path.join(root, '*.jpg')) + glob.glob(os.path.join(root, '*.png'))):
    name = os.path.splitext(os.path.basename(path))[0]
    img = cv2.imread(path)
    if img is None:
        print(name, 'unreadable'); continue
    h, w = img.shape[:2]
    # luminance-only input, exactly like the app (Rec.709 weights on RGB)
    rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB).astype('float32')
    y = (0.2126 * rgb[..., 0] + 0.7152 * rgb[..., 1] + 0.0722 * rgb[..., 2]).round().clip(0, 255).astype('uint8')
    gray3 = cv2.merge([y, y, y])
    res = fm.process(gray3)
    if not res.multi_face_landmarks:
        print(name, 'no face'); continue
    lm = res.multi_face_landmarks[0].landmark
    out[name] = {'width': w, 'height': h, 'landmarks': [{'x': p.x, 'y': p.y, 'z': p.z} for p in lm], 'blendshapes': {}, 'matrix': [], 'source': 'python-facemesh'}
    print(name, 'ok', len(lm))
with open(os.path.join(root, 'landmarks.json'), 'w') as f:
    json.dump(out, f)
print('wrote', len(out), 'faces')
