import { useState } from 'react';
import { useServerFn } from '@tanstack/react-start';
import { Activity, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { checkAiKeysServer } from '@/lib/aiLook.functions';
import { personalKeys } from '@/lib/personalKeys';
import type { AiHealthReport, KeyHealthStatus } from '@/lib/aiLook.server';

export type HealthLevel = 'good' | 'partial' | 'bad';
const STORE = 'ai-key-health';
const DOT: Record<HealthLevel, string> = { good: 'bg-success-600', partial: 'bg-warning-500', bad: 'bg-error-600' };
const STATUS_DOT: Record<KeyHealthStatus, string> = { ok: DOT.good, quota: DOT.partial, 'no-model': DOT.partial, rejected: DOT.bad, error: DOT.bad };

export function healthLevel(report: AiHealthReport): HealthLevel {
  const ok = report.keys.filter((k) => k.status === 'ok').length;
  if (ok === report.keys.length && ok > 0) return 'good';
  return ok > 0 || (report.keys.length === 0 && report.builtIn === 'set-up') ? 'partial' : 'bad';
}
export function lastHealth(): HealthLevel | null {
  try { const v = sessionStorage.getItem(STORE); return v === 'good' || v === 'partial' || v === 'bad' ? v : null; } catch { return null; }
}
export function HealthDot({ level }: { level: HealthLevel | null }) {
  if (!level) return null;
  return <span aria-label={`AI keys: ${level}`} className={`inline-block h-2.5 w-2.5 rounded-full ${DOT[level]}`} />;
}

export default function AiKeyHealth() {
  const [busy, setBusy] = useState(false);
  const [report, setReport] = useState<AiHealthReport | null>(null);
  const [error, setError] = useState('');
  const check = useServerFn(checkAiKeysServer);

  const run = async () => {
    setBusy(true); setError('');
    try {
      const keys = personalKeys().gemini;
      const r = await check({ data: { personalKeys: keys?.length ? keys : undefined } });
      if (!r.ok) { setError(r.error); return; }
      setReport(r.report);
      try { sessionStorage.setItem(STORE, healthLevel(r.report)); } catch { /* ignore */ }
    } catch { setError('The test could not run. Check your connection and try again.'); }
    finally { setBusy(false); }
  };

  const level = report ? healthLevel(report) : null;
  return (
    <div className="space-y-2 rounded-md bg-ink-100 p-3">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-sm font-semibold"><HealthDot level={level} />AI key health</div>
        <Button type="button" variant="outline" size="sm" className="h-8" disabled={busy} onClick={() => void run()}>
          {busy ? <Loader2 className="animate-spin" /> : <Activity />}{busy ? 'Testing…' : 'Test keys'}
        </Button>
      </div>
      <p className="text-xs text-ink-500">Checks key access and available models without a photo. Photo-check quota is not verified.</p>
      {error && <p role="alert" className="text-xs text-error-700">{error}</p>}
      {report && (
        <ul className="space-y-1.5 text-xs">
          {report.keys.length === 0 && <li className="text-ink-500">No {report.personal ? 'saved' : 'shared'} Gemini or Groq keys found.</li>}
          {report.keys.map((k) => (
            <li key={`${k.provider}-${k.index}`} className="flex items-start gap-2">
              <span className={`mt-1 h-2 w-2 shrink-0 rounded-full ${STATUS_DOT[k.status]}`} />
              <span><b>{k.provider === 'gemini' ? 'Gemini' : 'Groq'} key {k.index}</b>{report.personal ? '' : ' (shared)'}: {k.detail}{k.model ? ` · ${k.model}` : ''}</span>
            </li>
          ))}
          <li className="flex items-start gap-2 text-ink-500">
            <span className={`mt-1 h-2 w-2 shrink-0 rounded-full ${report.builtIn === 'set-up' ? 'bg-ink-400' : DOT.bad}`} />
            <span>Built-in backup AI: {report.builtIn === 'set-up' ? 'set up (credit balance can only be seen when a check runs)' : 'not set up'}</span>
          </li>
        </ul>
      )}
    </div>
  );
}
