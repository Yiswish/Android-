import { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle } from 'lucide-react';

interface ErrorBoundaryProps {
  children: ReactNode;
  fallback?: ReactNode;
  label?: string;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

export default class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo): void {
    console.warn(`ErrorBoundary [${this.props.label ?? 'unnamed'}]:`, error.message, errorInfo.componentStack);
  }

  render(): ReactNode {
    if (this.state.hasError) {
      if (this.props.fallback) return this.props.fallback;

      return (
        <div className="card p-6 flex flex-col items-center text-center space-y-3 animate-fade-in">
          <div className="w-12 h-12 rounded-xl bg-warning-50 flex items-center justify-center">
            <AlertTriangle className="w-6 h-6 text-warning-600" />
          </div>
          <div className="space-y-1">
            <p className="text-sm font-semibold text-ink-700">
              {this.props.label ? `${this.props.label} failed to load` : 'Something went wrong'}
            </p>
            <p className="text-2xs text-ink-400">
              {this.state.error?.message ?? 'An unexpected error occurred.'}
            </p>
          </div>
          <button
            onClick={() => this.setState({ hasError: false, error: null })}
            className="btn-secondary text-2xs"
          >
            Try again
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
