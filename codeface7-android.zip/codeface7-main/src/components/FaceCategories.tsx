import type { AestheticScores, FaceCategory } from '@/lib/types';
import { FACE_CATEGORIES } from '@/lib/faceTeaching';
import { ToggleGroup, ToggleGroupItem } from './ui/toggle-group';

type Level = 'no' | 'partly' | 'yes';
const LEVELS: Array<{ value: Level; label: string }> = [
  { value: 'no', label: 'No' },
  { value: 'partly', label: 'Partly' },
  { value: 'yes', label: 'Yes' },
];

/** Each category is No / Partly / Yes, so a face can be cute and beautiful, or only a bit attractive. */
export default function FaceCategories({ scores, onChange }: { scores: AestheticScores; onChange?: (values: FaceCategory[], partly: FaceCategory[]) => void }) {
  const yes = scores.userFaceCategories ?? [];
  const partly = (scores.userFacePartial ?? []).filter((c) => !yes.includes(c));
  const levelOf = (c: FaceCategory): Level => (yes.includes(c) ? 'yes' : partly.includes(c) ? 'partly' : 'no');
  const set = (c: FaceCategory, level: Level) => {
    if (!onChange) return;
    const nextYes = yes.filter((x) => x !== c);
    const nextPartly = partly.filter((x) => x !== c);
    if (level === 'yes') nextYes.push(c);
    if (level === 'partly') nextPartly.push(c);
    onChange(nextYes, nextPartly);
  };
  const ai = scores.aiLook;
  const aiText = [
    ...(ai?.categories ?? []),
    ...(ai?.partialCategories ?? []).map((c) => `partly ${c.toLowerCase()}`),
  ].join(' + ');
  return <section className="space-y-3 border-t border-border pt-3">
    <h3 className="text-sm font-semibold text-foreground">Face category</h3>
    <p className="text-xs text-muted-foreground">Pick as many as fit — both, all three, or just partly.</p>
    <div className="space-y-2">
      {FACE_CATEGORIES.map((category) => <div key={category} className="flex items-center justify-between gap-3">
        <span className="text-xs font-medium text-foreground">{category}</span>
        <ToggleGroup type="single" size="sm" variant="outline" value={levelOf(category)} disabled={!onChange}
          aria-label={`${category} level`}
          onValueChange={(v) => { if (v) set(category, v as Level); }}>
          {LEVELS.map((l) => <ToggleGroupItem key={l.value} value={l.value} aria-label={`${category}: ${l.label}`} className="h-8 px-3 text-xs">{l.label}</ToggleGroupItem>)}
        </ToggleGroup>
      </div>)}
    </div>
    <p className="text-xs text-muted-foreground">AI: {aiText || 'Not classified yet'}</p>
  </section>;
}
