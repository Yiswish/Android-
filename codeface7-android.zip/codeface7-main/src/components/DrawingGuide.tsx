import { useState } from 'react';
import type { DetectedFace } from '@/lib/types';

/** Paper-sized grid for copying by hand. */
const PAPERS: Record<string, [number, number]> = { A5: [14.8, 21], A4: [21, 29.7], A3: [29.7, 42], Letter: [21.6, 27.9] };

export default function DrawingGuide({ src, face }: { src: string; face?: DetectedFace }) {
  const [size, setSize] = useState({ w: 0, h: 0 });
  const [paper, setPaper] = useState('A4');
  const [landscape, setLandscape] = useState(false);
  const [cell, setCell] = useState(2);
  const [thick, setThick] = useState(0.5);
  const { w, h } = size;

  // Grid: photo fitted inside the chosen paper (keeping its shape)
  const [pw0, ph0] = PAPERS[paper];
  const [pw, ph] = landscape ? [ph0, pw0] : [pw0, ph0];
  const c = Math.max(0.5, cell || 1);
  const cmW = w && h ? Math.min(pw, ph * (w / h)) : pw;
  const cmH = w && h ? cmW * (h / w) : ph;
  const pxPerCm = w ? w / cmW : 1;
  const cols = Math.ceil(cmW / c), rows = Math.ceil(cmH / c);
  const lineW = Math.max(0.3, (thick || 0.1) / 10 * pxPerCm);

  const grid = () => (
    <g stroke="currentColor" strokeWidth={lineW} className="text-primary" opacity={0.85}>
      {Array.from({ length: cols + 1 }, (_, i) => <line key={'c' + i} x1={i * c * pxPerCm} y1={0} x2={i * c * pxPerCm} y2={h} />)}
      {Array.from({ length: rows + 1 }, (_, i) => <line key={'r' + i} x1={0} y1={i * c * pxPerCm} x2={w} y2={i * c * pxPerCm} />)}
    </g>
  );

  const inp = 'w-full min-h-10 rounded-lg border border-ink-100 bg-background px-2 text-sm';

  return (
    <div className="card p-4 space-y-3">
      <p className="text-2xs uppercase tracking-wide text-ink-400">Draw · Grid</p>
        <div className="grid grid-cols-2 gap-2 text-2xs text-ink-600">
          <label>Paper<select className={inp} value={paper} onChange={e => setPaper(e.target.value)}>{Object.keys(PAPERS).map(k => <option key={k}>{k}</option>)}</select></label>
          <label>Direction<select className={inp} value={landscape ? 'l' : 'p'} onChange={e => setLandscape(e.target.value === 'l')}><option value="p">Portrait</option><option value="l">Landscape</option></select></label>
          <label>Cell size (cm)<input type="number" min={0.5} step={0.5} className={inp} value={cell} onChange={e => setCell(parseFloat(e.target.value))} /></label>
          <label>Line thickness (mm)<input type="number" min={0.1} step={0.1} className={inp} value={thick} onChange={e => setThick(parseFloat(e.target.value))} /></label>
        </div>
      <div className="relative rounded-xl overflow-hidden">
        <img src={src} alt="Drawing guide" className="block w-full" draggable={false}
          onLoad={e => setSize({ w: e.currentTarget.naturalWidth, h: e.currentTarget.naturalHeight })} />
        {w > 0 && (
          <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox={`0 0 ${w} ${h}`}>
            {grid()}
          </svg>
        )}
      </div>
      <p className="text-2xs text-ink-400">
        {`On ${paper}: ${cmW.toFixed(1)} × ${cmH.toFixed(1)} cm · ${cols} × ${rows} cells · ${c} cm per cell · ${thick} mm lines`}
      </p>
    </div>
  );
}
