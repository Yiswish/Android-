import { useMemo, useRef, useState } from 'react';
import { Compass, Loader2, RefreshCw, Square, ArrowRight } from 'lucide-react';
import { Button } from './ui/button';
import StarRating from './StarRating';
import { buildDiscoveryProfile, discoverPortraits, predictDiscovery } from '@/lib/discovery';
import { searchImages } from '@/lib/search';
import { applyAiLook } from '@/lib/aiLookClient';
import { deriveMetricsFromFace, detectFaces, imageQualityOf } from '@/lib/faceDetection';
import { clampAestheticScores, computeAestheticScores } from '@/lib/metrics';
import type { AnalysisResult, FaceDetectionResult, SearchResultImage, StarRating as Rating } from '@/lib/types';
import type { TasteModel } from '@/lib/preferenceEngine';
import { emptyMetrics } from '@/lib/metricKeys';

async function analyzePortrait(image: SearchResultImage): Promise<AnalysisResult> {
  const started = performance.now();
  // AI-first: start the normal look check without waiting for the mesh to load.
  const neutral = clampAestheticScores(computeAestheticScores(emptyMetrics(50)));
  const aiPromise = applyAiLook(neutral, image.url, { aiOnly: true, batch: true });
  // A failed mesh must not discard a working AI assessment.
  const face: FaceDetectionResult = await detectFaces(image.url, image.id, () => {}).catch(() => ({ detected: false, faceCount: 0, faces: [], primaryFaceIndex: 0, expression: 'neutral' as const, expressionConfidence: 0, pose: 'frontal' as const, poseConfidence: 0, logs: [] }));
  const measured = clampAestheticScores(computeAestheticScores(deriveMetricsFromFace(face), face.geometry, imageQualityOf(face)));
  const ai = await aiPromise;
  const scores = { ...measured, overall: ai.overall, breakdown: measured.breakdown ? { ...measured.breakdown, overall: ai.overall, formula: 'AI look only; geometry is supporting discovery evidence' } : undefined, aiLook: ai.aiLook ? { ...ai.aiLook, geometryOverall: measured.overall } : undefined, aiLookError: ai.aiLookError };
  return { id: `analysis-discover-${crypto.randomUUID()}`, imageId: image.id, imageUrl: image.url, thumbUrl: image.thumbUrl, source: image.source,
    timestamp: Date.now(), faceDetection: face, scores, topArchetypes: [], warnings: face.detected ? [] : ['No reliable face measurements; discovery uses the AI look check.'], duration: performance.now() - started };
}

export default function DiscoverForYou({ results, ratings, tasteModel, candidates, onCandidate, onOpen, onRate, onGoRate }: {
  results: AnalysisResult[]; ratings: Rating[]; tasteModel: TasteModel; candidates: AnalysisResult[];
  onCandidate: (result: AnalysisResult) => void; onOpen: (result: AnalysisResult) => void;
  onRate: (imageId: string, rating: number) => void; onGoRate: () => void;
}) {
  const profile = useMemo(() => buildDiscoveryProfile(results, ratings), [results, ratings]);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('');
  const [errors, setErrors] = useState<string[]>([]);
  const stopping = useRef(false);
  const running = useRef(false);
  const latestRatings = useMemo(() => {
    const map = new Map<string, Rating>();
    for (const r of ratings) if (r.timestamp >= (map.get(r.imageId)?.timestamp ?? -1)) map.set(r.imageId, r);
    return map;
  }, [ratings]);
  const ranked = useMemo(() => candidates.map((candidate) => {
    const result = results.find((r) => r.id === candidate.id) ?? candidate;
    return { result, prediction: predictDiscovery(result, profile, tasteModel) };
  }).filter((r) => r.prediction).sort((a, b) => (b.prediction?.score ?? 0) - (a.prediction?.score ?? 0)), [candidates, results, profile, tasteModel]);
  const run = async () => {
    if (running.current || !profile.ready) return;
    running.current = true; stopping.current = false; setBusy(true); setErrors([]);
    try {
      const excluded = { ids: new Set([...ratings.map((r) => r.imageId), ...results.map((r) => r.imageId)]), urls: new Set([...results, ...candidates].map((r) => r.imageUrl)) };
      const outcome = await discoverPortraits(profile, excluded, {
        search: (query, page) => searchImages({ query, source: 'google', page, perPage: 20, portraitMode: 'all-ages' }),
        analyze: analyzePortrait, shouldStop: () => stopping.current, onResult: onCandidate, onProgress: setStatus,
      });
      setErrors(outcome.errors);
      setStatus(stopping.current ? 'Stopped — completed portraits are kept.' : outcome.results.length ? `${outcome.results.length} new portraits checked` : 'No new AI-checked portraits found. Try again later.');
    } catch { setErrors(['Discovery could not finish. Completed portraits are kept; please try again.']); }
    finally { running.current = false; setBusy(false); }
  };
  return <section className="space-y-6">
    <div className="flex flex-wrap items-start justify-between gap-4 border-b border-border pb-5">
      <div className="space-y-2 min-w-0">
        <h2 className="text-2xl font-display font-semibold text-foreground flex items-center gap-2"><Compass className="w-6 h-6 shrink-0 text-primary" />Discover for You</h2>
        <p className="text-sm text-ink-500">{profile.references.length} rated AI references · {profile.top.length} rated 80+</p>
      </div>
      {busy ? <Button variant="outline" onClick={() => { stopping.current = true; setStatus('Stopping after current checks…'); }}><Square className="w-4 h-4" />Stop</Button>
        : <Button disabled={!profile.ready} onClick={() => void run()}><RefreshCw className="w-4 h-4" />{candidates.length ? 'Find more faces' : 'Find faces for me'}</Button>}
    </div>
    {!profile.ready ? <div className="py-8 space-y-4 max-w-xl">
      <h3 className="text-lg font-semibold text-foreground">Your taste needs a little more evidence</h3>
      <p className="text-sm text-ink-600">Rate at least three different AI-checked photos, including one at 80 or above. Photos without AI notes cannot guide reference matching yet.</p>
      <Button variant="outline" onClick={onGoRate}>Rate more photos<ArrowRight className="w-4 h-4" /></Button>
    </div> : <>
      <div className="space-y-3">
        <p className="text-sm text-ink-600">{profile.references.length < 10 ? 'Early predictions — a few ratings are not enough to know your taste reliably.' : 'Likely matches, not guarantees — your next ratings will refine these estimates.'}</p>
        {(profile.traits.length > 0 || profile.categories.length > 0) && <p className="text-xs text-ink-500">Your top references: {[...profile.traits, ...profile.categories].join(' · ')}</p>}
        <div className="flex gap-2 overflow-x-auto pb-2">
          {profile.top.slice(0, 6).map((r) => <Button key={r.result.id} variant="ghost" className="h-auto p-0 shrink-0 rounded-lg overflow-hidden" aria-label={`Open reference rated ${r.rating}`} onClick={() => onOpen(r.result)}>
            <img src={r.result.thumbUrl ?? r.result.imageUrl} alt={`Reference rated ${r.rating}`} className="w-16 h-20 object-cover" />
          </Button>)}
        </div>
      </div>
      {status && <p role="status" className="text-sm text-ink-600 flex items-center gap-2">{busy && <Loader2 className="w-4 h-4 animate-spin shrink-0" />}{status}</p>}
      {errors.length > 0 && <div role="alert" className="border-l-2 border-warning-500 pl-3 space-y-1">{errors.slice(0, 3).map((e) => <p key={e} className="text-sm text-warning-700 break-words">{e}</p>)}<p className="text-xs text-ink-500">Photos without a successful AI check are not ranked.</p></div>}
      {ranked.length > 0 && <div className="space-y-4">
        <h3 className="text-sm font-semibold text-foreground">Predicted for you</h3>
        <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-5">
          {ranked.map(({ result, prediction }) => <article key={result.id} className="min-w-0 rounded-lg border border-border overflow-hidden bg-background">
            <Button variant="ghost" onClick={() => onOpen(result)} aria-label="Open discovered portrait" className="block w-full h-auto p-0 rounded-none overflow-hidden">
              <img src={result.thumbUrl ?? result.imageUrl} alt="Discovered portrait" loading="lazy" className="w-full aspect-[3/4] object-cover" />
            </Button>
            <div className="p-3 space-y-2">
              <div className="flex flex-wrap justify-between gap-1"><span className="text-xs text-ink-500">Predicted for you</span><strong className="text-primary font-mono">{prediction?.score}/100</strong></div>
              <p className="text-2xs text-ink-400">{prediction?.confidence} · AI look {Math.round(result.scores.aiLook?.attractiveness ?? 0)}</p>
              <p className="text-xs leading-relaxed text-ink-600 break-words">{prediction?.explanation}</p>
              <StarRating imageId={result.imageId} initialRating={latestRatings.get(result.imageId)?.rating} onRate={onRate} />
            </div>
          </article>)}
        </div>
      </div>}
    </>}
  </section>;
}