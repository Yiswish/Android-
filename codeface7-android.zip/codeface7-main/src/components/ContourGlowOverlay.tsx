import { accentColor, useUserPrefs } from '@/lib/userPrefs';
import { useState } from 'react';
import type { FaceDetectionResult } from '@/lib/types';

interface ContourGlowOverlayProps {
  faceDetection: FaceDetectionResult;
  imageUrl: string;
}

export default function ContourGlowOverlay({ faceDetection }: ContourGlowOverlayProps) {
  useUserPrefs(); // re-render when the theme colour changes
  const [showMesh, setShowMesh] = useState(true);

  if (!faceDetection.detected || !faceDetection.boundingBox || !faceDetection.landmarks) {
    return null;
  }

  const { boundingBox: bb, landmarks: lm } = faceDetection;
  const pct = (v: number) => `${(v * 100).toFixed(1)}%`;

  const points = [
    { x: lm.leftEye.x, y: lm.leftEye.y, color: accentColor(500), label: 'L Eye' },
    { x: lm.rightEye.x, y: lm.rightEye.y, color: accentColor(500), label: 'R Eye' },
    { x: lm.noseTip.x, y: lm.noseTip.y, color: accentColor(700), label: 'Nose' },
    { x: lm.noseBridge.x, y: lm.noseBridge.y, color: accentColor(700), label: 'Bridge' },
    { x: lm.mouthLeft.x, y: lm.mouthLeft.y, color: accentColor(700), label: 'Mouth L' },
    { x: lm.mouthRight.x, y: lm.mouthRight.y, color: accentColor(700), label: 'Mouth R' },
    { x: lm.chin.x, y: lm.chin.y, color: '#f97316', label: 'Chin' },
    { x: lm.forehead.x, y: lm.forehead.y, color: '#f97316', label: 'Brow' },
    { x: lm.leftCheek.x, y: lm.leftCheek.y, color: '#f97316', label: 'L Cheek' },
    { x: lm.rightCheek.x, y: lm.rightCheek.y, color: '#f97316', label: 'R Cheek' },
    { x: lm.leftBrow.x, y: lm.leftBrow.y, color: '#8b5cf6', label: 'L Brow' },
    { x: lm.rightBrow.x, y: lm.rightBrow.y, color: '#8b5cf6', label: 'R Brow' },
    { x: lm.leftEar.x, y: lm.leftEar.y, color: '#ec4899', label: 'L Ear' },
    { x: lm.rightEar.x, y: lm.rightEar.y, color: '#ec4899', label: 'R Ear' },
  ];

  return (
    <div className="absolute inset-0 pointer-events-auto">
      <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
        <defs>
          <linearGradient id="glow-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={accentColor(500)} stopOpacity="0.7" />
            <stop offset="50%" stopColor={accentColor(700)} stopOpacity="0.6" />
            <stop offset="100%" stopColor="#f97316" stopOpacity="0.5" />
          </linearGradient>
          <radialGradient id="point-glow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="white" stopOpacity="0.4" />
            <stop offset="100%" stopColor="white" stopOpacity="0" />
          </radialGradient>
          <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="0.6" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <filter id="soft-glow">
            <feGaussianBlur stdDeviation="0.3" />
          </filter>
        </defs>

        {/* Bounding box with animated corners */}
        <rect
          x={pct(bb.x)} y={pct(bb.y)} width={pct(bb.width)} height={pct(bb.height)}
          fill="none" stroke="url(#glow-gradient)" strokeWidth="0.3"
          strokeDasharray="1 0.4" rx="0.8" opacity="0.6"
        />

        {/* Face contour mesh */}
        {showMesh && (
          <g filter="url(#glow)" opacity="0.55">
            {/* Eye line */}
            <line x1={pct(lm.leftEye.x)} y1={pct(lm.leftEye.y)} x2={pct(lm.rightEye.x)} y2={pct(lm.rightEye.y)} stroke={accentColor(500)} strokeWidth="0.2" />
            {/* Eyes to nose bridge */}
            <line x1={pct(lm.leftEye.x)} y1={pct(lm.leftEye.y)} x2={pct(lm.noseBridge.x)} y2={pct(lm.noseBridge.y)} stroke={accentColor(500)} strokeWidth="0.15" opacity="0.5" />
            <line x1={pct(lm.rightEye.x)} y1={pct(lm.rightEye.y)} x2={pct(lm.noseBridge.x)} y2={pct(lm.noseBridge.y)} stroke={accentColor(500)} strokeWidth="0.15" opacity="0.5" />
            {/* Nose bridge to tip */}
            <line x1={pct(lm.noseBridge.x)} y1={pct(lm.noseBridge.y)} x2={pct(lm.noseTip.x)} y2={pct(lm.noseTip.y)} stroke={accentColor(700)} strokeWidth="0.2" />
            {/* Nose to mouth */}
            <line x1={pct(lm.noseTip.x)} y1={pct(lm.noseTip.y)} x2={pct(lm.mouthLeft.x)} y2={pct(lm.mouthLeft.y)} stroke={accentColor(700)} strokeWidth="0.15" />
            <line x1={pct(lm.noseTip.x)} y1={pct(lm.noseTip.y)} x2={pct(lm.mouthRight.x)} y2={pct(lm.mouthRight.y)} stroke={accentColor(700)} strokeWidth="0.15" />
            {/* Mouth line */}
            <line x1={pct(lm.mouthLeft.x)} y1={pct(lm.mouthLeft.y)} x2={pct(lm.mouthRight.x)} y2={pct(lm.mouthRight.y)} stroke={accentColor(700)} strokeWidth="0.25" />
            {/* Brow line */}
            <line x1={pct(lm.leftBrow.x)} y1={pct(lm.leftBrow.y)} x2={pct(lm.rightBrow.x)} y2={pct(lm.rightBrow.y)} stroke="#8b5cf6" strokeWidth="0.2" />
            {/* Forehead to chin (vertical axis) */}
            <line x1={pct(lm.forehead.x)} y1={pct(lm.forehead.y)} x2={pct(lm.chin.x)} y2={pct(lm.chin.y)} stroke="#f97316" strokeWidth="0.15" opacity="0.3" strokeDasharray="0.5 0.3" />
            {/* Cheekbones */}
            <line x1={pct(lm.leftCheek.x)} y1={pct(lm.leftCheek.y)} x2={pct(lm.rightCheek.x)} y2={pct(lm.rightCheek.y)} stroke="#f97316" strokeWidth="0.15" opacity="0.25" />
            {/* Left side contour */}
            <line x1={pct(lm.leftBrow.x)} y1={pct(lm.leftBrow.y)} x2={pct(lm.leftCheek.x)} y2={pct(lm.leftCheek.y)} stroke="#f97316" strokeWidth="0.12" opacity="0.2" />
            <line x1={pct(lm.leftCheek.x)} y1={pct(lm.leftCheek.y)} x2={pct(lm.chin.x)} y2={pct(lm.chin.y)} stroke="#f97316" strokeWidth="0.12" opacity="0.2" />
            {/* Right side contour */}
            <line x1={pct(lm.rightBrow.x)} y1={pct(lm.rightBrow.y)} x2={pct(lm.rightCheek.x)} y2={pct(lm.rightCheek.y)} stroke="#f97316" strokeWidth="0.12" opacity="0.2" />
            <line x1={pct(lm.rightCheek.x)} y1={pct(lm.rightCheek.y)} x2={pct(lm.chin.x)} y2={pct(lm.chin.y)} stroke="#f97316" strokeWidth="0.12" opacity="0.2" />
            {/* Ears */}
            <line x1={pct(lm.leftEar.x)} y1={pct(lm.leftEar.y)} x2={pct(lm.leftEye.x)} y2={pct(lm.leftEye.y)} stroke="#ec4899" strokeWidth="0.1" opacity="0.15" />
            <line x1={pct(lm.rightEar.x)} y1={pct(lm.rightEar.y)} x2={pct(lm.rightEye.x)} y2={pct(lm.rightEye.y)} stroke="#ec4899" strokeWidth="0.1" opacity="0.15" />
          </g>
        )}

        {/* Key landmark points with glow */}
        {points.map((pt, i) => (
          <g key={i}>
            <circle cx={pct(pt.x)} cy={pct(pt.y)} r="1.2" fill="url(#point-glow)" opacity="0.5" />
            <circle
              cx={pct(pt.x)} cy={pct(pt.y)} r="0.4" fill={pt.color}
              opacity="0.85" filter="url(#glow)"
            />
          </g>
        ))}

        {/* Bounding box corners */}
        {(() => {
          const corners = [
            { x: bb.x, y: bb.y, dx: 1, dy: 1 },
            { x: bb.x + bb.width, y: bb.y, dx: -1, dy: 1 },
            { x: bb.x, y: bb.y + bb.height, dx: 1, dy: -1 },
            { x: bb.x + bb.width, y: bb.y + bb.height, dx: -1, dy: -1 },
          ];
          const len = 2;
          return corners.map((c, i) => (
            <g key={`corner-${i}`}>
              <line x1={pct(c.x)} y1={pct(c.y)} x2={pct(c.x + c.dx * len / 100)} y2={pct(c.y)} stroke={accentColor(500)} strokeWidth="0.5" opacity="0.9" />
              <line x1={pct(c.x)} y1={pct(c.y)} x2={pct(c.x)} y2={pct(c.y + c.dy * len / 100)} stroke={accentColor(500)} strokeWidth="0.5" opacity="0.9" />
            </g>
          ));
        })()}
      </svg>

      {/* Info label */}
      <div
        className="absolute glass-sm rounded-lg px-2.5 py-1.5 text-2xs font-mono animate-fade-in space-y-0.5"
        style={{ left: pct(bb.x), top: `calc(${pct(bb.y)} - 2rem)` }}
      >
        <div className="text-primary-600 font-semibold">Face 1</div>
        <div className="text-ink-500 capitalize">{faceDetection.expression} · {faceDetection.pose}</div>
      </div>

      {/* Toggle mesh button */}
      <button
        onClick={() => setShowMesh((prev) => !prev)}
        className="absolute bottom-2 right-2 glass-sm rounded-lg px-2 py-1 text-2xs text-ink-600 hover:text-primary-600 transition-colors"
      >
        {showMesh ? 'Hide' : 'Show'} mesh
      </button>

      {/* Attribute badges */}
      <div
        className="absolute flex flex-wrap gap-1 max-w-[200px]"
        style={{ left: pct(bb.x + bb.width), top: pct(bb.y) }}
      >
        {faceDetection.lightingDirection && (
          <span className="badge badge-warning text-2xs capitalize animate-fade-in">{faceDetection.lightingDirection} light</span>
        )}
        {faceDetection.clothingStyle && (
          <span className="badge badge-accent text-2xs capitalize animate-fade-in">{faceDetection.clothingStyle}</span>
        )}
        {faceDetection.backgroundType && (
          <span className="badge badge-primary text-2xs capitalize animate-fade-in">{faceDetection.backgroundType}</span>
        )}
      </div>
    </div>
  );
}
