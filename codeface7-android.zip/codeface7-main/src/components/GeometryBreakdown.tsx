import type { ReactNode } from 'react';
import { FACE_TESSELLATION } from '@/lib/faceTessellation';
import { accentColor, useUserPrefs } from '@/lib/userPrefs';
import type { FaceGeometryReport } from '@/lib/faceGeometry';
import { SYMMETRY_SIGMA_2D, SYMMETRY_SIGMA_MESH, SYMMETRY_SIGMA_PAIR, SYMMETRY_WEIGHTS, HARMONY_POWER, GOLDEN_SIGMA_SCALE, STRUCTURE_SIGMA_SCALE, EXPRESSION_SIGMA_GAIN, MOUTH_JAW_POWER } from '@/lib/faceGeometry';
import { SKIN_PARAMS } from '@/lib/skin';
import { Download, Copy } from 'lucide-react';
import { useDisplaySettings } from '@/lib/displaySettings';
import { groupRawError, ipdPercent, ratioErrorText, rawMeasurementRows, rowsToCsv, symmetryErrorIpd } from '@/lib/rawError';

function download(name: string, text: string, type: string) {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = document.createElement('a');
  a.href = url; a.download = name; a.click();
  URL.revokeObjectURL(url);
}

const f = (n: number, d = 1) => n.toFixed(d);

function Stat({ label, value, sub }: { label: string; value: string; sub: string }) {
  return (
    <div className="rounded-xl bg-ink-50 px-3 py-2.5 min-w-0">
      <div className="text-2xs text-ink-500 truncate">{label}</div>
      <div className="text-xl font-bold text-ink-900 tabular-nums">{value}</div>
      <div className="text-2xs text-ink-400 truncate" title={sub}>{sub}</div>
    </div>
  );
}


/** All detected mesh points (478 incl. irises), joined by the engine's own face tessellation so it reads as a face. */
function Section({ title, children, open = false }: { title: string; children: ReactNode; open?: boolean }) {
  return (
    <details className="group rounded-xl border border-ink-100" open={open}>
      <summary className="flex cursor-pointer list-none items-center justify-between px-3 py-2.5 text-xs font-semibold text-ink-700">
        {title}
        <span className="text-ink-400 transition-transform group-open:rotate-90">›</span>
      </summary>
      <div className="px-3 pb-3 space-y-2">{children}</div>
    </details>
  );
}

function MeshPlot({ points }: { points: Array<[number, number]> }) {
  useUserPrefs(); // re-render when the theme colour changes
  const xs = points.map((p) => p[0]), ys = points.map((p) => p[1]);
  const minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys), maxY = Math.max(...ys);
  const pad = 0.1;
  const vb = `${minX - pad} ${minY - pad} ${maxX - minX + 2 * pad} ${maxY - minY + 2 * pad}`;
  return (
    <div className="space-y-1">
      <svg viewBox={vb} className="w-full h-80 bg-ink-900 rounded-xl" aria-label="Frontalised face mesh">
        <line x1={0} x2={0} y1={minY - pad} y2={maxY + pad} stroke={accentColor(700)} strokeWidth={0.01} strokeDasharray="0.04 0.03" />
        {FACE_TESSELLATION.map(([s0, e0], i) => {
          const a = points[s0], b = points[e0];
          return a && b ? <line key={i} x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} stroke={accentColor(400)} strokeOpacity={0.35} strokeWidth={0.004} /> : null;
        })}
        {points.map(([x, y], i) => (
          <circle key={i} cx={x} cy={y} r={i >= 468 ? 0.014 : 0.008} fill={accentColor(300)} />
        ))}
      </svg>
      <p className="text-2xs text-ink-500 font-mono">{points.length} points detected</p>
    </div>
  );
}

export default function GeometryBreakdown({ geometry: g }: { geometry: FaceGeometryReport }) {
  const [opt] = useDisplaySettings();
  const rows = rawMeasurementRows(g);
  const shownRatios = [...g.ratios]
    .filter((r) => opt.ratioFilter === 'all' || r.z >= 1)
    .sort((a, b) => (opt.ratioSort === 'worst' ? b.deviation - a.deviation : opt.ratioSort === 'best' ? a.deviation - b.deviation : 0));
  const copyJson = () => { void navigator.clipboard?.writeText(JSON.stringify(rows, null, 2)); };
  return (
    <div className="card p-4 space-y-4">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <h3 className="text-sm font-semibold text-ink-800">Landmark Geometry</h3>
          <div className="mt-1 flex flex-wrap gap-1">
            {[`${g.landmarkCount} points`, `yaw ${f(g.yaw, 0)}°`, `pitch ${f(g.pitch, 0)}°`, `roll ${f(g.roll, 0)}°`].map((t) => (
              <span key={t} className="rounded-full bg-ink-50 px-2 py-0.5 text-2xs text-ink-500 tabular-nums">{t}</span>
            ))}
          </div>
        </div>
        <div className="flex shrink-0 gap-1">
          <button type="button" aria-label="Download CSV" title="Download CSV" className="rounded-lg p-2 text-ink-500 hover:bg-ink-50" onClick={() => download('raw-measurements.csv', rowsToCsv(rows), 'text/csv')}><Download className="w-4 h-4" /></button>
          <button type="button" aria-label="Copy JSON" title="Copy JSON" className="rounded-lg p-2 text-ink-500 hover:bg-ink-50" onClick={copyJson}><Copy className="w-4 h-4" /></button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2 [&>*:last-child:nth-child(odd)]:col-span-2 md:[&>*:last-child:nth-child(odd)]:col-span-1">
        <Stat label="Symmetry" value={`${f(g.symmetryPercent)}%`} sub={opt.showRawError ? `raw error ${ipdPercent(symmetryErrorIpd(g))} · 3D ${f(g.pairSymmetry)} · 2D ${f(g.frontalSymmetry)} · mesh ${f(g.meshSymmetry)}` : `3D ${f(g.pairSymmetry)} · 2D ${f(g.frontalSymmetry)} · mesh ${f(g.meshSymmetry)}`} />
        <Stat label="Structural balance" value={f(g.structuralBalanceIndex)} sub="thirds · fifths · jaw/cheek" />
        <Stat label="Golden-ratio index" value={f(g.goldenRatioIndex)} sub="φ-based ratios" />
        <Stat label="Proportion deviation" value={`${f(g.proportionDeviation)}%`} sub="mean distance from ideal" />
        <Stat label="Skin & age" value={g.skin ? f(g.skin.score) : 'n/a'} sub={g.skin ? `confidence ${f(g.skin.confidence * 100, 0)}%` : 'not measurable'} />
      </div>

      <div className="space-y-2">
      <Section title="Skin & age details">
      <div className="rounded-xl bg-ink-50 p-3 space-y-1 font-mono text-2xs text-ink-700 leading-relaxed">
        <div className="text-xs font-sans font-semibold text-ink-700">Skin &amp; age (pixel measurement, luminance only)</div>
        {g.skin ? (
          <>
            <div>skinDetail = 1.4826·MAD(band over both cheek discs) ÷ mean luminance = <b>{f(g.skin.skinDetail, 4)}</b></div>
            <div>eyeDetail = P95(|band| over both pupil discs) ÷ mean luminance = <b>{f(g.skin.eyeDetail, 4)}</b> (the eyes are the face&apos;s own sharpness reference)</div>
            <div>ratio = skinDetail ÷ eyeDetail = <b>{f(g.skin.ratio, 3)}</b> → raw = 100·exp(−(ratio/{SKIN_PARAMS.tau})<sup>{SKIN_PARAMS.k}</sup>) = <b>{f(g.skin.rawScore)}</b></div>
            <div>confidence = {f(g.skin.confidence * 100, 0)}% (IPD {f(g.skin.ipdPx, 0)} px, {g.skin.skinSamples} cheek samples, {f(g.skin.maskedFraction * 100, 0)}% masked as hair/shadow) → score = c·soft(raw) + (1 − c)·{SKIN_PARAMS.neutral} = <b>{f(g.skin.score)}</b></div>
            <div className="text-ink-400">band = Gaussian({SKIN_PARAMS.sigmaFine}·IPD) − Gaussian({SKIN_PARAMS.sigmaCoarse}·IPD). Constants τ, k and the confidence terms are uncalibrated guesses. Heavy retouching lowers the ratio (raises the score); unretouched high-resolution skin may read harsh.</div>
          </>
        ) : (
          <div>Not measurable (pixels unavailable, or the face is too small / out of frame). The group is left out and the other weights renormalise; the bar shows a neutral {SKIN_PARAMS.neutral} for display only.</div>
        )}
      </div>

      </Section>
      <Section title="Score groups" open>
      <div className="overflow-x-auto">
        <table className="w-full text-2xs">
          <thead className="text-ink-400 text-left"><tr><th className="py-1 pr-2">Group</th><th className="pr-2 text-right">Score</th>{opt.showRawError && <th className="pr-2 text-right">Raw error</th>}<th className="pr-2 text-right">Weight</th><th className="text-right">Nominal</th></tr></thead>
          <tbody className="font-mono text-ink-700">
            {g.groups.filter((x) => x.id !== 'expression').map((x) => (
              <tr key={x.id} className="border-t border-ink-100">
                <td className="py-1 pr-2 font-sans">{x.label}</td>
                <td className="pr-2 text-right font-bold">{f(x.score)}</td>
                {opt.showRawError && <td className="pr-2 text-right text-ink-500" title={groupRawError(g, x.id)?.detail}>{groupRawError(g, x.id)?.short ?? '—'}</td>}
                <td className="pr-2 text-right">{f(x.weight * 100, 0)}%</td>
                <td className="text-right text-ink-400">{f(g.harmonyWeights[x.id] * 100, 0)}%</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="mt-1 font-mono text-2xs text-ink-500">
          Mouth &amp; jaw integrity: {g.mouthJaw.terms.map((t) => `${t.id} ${f(t.score, 0)}${opt.showRawError ? ` (${ipdPercent(t.measured)})` : ''}`).join(' · ')} (power-mean p = {MOUTH_JAW_POWER}; mouth openness {f(g.mouthJaw.mouthOpenness * 100, 0)}% of mouth width is informational, not scored)
        </div>
      </div>

      </Section>
      {opt.showFormulas && <Section title="Formulas"><div className="rounded-xl bg-primary-50/60 p-3 font-mono text-2xs text-ink-700 leading-relaxed">
        Harmony = power-mean<sub>p={HARMONY_POWER}</sub>({g.groups.filter((x) => x.id !== 'expression').map((x) => `${f(x.weight, 2)}×${x.label.toLowerCase()} ${f(x.score)}`).join(', ')}) = <b>{f(g.facialHarmony)}</b>
        <br />
        Symmetry = {SYMMETRY_WEIGHTS.pair3D}×3D + {SYMMETRY_WEIGHTS.frontal2D}×2D + {SYMMETRY_WEIGHTS.mesh}×mesh on the pose-normalised face (yaw/pitch/roll removed by mirror-Procrustes): 3D d = {f(g.pairAsymmetry * 100, 2)}% (σ {SYMMETRY_SIGMA_PAIR * 100}%), 2D d = {f(g.frontalAsymmetry * 100, 2)}% (σ {SYMMETRY_SIGMA_2D * 100}%), mesh d = {f(g.meshMirrorDistance * 100, 2)}% (σ {SYMMETRY_SIGMA_MESH * 100}%) — IPD units
        <br />
        Every landmark score = 100 / (1 + (z / 2)⁴), z = |measured − ideal| / σ · tiny variation is nearly free, z ≥ 3 falls hard · σ scales (uncalibrated guesses): golden ×{GOLDEN_SIGMA_SCALE}, structure ×{STRUCTURE_SIGMA_SCALE}, alignment ×1 · pose confidence {f(g.confidence * 100, 0)}%
        <br />
        Mesh-based symmetry is a lower bound: the mesh regularises every face toward a near-symmetric template, so a high value means &quot;no asymmetry the mesh could see&quot;.
      </div></Section>}

      <Section title={`Proportions (${shownRatios.length})`}>
      <div className="overflow-x-auto">
        <table className="w-full text-2xs">
          <thead className="text-ink-400 text-left">
            <tr><th className="py-1 pr-2">Proportion</th><th className="pr-2">Landmarks</th><th className="pr-2 text-right">Measured</th><th className="pr-2 text-right">Ideal</th>{opt.showRawError && <th className="pr-2 text-right">Raw error</th>}<th className="pr-2 text-right">Dev.</th><th className="pr-2 text-right">σ</th><th className="pr-2 text-right">z</th><th className="text-right">Score</th></tr>
          </thead>
          <tbody className="font-mono text-ink-700">
            {shownRatios.map((r) => (
              <tr key={r.id} className="border-t border-ink-100" title={r.reference}>
                <td className="py-1 pr-2 font-sans">{r.label}<div className="text-ink-400">{r.reference}</div></td>
                <td className="pr-2 text-ink-500">{r.formula}</td>
                <td className="pr-2 text-right">{f(r.measured, 3)}</td>
                <td className="pr-2 text-right">{f(r.ideal, 3)}</td>
                {opt.showRawError && <td className="pr-2 text-right text-ink-500">{ratioErrorText(r, opt.errorUnit)}</td>}
                <td className="pr-2 text-right">{f(r.deviation * 100)}%</td>
                <td className="pr-2 text-right">{f(r.tolerance, 3)}</td>
                <td className="pr-2 text-right">{f(r.z ?? 0, 2)}</td>
                <td className="text-right font-bold">{f(r.score)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {shownRatios.length === 0 && <p className="text-2xs text-ink-400 py-2">Every proportion is within 1σ of its ideal.</p>}
      </div>

      </Section>
      <Section title="Asymmetry & mesh">
      <div className="grid md:grid-cols-2 gap-3">
        <div className="space-y-1">
          <div className="text-2xs font-semibold text-ink-600">Largest bilateral deviations</div>
          {g.worstPairs.map((p) => (
            <div key={p.right} className="flex justify-between font-mono text-2xs text-ink-600">
              <span>#{p.right} ↔ #{p.left} ({p.region})</span>
              <span>{f(p.asymmetry * 100, 2)}% IPD</span>
            </div>
          ))}
        </div>
        {opt.showMeshPlot && <MeshPlot points={g.frontalMesh} />}
      </div>
      </Section>
      </div>
      {!g.reliable && <p className="text-2xs text-warning-700">{g.reliabilityNote}</p>}
    </div>
  );
}
