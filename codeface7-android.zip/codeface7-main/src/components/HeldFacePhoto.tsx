import { useEffect, useRef, useState } from 'react';
import type { DetectedFace } from '@/lib/types';

interface Props {
  src: string;
  alt: string;
  name?: string;
  faces?: DetectedFace[];
  className?: string;
  imageClassName?: string;
  onClick?: () => void;
}

/** Original image-space measurements only; never project the frontalised plot onto a photo. */
export default function HeldFacePhoto({ src, alt, name, faces = [], className = '', imageClassName = '', onClick }: Props) {
  const [held, setHeld] = useState(false);
  const [size, setSize] = useState({ width: 0, height: 0 });
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const origin = useRef<{ x: number; y: number; id: number } | null>(null);
  const suppressClick = useRef(false);
  const wrapper = useRef<HTMLDivElement>(null);
  const points = faces.flatMap(face => face.meshLandmarks ?? []);

  const cancel = () => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = null;
    origin.current = null;
    setHeld(false);
  };

  useEffect(() => {
    window.addEventListener('pointerup', cancel);
    window.addEventListener('pointercancel', cancel);
    window.addEventListener('blur', cancel);
    return () => {
      if (timer.current) clearTimeout(timer.current);
      window.removeEventListener('pointerup', cancel);
      window.removeEventListener('pointercancel', cancel);
      window.removeEventListener('blur', cancel);
    };
  }, [src]);

  return (
    <div ref={wrapper} className={`relative select-none ${className}`}
      onPointerDown={event => {
        if (event.button !== 0 || origin.current) { cancel(); return; }
        suppressClick.current = false;
        if (wrapper.current) wrapper.current.dataset.heldPhoto = 'false';
        if (!points.length) return;
        origin.current = { x: event.clientX, y: event.clientY, id: event.pointerId };
        timer.current = setTimeout(() => {
          suppressClick.current = true;
          if (wrapper.current) wrapper.current.dataset.heldPhoto = 'true';
          setHeld(true);
        }, 350);
      }}
      onPointerMove={event => {
        const start = origin.current;
        if (start && (start.id !== event.pointerId || Math.hypot(event.clientX - start.x, event.clientY - start.y) > 10)) cancel();
      }}
      onPointerUp={cancel} onPointerCancel={cancel} onPointerLeave={cancel}
      onContextMenu={event => event.preventDefault()}
      onClickCapture={event => {
        if (suppressClick.current) { event.preventDefault(); event.stopPropagation(); }
      }}
      onClick={onClick}
    >
      <img src={src} alt={alt} data-search-label={name ?? ''} draggable={false}
        className={`block select-none [-webkit-touch-callout:none] ${imageClassName}`}
        onLoad={event => setSize({ width: event.currentTarget.naturalWidth, height: event.currentTarget.naturalHeight })} />
      {held && size.width > 0 && size.height > 0 && (
        <svg aria-label={`${points.length} detected face landmarks`} className="absolute inset-0 w-full h-full pointer-events-none text-primary-600"
          viewBox={`0 0 ${size.width} ${size.height}`} preserveAspectRatio="xMidYMid meet">
          {points.map((point, index) => <circle key={index} cx={point.x * size.width} cy={point.y * size.height}
            r={Math.max(size.width, size.height) / 700} fill="currentColor" />)}
        </svg>
      )}
    </div>
  );
}