import PhotoHeading from './PhotoHeading';
import { Button } from './ui/button';
import { useState } from 'react';
import { ArrowLeft, GitCompare, Download, Users, Maximize2, Sparkles, Loader2 } from 'lucide-react';
import PhotoViewer from './PhotoViewer';
import type { AnalysisResult, DetectedFace, TasteMatch } from '@/lib/types';
import TasteMatchCard from './TasteMatchCard';
import AiLookCard from './AiLookCard';
import FaceZoneMap from './FaceZoneMap';
import DrawingGuide from './DrawingGuide';
import BodyRatingCard from './BodyRatingCard';
import type { BodyKey } from '@/lib/bodyTeaching';
import { haptic } from '@/lib/haptics';
import ScoreDisplay from './ScoreDisplay';
import MetricsPanel from './MetricsPanel';
import WarningBanner from './WarningBanner';
import StarRating from './StarRating';
import FaceCategories from './FaceCategories';
import type { FaceCategory } from '@/lib/types';
import HeldFacePhoto from './HeldFacePhoto';
import GeometryBreakdown from './GeometryBreakdown';
import ErrorBoundary from './ErrorBoundary';
import DisplayOptions from './DisplayOptions';
import { WeightedScore, FolderPicker } from './CollectionTools';

interface FaceSelectionData {
  faces: DetectedFace[];
  selectedIndex: number;
  onSelect: (index: number) => void;
}

interface ResultsViewProps {
  onAiCheck?: () => void;
  aiBusy?: boolean;
  result: AnalysisResult;
  onReset: () => void;
  /** Label for the back/reset button (e.g. "Back to History"). */
  resetLabel?: string;
  onAddToCompare: () => void;
  onRate: (imageId: string, rating: number) => void;
  currentRating?: number;
  onCategories?: (values: FaceCategory[], partly?: FaceCategory[]) => void;
  onWayOff?: () => void;
  wayOffBusy?: boolean;
  onRateBody?: () => void;
  onUserBody?: (values: Record<BodyKey, number>) => void;
  bodyBusy?: boolean;
  onExport: () => void;
  faceData?: FaceSelectionData;
  tasteMatch?: TasteMatch;
  ratingsCount?: number;
  photoNames?: Map<string, string>;
}

export default function ResultsView({ result, onAiCheck, aiBusy, onReset, onAddToCompare, onRate, currentRating, onCategories, onWayOff, wayOffBusy, onRateBody, onUserBody, bodyBusy, onExport, faceData, tasteMatch, ratingsCount = 0, resetLabel, photoNames }: ResultsViewProps) {
  const [viewerOpen, setViewerOpen] = useState(false);
  return (
    <div className="space-y-4 animate-fade-in">
      {/* Action bar */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h2 className="text-lg font-display font-semibold text-ink-900">Analysis Results</h2>
        <div className="flex items-center gap-2">
          <button onClick={onExport} className="btn-secondary">
            <Download className="w-4 h-4" />
            <span>Export</span>
          </button>
          <button onClick={onAddToCompare} className="btn-secondary">
            <GitCompare className="w-4 h-4" />
            <span>Add to Compare</span>
          </button>
          <Button variant="outline" onClick={onReset}><ArrowLeft /><span>{resetLabel ?? 'Back'}</span></Button>
        </div>
      </div>

      <DisplayOptions />

      {/* Warnings */}
      <WarningBanner warnings={result.warnings} />

      {/* Main result layout */}
      <div className="grid lg:grid-cols-2 gap-4">
        {/* Image with overlay */}
        <ErrorBoundary label="Image visualization">
          <div className="card p-4 space-y-3">
            <PhotoHeading name={result.searchLabel} />
            <div className="relative rounded-xl overflow-hidden">
              <HeldFacePhoto src={result.imageUrl} alt="Analyzed" name={result.searchLabel}
                faces={result.faceDetection.faces} onClick={() => setViewerOpen(true)}
                imageClassName="w-full max-h-[500px] object-contain rounded-xl bg-ink-50" />
              <button type="button" aria-label="Full screen" onClick={() => setViewerOpen(true)} className="absolute top-2 right-2 p-2 rounded-full bg-white/90 text-ink-700 shadow z-10"><Maximize2 className="w-4 h-4" /></button>
            </div>
            {viewerOpen && <PhotoViewer items={[{ id: result.id, src: result.imageUrl, name: result.searchLabel, faces: result.faceDetection.faces }]} index={0} onClose={() => setViewerOpen(false)} />}
            {/* Multi-face selector */}
            {faceData && faceData.faces.length > 1 && (
              <div className="flex items-center gap-2 p-3 rounded-xl bg-primary-50/50">
                <Users className="w-4 h-4 text-primary-500 flex-shrink-0" />
                <span className="text-2xs text-ink-600 font-medium">Primary subject:</span>
                <div className="flex gap-1.5 ml-auto">
                  {faceData.faces.map((f) => (
                    <button
                      key={f.index}
                      onClick={() => { haptic('selection'); faceData.onSelect(f.index); }}
                      className={`px-3 py-1.5 rounded-lg text-2xs font-medium transition-all min-h-[36px] ${
                        faceData.selectedIndex === f.index
                          ? 'bg-primary-500 text-white shadow-glow-primary'
                          : 'bg-ink-100 text-ink-600 hover:bg-ink-200'
                      }`
                      }
                    >
                      Face {f.index + 1}
                    </button>
                  ))}
                </div>
              </div>
            )}
            <StarRating imageId={result.imageId} initialRating={currentRating} onRate={onRate} />
            {result.faceDetection.detected && <FaceCategories scores={result.scores} onChange={onCategories} />}
            <div className="flex items-center justify-end">
              <span className="text-2xs text-ink-400 font-mono">
                {result.duration.toFixed(0)}ms · {result.faceDetection.detected ? `${result.faceDetection.faceCount} face(s)` : 'no face'}
              </span>
            </div>
          </div>
        </ErrorBoundary>

        {/* Score + metrics */}
        <div className="space-y-4">
          <ErrorBoundary label="Score display">
            <div className="card p-6 flex flex-col items-center">
              <ScoreDisplay scores={result.scores} size="lg" weighted />
              <WeightedScore scores={result.scores} detailsOnly />
            </div>
          </ErrorBoundary>
          <ErrorBoundary label="AI look check">
            {onAiCheck && !result.scores.aiLook && <Button variant="outline" disabled={aiBusy} onClick={onAiCheck} className="w-full min-h-11">{aiBusy ? <Loader2 className="animate-spin" /> : <Sparkles />}{aiBusy ? 'Checking photo…' : result.scores.aiLookError ? 'Retry AI check' : 'AI check this photo'}</Button>}
            <AiLookCard scores={result.scores} onWayOff={result.faceDetection.detected ? onWayOff : undefined} busy={wayOffBusy} />
            {result.faceDetection.detected && (
              <FaceZoneMap src={result.imageUrl}
                face={result.faceDetection.faces.find(f => f.isPrimary) ?? result.faceDetection.faces[0]} />
            )}
          </ErrorBoundary>
          <ErrorBoundary label="Draw">
            <DrawingGuide src={result.imageUrl}
              face={result.faceDetection.faces.find(f => f.isPrimary) ?? result.faceDetection.faces[0]} />
          </ErrorBoundary>
          <ErrorBoundary label="Body rating">
            <BodyRatingCard key={result.id} scores={result.scores} onRate={onRateBody} busy={bodyBusy} onUserRate={onUserBody} />
          </ErrorBoundary>
          <ErrorBoundary label="Taste match">
            <TasteMatchCard match={tasteMatch} ratingsCount={ratingsCount} photoNames={photoNames} />
          </ErrorBoundary>
          <ErrorBoundary label="Metrics panel">
            <div className="card p-4 space-y-3">
              <h3 className="text-sm font-semibold text-ink-800">Aesthetic Metrics <span className="font-normal text-2xs text-ink-400">· face measurements incl. skin &amp; age</span></h3>
              <MetricsPanel metrics={result.scores.metrics} geometry={result.faceDetection.geometry} />
            </div>
          </ErrorBoundary>
        </div>
      </div>

      {result.faceDetection.geometry && (
        <ErrorBoundary label="Geometry breakdown">
          <GeometryBreakdown geometry={result.faceDetection.geometry} />
        </ErrorBoundary>
      )}

      {/* Save to folder — last, after the analysis itself */}
      <FolderPicker analysisId={result.id} />
    </div>
  );
}
