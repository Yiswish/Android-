import PhotoHeading from './PhotoHeading';
import { useState } from 'react';
import { ImageOff, Loader2, ChevronDown } from 'lucide-react';
import type { SearchResultImage } from '@/lib/types';

interface ImageGridProps {
  images: SearchResultImage[];
  onImageSelect: (image: SearchResultImage) => void;
  selectedImageId?: string;
  onLoadMore?: () => void;
  hasMore?: boolean;
  loadingMore?: boolean;
  totalCount?: number;
  tasteScores?: Map<string, number>;
  scores?: Map<string, number>;
}

function ImageCard({
  image,
  onSelect,
  isSelected,
  taste,
  score,
  index = 0,
}: {
  taste?: number;
  score?: number;
  image: SearchResultImage;
  onSelect: (img: SearchResultImage) => void;
  isSelected: boolean;
  index?: number;
}) {
  const [errored, setErrored] = useState(false);
  const [loaded, setLoaded] = useState(false);

  if (errored) {
    return (
      <div className="aspect-[3/4] rounded-xl bg-ink-100 flex flex-col items-center justify-center gap-2 text-ink-400 ring-1 ring-ink-200">
        <ImageOff className="w-8 h-8 opacity-50" />
        <span className="text-2xs">Image unavailable</span>
        {image.source !== 'curated' && (
          <span className="text-2xs text-ink-300 capitalize">{image.source}</span>
        )}
      </div>
    );
  }

  return (
    <button
      onClick={() => onSelect(image)}
      style={{ animationDelay: `${Math.min(index, 12) * 45}ms` }}
      className={`group relative w-full aspect-[3/4] rounded-xl overflow-hidden transition-all duration-300 animate-fade-stagger ${
        isSelected
          ? 'ring-2 ring-primary-500 ring-offset-2 ring-offset-white scale-[0.97] shadow-glow-primary'
          : 'ring-1 ring-ink-200 hover:ring-primary-300 hover:scale-[1.02] hover:shadow-glass-lg'
      }`}
    >
      {!loaded && (
        <div className="absolute inset-0 bg-ink-100 animate-pulse flex items-center justify-center">
          <Loader2 className="w-5 h-5 text-ink-300 animate-spin" />
        </div>
      )}
      <img
        src={image.thumbUrl}
        alt={image.alt}
        loading="lazy"
        onLoad={() => setLoaded(true)}
        onError={() => setErrored(true)}
        className={`w-full h-full object-cover transition-opacity duration-300 ${loaded ? 'opacity-100' : 'opacity-0'}`}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      <div className="absolute bottom-0 left-0 right-0 p-3 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-2 group-hover:translate-y-0">
        <p className="text-white text-2xs font-medium truncate">{image.alt}</p>
        <div className="flex items-center gap-1 mt-1">
          <span className="badge text-[0.625rem] capitalize" style={{
            background: image.source === 'pinterest' ? 'rgba(239,68,68,0.25)' : 'rgba(45,156,255,0.25)',
            color: image.source === 'pinterest' ? '#fca5a5' : '#93c5fd',
          }}>
            {image.source}
          </span>
          {image.orientation && (
            <span className="text-2xs text-white/60 capitalize">{image.orientation}</span>
          )}
        </div>
      </div>
      {(taste !== undefined || score !== undefined) && (
        <span className="absolute top-2 left-2 flex flex-col items-start gap-1">
          {score !== undefined && <span className="badge badge-primary text-2xs">Score {score}</span>}
          {taste !== undefined && <span className="badge badge-secondary text-2xs">Taste {taste}</span>}
        </span>
      )}
      {/* Quick-analyze indicator on hover */}
      <div className="absolute top-2 right-2 w-8 h-8 rounded-full bg-white/80 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 transform scale-50 group-hover:scale-100">
        <svg className="w-4 h-4 text-primary-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
        </svg>
      </div>
    </button>
  );
}

export default function ImageGrid({
  images,
  onImageSelect,
  selectedImageId,
  onLoadMore,
  hasMore,
  loadingMore,
  totalCount,
  tasteScores,
  scores,
}: ImageGridProps) {
  if (images.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-ink-400 space-y-2">
        <ImageOff className="w-12 h-12 opacity-30" />
        <p className="text-sm">No images found. Try a different search term or adjust filters.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {totalCount !== undefined && (
        <div className="flex items-center justify-between">
          <p className="text-2xs text-ink-400">
            {totalCount > 0 ? `Showing ${images.length} of ${totalCount} images` : `Showing ${images.length} images`}
          </p>
        </div>
      )}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {images.map((image, i) => (
          <div key={image.id} className="min-w-0 space-y-2"><PhotoHeading name={image.searchLabel} /><ImageCard
            index={i}
            image={image}
            onSelect={onImageSelect}
            isSelected={selectedImageId === image.id}
            taste={tasteScores?.get(image.url)}
            score={scores?.get(image.url)}
          /></div>
        ))}
      </div>

      {hasMore && onLoadMore && (
        <div className="flex justify-center pt-4">
          <button
            onClick={onLoadMore}
            disabled={loadingMore}
            className="btn-primary disabled:opacity-50 group"
          >
            {loadingMore ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Loading more...</span>
              </>
            ) : (
              <>
                <ChevronDown className="w-4 h-4 group-hover:animate-bounce-subtle" />
                <span>Load More Images</span>
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
}
