import PhotoHeading from './PhotoHeading';
import { useState, useRef, useCallback, useEffect } from 'react';
import { GitCompare, X, SlidersHorizontal, Plus, Trash2, Search, Trophy } from 'lucide-react';
import { scoreLabel } from '@/lib/scoring';
import type { ComparisonItem, MetricKey } from '@/lib/types';
import { METRIC_KEYS, METRIC_LABELS } from '@/lib/metricKeys';

interface ComparisonViewProps {
  items: ComparisonItem[];
  onRemove: (id: string) => void;
  onAddMore: () => void;
  onClear: () => void;
}

type ViewMode = 'cards' | 'slider' | 'matrix';

const metricKeys: MetricKey[] = METRIC_KEYS;
const metricLabels: Record<MetricKey, string> = METRIC_LABELS;

const winnerId = (items: ComparisonItem[]) => {
  if (items.length < 2) return undefined;
  const top = [...items].sort((a, b) => b.result.scores.overall - a.result.scores.overall);
  return top[0].result.scores.overall > top[1].result.scores.overall ? top[0].result.id : undefined;
};
const metricOf = (item: ComparisonItem, key: MetricKey) => {
  const v = item.result.scores.metrics?.[key];
  return typeof v === 'number' && Number.isFinite(v) ? Math.round(v) : undefined;
};

// ============================================================================
// SIDE-BY-SIDE SLIDER — Interactive image comparison
// ============================================================================
function SliderComparison({ items, onRemove }: { items: ComparisonItem[]; onRemove: (id: string) => void }) {
  const [sliderPos, setSliderPos] = useState(50);
  const [containerWidth, setContainerWidth] = useState(600);
  const containerRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const update = () => setContainerWidth(el.clientWidth);
    update();
    const observer = new ResizeObserver(update);
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const handleMove = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const pct = ((clientX - rect.left) / rect.width) * 100;
    setSliderPos(Math.max(0, Math.min(100, pct)));
  }, []);

  const start = (x: number) => { isDragging.current = true; handleMove(x); };
  const stop = () => { isDragging.current = false; };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    const step = e.shiftKey ? 10 : 2;
    if (e.key === 'ArrowLeft') { setSliderPos((p) => Math.max(0, p - step)); e.preventDefault(); }
    if (e.key === 'ArrowRight') { setSliderPos((p) => Math.min(100, p + step)); e.preventDefault(); }
    if (e.key === 'Home') { setSliderPos(0); e.preventDefault(); }
    if (e.key === 'End') { setSliderPos(100); e.preventDefault(); }
  };

  if (items.length < 2) {
    return <div className="card p-6 text-center text-sm text-ink-500">Add at least 2 images to use the slider comparison.</div>;
  }

  const left = items[0];
  const right = items[1];
  const diff = left.result.scores.overall - right.result.scores.overall;
  const verdict = diff === 0 ? 'Tied overall' : `${diff > 0 ? 'Left' : 'Right'} photo leads by ${Math.abs(diff)} ${Math.abs(diff) === 1 ? 'point' : 'points'}`;

  const chip = (item: ComparisonItem, side: string, lead: boolean) => (
    <div className={`flex items-center gap-1 rounded-full pl-3 pr-1 py-1 text-2xs font-medium ${lead ? 'bg-success-50 text-success-700 ring-1 ring-success-200' : 'bg-ink-100 text-ink-600'}`}>
      <span>{item.result.searchLabel ?? side} · {item.result.scores.overall}</span>
      <button onClick={() => onRemove(item.result.id)} className="p-1 rounded-full hover:bg-ink-200/60" aria-label={`Remove ${item.label} from comparison`}><X className="w-3 h-3" /></button>
    </div>
  );

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-2">
        {chip(left, 'Left', diff > 0)}
        <span className="text-2xs font-semibold text-ink-500 text-center">{verdict}</span>
        {chip(right, 'Right', diff < 0)}
      </div>

      <div
        ref={containerRef}
        className="relative w-full aspect-[3/4] max-h-[70vh] rounded-2xl overflow-hidden cursor-ew-resize select-none touch-none ring-1 ring-ink-200"
        onMouseDown={(e) => start(e.clientX)}
        onMouseUp={stop}
        onMouseLeave={stop}
        onMouseMove={(e) => { if (isDragging.current) handleMove(e.clientX); }}
        onTouchStart={(e) => start(e.touches[0].clientX)}
        onTouchEnd={stop}
        onTouchMove={(e) => { if (isDragging.current) handleMove(e.touches[0].clientX); }}
      >
        <img src={right.result.imageUrl} alt={right.label} className="absolute inset-0 w-full h-full object-cover" draggable={false} />
        <div className="absolute inset-0 overflow-hidden" style={{ width: `${sliderPos}%` }}>
          <img src={left.result.imageUrl} alt={left.label} className="absolute inset-0 h-full max-w-none object-cover" style={{ width: `${containerWidth}px` }} draggable={false} />
        </div>
        <div
          role="slider"
          tabIndex={0}
          aria-label="Comparison slider"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={Math.round(sliderPos)}
          onKeyDown={handleKeyDown}
          className="absolute top-0 bottom-0 w-0.5 -ml-px bg-white shadow-lg cursor-ew-resize focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-400"
          style={{ left: `${sliderPos}%` }}
        >
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-white shadow-glass-lg flex items-center justify-center">
            <SlidersHorizontal className="w-4 h-4 text-ink-600" />
          </div>
        </div>
        <div className="absolute bottom-3 left-3 glass-sm rounded-lg px-2 py-1">
          <span className="text-base font-bold text-ink-800">{left.result.scores.overall}</span>
          <span className="text-2xs text-ink-400">/100</span>
        </div>
        <div className="absolute bottom-3 right-3 glass-sm rounded-lg px-2 py-1">
          <span className="text-base font-bold text-ink-800">{right.result.scores.overall}</span>
          <span className="text-2xs text-ink-400">/100</span>
        </div>
      </div>

      <div className="card p-3 space-y-2">
        {metricKeys.map((key) => {
          const a = metricOf(left, key), b = metricOf(right, key);
          if (a === undefined && b === undefined) return null;
          return (
            <div key={key} className="grid grid-cols-[2.5rem_1fr_2.5rem] items-center gap-2">
              <span className={`text-xs font-mono text-left ${a !== undefined && b !== undefined && a > b ? 'font-bold text-success-600' : 'text-ink-500'}`}>{a ?? '–'}</span>
              <span className="text-2xs text-ink-600 text-center">{metricLabels[key]}</span>
              <span className={`text-xs font-mono text-right ${a !== undefined && b !== undefined && b > a ? 'font-bold text-success-600' : 'text-ink-500'}`}>{b ?? '–'}</span>
            </div>
          );
        })}
      </div>
      <p className="text-2xs text-ink-400 text-center">Drag the line or use arrow keys to compare</p>
    </div>
  );
}

// ============================================================================
// COMPARISON MATRIX — Metric-by-metric table
// ============================================================================
function MatrixComparison({ items, onRemove }: { items: ComparisonItem[]; onRemove: (id: string) => void }) {
  if (items.length === 0) return null;
  const best = winnerId(items);

  const row = (label: string, values: Array<number | undefined>, strong = false) => {
    const finite = values.filter((v): v is number => v !== undefined);
    const max = finite.length ? Math.max(...finite) : undefined;
    const unique = finite.filter((v) => v === max).length === 1;
    return (
      <tr key={label} className={`border-b border-ink-100 ${strong ? 'bg-ink-50/40' : ''}`}>
        <td className={`py-2.5 px-3 sticky left-0 bg-white z-10 ${strong ? 'text-sm font-semibold text-ink-800' : 'text-xs font-medium text-ink-600'}`}>{label}</td>
        {values.map((val, i) => {
          const isMax = val !== undefined && val === max && unique && items.length > 1;
          return (
            <td key={items[i].result.id} className="text-center py-2.5 px-2">
              <div className="flex flex-col items-center gap-1">
                <span className={`font-mono ${strong ? 'text-base font-bold' : 'text-sm'} ${isMax ? 'text-success-600 font-bold' : 'text-ink-600'}`}>{val ?? '–'}{isMax && strong ? ' ★' : ''}</span>
                {!strong && (
                  <div className="h-1.5 w-14 bg-ink-100 rounded-full overflow-hidden">
                    <div className={`h-full rounded-full ${isMax ? 'bg-success-500' : 'bg-primary-300'}`} style={{ width: `${val ?? 0}%` }} />
                  </div>
                )}
              </div>
            </td>
          );
        })}
      </tr>
    );
  };

  return (
    <div className="card p-3 overflow-x-auto">
      <table className="w-full text-sm border-collapse">
        <thead>
          <tr className="border-b border-ink-200">
            <th className="text-left py-2 px-3 text-2xs font-semibold text-ink-500 uppercase tracking-wide sticky left-0 bg-white z-10 align-bottom">Metric</th>
            {items.map((item) => (
              <th key={item.result.id} className="text-center py-2 px-2 min-w-[84px] align-bottom">
                <div className="flex flex-col items-center gap-1">
                  <PhotoHeading name={item.result.searchLabel} className="text-xs max-w-32" />
                  <div className="relative">
                    <img src={item.result.thumbUrl ?? item.result.imageUrl} alt="" className={`w-12 h-14 rounded-lg object-cover ${item.result.id === best ? 'ring-2 ring-success-500' : 'ring-1 ring-ink-200'}`} />
                    <button onClick={() => onRemove(item.result.id)} className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-white shadow ring-1 ring-ink-200 flex items-center justify-center" aria-label={`Remove ${item.label} from comparison`}>
                      <X className="w-3 h-3 text-ink-500" />
                    </button>
                  </div>
                  <span className="text-2xs font-medium text-ink-500 truncate max-w-[84px]">{item.label}</span>
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {row('Overall', items.map((i) => i.result.scores.overall), true)}
          {metricKeys.map((key) => row(metricLabels[key], items.map((i) => metricOf(i, key))))}
        </tbody>
      </table>
      <p className="text-2xs text-ink-400 text-center pt-2">Green marks the best value in each row</p>
    </div>
  );
}

// ============================================================================
// CARD VIEW — Individual cards side by side
// ============================================================================
function CardComparison({ items, onRemove }: { items: ComparisonItem[]; onRemove: (id: string) => void }) {
  const best = winnerId(items);
  const maxOf = (key: MetricKey) => {
    const vals = items.map((i) => metricOf(i, key)).filter((v): v is number => v !== undefined);
    return vals.length > 1 ? Math.max(...vals) : undefined;
  };
  return (
    <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
      {items.map((item) => {
        const isBest = item.result.id === best;
        return (
          <div key={item.result.id} className={`card p-0 overflow-hidden animate-scale-in ${isBest ? 'ring-2 ring-success-500' : ''}`}>
            <PhotoHeading name={item.result.searchLabel} className="px-3 py-2" />
            <div className="relative aspect-[4/5]">
              <img src={item.result.imageUrl} alt={item.label} className="absolute inset-0 w-full h-full object-cover" />
              <button onClick={() => onRemove(item.result.id)} className="absolute top-2 right-2 w-7 h-7 rounded-full glass-sm flex items-center justify-center" aria-label={`Remove ${item.label} from comparison`}><X className="w-3.5 h-3.5 text-ink-700" /></button>
              {isBest && <span className="absolute top-2 left-2 rounded-full bg-success-500 px-2 py-0.5 text-2xs font-semibold text-white flex items-center gap-1"><Trophy className="w-3 h-3" />Best</span>}
              <div className="absolute bottom-2 left-2 glass-sm rounded-lg px-2 py-1">
                <span className="text-lg font-bold text-ink-800">{item.result.scores.overall}</span>
                <span className="text-2xs text-ink-400">/100</span>
                <span className="block text-2xs text-ink-500 -mt-0.5">{scoreLabel(item.result.scores.overall)}</span>
              </div>
            </div>
            <div className="p-3 space-y-2">
              {metricKeys.map((key) => {
                const v = metricOf(item, key);
                if (v === undefined) return null;
                const top = v === maxOf(key);
                return (
                  <div key={key} className="space-y-0.5">
                    <div className="flex items-center justify-between gap-1">
                      <span className="text-2xs text-ink-500 truncate">{metricLabels[key]}</span>
                      <span className={`text-2xs font-mono ${top ? 'font-bold text-success-600' : 'text-ink-600'}`}>{v}</span>
                    </div>
                    <div className="h-1.5 bg-ink-100 rounded-full overflow-hidden">
                      <div className={`h-full rounded-full ${top ? 'bg-success-500' : 'bg-primary-400'}`} style={{ width: `${v}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ============================================================================
// MAIN COMPONENT
// ============================================================================
export default function ComparisonView({ items, onRemove, onAddMore, onClear }: ComparisonViewProps) {
  const [mode, setMode] = useState<ViewMode>('cards');
  const canSlider = items.length >= 2;

  if (items.length === 0) {
    return (
      <div className="card p-8 text-center space-y-3">
        <GitCompare className="w-10 h-10 text-ink-300 mx-auto" />
        <p className="text-sm text-ink-500">
          Analyze multiple images and add them here to compare side by side.
        </p>
        <button onClick={onAddMore} className="btn-primary mx-auto flex items-center gap-2">
          <Search className="w-4 h-4" />
          Find images to compare
        </button>
      </div>
    );
  }

  const modeButton = (id: ViewMode, label: string, disabled = false, hint?: string) => (
    <button
      onClick={() => !disabled && setMode(id)}
      aria-pressed={mode === id}
      disabled={disabled}
      title={hint}
      className={`px-3 py-1.5 rounded-lg text-2xs font-medium transition-all ${
        disabled
          ? 'text-ink-300 cursor-not-allowed'
          : mode === id
            ? 'bg-white text-ink-800 shadow-sm'
            : 'text-ink-500'
      }`}
    >
      {label}
    </button>
  );

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="flex items-center gap-1 p-1 rounded-xl bg-ink-100">
          {modeButton('cards', 'Cards')}
          {modeButton('slider', 'Slider', !canSlider, canSlider ? undefined : 'Needs at least 2 images')}
          {modeButton('matrix', 'Matrix')}
        </div>
        <span className="badge badge-primary">{items.length} {items.length === 1 ? 'item' : 'items'}</span>
        <div className="flex items-center gap-1 ml-auto">
          <button onClick={onAddMore} className="btn-ghost flex items-center gap-1 text-2xs">
            <Plus className="w-3.5 h-3.5" />
            Add
          </button>
          <button onClick={onClear} className="btn-ghost flex items-center gap-1 text-2xs text-ink-400 hover:text-danger-500">
            <Trash2 className="w-3.5 h-3.5" />
            Clear
          </button>
        </div>
      </div>

      {mode === 'cards' && <CardComparison items={items} onRemove={onRemove} />}
      {mode === 'slider' && (canSlider ? <SliderComparison items={items} onRemove={onRemove} /> : <CardComparison items={items} onRemove={onRemove} />)}
      {mode === 'matrix' && <MatrixComparison items={items} onRemove={onRemove} />}
    </div>
  );
}
