import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';

/** Gestures stay on one result; vertical movement always remains native scrolling. */
export default function BestResultRow({ children, first, onDelete, onRate }: {
  children: ReactNode; first: boolean; onDelete: () => void; onRate: () => void;
}) {
  const gesture = useRef<{ x: number; y: number; dx: number; dy: number; held: boolean } | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const releaseTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const [consumed, setConsumed] = useState(false);
  const clear = () => { clearTimeout(timer.current); timer.current = undefined; };
  useEffect(() => () => { clearTimeout(timer.current); clearTimeout(releaseTimer.current); }, []);
  const consume = () => {
    setConsumed(true);
    clearTimeout(releaseTimer.current);
    releaseTimer.current = setTimeout(() => setConsumed(false), 500);
  };
  return <li className={`card flex gap-3 items-center p-2.5 min-w-0 touch-pan-y select-none ${first ? 'ring-2 ring-primary-500' : ''}`}
    data-held-photo={consumed ? 'true' : undefined}
    onContextMenu={(event) => event.preventDefault()}
    onClickCapture={(event) => { if (consumed) { event.preventDefault(); event.stopPropagation(); } }}
    onPointerDown={(event) => {
      clear();
      if (!event.isPrimary || event.button !== 0) return;
      gesture.current = { x: event.clientX, y: event.clientY, dx: 0, dy: 0, held: false };
      timer.current = setTimeout(() => {
        const current = gesture.current;
        if (!current) return;
        current.held = true; consume(); onRate();
      }, 500);
    }}
    onPointerMove={(event) => {
      const current = gesture.current;
      if (!current) return;
      current.dx = event.clientX - current.x; current.dy = event.clientY - current.y;
      if (Math.hypot(current.dx, current.dy) > 10) clear();
    }}
    onPointerUp={() => {
      clear();
      const current = gesture.current; gesture.current = null;
      if (!current) return;
      if (current.held) consume();
      else if (current.dx >= 80 && current.dx > Math.abs(current.dy) * 1.5) { consume(); onDelete(); }
    }}
    onPointerCancel={() => { clear(); gesture.current = null; }}
    onPointerLeave={() => { clear(); gesture.current = null; }}
  >{children}</li>;
}