import { useEffect, useState } from 'react';
import type { MetricScores, MetricKey } from '@/lib/types';
import { clampScore } from '@/lib/metrics';
import type { FaceGeometryReport } from '@/lib/faceGeometry';
import { metricRawErrors, type RawError } from '@/lib/rawError';
import { useDisplaySettings } from '@/lib/displaySettings';
import { METRIC_KEYS } from '@/lib/metricKeys';

interface MetricsPanelProps {
  metrics: MetricScores;
  compact?: boolean;
  /** When given, the raw measurement error is shown beside each geometric score. */
  geometry?: FaceGeometryReport;
}

const metricInfo: Record<MetricKey, { label: string; color: string; gradient: string }> = {
  symmetry: { label: 'Symmetry', color: 'rgb(var(--p-500))', gradient: 'from-primary-400 to-primary-600' },
  proportions: { label: 'Golden Proportions', color: 'rgb(var(--p-400))', gradient: 'from-primary-300 to-primary-500' },
  structure: { label: 'Structural Balance', color: 'rgb(var(--p-700))', gradient: 'from-primary-500 to-primary-700' },
  skin: { label: 'Skin & age', color: 'rgb(var(--p-800))', gradient: 'from-primary-600 to-primary-800' },
  composition: { label: 'Composition', color: '#f97316', gradient: 'from-orange-400 to-orange-600' },
  lighting: { label: 'Lighting', color: '#f59e0b', gradient: 'from-amber-400 to-amber-600' },
  texture: { label: 'Image sharpness', color: '#8b5cf6', gradient: 'from-violet-400 to-violet-600' },
  contrast: { label: 'Contrast', color: '#ec4899', gradient: 'from-pink-400 to-pink-600' },
  naturalness: { label: 'Photo processing', color: '#22c55e', gradient: 'from-green-400 to-green-600' },
};

function getLevel(value: number): { label: string; opacity: string } {
  if (value >= 80) return { label: 'Excellent', opacity: '100%' };
  if (value >= 65) return { label: 'Strong', opacity: '90%' };
  if (value >= 50) return { label: 'Good', opacity: '80%' };
  if (value >= 35) return { label: 'Fair', opacity: '70%' };
  return { label: 'Low', opacity: '60%' };
}

function MetricBar({ metric, value, delay, compact, raw, infoOverride }: { metric?: MetricKey; value: number; delay: number; compact?: boolean; raw?: RawError; infoOverride?: { label: string; color: string } }) {
  const info = infoOverride ?? metricInfo[metric!];
  const clampedValue = clampScore(value);
  const [width, setWidth] = useState(0);
  const level = getLevel(clampedValue);

  useEffect(() => {
    const timer = setTimeout(() => setWidth(clampedValue), delay + 100);
    return () => clearTimeout(timer);
  }, [clampedValue, delay]);

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div
            className="w-2.5 h-2.5 rounded-full transition-transform hover:scale-125"
            style={{ background: info.color, boxShadow: `0 0 6px color-mix(in srgb, ${info.color} 38%, transparent)` }}
          />
          <span className="text-2xs font-medium text-ink-600">{info.label}</span>
          {!compact && (
            <span className="text-2xs text-ink-300 font-mono">{level.label}</span>
          )}
        </div>
        <span className="flex items-baseline gap-1.5">
          {raw && (
            <span className="font-mono text-2xs text-ink-500" title={raw.detail}>
              {raw.short}
            </span>
          )}
          <span className="font-mono text-xs font-bold" style={{ color: info.color }}>
            {clampedValue}
          </span>
        </span>
      </div>
      <div className="h-2.5 bg-ink-100 rounded-full overflow-hidden relative group">
        <div
          className="h-full rounded-full transition-all duration-700 ease-out relative"
          style={{
            width: `${width}%`,
            background: `linear-gradient(90deg, color-mix(in srgb, ${info.color} 65%, transparent), ${info.color})`,
            boxShadow: width > 0 ? `0 0 8px color-mix(in srgb, ${info.color} 25%, transparent)` : 'none',
          }}
        >
          <div className="absolute inset-0 shimmer rounded-full opacity-50" />
        </div>
      </div>
    </div>
  );
}

export default function MetricsPanel({ metrics, compact, geometry }: MetricsPanelProps) {
  const [settings] = useDisplaySettings();
  const keys = METRIC_KEYS.filter((k) => Number.isFinite(metrics[k]));
  const raws = settings.showRawError ? metricRawErrors(geometry) : {};
  const isCompact = compact || settings.compactMetrics;

  return (
    <div className={`grid gap-3 ${isCompact ? 'grid-cols-1' : 'grid-cols-1 sm:grid-cols-2'}`}>
      {keys.map((key, i) => (
        <MetricBar key={key} metric={key} value={metrics[key]} delay={i * 60} compact={isCompact} raw={raws[key]} />
      ))}
      {geometry && (['mouthJaw', 'alignment'] as const).map((id, i) => {
        const g = geometry.groups.find((x) => x.id === id);
        const meta = EXTRA_GROUPS[id];
        if (!g) {
          return geometry.viewMode === 'angled' ? (
            <p key={id} className="text-2xs text-ink-400">{meta.label}: not measured on an angled face</p>
          ) : null;
        }
        return <MetricBar key={id} value={g.score} delay={(keys.length + i) * 60} compact={isCompact} infoOverride={meta} />;
      })}
    </div>
  );
}

/** Face groups that count in the score but have no photo-metric key of their own. */
const EXTRA_GROUPS = {
  expression: { label: 'Expression', color: '#e11d48' },
  mouthJaw: { label: 'Mouth & jaw', color: '#0891b2' },
  alignment: { label: 'Alignment', color: '#4f46e5' },
} as const;
