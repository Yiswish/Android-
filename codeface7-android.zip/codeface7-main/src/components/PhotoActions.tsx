import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { Search, X } from 'lucide-react';
import { Button } from './ui/button';

/** Search only supplied text, never infer a name from the image or its alt text. */
export default function PhotoActions({ names, onSearch }: { names: Map<string, string>; onSearch: (name: string) => void }) {
  const [photo, setPhoto] = useState<{ src: string; name: string } | null>(null);
  const [expanded, setExpanded] = useState(false);
  const [name, setName] = useState('');
  useEffect(() => {
    const select = (event: MouseEvent) => {
      const target = event.target;
      if (!(target instanceof HTMLImageElement) || target.closest('[data-photo-actions], [data-photo-ghost], [data-held-photo="true"]')) return;
      const src = target.getAttribute('src') || target.currentSrc;
      if (!src) return;
      const label = (target.dataset.searchLabel ?? names.get(src) ?? '').trim();
      setPhoto({ src, name: label });
      setName(label);
      setExpanded(false);
    };
    document.addEventListener('click', select, true);
    return () => document.removeEventListener('click', select, true);
  }, [names]);
  if (!photo) return null;
  const search = () => {
    const query = name.trim();
    if (!query) return;
    setPhoto(null);
    // Close any existing photo viewer before the shared app search.
    window.dispatchEvent(new CustomEvent('photo-name-search'));
    onSearch(query);
  };
  return createPortal(
    <aside data-photo-actions aria-label="Selected photo search" className="fixed z-[250] bottom-[calc(5.5rem+env(safe-area-inset-bottom))] sm:bottom-5 left-4 right-4 sm:left-auto sm:w-80 rounded-lg border border-input bg-background text-foreground shadow-lg p-2.5 space-y-2">
      <div className="flex items-center gap-2 min-w-0">
        <img src={photo.src} alt="Selected photo" className="h-12 w-10 rounded-md object-cover shrink-0" />
        <Button size="sm" className="flex-1 min-w-0 h-auto min-h-10 whitespace-normal break-words" onClick={() => photo.name ? search() : setExpanded(true)}><Search />{photo.name ? `Search ${photo.name}` : 'Search by name'}</Button>
        <Button variant="ghost" size="icon" aria-label="Dismiss photo search" title="Dismiss" onClick={() => setPhoto(null)}><X /></Button>
      </div>
      {expanded && <form className="flex gap-2" onSubmit={(event) => { event.preventDefault(); search(); }}>
        <input autoFocus aria-label="Name to search" placeholder="Enter a name you know" value={name} onChange={(event) => setName(event.target.value)} className="min-w-0 flex-1 h-10 rounded-md border border-input bg-background px-3 text-base" />
        <Button type="submit" size="icon" className="h-10 w-10" disabled={!name.trim()} aria-label="Search entered name" title="Search"><Search /></Button>
      </form>}
    </aside>, document.body,
  );
}