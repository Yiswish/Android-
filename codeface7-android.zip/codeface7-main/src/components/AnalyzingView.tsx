import PhotoHeading from './PhotoHeading';
import { accentColor, useUserPrefs } from '@/lib/userPrefs';
import { Loader2, Scan, Sparkles, Brain, Eye, Palette, Sun, Shirt, Image as ImageIcon } from 'lucide-react';
import type { AnalysisLogEntry } from '@/lib/types';
import ScanningCanvas from './ScanningCanvas';

interface AnalyzingViewProps {
  imageUrl: string;
  searchLabel?: string;
  logs: AnalysisLogEntry[];
  progress: number;
  boundingBox?: { x: number; y: number; width: number; height: number };
}

const categoryConfig: Record<AnalysisLogEntry['category'], { color: string; bg: string; icon: typeof Scan; label: string }> = {
  detection: { color: 'text-primary-600', bg: 'bg-primary-50', icon: Scan, label: 'Detect' },
  landmarks: { color: 'text-secondary-600', bg: 'bg-secondary-50', icon: Eye, label: 'Landmarks' },
  expression: { color: 'text-accent-600', bg: 'bg-accent-50', icon: Sparkles, label: 'Expression' },
  pose: { color: 'text-purple-600', bg: 'bg-purple-50', icon: Brain, label: 'Pose' },
  lighting: { color: 'text-warning-600', bg: 'bg-warning-50', icon: Sun, label: 'Lighting' },
  aesthetic: { color: 'text-success-600', bg: 'bg-success-50', icon: Palette, label: 'Aesthetic' },
  preference: { color: 'text-pink-600', bg: 'bg-pink-50', icon: Sparkles, label: 'Preference' },
  composition: { color: 'text-primary-600', bg: 'bg-primary-50', icon: Brain, label: 'Composition' },
  color: { color: 'text-teal-600', bg: 'bg-teal-50', icon: Palette, label: 'Color' },
  background: { color: 'text-primary-700', bg: 'bg-primary-100', icon: ImageIcon, label: 'Background' },
  clothing: { color: 'text-orange-600', bg: 'bg-orange-50', icon: Shirt, label: 'Clothing' },
};

const phaseLabels: Array<{ threshold: number; label: string; icon: typeof Scan }> = [
  { threshold: 15, label: 'Initializing neural detection models...', icon: Scan },
  { threshold: 30, label: 'Scanning for faces and landmarks...', icon: Eye },
  { threshold: 50, label: 'Analyzing expression, pose & lighting...', icon: Sparkles },
  { threshold: 70, label: 'Detecting clothing, background & composition...', icon: Shirt },
  { threshold: 90, label: 'Computing aesthetic scores...', icon: Palette },
  { threshold: 100, label: 'Finalizing analysis report...', icon: Brain },
];

function getPhaseLabel(progress: number): string {
  for (let i = phaseLabels.length - 1; i >= 0; i--) {
    if (progress >= phaseLabels[i].threshold) return phaseLabels[i].label;
  }
  return phaseLabels[0].label;
}

export default function AnalyzingView({ imageUrl, searchLabel, logs, progress, boundingBox }: AnalyzingViewProps) {
  useUserPrefs(); // re-render when the theme colour changes
  return (
    <div className="grid lg:grid-cols-2 gap-6 animate-fade-in">
      {/* Scanning visualization */}
      <div className="card p-6 space-y-4">
        <div className="flex items-center gap-3">
          <div className="relative">
            <Scan className="w-5 h-5 text-primary-500 animate-pulse" />
            <div className="absolute inset-0 animate-ping opacity-30">
              <Scan className="w-5 h-5 text-primary-500" />
            </div>
          </div>
          <h3 className="text-base font-semibold text-ink-800">Analyzing Image</h3>
          <div className="ml-auto flex items-center gap-2">
            <div className="relative w-10 h-10">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 40 40">
                <circle cx="20" cy="20" r="16" fill="none" stroke="#e2e8f0" strokeWidth="3" />
                <circle
                  cx="20" cy="20" r="16" fill="none" stroke={accentColor(500)} strokeWidth="3"
                  strokeLinecap="round"
                  strokeDasharray={`${(progress / 100) * 2 * Math.PI * 16} ${2 * Math.PI * 16}`}
                  style={{ transition: 'stroke-dasharray 0.3s ease-out' }}
                />
              </svg>
              <span className="absolute inset-0 flex items-center justify-center text-2xs font-bold text-primary-600">
                {progress}%
              </span>
            </div>
          </div>
        </div>

        <PhotoHeading name={searchLabel} />
        <ScanningCanvas imageUrl={imageUrl} active={progress < 100} boundingBox={boundingBox} logs={logs} />

        {/* Progress bar with gradient */}
        <div className="space-y-2">
          <div className="h-2.5 bg-ink-100 rounded-full overflow-hidden relative">
            <div
              className="h-full bg-gradient-primary transition-all duration-500 ease-out rounded-full relative"
              style={{ width: `${progress}%` }}
            >
              <div className="absolute inset-0 shimmer rounded-full" />
            </div>
          </div>
          <div className="flex items-center justify-center gap-2 text-ink-500 text-sm">
            <Loader2 className="w-3.5 h-3.5 animate-spin text-primary-400" />
            <span className="animate-fade-in">{getPhaseLabel(progress)}</span>
          </div>
        </div>

        {/* Phase indicators */}
        <div className="flex items-center justify-between px-1">
          {phaseLabels.map((phase, i) => {
            const isActive = progress >= phase.threshold;
            const Icon = phase.icon;
            return (
              <div
                key={i}
                className={`flex flex-col items-center gap-1 transition-all duration-500 ${
                  isActive ? 'opacity-100' : 'opacity-30'
                }`}
              >
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center transition-all ${
                    isActive
                      ? 'bg-gradient-primary text-white scale-100 shadow-glow-primary'
                      : 'bg-ink-100 text-ink-400 scale-90'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                </div>
                <span className="text-2xs text-ink-400 font-mono">{phase.threshold}%</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Log panel — "What the Engine Sees" */}
      <div className="card p-6 space-y-3 flex flex-col">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-secondary-500" />
          <h3 className="text-base font-semibold text-ink-800">What the Engine Sees</h3>
          <span className="badge badge-secondary text-2xs ml-auto">{logs.length} steps</span>
        </div>

        <div className="h-[480px] overflow-y-auto space-y-2 scrollbar-hide pr-1">
          {logs.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-ink-400 space-y-3">
              <div className="relative">
                <Brain className="w-12 h-12 text-ink-200" />
                <div className="absolute inset-0 animate-ping opacity-20">
                  <Brain className="w-12 h-12 text-primary-300" />
                </div>
              </div>
              <p className="text-sm text-center">Waiting for analysis to begin...</p>
              <p className="text-2xs text-ink-300 text-center max-w-xs">
                The engine will output a step-by-step breakdown of everything it detects in the image.
              </p>
            </div>
          )}
          {logs.map((log) => {
            const config = categoryConfig[log.category];
            const Icon = config.icon;
            return (
              <div
                key={log.step}
                className="flex gap-3 p-3 rounded-xl bg-ink-50/50 hover:bg-ink-50 transition-colors animate-slide-in-right"
              >
                <div className="flex-shrink-0">
                  <div className={`w-8 h-8 rounded-lg ${config.bg} flex items-center justify-center`}>
                    <Icon className={`w-4 h-4 ${config.color}`} />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-2xs font-mono text-ink-300">#{log.step}</span>
                    <p className="text-sm font-medium text-ink-800">{log.label}</p>
                    {log.value && (
                      <span className={`badge text-2xs ${config.bg} ${config.color} ml-auto capitalize`}>
                        {log.value}
                      </span>
                    )}
                  </div>
                  <p className="text-2xs text-ink-500 mt-1 leading-relaxed">{log.detail}</p>
                  {log.confidence !== undefined && (
                    <div className="flex items-center gap-2 mt-1.5">
                      <span className="text-2xs text-ink-400 font-mono">Confidence</span>
                      <div className="h-1.5 flex-1 max-w-[80px] bg-ink-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-primary rounded-full transition-all duration-500"
                          style={{ width: `${log.confidence * 100}%` }}
                        />
                      </div>
                      <span className="text-2xs font-mono font-semibold text-ink-600">
                        {(log.confidence * 100).toFixed(0)}%
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
