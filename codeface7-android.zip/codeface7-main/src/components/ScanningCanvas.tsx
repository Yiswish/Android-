import { accentColor } from '@/lib/userPrefs';
import { useEffect, useRef } from 'react';

interface ScanningCanvasProps {
  imageUrl: string;
  active: boolean;
  boundingBox?: { x: number; y: number; width: number; height: number };
  logs?: Array<{ step: number; label: string; detail: string; value?: string }>;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
}

export default function ScanningCanvas({ imageUrl, active, boundingBox, logs }: ScanningCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);
  const particlesRef = useRef<Particle[]>([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Try the photo directly, then through our image relay, then without CORS (display only),
    // so the photo is always visible while it is analysed.
    const isRemote = /^https?:/i.test(imageUrl) && !imageUrl.startsWith(window.location.origin);
    const tries: Array<{ src: string; cors: boolean }> = [{ src: imageUrl, cors: true }];
    if (isRemote) {
      tries.push({ src: `/api/public/image-proxy?url=${encodeURIComponent(imageUrl)}`, cors: true });
      tries.push({ src: imageUrl, cors: false });
    }
    let cancelled = false;
    const load = (i: number) => {
      const t = tries[i];
      const img = new Image();
      if (t.cors) img.crossOrigin = 'anonymous';
      img.onload = () => {
        if (cancelled) return;
        imgRef.current = img;
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        ctx.drawImage(img, 0, 0);
      };
      img.onerror = () => {
        if (cancelled) return;
        if (i + 1 < tries.length) load(i + 1);
        else { canvas.width = 400; canvas.height = 400; }
      };
      img.src = t.src;
      if (i === 0) imgRef.current = img;
    };
    load(0);
    return () => { cancelled = true; };
  }, [imageUrl]);

  useEffect(() => {
    if (!active) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let frame = 0;
    let raf: number;

    const spawnParticle = (x: number, y: number) => {
      const angle = Math.random() * Math.PI * 2;
      const speed = 0.5 + Math.random() * 1.5;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: 0,
        maxLife: 30 + Math.random() * 20,
      });
      if (particlesRef.current.length > 80) particlesRef.current.shift();
    };

    const animate = () => {
      const img = imgRef.current;
      if (!img || !img.complete) {
        raf = requestAnimationFrame(animate);
        return;
      }

      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

      const scanY = (Math.sin(frame * 0.03) * 0.5 + 0.5) * canvas.height;

      // Scan line gradient glow
      const gradient = ctx.createLinearGradient(0, scanY - 30, 0, scanY + 30);
      gradient.addColorStop(0, accentColor(500, 0));
      gradient.addColorStop(0.5, accentColor(500, 0.18));
      gradient.addColorStop(1, accentColor(500, 0));
      ctx.fillStyle = gradient;
      ctx.fillRect(0, scanY - 30, canvas.width, 60);

      // Bright scan line
      ctx.strokeStyle = accentColor(500);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, scanY);
      ctx.lineTo(canvas.width, scanY);
      ctx.stroke();

      // Glow on scan line
      ctx.shadowColor = accentColor(500);
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.moveTo(0, scanY);
      ctx.lineTo(canvas.width, scanY);
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Grid overlay during scan
      ctx.strokeStyle = accentColor(500, 0.06);
      ctx.lineWidth = 1;
      const gridSize = 40;
      for (let gx = 0; gx <= canvas.width; gx += gridSize) {
        ctx.beginPath();
        ctx.moveTo(gx, 0);
        ctx.lineTo(gx, canvas.height);
        ctx.stroke();
      }
      for (let gy = 0; gy <= canvas.height; gy += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, gy);
        ctx.lineTo(canvas.width, gy);
        ctx.stroke();
      }

      // Spawn particles at scan line edges
      if (frame % 3 === 0) {
        spawnParticle(0, scanY);
        spawnParticle(canvas.width, scanY);
      }

      // Update and draw particles
      const particles = particlesRef.current;
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.life++;
        const alpha = 1 - p.life / p.maxLife;
        if (alpha <= 0) {
          particles.splice(i, 1);
          continue;
        }
        ctx.fillStyle = accentColor(700, alpha * 0.6);
        ctx.beginPath();
        ctx.arc(p.x, p.y, 1.5, 0, Math.PI * 2);
        ctx.fill();
      }

      // Bounding box with animated corners
      if (boundingBox) {
        const bx = boundingBox.x * canvas.width;
        const by = boundingBox.y * canvas.height;
        const bw = boundingBox.width * canvas.width;
        const bh = boundingBox.height * canvas.height;

        // Semi-transparent fill
        ctx.fillStyle = accentColor(700, 0.05);
        ctx.fillRect(bx, by, bw, bh);

        // Dashed border
        ctx.strokeStyle = accentColor(700);
        ctx.lineWidth = 3;
        ctx.setLineDash([8, 4]);
        ctx.lineDashOffset = -frame * 0.5;
        ctx.strokeRect(bx, by, bw, bh);
        ctx.setLineDash([]);
        ctx.lineDashOffset = 0;

        // Animated corner markers
        const cornerLen = 16;
        const pulse = Math.sin(frame * 0.08) * 0.3 + 0.7;
        ctx.lineWidth = 4;
        ctx.strokeStyle = accentColor(500, pulse);
        // top-left
        ctx.beginPath();
        ctx.moveTo(bx, by + cornerLen);
        ctx.lineTo(bx, by);
        ctx.lineTo(bx + cornerLen, by);
        ctx.stroke();
        // top-right
        ctx.beginPath();
        ctx.moveTo(bx + bw - cornerLen, by);
        ctx.lineTo(bx + bw, by);
        ctx.lineTo(bx + bw, by + cornerLen);
        ctx.stroke();
        // bottom-left
        ctx.beginPath();
        ctx.moveTo(bx, by + bh - cornerLen);
        ctx.lineTo(bx, by + bh);
        ctx.lineTo(bx + cornerLen, by + bh);
        ctx.stroke();
        // bottom-right
        ctx.beginPath();
        ctx.moveTo(bx + bw - cornerLen, by + bh);
        ctx.lineTo(bx + bw, by + bh);
        ctx.lineTo(bx + bw, by + bh - cornerLen);
        ctx.stroke();

        // Crosshair at center of bounding box
        const cx = bx + bw / 2;
        const cy = by + bh / 2;
        ctx.strokeStyle = accentColor(500, 0.4);
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(cx - 10, cy);
        ctx.lineTo(cx + 10, cy);
        ctx.moveTo(cx, cy - 10);
        ctx.lineTo(cx, cy + 10);
        ctx.stroke();
      }

      frame++;
      raf = requestAnimationFrame(animate);
    };

    raf = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(raf);
  }, [active, boundingBox]);

  return (
    <div className="relative w-full max-w-lg mx-auto">
      <canvas
        ref={canvasRef}
        className="w-full rounded-2xl ring-1 ring-primary-200/30"
        style={{ maxHeight: '500px', objectFit: 'contain' }}
      />
      {active && (
        <div className="scan-overlay rounded-2xl" />
      )}
      {active && logs && logs.length > 0 && (
        <div className="absolute bottom-0 left-0 right-0 rounded-b-2xl bg-ink-900/80 backdrop-blur-sm p-3 max-h-32 overflow-y-auto scrollbar-hide font-mono text-2xs space-y-0.5">
          {logs.slice(-4).map((log) => (
            <div key={log.step} className="text-primary-300 animate-fade-in leading-relaxed">
              <span className="text-ink-500">[{String(log.step).padStart(2, '0')}]</span>{' '}
              <span className="text-secondary-300">{log.label}</span>
              {log.value && <span className="text-accent-400"> → {log.value}</span>}
            </div>
          ))}
          <div className="text-primary-400 flex items-center gap-1">
            <span className="animate-pulse">▊</span>
          </div>
        </div>
      )}
    </div>
  );
}
