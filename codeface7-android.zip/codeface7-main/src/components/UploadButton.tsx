import { Upload, ImagePlus, Loader2 } from 'lucide-react';
import { useCallback, useRef, useState } from 'react';
import { haptic } from '@/lib/haptics';
import ImageCropModal from './ImageCropModal';

interface UploadButtonProps {
  onUpload: (file: File) => void;
}

export default function UploadButton({ onUpload }: UploadButtonProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [pendingFile, setPendingFile] = useState<File | null>(null);

  const handleFile = useCallback((file: File) => {
    if (!file || !file.type.startsWith('image/')) return;
    haptic('light');
    setPendingFile(file);
  }, []);

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    haptic('medium');
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const handleCropConfirm = useCallback((croppedFile: File) => {
    haptic('success');
    setPendingFile(null);
    setIsProcessing(true);
    onUpload(croppedFile);
    setTimeout(() => setIsProcessing(false), 800);
    if (inputRef.current) inputRef.current.value = '';
  }, [onUpload]);

  const handleCropCancel = useCallback(() => {
    haptic('light');
    setPendingFile(null);
    if (inputRef.current) inputRef.current.value = '';
  }, []);

  return (
    <>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        onChange={handleInputChange}
        className="hidden"
      />
      <button
        onClick={() => { haptic('selection'); inputRef.current?.click(); }}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        disabled={isProcessing}
        className={`btn-secondary relative overflow-hidden transition-all duration-300 ${
          isDragging
            ? 'ring-2 ring-primary-400 scale-105 shadow-glow-primary'
            : 'hover:scale-[1.02]'
        } ${isProcessing ? 'opacity-70' : ''}`}
      >
        {isProcessing ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin" />
            <span>Processing...</span>
          </>
        ) : isDragging ? (
          <>
            <Upload className="w-4 h-4 text-primary-500" />
            <span className="text-primary-600">Drop to upload</span>
          </>
        ) : (
          <>
            <ImagePlus className="w-4 h-4 transition-transform group-hover:scale-110" />
            <span>Upload Photo</span>
          </>
        )}
        {isDragging && (
          <div className="absolute inset-0 bg-primary-50/50 animate-pulse" />
        )}
      </button>

      {pendingFile && (
        <ImageCropModal
          file={pendingFile}
          onConfirm={handleCropConfirm}
          onCancel={handleCropCancel}
        />
      )}
    </>
  );
}
