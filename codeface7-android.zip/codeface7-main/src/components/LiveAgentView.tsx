import { useEffect, useRef } from 'react';
import { Crown, Loader2, Search, Ruler, Sparkles, Check, X } from 'lucide-react';
import type { FindBestProgress } from '@/lib/findBest';

const PHASES: Array<{ key: FindBestProgress['phase']; label: string; Icon: typeof Search }> = [
  { key: 'search', label: 'Search', Icon: Search },
  { key: 'measure', label: 'Measure', Icon: Ruler },
  { key: 'ai', label: 'AI check', Icon: Sparkles },
  { key: 'complete', label: 'Winner', Icon: Crown },
];

const STATUS_TEXT: Record<FindBestProgress['photos'][number]['status'], string> = {
  queued: 'Waiting', measuring: 'Measuring…', measured: 'Measured', checking: 'AI looking…',
  complete: 'AI checked', failed: 'Skipped', cancelled: 'Stopped',
};

/** Live, real-time view of the "Find the best" agent: phases, every candidate photo and a running log. */
export default function LiveAgentView({ progress: p, running }: { progress: FindBestProgress; running: boolean }) {
  const logRef = useRef<HTMLOListElement>(null);
  useEffect(() => { logRef.current?.scrollTo({ top: logRef.current.scrollHeight, behavior: 'smooth' }); }, [p.log.length]);
  const phaseIdx = PHASES.findIndex((x) => x.key === p.phase);
  const measuredCount = p.photos.filter((x) => x.score != null).length;

  return (
    <div className="space-y-3" data-testid="find-best-progress">
      <ol className="grid grid-cols-4 gap-1" aria-label="Agent steps">
        {PHASES.map(({ key, label, Icon }, i) => {
          const state = i < phaseIdx || p.phase === 'complete' ? 'done' : i === phaseIdx ? 'now' : 'next';
          return (
            <li key={key} className={`flex flex-col items-center gap-1 rounded-lg py-1.5 text-[11px] font-medium transition-colors ${state === 'now' ? 'bg-primary-50 text-primary-700' : state === 'done' ? 'text-primary-600' : 'text-ink-400'}`}>
              {state === 'now' && running ? <Loader2 className="w-4 h-4 animate-spin motion-reduce:animate-none" /> : <Icon className="w-4 h-4" />}
              {label}
            </li>
          );
        })}
      </ol>

      <p role="status" className="text-xs text-ink-500 leading-relaxed">
        Searches {p.searchesDone}/{p.searchesTotal} · {p.candidates} found · measured {measuredCount}/{p.selected || p.cap} · AI checks {p.aiChecks}/{p.topN}
        {p.activeQueries.length > 0 && <span className="block truncate">Now searching “{p.activeQueries.join('”, “')}”</span>}
      </p>

      {p.photos.length > 0 && (
        <ul className="grid grid-cols-3 sm:grid-cols-5 gap-2" aria-label="Candidate photos">
          {p.photos.map((ph, i) => {
            const leader = ph.image.id === p.leaderId;
            const busy = ph.status === 'measuring' || ph.status === 'checking';
            const dim = ph.status === 'failed' || ph.status === 'cancelled' || ph.status === 'queued';
            return (
              <li key={ph.image.id} className={`relative rounded-lg overflow-hidden border-2 transition-all duration-300 ${leader ? 'border-primary-500 shadow-md scale-[1.03]' : 'border-transparent'}`}>
                <div className="aspect-[3/4] bg-ink-100">
                  <img src={ph.image.thumbUrl || ph.image.url} data-search-label={ph.image.searchLabel ?? ''} alt={ph.image.alt} loading="lazy" className={`w-full h-full object-cover transition-opacity ${dim ? 'opacity-40' : 'opacity-100'}`} />
                </div>
                {busy && <div className="absolute inset-x-0 h-1/4 bg-gradient-to-b from-transparent via-primary-400/40 to-transparent animate-[scan_1.4s_ease-in-out_infinite] motion-reduce:hidden" style={{ top: 0 }} />}
                <span className="absolute top-1 left-1 rounded bg-ink-900/70 px-1 text-[10px] font-semibold text-white">#{i + 1}</span>
                {leader && <Crown className="absolute top-1 right-1 w-4 h-4 text-primary-400 drop-shadow" aria-label="Current best" />}
                <div className="absolute inset-x-0 bottom-0 bg-ink-900/75 px-1.5 py-1 text-[10px] text-white flex items-center gap-1 min-w-0">
                  {ph.status === 'complete' ? <Sparkles className="w-3 h-3 shrink-0" /> : ph.status === 'measured' ? <Check className="w-3 h-3 shrink-0" /> : ph.status === 'failed' ? <X className="w-3 h-3 shrink-0" /> : busy ? <Loader2 className="w-3 h-3 shrink-0 animate-spin motion-reduce:animate-none" /> : null}
                  <span className="truncate flex-1">{STATUS_TEXT[ph.status]}</span>
                  {ph.score != null && <b className="shrink-0">{ph.score}</b>}
                </div>
              </li>
            );
          })}
        </ul>
      )}

      {p.log.length > 0 && (
        <ol ref={logRef} aria-label="Agent log" className="max-h-28 overflow-y-auto rounded-lg bg-ink-50 border border-ink-200 p-2 font-mono text-[11px] text-ink-600 space-y-0.5">
          {p.log.map((line, i) => <li key={i} className="animate-in fade-in slide-in-from-bottom-1 duration-300">› {line}</li>)}
        </ol>
      )}
    </div>
  );
}
