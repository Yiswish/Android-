import { Download, FileText, ArrowLeft } from 'lucide-react';
import { Button } from './ui/button';
import PhotoHeading from './PhotoHeading';
import type { AnalysisResult, MetricKey } from '@/lib/types';
import { METRIC_LABELS } from '@/lib/metricKeys';
import { generateExplanation } from '@/lib/explanations';
import ScoreDisplay from './ScoreDisplay';
import { metricRawErrors, rawMeasurementRows, rowsToCsv, ipdPercent, symmetryErrorIpd } from '@/lib/rawError';

interface ExportReportProps {
  result: AnalysisResult;
  onClose: () => void;
}

export default function ExportReport({ result, onClose }: ExportReportProps) {
  const explanations = generateExplanation(result);

  const handleExport = () => {
    const report = buildReportText(result, explanations);
    const blob = new Blob([report], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `aesthetic-report-${result.id}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportJSON = () => {
    const data = {
      id: result.id,
      imageId: result.imageId,
      imageUrl: result.imageUrl,
      source: result.source,
      timestamp: result.timestamp,
      date: new Date(result.timestamp).toISOString(),
      overallScore: result.scores.overall,
      metrics: result.scores.metrics,
      rawErrors: result.faceDetection.geometry ? rawMeasurementRows(result.faceDetection.geometry) : undefined,
      archetypeMatch: result.scores.archetypeMatch,
      topArchetypes: result.topArchetypes.map((ta) => ({
        name: ta.archetype.name,
        match: ta.match,
      })),
      faceDetection: {
        detected: result.faceDetection.detected,
        faceCount: result.faceDetection.faceCount,
        expression: result.faceDetection.expression,
        pose: result.faceDetection.pose,
        lightingDirection: result.faceDetection.lightingDirection,
        clothingStyle: result.faceDetection.clothingStyle,
        backgroundType: result.faceDetection.backgroundType,
      },
      warnings: result.warnings,
      explanations,
      duration: result.duration,
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `aesthetic-report-${result.id}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportCsv = () => {
    const g = result.faceDetection.geometry;
    if (!g) return;
    const url = URL.createObjectURL(new Blob([rowsToCsv(rawMeasurementRows(g))], { type: 'text/csv' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = `aesthetic-raw-errors-${result.id}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm animate-fade-in p-4">
      <div className="card p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto space-y-4 animate-scale-in">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-primary-500" />
            <h3 className="text-base font-semibold text-ink-800">Export Analysis Report</h3>
          </div>
          <Button variant="ghost" size="sm" aria-label="Back" onClick={onClose}><ArrowLeft />Back</Button>
        </div>

        {/* Report preview */}
        <div className="card p-5 space-y-4 bg-ink-50/50">
          <PhotoHeading name={result.searchLabel} />
          <div className="flex items-start gap-4">
            <div className="w-24 h-28 rounded-lg overflow-hidden flex-shrink-0 ring-1 ring-ink-200">
              <img src={result.imageUrl} alt="Analyzed" className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 space-y-2">
              <ScoreDisplay scores={result.scores} animated={false} size="sm" />
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="text-2xs font-semibold text-ink-500 uppercase tracking-wide">Summary</h4>
            {explanations.map((exp, i) => (
              <p key={i} className="text-2xs text-ink-600 leading-relaxed">
                {i + 1}. {exp}
              </p>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-2 text-2xs">
            <div className="space-y-1">
              <h4 className="font-semibold text-ink-500 uppercase">Key Metrics</h4>
              {Object.entries(result.scores.metrics).map(([key, val]) => (
                <div key={key} className="flex justify-between">
                  <span className="text-ink-500 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                  <span className="font-mono font-semibold text-ink-700">{val}</span>
                </div>
              ))}
            </div>
            <div className="space-y-1">
              <h4 className="font-semibold text-ink-500 uppercase">Detection</h4>
              <div className="flex justify-between"><span className="text-ink-500">Face detected</span><span className="font-mono text-ink-700">{result.faceDetection.detected ? 'Yes' : 'No'}</span></div>
              {result.faceDetection.detected && (
                <>
                  <div className="flex justify-between"><span className="text-ink-500">Expression</span><span className="font-mono text-ink-700 capitalize">{result.faceDetection.expression}</span></div>
                  <div className="flex justify-between"><span className="text-ink-500">Pose</span><span className="font-mono text-ink-700 capitalize">{result.faceDetection.pose}</span></div>
                  <div className="flex justify-between"><span className="text-ink-500">Lighting</span><span className="font-mono text-ink-700 capitalize">{result.faceDetection.lightingDirection ?? 'N/A'}</span></div>
                  <div className="flex justify-between"><span className="text-ink-500">Clothing</span><span className="font-mono text-ink-700 capitalize">{result.faceDetection.clothingStyle ?? 'N/A'}</span></div>
                </>
              )}
              <div className="flex justify-between"><span className="text-ink-500">Duration</span><span className="font-mono text-ink-700">{result.duration.toFixed(0)}ms</span></div>
            </div>
          </div>

          {result.warnings.length > 0 && (
            <div className="space-y-1">
              <h4 className="font-semibold text-warning-600 uppercase text-2xs">Warnings</h4>
              {result.warnings.map((w, i) => (
                <p key={i} className="text-2xs text-warning-700">{w}</p>
              ))}
            </div>
          )}
        </div>

        {/* Export buttons */}
        <div className="flex items-center gap-2 justify-end">
          {result.faceDetection.geometry && (
            <button onClick={handleExportCsv} className="btn-secondary">
              <Download className="w-4 h-4" />
              <span>Export raw errors (CSV)</span>
            </button>
          )}
          <button onClick={handleExportJSON} className="btn-secondary">
            <Download className="w-4 h-4" />
            <span>Export JSON</span>
          </button>
          <button onClick={handleExport} className="btn-primary">
            <Download className="w-4 h-4" />
            <span>Export Text Report</span>
          </button>
        </div>
      </div>
    </div>
  );
}

function buildReportText(result: AnalysisResult, explanations: string[]): string {
  const lines: string[] = [];
  lines.push('='.repeat(60));
  lines.push('  AESTHETICS ANALYZER — ANALYSIS REPORT');
  lines.push('='.repeat(60));
  lines.push('');
  lines.push(`Date: ${new Date(result.timestamp).toLocaleString()}`);
  lines.push(`Image ID: ${result.imageId}`);
  lines.push(`Source: ${result.source}`);
  lines.push(`Analysis Duration: ${result.duration.toFixed(0)}ms`);
  lines.push('');
  lines.push('--- OVERALL SCORE ---');
  lines.push(`Score: ${result.scores.overall}/100`);
  lines.push('');
  lines.push('--- METRIC BREAKDOWN ---');
  for (const [key, val] of Object.entries(result.scores.metrics)) {
    const label = METRIC_LABELS[key as MetricKey] ?? key.replace(/([A-Z])/g, ' $1').replace(/^./, (c) => c.toUpperCase()).trim();
    lines.push(`  ${label}: ${val}/100`);
  }
  lines.push('');
  const geo = result.faceDetection.geometry;
  if (geo) {
    const raws = metricRawErrors(geo);
    lines.push('--- RAW ERRORS (unscaled measurements) ---');
    lines.push(`  Overall asymmetry: ${ipdPercent(symmetryErrorIpd(geo))}`);
    lines.push(`  Proportion deviation: ${geo.proportionDeviation.toFixed(1)}% of ideal (mean)`);
    for (const [key, raw] of Object.entries(raws)) {
      lines.push(`  ${METRIC_LABELS[key as MetricKey] ?? key}: ${raw!.short}`);
    }
    for (const r of geo.ratios) {
      lines.push(`  ${r.label}: measured ${r.measured.toFixed(3)} vs ideal ${r.ideal.toFixed(3)} (${(r.deviation * 100).toFixed(1)}% of ideal)`);
    }
    lines.push('');
  }
  lines.push('--- FACE DETECTION ---');
  lines.push(`  Face detected: ${result.faceDetection.detected ? 'Yes' : 'No'}`);
  if (result.faceDetection.detected) {
    lines.push(`  Face count: ${result.faceDetection.faceCount}`);
    lines.push(`  Expression: ${result.faceDetection.expression} (${(result.faceDetection.expressionConfidence * 100).toFixed(0)}% confidence)`);
    lines.push(`  Pose: ${result.faceDetection.pose} (${(result.faceDetection.poseConfidence * 100).toFixed(0)}% confidence)`);
    lines.push(`  Lighting: ${result.faceDetection.lightingDirection ?? 'N/A'}`);
    lines.push(`  Clothing style: ${result.faceDetection.clothingStyle ?? 'N/A'}`);
    lines.push(`  Background: ${result.faceDetection.backgroundType ?? 'N/A'}`);
    if (result.faceDetection.ageEstimate) lines.push(`  Age estimate: ~${result.faceDetection.ageEstimate}`);
    if (result.faceDetection.focusQuality) lines.push(`  Focus quality: ${(result.faceDetection.focusQuality * 100).toFixed(0)}%`);
  }
  lines.push('');
  lines.push('--- EXPLANATION ---');
  explanations.forEach((exp, i) => {
    lines.push(`  ${i + 1}. ${exp}`);
  });
  lines.push('');
  if (result.warnings.length > 0) {
    lines.push('--- WARNINGS ---');
    result.warnings.forEach((w) => lines.push(`  ! ${w}`));
    lines.push('');
  }
  lines.push('='.repeat(60));
  return lines.join('\n');
}
