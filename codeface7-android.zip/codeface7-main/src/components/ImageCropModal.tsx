import { accentColor } from '@/lib/userPrefs';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Crop, RotateCw, Check, X, ZoomIn, ZoomOut } from 'lucide-react';

interface ImageCropModalProps {
  file: File;
  onConfirm: (croppedFile: File) => void;
  onCancel: () => void;
}

type Tool = 'crop' | 'rotate';

export default function ImageCropModal({ file, onConfirm, onCancel }: ImageCropModalProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);
  const [rotation, setRotation] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [cropRect, setCropRect] = useState({ x: 0.1, y: 0.1, width: 0.8, height: 0.8 });
  const [dragMode, setDragMode] = useState<'none' | 'move' | 'resize-se' | 'resize-nw'>('none');
  const [imgSize, setImgSize] = useState({ w: 0, h: 0 });
  const dragStart = useRef({ x: 0, y: 0, rect: { x: 0, y: 0, width: 0, height: 0 } });

  useEffect(() => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      imgRef.current = img;
      setImgSize({ w: img.naturalWidth, h: img.naturalHeight });
      // Default crop = the whole fitted image. The crop box is expressed in CANVAS fractions,
      // and a portrait photo is letterboxed inside the 4:3 canvas, so a fixed 10–90% box cut the face.
      const c = canvasRef.current;
      if (c && c.clientWidth && c.clientHeight) {
        const sc = Math.min(c.clientWidth / img.width, c.clientHeight / img.height);
        const fw = (img.width * sc) / c.clientWidth, fh = (img.height * sc) / c.clientHeight;
        setCropRect({ x: (1 - fw) / 2, y: (1 - fh) / 2, width: fw, height: fh });
      }
    };
    img.src = url;
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const img = imgRef.current;
    if (!canvas || !img) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const cw = canvas.clientWidth;
    const ch = canvas.clientHeight;
    canvas.width = cw;
    canvas.height = ch;

    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, cw, ch);

    const scale = Math.min(cw / img.width, ch / img.height) * zoom;
    const dw = img.width * scale;
    const dh = img.height * scale;
    const dx = (cw - dw) / 2;
    const dy = (ch - dh) / 2;

    ctx.save();
    ctx.translate(cw / 2, ch / 2);
    ctx.rotate((rotation * Math.PI) / 180);
    ctx.translate(-cw / 2, -ch / 2);
    ctx.drawImage(img, dx, dy, dw, dh);
    ctx.restore();

    const crx = cropRect.x * cw;
    const cry = cropRect.y * ch;
    const crw = cropRect.width * cw;
    const crh = cropRect.height * ch;

    ctx.fillStyle = 'rgba(15, 23, 42, 0.6)';
    ctx.fillRect(0, 0, cw, cry);
    ctx.fillRect(0, cry + crh, cw, ch - (cry + crh));
    ctx.fillRect(0, cry, crx, crh);
    ctx.fillRect(crx + crw, cry, cw - (crx + crw), crh);

    ctx.strokeStyle = accentColor(500);
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 4]);
    ctx.strokeRect(crx, cry, crw, crh);
    ctx.setLineDash([]);

    const handleSize = 10;
    ctx.fillStyle = accentColor(500);
    ctx.fillRect(crx - handleSize / 2, cry - handleSize / 2, handleSize, handleSize);
    ctx.fillRect(crx + crw - handleSize / 2, cry + crh - handleSize / 2, handleSize, handleSize);

    const thirdW = crw / 3;
    const thirdH = crh / 3;
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.lineWidth = 1;
    for (let i = 1; i < 3; i++) {
      ctx.beginPath();
      ctx.moveTo(crx + thirdW * i, cry);
      ctx.lineTo(crx + thirdW * i, cry + crh);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(crx, cry + thirdH * i);
      ctx.lineTo(crx + crw, cry + thirdH * i);
      ctx.stroke();
    }
  }, [rotation, zoom, cropRect]);

  useEffect(() => {
    draw();
  }, [draw]);

  const getCanvasPos = (e: React.MouseEvent | React.TouchEvent): { x: number; y: number } => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    return { x: (clientX - rect.left) / rect.width, y: (clientY - rect.top) / rect.height };
  };

  const handlePointerDown = (e: React.MouseEvent | React.TouchEvent) => {
    const pos = getCanvasPos(e);
    const cr = cropRect;
    const seDist = Math.abs(pos.x - (cr.x + cr.width)) + Math.abs(pos.y - (cr.y + cr.height));
    const nwDist = Math.abs(pos.x - cr.x) + Math.abs(pos.y - cr.y);

    if (seDist < 0.05) {
      setDragMode('resize-se');
    } else if (nwDist < 0.05) {
      setDragMode('resize-nw');
    } else if (pos.x >= cr.x && pos.x <= cr.x + cr.width && pos.y >= cr.y && pos.y <= cr.y + cr.height) {
      setDragMode('move');
    } else {
      return;
    }
    dragStart.current = { x: pos.x, y: pos.y, rect: { ...cr } };
  };

  const handlePointerMove = (e: React.MouseEvent | React.TouchEvent) => {
    if (dragMode === 'none') return;
    const pos = getCanvasPos(e);
    const start = dragStart.current;
    const dx = pos.x - start.x;
    const dy = pos.y - start.y;

    if (dragMode === 'move') {
      let nx = start.rect.x + dx;
      let ny = start.rect.y + dy;
      nx = Math.max(0, Math.min(1 - start.rect.width, nx));
      ny = Math.max(0, Math.min(1 - start.rect.height, ny));
      setCropRect({ ...start.rect, x: nx, y: ny });
    } else if (dragMode === 'resize-se') {
      let nw = start.rect.width + dx;
      let nh = start.rect.height + dy;
      nw = Math.max(0.1, Math.min(1 - start.rect.x, nw));
      nh = Math.max(0.1, Math.min(1 - start.rect.y, nh));
      setCropRect({ ...start.rect, width: nw, height: nh });
    } else if (dragMode === 'resize-nw') {
      let nx = start.rect.x + dx;
      let ny = start.rect.y + dy;
      let nw = start.rect.width - dx;
      let nh = start.rect.height - dy;
      nx = Math.max(0, nx);
      ny = Math.max(0, ny);
      nw = Math.max(0.1, Math.min(start.rect.x + start.rect.width, nw));
      nh = Math.max(0.1, Math.min(start.rect.y + start.rect.height, nh));
      setCropRect({ x: nx, y: ny, width: nw, height: nh });
    }
  };

  const handlePointerUp = () => setDragMode('none');

  const handleConfirm = () => {
    const img = imgRef.current;
    const canvas = canvasRef.current;
    if (!img || !canvas) return;
    const cw = canvas.width, ch = canvas.height;
    const base = Math.min(cw / img.width, ch / img.height) * zoom;
    const dw = img.width * base, dh = img.height * base;
    const dx = (cw - dw) / 2, dy = (ch - dh) / 2;

    // Untouched crop (whole image, no rotation / zoom): send the ORIGINAL file — no re-encode.
    const covers = cropRect.x * cw <= dx + 3 && cropRect.y * ch <= dy + 3 &&
      (cropRect.x + cropRect.width) * cw >= dx + dw - 3 && (cropRect.y + cropRect.height) * ch >= dy + dh - 3;
    if (rotation % 360 === 0 && zoom === 1 && covers) { onConfirm(file); return; }

    // Otherwise re-render with exactly the geometry draw() shows, at native resolution (capped at 2048 px).
    const cropW = cropRect.width * cw, cropH = cropRect.height * ch;
    const m = Math.min(1 / base, 2048 / Math.max(cropW, cropH));
    const outCanvas = document.createElement('canvas');
    outCanvas.width = Math.max(1, Math.round(cropW * m));
    outCanvas.height = Math.max(1, Math.round(cropH * m));
    const ctx = outCanvas.getContext('2d');
    if (!ctx) return;
    ctx.fillStyle = '#808080'; // neutral gray for any area outside the photo
    ctx.fillRect(0, 0, outCanvas.width, outCanvas.height);
    ctx.scale(m, m);
    ctx.translate(-cropRect.x * cw, -cropRect.y * ch);
    ctx.translate(cw / 2, ch / 2);
    ctx.rotate((rotation * Math.PI) / 180);
    ctx.translate(-cw / 2, -ch / 2);
    ctx.drawImage(img, dx, dy, dw, dh);

    outCanvas.toBlob((blob) => {
      if (blob) onConfirm(new File([blob], file.name, { type: 'image/jpeg' }));
    }, 'image/jpeg', 0.92);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-900/70 backdrop-blur-sm animate-fade-in p-4">
      <div className="card glass-dark p-6 max-w-2xl w-full space-y-4 text-white animate-scale-in">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-display font-semibold flex items-center gap-2">
            <Crop className="w-5 h-5 text-primary-400" />
            Crop & Rotate
          </h3>
          <button onClick={onCancel} className="p-2 rounded-lg hover:bg-white/10 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="relative rounded-xl overflow-hidden bg-ink-900" style={{ aspectRatio: '4/3' }}>
          <canvas
            ref={canvasRef}
            className="w-full h-full touch-none cursor-pointer"
            onMouseDown={handlePointerDown}
            onMouseMove={handlePointerMove}
            onMouseUp={handlePointerUp}
            onTouchStart={handlePointerDown}
            onTouchMove={handlePointerMove}
            onTouchEnd={handlePointerUp}
          />
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setRotation((r) => (r - 90) % 360)}
              className="btn-secondary text-white border-white/20 bg-white/10 hover:bg-white/20 micro-press"
            >
              <RotateCw className="w-4 h-4 -scale-x-100" />
            </button>
            <button
              onClick={() => setRotation((r) => (r + 90) % 360)}
              className="btn-secondary text-white border-white/20 bg-white/10 hover:bg-white/20 micro-press"
            >
              <RotateCw className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setZoom((z) => Math.max(0.5, z - 0.1))}
              className="btn-secondary text-white border-white/20 bg-white/10 hover:bg-white/20 micro-press"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <span className="text-2xs font-mono text-white/60 w-10 text-center">{zoom.toFixed(1)}x</span>
            <button
              onClick={() => setZoom((z) => Math.min(3, z + 0.1))}
              className="btn-secondary text-white border-white/20 bg-white/10 hover:bg-white/20 micro-press"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
          </div>

          <div className="ml-auto flex items-center gap-2">
            <button onClick={onCancel} className="btn-secondary text-white border-white/20 bg-white/10 hover:bg-white/20">
              <X className="w-4 h-4" />
              <span>Cancel</span>
            </button>
            <button onClick={handleConfirm} className="btn-primary">
              <Check className="w-4 h-4" />
              <span>Apply</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export type { Tool };
