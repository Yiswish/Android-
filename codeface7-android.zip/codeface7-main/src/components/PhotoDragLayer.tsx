import { useEffect, useRef, useState } from 'react';
import { GitCompare } from 'lucide-react';
import type { AnalysisResult } from '@/lib/types';

const registry = new Map<string, AnalysisResult>();
/** Spread onto any photo tile to make it draggable into Compare (hold, then drag). */
export function dragProps(id: string, result?: AnalysisResult) {
  if (result) registry.set(id, result);
  return { 'data-drag-id': id } as const;
}
export const registeredDragResult = (id: string) => registry.get(id);

const HOLD_MS = 280;

/** Swallow the click that follows a drag so the photo doesn't also open. */
function swallowNextClick() {
  const block = (e: Event) => { e.preventDefault(); e.stopPropagation(); };
  window.addEventListener('click', block, { capture: true, once: true });
  setTimeout(() => window.removeEventListener('click', block, { capture: true }), 400);
}

export default function PhotoDragLayer({ resolve, onDrop, isIn }: {
  resolve: (id: string) => AnalysisResult | undefined;
  onDrop: (r: AnalysisResult) => void;
  isIn: (id: string) => boolean;
}) {
  const [drag, setDrag] = useState<{ src: string; x: number; y: number; over: boolean; id: string } | null>(null);
  const zone = useRef<HTMLDivElement>(null);
  const cb = useRef({ resolve, onDrop });
  cb.current = { resolve, onDrop };

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout> | undefined;
    let sx = 0, sy = 0, active = false, id = '', src = '', wasOver = false;
    const find = (i: string) => cb.current.resolve(i) ?? registry.get(i);
    const overZone = (x: number, y: number) => {
      const r = zone.current?.getBoundingClientRect();
      return !!r && x >= r.left - 20 && x <= r.right + 20 && y >= r.top - 30 && y <= r.bottom + 20;
    };
    const begin = (target: EventTarget | null, x: number, y: number) => {
      const el = (target as Element | null)?.closest?.('[data-drag-id]') as HTMLElement | null;
      if (!el) return;
      sx = x; sy = y; wasOver = false;
      id = el.dataset.dragId!; src = el.querySelector('img')?.currentSrc || el.querySelector('img')?.src || '';
      timer = setTimeout(() => {
        timer = undefined;
        if (!find(id)) return;
        active = true; document.body.dataset.photoDrag = '1';
        navigator.vibrate?.(15);
        setDrag({ src, x: sx, y: sy, over: false, id });
      }, HOLD_MS);
    };
    const moveTo = (x: number, y: number) => {
      if (!active) { if (timer && Math.hypot(x - sx, y - sy) > 10) { clearTimeout(timer); timer = undefined; } return false; }
      const over = overZone(x, y);
      if (over && !wasOver) navigator.vibrate?.(8);
      wasOver = over;
      setDrag((d) => d && { ...d, x, y, over });
      return true;
    };
    const finish = (x?: number, y?: number) => {
      if (timer) clearTimeout(timer); timer = undefined;
      if (!active) return;
      active = false;
      // Keep the flag a moment so swipe/long-press handlers firing on this same release still see it.
      setTimeout(() => { delete document.body.dataset.photoDrag; }, 50);
      swallowNextClick();
      if (x !== undefined && y !== undefined && overZone(x, y)) {
        const r = find(id);
        if (r) { navigator.vibrate?.([10, 40, 10]); cb.current.onDrop(r); }
      }
      setDrag(null);
    };

    const tStart = (e: TouchEvent) => { if (e.touches.length === 1) begin(e.target, e.touches[0].clientX, e.touches[0].clientY); };
    const tMove = (e: TouchEvent) => { const t = e.touches[0]; if (t && moveTo(t.clientX, t.clientY)) e.preventDefault(); };
    const tEnd = (e: TouchEvent) => { const t = e.changedTouches[0]; finish(t?.clientX, t?.clientY); };
    const mDown = (e: MouseEvent) => { if (e.button === 0) begin(e.target, e.clientX, e.clientY); };
    const mMove = (e: MouseEvent) => { if (moveTo(e.clientX, e.clientY)) e.preventDefault(); };
    const mUp = (e: MouseEvent) => finish(e.clientX, e.clientY);
    const noNativeDrag = (e: DragEvent) => { if ((e.target as Element | null)?.closest?.('[data-drag-id]')) e.preventDefault(); };

    window.addEventListener('touchstart', tStart, { passive: true });
    window.addEventListener('touchmove', tMove, { passive: false });
    window.addEventListener('touchend', tEnd);
    window.addEventListener('touchcancel', tEnd);
    window.addEventListener('mousedown', mDown);
    window.addEventListener('mousemove', mMove);
    window.addEventListener('mouseup', mUp);
    window.addEventListener('dragstart', noNativeDrag);
    return () => {
      window.removeEventListener('touchstart', tStart);
      window.removeEventListener('touchmove', tMove);
      window.removeEventListener('touchend', tEnd);
      window.removeEventListener('touchcancel', tEnd);
      window.removeEventListener('mousedown', mDown);
      window.removeEventListener('mousemove', mMove);
      window.removeEventListener('mouseup', mUp);
      window.removeEventListener('dragstart', noNativeDrag);
    };
  }, []);

  if (!drag) return null;
  const already = isIn(drag.id);
  return (
    <div className="fixed inset-0 z-[90] pointer-events-none" data-testid="photo-drag-layer">
      <div className="absolute inset-0 bg-ink-900/30 animate-fade-in" />
      <div ref={zone} className={`drop-zone absolute left-4 right-4 bottom-24 rounded-2xl border-2 border-dashed flex items-center justify-center gap-2 py-6 font-semibold ${drag.over ? 'is-over border-primary-500 bg-primary-500 text-white' : 'border-primary-400 bg-white/90 text-primary-600'}`}>
        <GitCompare className="w-5 h-5" />
        {already ? 'Already in Compare' : drag.over ? 'Release to add' : 'Drop here to compare'}
      </div>
      {drag.src && <img src={drag.src} alt="" className="drag-ghost absolute w-24 h-24 rounded-xl object-cover shadow-2xl ring-2 ring-white"
        style={{ left: drag.x - 48, top: drag.y - 60, transform: `scale(${drag.over ? 0.75 : 1.08}) rotate(${drag.over ? 0 : -4}deg)` }} />}
    </div>
  );
}
