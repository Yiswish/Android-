import PhotoHeading, { PhotoNameSearchContext } from './PhotoHeading';
import { Button } from './ui/button';
import { useContext, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { TransformWrapper, TransformComponent, type ReactZoomPanPinchContentRef as ReactZoomPanPinchRef } from 'react-zoom-pan-pinch';
import { ArrowLeft, ChevronLeft, ChevronRight, Info, ZoomIn, ZoomOut } from 'lucide-react';
import { haptic } from '@/lib/haptics';
import HeldFacePhoto from './HeldFacePhoto';
import type { DetectedFace } from '@/lib/types';

export interface ViewerItem { id: string; src: string; caption?: string; name?: string; faces?: DetectedFace[] }

interface Props {
  items: ViewerItem[];
  index: number;
  onIndexChange?: (i: number) => void;
  onClose: () => void;
  /** Shown as an "info" button: opens the full analysis for the current photo. */
  onDetails?: (id: string) => void;
}

/** Full-screen photo viewer: pinch / double-tap / wheel zoom, swipe to change photo, swipe down to close. */
export default function PhotoViewer({ items, index, onIndexChange, onClose, onDetails }: Props) {
  const searchName = useContext(PhotoNameSearchContext);
  const [i, setI] = useState(index);
  const [zoomed, setZoomed] = useState(false);
  const [drag, setDrag] = useState({ x: 0, y: 0 });
  const zoomRef = useRef<ReactZoomPanPinchRef>(null);
  const start = useRef<{ x: number; y: number } | null>(null);
  const item = items[i];

  const go = (n: number) => {
    if (n < 0 || n >= items.length) return;
    haptic('selection');
    zoomRef.current?.resetTransform(0);
    setI(n);
    onIndexChange?.(n);
  };

  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') go(i + 1);
      if (e.key === 'ArrowLeft') go(i - 1);
    };
    window.addEventListener('keydown', onKey);
    // Phone back button closes the viewer instead of leaving the app.
    history.pushState({ viewer: true }, '');
    const onPop = () => onClose();
    window.addEventListener('popstate', onPop);
    window.addEventListener('photo-name-search', onClose);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('popstate', onPop);
      window.removeEventListener('photo-name-search', onClose);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [i]);

  const close = () => { if (history.state?.viewer) history.back(); else onClose(); };

  if (!item) return null;

  const onTouchStart = (e: React.TouchEvent) => {
    if (zoomed || e.touches.length !== 1) { start.current = null; return; }
    start.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
  };
  const onTouchMove = (e: React.TouchEvent) => {
    if (!start.current || zoomed || e.touches.length !== 1) return;
    setDrag({ x: e.touches[0].clientX - start.current.x, y: e.touches[0].clientY - start.current.y });
  };
  const onTouchEnd = () => {
    if (!start.current) return;
    const { x, y } = drag;
    start.current = null;
    setDrag({ x: 0, y: 0 });
    if (y > 110 && Math.abs(y) > Math.abs(x)) { haptic('light'); close(); return; }
    if (Math.abs(x) > 70 && Math.abs(x) > Math.abs(y)) go(x < 0 ? i + 1 : i - 1);
  };

  const fade = Math.max(0.35, 1 - Math.max(0, drag.y) / 400);

  return createPortal(
    <div
      className="viewer-backdrop fixed inset-0 z-[200] flex flex-col animate-fade-in select-none"
      style={{ ['--viewer-fade' as string]: fade }}
      role="dialog"
      aria-modal="true"
      aria-label="Photo viewer"
    >
      <div className="flex items-center justify-between px-3 pt-[calc(env(safe-area-inset-top)+0.5rem)] pb-2 viewer-chrome">
        <Button variant="ghost" aria-label="Back" onClick={close} className="viewer-btn w-auto px-3"><ArrowLeft />Back</Button>
        <span className="text-xs font-mono viewer-text">{i + 1} / {items.length}</span>
        <div className="flex gap-2">
          <button aria-label="Zoom out" onClick={() => zoomRef.current?.zoomOut()} className="viewer-btn hidden sm:flex"><ZoomOut className="w-5 h-5" /></button>
          <button aria-label="Zoom in" onClick={() => zoomRef.current?.zoomIn()} className="viewer-btn hidden sm:flex"><ZoomIn className="w-5 h-5" /></button>
          {onDetails && <button aria-label="Show details" onClick={() => onDetails(item.id)} className="viewer-btn"><Info className="w-5 h-5" /></button>}
        </div>
      </div>

      <PhotoHeading name={item.name} onSearch={searchName ? (name) => { close(); onClose(); searchName(name); } : undefined} className="viewer-text text-center px-4 py-2 viewer-chrome" />
      <div
        className="relative flex-1 overflow-hidden touch-none"
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
      >
        <div
          className="w-full h-full"
          style={{ transform: `translate(${drag.x}px, ${Math.max(0, drag.y)}px)`, transition: start.current ? 'none' : 'transform 0.25s ease' }}
        >
          <TransformWrapper
            key={item.id}
            ref={zoomRef}
            minScale={1}
            maxScale={6}
            doubleClick={{ mode: 'toggle', step: 2.5 }}
            wheel={{ step: 0.15 }}
            panning={{ disabled: !zoomed }}
            onTransform={(_r: unknown, s: { scale: number }) => setZoomed(s.scale > 1.02)}
          >
            <TransformComponent wrapperClass="!w-full !h-full" contentClass="!w-full !h-full flex items-center justify-center">
              <HeldFacePhoto key={item.id} src={item.src} name={item.name} alt={item.caption ?? 'Photo'} faces={item.faces}
                className="w-full h-full" imageClassName="w-full h-full object-contain" />
            </TransformComponent>
          </TransformWrapper>
        </div>

        {i > 0 && <button aria-label="Previous photo" onClick={() => go(i - 1)} className="viewer-btn absolute left-3 top-1/2 -translate-y-1/2 hidden sm:flex"><ChevronLeft className="w-6 h-6" /></button>}
        {i < items.length - 1 && <button aria-label="Next photo" onClick={() => go(i + 1)} className="viewer-btn absolute right-3 top-1/2 -translate-y-1/2 hidden sm:flex"><ChevronRight className="w-6 h-6" /></button>}
      </div>

      {item.caption && (
        <p className="text-center text-sm viewer-text px-4 pt-2 pb-[calc(env(safe-area-inset-bottom)+1rem)] viewer-chrome">{item.caption}</p>
      )}
    </div>,
    document.body,
  );
}
