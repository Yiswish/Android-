import { useState, useCallback, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Search, Upload, Loader2, SlidersHorizontal, X, Filter } from 'lucide-react';
import type { ImageSource, SearchFilters, OrientationFilter, StyleCategoryFilter } from '@/lib/types';
import { defaultFilters } from '@/lib/search';
import { haptic } from '@/lib/haptics';
import { useUserPrefs } from '@/lib/userPrefs';

interface SearchBarProps {
  externalQuery?: string;
  onSearch: (query: string, source: ImageSource) => void;
  onUpload: (file: File) => void;
  /** Several photos at once: analyse and rank them. */
  onUploadMany?: (files: File[]) => void;
  loading?: boolean;
  analysisBusy?: boolean;
  suggestions?: string[];
  filters: SearchFilters;
  onFiltersChange: (filters: SearchFilters) => void;
  resultCount?: number;
}

const orientationOptions: { value: OrientationFilter; label: string }[] = [
  { value: 'all', label: 'All' },
  { value: 'landscape', label: 'Landscape' },
  { value: 'portrait', label: 'Portrait' },
  { value: 'square', label: 'Square' },
];

const categoryOptions: { value: StyleCategoryFilter; label: string }[] = [
  { value: 'all', label: 'All Styles' },
  { value: 'minimalist', label: 'Minimalist' },
  { value: 'warm-earth', label: 'Warm Earth' },
  { value: 'moody-noir', label: 'Moody Noir' },
  { value: 'vibrant-pop', label: 'Vibrant Pop' },
  { value: 'natural-organic', label: 'Natural Organic' },
  { value: 'editorial-chic', label: 'Editorial Chic' },
  { value: 'vintage-film', label: 'Vintage Film' },
  { value: 'architectural', label: 'Architectural' },
];

export default function SearchBar({ externalQuery = '', onSearch, onUpload, onUploadMany, loading, analysisBusy, suggestions, filters, onFiltersChange, resultCount }: SearchBarProps) {
  const uploadInput = useRef<HTMLInputElement>(null);
  const [query, setQuery] = useState(externalQuery);
  useEffect(() => { setQuery(externalQuery); }, [externalQuery]);
  const prefs = useUserPrefs();
  const [source, setSource] = useState<ImageSource>(prefs.defaultSource);
  useEffect(() => { setSource(prefs.defaultSource); }, [prefs.defaultSource]);
  const [showFilters, setShowFilters] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 640);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  const activeFilterCount =
    (filters.orientation !== 'all' ? 1 : 0) +
    0;

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      haptic('light');
      onSearch(query.trim(), source);
    }
  }, [query, source, onSearch]);

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []).filter((f) => f.type.startsWith('image/'));
    e.target.value = '';
    if (!files.length) return;
    haptic('medium');
    if (files.length > 1 && onUploadMany) onUploadMany(files);
    else onUpload(files[0]);
  }, [onUpload, onUploadMany]);

  const resetFilters = () => {
    haptic('selection');
    onFiltersChange(defaultFilters);
  };

  const filterBody = (
    <>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Orientation */}
            <div className="space-y-2">
              <label className="text-2xs font-medium text-ink-500 uppercase tracking-wide">Orientation</label>
              <div className="flex flex-wrap gap-1.5">
                {orientationOptions.map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => onFiltersChange({ ...filters, orientation: opt.value })}
                    className={`px-3 py-1.5 rounded-lg text-2xs font-medium transition-all ${
                      filters.orientation === opt.value
                        ? 'bg-primary-500 text-white shadow-glow-primary'
                        : 'bg-ink-100 text-ink-600 hover:bg-ink-200'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

          </div>

          {resultCount !== undefined && (
            <div className="text-2xs text-ink-400 pt-1 border-t border-ink-100">
              {resultCount} image{resultCount !== 1 ? 's' : ''} match current filters
            </div>
          )}
    </>
  );

  return (
    <div className="w-full space-y-3">
      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row sm:flex-wrap gap-2">
        <div className="relative flex-1 sm:min-w-48">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search for aesthetic images..."
            className="input-field pl-11"
            disabled={loading}
          />
        </div>
        <select
          value={source}
          onChange={(e) => setSource(e.target.value as ImageSource)}
          className="input-field sm:w-36"
          disabled={loading}
        >
          <option value="google">Google Images</option>
          <option value="elitebabes">Elite Babes</option>
        </select>
        <button
          type="submit"
          disabled={loading || !query.trim()}
          className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
          <span>Search</span>
        </button>
        <Button type="button" variant="secondary" disabled={analysisBusy} className="btn-secondary h-auto" onClick={() => uploadInput.current?.click()}>
          <Upload className="w-4 h-4" />
          <span>Upload photos</span>
        </Button>
        <input ref={uploadInput} aria-label="Upload photos" type="file" accept="image/*" multiple disabled={analysisBusy} onChange={handleFileChange} className="hidden" />
        <button
          type="button"
          onClick={() => { haptic('selection'); setShowFilters((prev) => !prev); }}
          className={`btn-secondary relative min-h-[44px] ${showFilters ? 'ring-2 ring-primary-400' : ''}`}
        >
          <SlidersHorizontal className="w-4 h-4" />
          <span className="hidden sm:inline">Filters</span>
          {activeFilterCount > 0 && (
            <span className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-primary-500 text-white text-2xs font-bold flex items-center justify-center">
              {activeFilterCount}
            </span>
          )}
        </button>
      </form>

      <div className="flex flex-wrap gap-1.5" aria-label="Quick searches for your face type">
        {prefs.quickSearches.map((q) => (
          <button
            key={q}
            type="button"
            disabled={loading}
            onClick={() => { haptic('selection'); setQuery(q); onSearch(q, source); }}
            className="px-2.5 py-1 rounded-full bg-primary-50 text-primary-700 text-2xs hover:bg-primary-100 disabled:opacity-50"
          >
            {q}
          </button>
        ))}
      </div>

      {/* Filter panel — bottom sheet on mobile, inline card on desktop */}
      {showFilters && (
        isMobile ? (
          <>
            <div
              className="fixed inset-0 z-40 bg-ink-900/40 backdrop-blur-sm animate-fade-in"
              onClick={() => { haptic('light'); setShowFilters(false); }}
            />
            <div className="fixed bottom-0 left-0 right-0 z-50 glass rounded-t-3xl p-5 pb-8 space-y-4 animate-fade-in-up max-h-[80vh] overflow-y-auto">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-semibold text-ink-700 flex items-center gap-2">
                  <Filter className="w-4 h-4 text-primary-500" />
                  Filters
                </h4>
                <button onClick={() => { haptic('light'); setShowFilters(false); }} className="p-2 rounded-lg hover:bg-ink-100 min-h-[40px] min-w-[40px] flex items-center justify-center">
                  <X className="w-4 h-4" />
                </button>
              </div>
              {filterBody}
            </div>
          </>
        ) : (
        <div className="card p-4 space-y-4 animate-fade-in-down">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-semibold text-ink-700">Multi-Criteria Filters</h4>
            {activeFilterCount > 0 && (
              <button onClick={resetFilters} className="btn-ghost text-2xs">
                <X className="w-3 h-3" />
                <span>Reset</span>
              </button>
            )}
          </div>

          {filterBody}
        </div>
        )
      )}

      {suggestions && suggestions.length > 0 && !showFilters && (
        <div className="flex flex-wrap gap-2">
          {suggestions.map((s) => (
            <button
              key={s}
              onClick={() => {
                setQuery(s);
                onSearch(s, source);
              }}
              className="badge badge-primary hover:bg-primary-200 transition-colors cursor-pointer"
            >
              {s}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
