import { useMemo, useState } from 'react';
import { Sparkles, SkipForward, RotateCcw } from 'lucide-react';
import { Button } from './ui/button';
import { suggestNextToRate, tasteSkill, type TasteModel } from '@/lib/preferenceEngine';
import type { AnalysisResult } from '@/lib/types';

export const CALIBRATION_SIZE = 5;
/** Quick answers mapped onto the existing 1–5 star scale. */
export const QUICK_ANSWERS = [
  { label: 'Not for me', stars: 1 }, { label: 'Meh', stars: 2 }, { label: 'Okay', stars: 3 }, { label: 'Like', stars: 4 }, { label: 'Love', stars: 5 },
] as const;

/** Five-photo taste quiz over already-analysed photos; picks the ones the taste model knows least about. Never runs new scans. */
export default function TasteCalibration({ results, tasteModel, onRate, onGoRate }: {
  results: AnalysisResult[]; tasteModel: TasteModel;
  onRate: (imageId: string, rating: number) => void; onGoRate: () => void;
}) {
  const [round, setRound] = useState<{ imageId: string; imageUrl: string }[] | null>(null);
  const [step, setStep] = useState(0);
  const [answered, setAnswered] = useState(0);
  const available = useMemo(() => suggestNextToRate(tasteModel, results, CALIBRATION_SIZE), [tasteModel, results]);
  const skill = Math.round(tasteSkill(tasteModel) * 100);

  const start = () => { setRound(available.map(({ imageId, imageUrl }) => ({ imageId, imageUrl }))); setStep(0); setAnswered(0); };
  const answer = (stars?: number) => {
    const current = round?.[step];
    if (current && stars) { onRate(current.imageId, stars); setAnswered((n) => n + 1); }
    setStep((s) => s + 1);
  };

  if (!round) return (
    <section className="border-b border-ink-200 pb-5 space-y-2">
      <div className="flex items-center gap-2"><Sparkles className="w-4 h-4" /><h2 className="font-semibold">Rapid taste calibration</h2></div>
      <p className="text-xs text-ink-500">{tasteModel.samples.length} ratings so far{tasteModel.samples.length >= 3 ? ` · prediction improvement over your average ${skill}%` : ''}</p>
      {available.length ? <Button className="w-full" onClick={start}>Start ({available.length} {available.length === 1 ? 'face' : 'faces'})</Button>
        : <Button variant="outline" className="w-full" onClick={onGoRate}>Analyse a few photos first</Button>}
    </section>
  );

  const current = round[step];
  if (!current) return (
    <section className="border-b border-ink-200 pb-5 space-y-3 text-center">
      <Sparkles className="mx-auto w-6 h-6" />
      <h2 className="font-semibold">Calibration done</h2>
      <p className="text-sm text-ink-500">{answered} new {answered === 1 ? 'rating' : 'ratings'} · {tasteModel.samples.length} in total{tasteModel.samples.length >= 3 ? ` · prediction improvement over your average ${skill}%` : ''}</p>
      <div className="flex gap-2">
        <Button variant="outline" className="flex-1" onClick={() => setRound(null)}>Close</Button>
        {available.length > 0 && <Button className="flex-1" onClick={start}><RotateCcw />Another round</Button>}
      </div>
    </section>
  );

  return (
    <section className="max-w-lg mx-auto border-b border-ink-200 pb-5 space-y-3">
      <div className="flex items-center justify-between text-xs text-ink-500">
        <span>Face {step + 1} of {round.length}</span>
        <div className="flex gap-1">{round.map((_, i) => <span key={i} className={`h-1.5 w-6 rounded-full ${i <= step ? 'bg-ink-900' : 'bg-ink-200'}`} />)}</div>
      </div>
      <img src={current.imageUrl} alt={`Face ${step + 1} to rate`} className="w-full h-[min(48dvh,28rem)] object-contain rounded-lg bg-ink-100" />
      <div className="grid grid-cols-5 gap-1.5">
        {QUICK_ANSWERS.map((a) => (
          <Button key={a.stars} variant={a.stars >= 4 ? 'default' : 'outline'} className="h-12 px-1 text-xs whitespace-normal leading-tight" onClick={() => answer(a.stars)}>{a.label}</Button>
        ))}
      </div>
      <Button variant="ghost" size="sm" className="w-full text-ink-500" onClick={() => answer()}><SkipForward />Skip</Button>
    </section>
  );
}
