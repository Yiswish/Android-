import { useEffect, useState } from 'react';
import { useServerFn } from '@tanstack/react-start';
import { Check, Eye, EyeOff, LockKeyhole, Unlock, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { lovable } from '@/integrations/lovable';
import { getKeyLocks, getKeyOwner, setKeyLock } from '@/lib/keySettings.functions';
import { clearPersonalKeys, maskKey, personalKeys, personalKeyStatus, removePersonalKey, savePersonalKeys, SEARCH_KEY_PROVIDERS, type KeyProvider, type SearchKeyProvider } from '@/lib/personalKeys';

const SEARCH_INFO: Record<SearchKeyProvider, { name: string; label: string; hint: string }> = {
  serper: { name: 'Serper', label: 'Serper API key', hint: 'Google images via serper.dev — used first.' },
  serpapi: { name: 'SerpAPI', label: 'SerpAPI key', hint: 'Backup Google & Pinterest search if Serper fails.' },
  pexels: { name: 'Pexels Photos', label: 'Pexels API key', hint: 'Free stock portraits from pexels.com.' },
  unsplash: { name: 'Unsplash Photos', label: 'Unsplash access key', hint: 'Free stock portraits from unsplash.com.' },
};
const NO_LOCKS: Record<KeyProvider, boolean> = { gemini: false, serpapi: false, serper: false, pexels: false, unsplash: false };
const EMPTY_SEARCH: Record<SearchKeyProvider, string> = { serpapi: '', serper: '', pexels: '', unsplash: '' };
const NAMES: Record<KeyProvider, string> = { gemini: 'Gemini / Groq', serper: 'Serper', serpapi: 'SerpAPI', pexels: 'Pexels', unsplash: 'Unsplash' };
import { clearSearchCache } from '@/lib/search';
import AiKeyHealth from '@/components/AiKeyHealth';

export default function ApiKeySettings({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const [gemini, setGemini] = useState<string[]>(Array(5).fill(''));
  const [searchKeys, setSearchKeys] = useState<Record<SearchKeyProvider, string>>(EMPTY_SEARCH);
  const [locks, setLocks] = useState<Record<KeyProvider, boolean>>(NO_LOCKS);
  const [ready, setReady] = useState(false);
  const [signedIn, setSignedIn] = useState(false);
  const [owner, setOwner] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState(personalKeyStatus);
  const [show, setShow] = useState<Record<string, boolean>>({});
  const readLocks = useServerFn(getKeyLocks);
  const readOwner = useServerFn(getKeyOwner);
  const changeLock = useServerFn(setKeyLock);

  useEffect(() => {
    if (!open) return;
    let active = true;
    setReady(false);
    setStatus(personalKeyStatus());
    const refresh = async () => {
      try {
        const next = await readLocks();
        if (active) { setLocks({ ...NO_LOCKS, ...next }); setReady(true); }
      } catch { if (active) setReady(true); }
    };
    const updateAccess = async (hasSession: boolean) => {
      if (!active) return;
      setSignedIn(hasSession);
      setOwner(false);
      if (hasSession) {
        try { const result = await readOwner(); if (active) setOwner(result.owner); }
        catch { if (active) setMessage('Could not check owner access. Try signing in again.'); }
      }
    };
    void refresh();
    // The auth client throws when Cloud is not connected; keys still work without sign-in.
    let unsubscribe: (() => void) | null = null;
    try {
      void supabase.auth.getSession().then(({ data }) => updateAccess(!!data.session)).catch(() => {});
      const { data: subscription } = supabase.auth.onAuthStateChange((_event, session) => {
        // Keep asynchronous role reads outside the auth callback's internal lock.
        window.setTimeout(() => { void updateAccess(!!session); }, 0);
      });
      unsubscribe = () => subscription.subscription.unsubscribe();
    } catch { /* no auth backend connected */ }
    const timer = window.setInterval(() => { void refresh(); }, 15000);
    return () => { active = false; window.clearInterval(timer); unsubscribe?.(); };
  }, [open, readLocks, readOwner]);

  const save = async (provider: KeyProvider) => {
    setBusy(true); setMessage('');
    try {
      const next = { ...NO_LOCKS, ...(await readLocks().catch(() => NO_LOCKS)) }; setLocks(next);
      if (next[provider]) { setMessage('The owner has locked personal keys for this service.'); return; }
      if (provider === 'gemini') {
        savePersonalKeys({ gemini: gemini.map((key) => key.trim()).filter(Boolean) });
        setGemini(Array(5).fill(''));
      } else { savePersonalKeys({ [provider]: searchKeys[provider].trim() }); setSearchKeys((k) => ({ ...k, [provider]: '' })); }
      clearSearchCache(); setStatus(personalKeyStatus());
      setMessage(`${NAMES[provider]} key saved.`);
    } catch { setMessage('Could not save keys. Please try again.'); }
    finally { setBusy(false); }
  };

  const toggleLock = async (provider: KeyProvider) => {
    setBusy(true); setMessage('');
    try {
      await changeLock({ data: { provider, locked: !locks[provider] } });
      setLocks({ ...NO_LOCKS, ...(await readLocks()) }); clearSearchCache(); setMessage('Lock updated.');
    } catch { setMessage('Could not update the lock. Only the owner can change locks.'); }
    finally { setBusy(false); }
  };

  const signIn = async (provider: 'google' | 'lovable') => {
    setBusy(true); setMessage('');
    try {
      const result = await lovable.auth.signInWithOAuth(provider, { redirect_uri: window.location.origin });
      if (result.error) setMessage('Sign-in did not complete. Please try again.');
    } catch { setMessage('Sign-in is unavailable. Please try again.'); }
    finally { setBusy(false); }
  };

  const lockButton = (provider: KeyProvider) => owner && (
    <Button type="button" variant="ghost" size="sm" className="h-7 px-2 text-xs" disabled={busy || !ready}
      onClick={() => void toggleLock(provider)} aria-label={`${locks[provider] ? 'Unlock' : 'Lock'} ${provider === 'gemini' ? 'Gemini / Groq' : SEARCH_INFO[provider].name} keys`}>
      {locks[provider] ? <LockKeyhole /> : <Unlock />}
    </Button>
  );

  const saved = personalKeys();
  const badge = (on: boolean, text: string) => (
    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium ${on ? 'bg-ink-900 text-ink-50' : 'bg-ink-100 text-ink-500'}`}>{on && <Check className="w-3 h-3" />}{text}</span>
  );
  const keyInput = (value: string, onChange: (v: string) => void, id: string, disabled: boolean, placeholder: string, onEnter?: () => void) => (
    <div className="relative flex-1">
      <input id={id} type={show[id] ? 'text' : 'password'} autoComplete="off" spellCheck={false} maxLength={512} value={value} disabled={disabled}
        onChange={(e) => onChange(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && onEnter) { e.preventDefault(); onEnter(); } }}
        className="input-field pr-10" placeholder={placeholder} />
      <button type="button" className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-ink-500" aria-label={show[id] ? 'Hide key' : 'Show key'} onClick={() => setShow((m) => ({ ...m, [id]: !m[id] }))}>
        {show[id] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
      </button>
    </div>
  );

  const geminiBlock = (
        <details open className="rounded-lg border border-ink-200 p-3">
          <summary className="flex cursor-pointer items-center justify-between gap-2 text-sm font-semibold">
            <span>Gemini AI keys (Groq keys also work)</span>{badge(status.gemini, locks.gemini ? 'Locked' : status.gemini ? `${saved.gemini?.length ?? 0} saved` : 'Shared')}
          </summary>
          <div className="mt-3 space-y-2">
            <AiKeyHealth />
            <div className="flex justify-end">{lockButton('gemini')}</div>
            {gemini.map((value, i) => <div key={i}>{keyInput(value, (v) => setGemini((prev) => prev.map((k, n) => n === i ? v : k)), `gemini-${i}`, busy || locks.gemini, `Gemini or Groq key ${i + 1}${i > 0 ? ' (optional)' : ''}`)}</div>)}
            <Button type="button" className="btn-primary h-auto w-full" disabled={busy || locks.gemini || !gemini[0]?.trim()} onClick={() => void save('gemini')}>Save AI keys</Button>
            {status.gemini && <button type="button" className="text-xs text-ink-500 underline" onClick={() => { removePersonalKey('gemini'); setStatus(personalKeyStatus()); setMessage('AI keys removed.'); }}>Remove saved AI keys</button>}
          </div>
        </details>
  );

  return (
    <Dialog open={open} onOpenChange={(next) => { onOpenChange(next); setMessage(''); setGemini(Array(5).fill('')); setSearchKeys(EMPTY_SEARCH); }}>
      <DialogContent className="bg-ink-50 text-ink-900 border-ink-200 w-[calc(100%-2rem)] max-h-[90dvh] overflow-y-auto rounded-lg p-5 gap-4">
        <DialogHeader>
          <DialogTitle className="tracking-normal">API Keys</DialogTitle>
          <DialogDescription className="text-ink-500">Paste a key and tap Save. Keys are saved on this device and kept after reload.</DialogDescription>
        </DialogHeader>
        {message && <p role="status" className="rounded-md bg-ink-100 px-3 py-2 text-sm text-ink-700">{message}</p>}
        <div className="space-y-3">
          {SEARCH_KEY_PROVIDERS.map((provider) => { const info = SEARCH_INFO[provider]; const locked = locks[provider]; const has = status[provider]; return (
            <div key={provider} className="space-y-3"><section className="rounded-lg border border-ink-200 p-3 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0"><h3 className="font-semibold text-sm">{info.name}</h3>{provider === 'serper' && badge(false, 'Default')}</div>
                <div className="flex items-center gap-1">{badge(has, locked ? 'Locked' : has ? `Saved ${maskKey(saved[provider])}` : 'Not set')}{lockButton(provider)}</div>
              </div>
              <p className="text-xs text-ink-500">{info.hint}</p>
              <div className="flex gap-2">
                {keyInput(searchKeys[provider], (v) => setSearchKeys((k) => ({ ...k, [provider]: v })), provider, busy || locked, has ? 'Paste a new key to replace' : info.label, () => { if (searchKeys[provider].trim()) void save(provider); })}
                <Button type="button" className="btn-primary h-auto px-4" disabled={busy || locked || !searchKeys[provider].trim()} onClick={() => void save(provider)}>Save</Button>
              </div>
              {has && <button type="button" className="text-xs text-ink-500 underline" disabled={busy} onClick={() => { removePersonalKey(provider); clearSearchCache(); setStatus(personalKeyStatus()); setMessage(`${info.name} key removed.`); }}>Remove saved key</button>}
            </section>{provider === 'serper' && geminiBlock}</div>); })}
        </div>
        <Button type="button" variant="ghost" className="btn-ghost h-auto" disabled={busy || !Object.values(status).some(Boolean)} onClick={() => { clearPersonalKeys(); clearSearchCache(); setStatus(personalKeyStatus()); setMessage('All saved keys removed.'); }}>Remove all saved keys</Button>
        <details className="rounded-lg border border-ink-200 p-3">
          <summary className="cursor-pointer text-sm font-semibold">Owner access</summary>
          <div className="mt-3 space-y-2">
          {signedIn ? <>
            <p className="text-xs text-ink-500">{owner ? 'Owner verified. You can lock or unlock personal keys.' : 'Signed in. Owner access has not been assigned to this account.'}</p>
            <Button type="button" variant="ghost" className="btn-ghost h-auto" disabled={busy} onClick={async () => { const { error } = await supabase.auth.signOut(); if (error) setMessage('Could not sign out. Try again.'); }}><LogOut />Sign out</Button>
          </> : <div className="flex flex-wrap gap-2">
            <Button type="button" variant="outline" className="btn-secondary h-auto text-xs px-3" disabled={busy} onClick={() => void signIn('google')}>Sign in with Google</Button>
            <Button type="button" variant="outline" className="btn-secondary h-auto text-xs px-3" disabled={busy} onClick={() => void signIn('lovable')}>Sign in with Lovable</Button>
          </div>}
          </div>
        </details>
      </DialogContent>
    </Dialog>
  );
}
