import { useMemo } from 'react';
import type { AnalysisResult, FaceCategory, StarRating } from '@/lib/types';
import { FACE_CATEGORIES, ratingToScore } from '@/lib/faceTeaching';

interface Props {
  results: AnalysisResult[];
  ratings: StarRating[];
  skill: number;
  next: { imageId: string; imageUrl: string }[];
  onOpen: (r: AnalysisResult) => void;
  onGoSearch: () => void;
}

const avg = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0);

/** Practical taste page: what you rated, how your scale differs from the AI, and what to rate next. */
export default function TasteProfile({ results, ratings, skill, next, onOpen, onGoSearch }: Props) {
  const data = useMemo(() => {
    const latest = new Map<string, StarRating>();
    for (const r of ratings) { const p = latest.get(r.imageId); if (!p || r.timestamp > p.timestamp) latest.set(r.imageId, r); }
    const byImage = new Map<string, AnalysisResult>();
    for (const r of results) if (!r.deletedAt && !byImage.has(r.imageId)) byImage.set(r.imageId, r);
    const rated = [...latest.values()].flatMap((r) => { const res = byImage.get(r.imageId); return res ? [{ res, score: ratingToScore(r.rating) }] : []; })
      .sort((a, b) => b.score - a.score);
    const withAi = rated.filter((r) => r.res.scores.aiLook);
    const gaps = withAi.map((r) => ({ ...r, gap: r.score - (r.res.scores.aiLook!.rawAttractiveness ?? r.res.scores.aiLook!.attractiveness) }));
    const bias = avg(gaps.map((g) => g.gap));
    const disagree = [...gaps].sort((a, b) => Math.abs(b.gap) - Math.abs(a.gap)).filter((g) => Math.abs(g.gap) >= 10).slice(0, 4);
    const cats = FACE_CATEGORIES.map((c: FaceCategory) => {
      const yes = rated.filter((r) => r.res.scores.userFaceCategories?.includes(c));
      return { c, count: yes.length, avg: Math.round(avg(yes.map((r) => r.score))) };
    });
    return { rated, bias, disagree, cats, aiCount: withAi.length };
  }, [results, ratings]);

  const nextResults = next.flatMap((n) => results.find((r) => r.imageId === n.imageId) ?? []);
  const Thumb = ({ r, label }: { r: AnalysisResult; label: string }) => (
    <button onClick={() => onOpen(r)} className="relative aspect-square overflow-hidden rounded-xl bg-ink-100">
      <img src={r.thumbUrl ?? r.imageUrl} alt="" className="h-full w-full object-cover" loading="lazy" />
      <span className="absolute bottom-1 right-1 rounded-md bg-background/90 px-1.5 py-0.5 text-2xs font-semibold text-foreground">{label}</span>
    </button>
  );

  if (!data.rated.length) return (
    <div className="card p-6 space-y-3 text-center">
      <h3 className="text-base font-semibold text-ink-900">Teach the app your taste</h3>
      <p className="text-sm text-ink-600">Open any photo and move the "Your face rating" slider. Every rating changes the AI scores of similar faces right away.</p>
      <button onClick={onGoSearch} className="btn-primary mx-auto">Find photos to rate</button>
    </div>
  );

  const biasText = data.aiCount < 2 ? 'Rate a few more AI-checked photos to see how your scale compares.'
    : Math.abs(data.bias) < 3 ? 'You and the AI score faces about the same.'
    : `You rate faces ${Math.round(Math.abs(data.bias))} points ${data.bias > 0 ? 'higher' : 'lower'} than the AI on average — scores are now shifted toward your scale.`;

  return (
    <div className="space-y-4">
      <section className="card p-5 space-y-2">
        <h3 className="text-sm font-semibold text-ink-900">What the app has learned</h3>
        <div className="grid grid-cols-3 gap-2 text-center">
          <div><p className="text-2xl font-bold text-ink-900">{data.rated.length}</p><p className="text-2xs text-ink-500">photos rated</p></div>
          <div><p className="text-2xl font-bold text-ink-900">{data.aiCount}</p><p className="text-2xs text-ink-500">teaching the AI</p></div>
          <div><p className="text-2xl font-bold text-ink-900">{Math.round(skill * 100)}%</p><p className="text-2xs text-ink-500">taste accuracy</p></div>
        </div>
        <p className="text-xs text-ink-600">{biasText}</p>
      </section>

      {nextResults.length > 0 && (
        <section className="card p-5 space-y-3">
          <h3 className="text-sm font-semibold text-ink-900">Rate these next</h3>
          <p className="text-xs text-ink-500">These faces are the least like anything you've rated, so they teach the most.</p>
          <div className="grid grid-cols-4 gap-2">{nextResults.map((r) => <Thumb key={r.id} r={r} label="Rate" />)}</div>
        </section>
      )}

      <section className="card p-5 space-y-3">
        <h3 className="text-sm font-semibold text-ink-900">Your favourites</h3>
        <div className="grid grid-cols-4 gap-2">{data.rated.slice(0, 8).map(({ res, score }) => <Thumb key={res.id} r={res} label={String(score)} />)}</div>
      </section>

      {data.disagree.length > 0 && (
        <section className="card p-5 space-y-3">
          <h3 className="text-sm font-semibold text-ink-900">Where you and the AI disagree most</h3>
          <div className="grid grid-cols-4 gap-2">{data.disagree.map(({ res, gap }) => <Thumb key={res.id} r={res} label={`${gap > 0 ? '+' : ''}${Math.round(gap)}`} />)}</div>
          <p className="text-2xs text-ink-500">Number = your rating minus the AI's. Re-rate if you changed your mind.</p>
        </section>
      )}

      <section className="card p-5 space-y-2">
        <h3 className="text-sm font-semibold text-ink-900">Your face categories</h3>
        {data.cats.map(({ c, count, avg: a }) => (
          <div key={c} className="flex justify-between text-xs"><span className="text-ink-700">{c}</span>
            <span className="text-ink-500">{count ? `${count} marked · your avg ${a}` : 'none marked yet'}</span></div>
        ))}
      </section>
    </div>
  );
}
