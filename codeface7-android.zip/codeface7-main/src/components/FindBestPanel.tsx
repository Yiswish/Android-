import PhotoHeading from './PhotoHeading';
import BestResultRow from './BestResultRow';
import StarRating from './StarRating';
import { Dialog, DialogContent, DialogTitle } from './ui/dialog';
import LiveAgentView from './LiveAgentView';
import { useEffect, useRef, useState } from 'react';
import { loadLastRun, saveLastRun } from '@/lib/lastRun';
import { deletedIds } from '@/lib/db';
import { bestSearchQuery, bestSearchLabels } from '@/lib/bestSearchContext';
import { AlertTriangle, Trophy, Square, Loader2, Sparkles, Check, Plus, Minus, Trash2, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { AnalysisResult, FaceDetectionResult, SearchResultImage, ImageSource, StarRating as RatingRecord } from '@/lib/types';

const SERVICES: { id: ImageSource; label: string }[] = [
  { id: 'google', label: 'Google' }, { id: 'pexels', label: 'Pexels' }, { id: 'unsplash', label: 'Unsplash' },
  { id: 'openverse', label: 'Openverse' }, { id: 'wikimedia', label: 'Wikimedia' },
  { id: 'elitebabes', label: 'Elite Babes' },
];
const MIN_SIDES = [0, 400, 800, 1200] as const;
const MIN_SCORES = [0, 50, 60, 70, 80] as const;
const ch = (on: boolean) => (on ? 'choice choice-on' : 'choice');

/** Pure filter: drop landscape photos and photos below the minimum short side when sizes are known. */
export function filterCandidates(images: SearchResultImage[], o: { portraitOnly: boolean; minSide: number }): SearchResultImage[] {
  return images.filter((img) => {
    const w = img.width || 0, h = img.height || 0;
    if (o.portraitOnly && w && h && w > h) return false;
    if (o.minSide && w && h && Math.min(w, h) < o.minSide) return false;
    return true;
  });
}
import { searchImages } from '@/lib/search';
import { detectFaces, deriveMetricsFromFace, imageQualityOf } from '@/lib/faceDetection';
import { computeAestheticScores, clampAestheticScores } from '@/lib/metrics';
import { applyAiLook } from '@/lib/aiLookClient';
import { findBest, parseQueries, clampCap, clampTopN, queryPhotoCounts, FIND_BEST_DEFAULT_CAP, FIND_BEST_DEFAULT_TOP_N, FIND_BEST_MAX_CAP, type FindBestProgress, type FindBestResult } from '@/lib/findBest';

export default function FindBestPanel({ onResults, onOpen, onAiCheck, aiBusyIds, onDelete, onRate, ratings }: {
  onResults: (results: AnalysisResult[]) => void;
  onOpen: (result: AnalysisResult) => void;
  onAiCheck: (result: AnalysisResult) => Promise<AnalysisResult>;
  aiBusyIds: Set<string>;
  onDelete: (ids: string[]) => Promise<void>;
  onRate: (imageId: string, rating: number) => void;
  ratings: RatingRecord[];
}) {
  const [ratingPhoto, setRatingPhoto] = useState<AnalysisResult | null>(null);
  const [deletingIds, setDeletingIds] = useState<Set<string>>(new Set());
  const [text, setText] = useState('');
  const [context, setContext] = useState('');
  const [restored, setRestored] = useState(false);
  const [cap, setCap] = useState(FIND_BEST_DEFAULT_CAP);
  const [topN, setTopN] = useState(FIND_BEST_DEFAULT_TOP_N);
  const [topNText, setTopNText] = useState(String(FIND_BEST_DEFAULT_TOP_N));
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [aiMode, setAiMode] = useState<'top' | 'all'>('top');
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState<FindBestProgress | null>(null);
  const [outcome, setOutcome] = useState<{ run: FindBestResult<FaceDetectionResult>; results: AnalysisResult[] } | null>(null);
  const [source, setSource] = useState<ImageSource>('google');
  const [portraitOnly, setPortraitOnly] = useState(true);
  const [minSide, setMinSide] = useState<number>(0);
  const [facesOnly, setFacesOnly] = useState(false);
  const [minScore, setMinScore] = useState(0);
  const [sortBy, setSortBy] = useState<'overall' | 'ai'>('overall');
  const cancel = useRef(false);
  // Restore the last run (results stay until a new search starts).
  useEffect(() => {
    loadLastRun<{ text: string; context?: string; progress: FindBestProgress | null; outcome: typeof outcome }>('best').then((v) => {
      if (!v) { setRestored(true); return; }
      setText((t) => t || v.text || '');
      setContext((c) => c || v.context || '');
      const tombstones = deletedIds();
      const removedImages = new Set(v.outcome?.results.filter((r) => tombstones.has(r.id)).map((r) => r.imageId));
      setProgress((p) => p ?? (v.progress ? { ...v.progress, photos: v.progress.photos.filter((p) => !removedImages.has(p.image.id)), leaderId: v.progress.leaderId && removedImages.has(v.progress.leaderId) ? undefined : v.progress.leaderId } : null));
      setOutcome((o) => {
        if (o || !v.outcome) return o;
        const ranked = v.outcome.run.ranked.filter((_, i) => !tombstones.has(v.outcome?.results[i]?.id ?? ''));
        return { ...v.outcome, results: v.outcome.results.filter((r) => !tombstones.has(r.id)), run: { ...v.outcome.run, ranked, best: ranked[0] } };
      });
      setRestored(true);
    });
  }, []);
  useEffect(() => {
    if (restored && !running) void saveLastRun('best', { text, context, progress, outcome });
  }, [restored, running, text, context, progress, outcome]);
  const lastProgress = useRef<FindBestProgress | null>(null);
  useEffect(() => { lastProgress.current = progress; }, [progress]);

  const deletePhoto = async (result: AnalysisResult) => {
    if (deletingIds.has(result.id)) return;
    setDeletingIds((prev) => new Set(prev).add(result.id));
    try {
      await onDelete([result.id]);
      setOutcome((prev) => {
        if (!prev) return prev;
        const ranked = prev.run.ranked.filter((_, i) => prev.results[i]?.id !== result.id);
        return { ...prev, results: prev.results.filter((r) => r.id !== result.id), run: { ...prev.run, ranked, best: ranked[0] } };
      });
      setProgress((prev) => prev ? { ...prev, photos: prev.photos.filter((p) => p.image.id !== result.imageId), leaderId: prev.leaderId === result.imageId ? undefined : prev.leaderId } : prev);
    } finally {
      setDeletingIds((prev) => { const next = new Set(prev); next.delete(result.id); return next; });
    }
  };

  const run = async () => {
    const queries = parseQueries(text);
    if (!queries.length || running) return;
    const c = clampCap(cap);
    cancel.current = false;
    setRunning(true); setOutcome(null);
    const t0 = performance.now();
    try {
      const photosPerQuery = queryPhotoCounts(queries, c, counts);
      const noMesh = new Set<string>();
      const r = await findBest<FaceDetectionResult>(queries, { photosPerQuery, topN: effectiveTopN, aiMode }, {
        search: async (q) => {
          const target = photosPerQuery[q];
          const images: SearchResultImage[] = [];
          const seen = new Set<string>();
          let page = 1;
          for (let attempt = 0; attempt < 12 && !cancel.current; attempt++) {
            const response = await searchImages({ query: bestSearchQuery(q, context), source, portraitMode: 'all-ages', page, perPage: Math.min(50, Math.max(5, target * 2)) });
            const resp = { ...response, images: bestSearchLabels(response.images, q) };
            if (resp.status?.attempts?.some((a) => a.provider === 'serpapi' && a.reason === 'quota')) return { ...resp, images };
            let added = 0;
            for (const image of filterCandidates(resp.images, { portraitOnly, minSide })) {
              if (!image.url || seen.has(image.url)) continue;
              seen.add(image.url); images.push(image); added++;
            }
            if (images.length >= target || !resp.hasMore || !added) return { ...resp, images };
            page = resp.nextPage ?? page + 1;
          }
          return { images, totalCount: images.length, hasMore: false, source };
        },
        measure: async (image: SearchResultImage) => {
          let face = await detectFaces(image.url, image.id, () => {});
          if (!face.detected) face = await detectFaces(image.url, image.id, () => {});
          let scores = clampAestheticScores(computeAestheticScores(deriveMetricsFromFace(face), face.geometry, imageQualityOf(face)));
          // Side / angled photo without a face mesh: rate it with the AI right away instead of leaving ~4/100.
          if (!face.detected) { noMesh.add(image.url); scores = await applyAiLook(scores, image.url, { aiOnly: true }); if (!scores.aiLook) scores = await applyAiLook(scores, image.url, { aiOnly: true }); }
          return { measured: face, scores };
        },
        aiCheck: (image, scores) => applyAiLook(scores, image.url, { aiOnly: noMesh.has(image.url), batch: true }),
        onProgress: setProgress,
        shouldCancel: () => cancel.current,
        concurrency: 4,
        aiConcurrency: 8, // fills batches of 4 photos per AI request
        searchConcurrency: 4,
      });
      const results: AnalysisResult[] = r.ranked.map((e) => {
        const warnings: string[] = [];
        if (!e.measured.detected) warnings.push('No face mesh (side or angled view) — score is the AI look check only.');
        if (e.measured.geometry?.reliabilityNote) warnings.push(e.measured.geometry.reliabilityNote);
        if (!e.aiChecked) warnings.push(e.aiError ? `Measurement-only score — ${e.aiError}` : 'Measurement-only score — AI look check not run yet.');
        return {
          id: `analysis-${Date.now()}-${Math.random().toString(36).slice(2)}`,
          searchLabel: e.image.searchLabel, imageId: e.image.id, imageUrl: e.image.url, thumbUrl: e.image.thumbUrl, source: e.image.source, timestamp: Date.now(),
          faceDetection: e.measured, scores: e.scores, topArchetypes: [], warnings, duration: performance.now() - t0,
        } as AnalysisResult;
      });
      setOutcome({ run: r, results });
      void saveLastRun('best', { text, context, progress: r.progress ?? lastProgress.current, outcome: { run: r, results } });
      onResults(results);
    } catch {
      setProgress(null);
    } finally {
      setRunning(false);
    }
  };

  const p = progress;
  const queries = parseQueries(text);
  const queryCount = queries.length;
  const photoCounts = queryPhotoCounts(queries, cap, counts);
  const totalPhotos = Object.values(photoCounts).reduce((sum, count) => sum + count, 0);
  const effectiveTopN = clampTopN(topN, totalPhotos || cap);
  const checkPhoto = async (result: AnalysisResult) => {
    const updated = await onAiCheck(result);
    setProgress((prev) => prev ? { ...prev, aiChecks: prev.aiChecks + (updated.scores.aiLook && !result.scores.aiLook ? 1 : 0), photos: prev.photos.map((photo) => photo.image.id === result.imageId ? { ...photo, status: updated.scores.aiLook ? 'complete' : 'failed', score: Math.round(updated.scores.overall), aiScore: updated.scores.aiLook?.attractiveness, detail: updated.scores.aiLookError } : photo) } : prev);
    setOutcome((prev) => { const next = prev ? {
      ...prev,
      results: prev.results.map((r) => r.id === updated.id ? updated : r),
      run: { ...prev.run, ranked: prev.run.ranked.map((e, i) => prev.results[i]?.id === updated.id ? { ...e, scores: updated.scores, aiChecked: !!updated.scores.aiLook, aiError: updated.scores.aiLookError } : e) },
    } : prev;
      if (next) void saveLastRun('best', { text, context, progress: lastProgress.current, outcome: next });
      return next; });
  };
  const input = "w-full min-h-11 rounded-lg border border-input bg-background px-3 text-base sm:text-sm focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-60";
  const okChecks = outcome ? outcome.run.ranked.filter((e) => e.aiChecked).length : 0;
  return (
    <section className="space-y-4" aria-label="Find the best">
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Trophy className="h-5 w-5 text-primary-500 shrink-0" />
          <h3 className="text-base font-semibold text-ink-800 flex-1">Find the best</h3>
          {text && <Button variant="link" size="sm" type="button" disabled={running} onClick={() => { setText(''); setCounts({}); }} className="text-xs text-ink-500">Clear</Button>}
        </div>
        <textarea
          aria-label="Names or searches, one per line"
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={4}
          placeholder={'One name or search per line\ne.g. Natalie Portman'}
          className="w-full text-base sm:text-sm rounded-lg border border-input bg-background p-3 resize-y focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-60"
          disabled={running}
        />
        <label className="block space-y-1.5 text-xs text-ink-600">
          <span>Search context for every name</span>
          <textarea aria-label="Search context for every name" value={context} onChange={(event) => setContext(event.target.value)} rows={2} disabled={running} placeholder="e.g. British actors, solo portrait, red carpet, -group" className="w-full text-base sm:text-sm rounded-lg border border-input bg-background p-3 resize-y focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-60" />
        </label>
        <div className="grid grid-cols-2 gap-3">
          <label className="text-xs text-ink-600 flex flex-col gap-1 min-w-0">
            <span>Photos per name</span>
            <NumberBox label="Photos per name" value={cap} disabled={running} onCommit={(n) => setCap(clampCap(n))} className={input} />
          </label>
          <label className="text-xs text-ink-600 flex flex-col gap-1 min-w-0">
            <span>AI checks</span>
            <input aria-label="AI checks" type="number" inputMode="numeric" min={1} max={totalPhotos || cap} value={aiMode === 'all' ? String(totalPhotos) : topNText === '' ? '' : String(effectiveTopN)} disabled={running || aiMode === 'all'}
              onChange={(e) => { setTopNText(e.target.value); const n = Math.floor(Number(e.target.value)); if (n >= 1) setTopN(n); }}
              onBlur={() => { setTopN(effectiveTopN); setTopNText(String(effectiveTopN)); }} className={input} />
          </label>
        </div>
        <div role="radiogroup" aria-label="Automatic AI checks" className="grid grid-cols-2 gap-2">
          <Button type="button" variant="outline" role="radio" aria-checked={aiMode === 'top'} disabled={running} className={`min-h-11 rounded-lg text-xs ${ch(aiMode === 'top')}`} onClick={() => setAiMode('top')}>{aiMode === 'top' && <Check />}Best {effectiveTopN}</Button>
          <Button type="button" variant="outline" role="radio" aria-checked={aiMode === 'all'} disabled={running} className={`min-h-11 rounded-lg text-xs ${ch(aiMode === 'all')}`} onClick={() => setAiMode('all')}>{aiMode === 'all' && <Check />}Every photo</Button>
        </div>

        <details className="border-y border-input py-2 [&_summary]:cursor-pointer">
          <summary className="text-xs font-medium text-ink-600 min-h-8 flex items-center">More options</summary>
          <div className="space-y-3 pt-2">
            {queries.length > 0 && <div>
              <span className="text-xs text-ink-600">Photos for each name</span>
              <div className="divide-y divide-ink-100">
                {queries.map((query) => <label key={query} className="flex items-center gap-3 py-1.5 text-xs text-ink-700">
                  <span className="min-w-0 flex-1 break-words">{query}</span>
                  <Button type="button" variant="outline" size="icon" aria-label={`Fewer photos for ${query}`} disabled={running || photoCounts[query] <= 1}
                    onClick={() => setCounts((prev) => ({ ...prev, [query]: clampCap((photoCounts[query] ?? cap) - 1) }))} className="shrink-0 h-10 w-10"><Minus /></Button>
                  <NumberBox label={`Photos for ${query}`} value={photoCounts[query]} disabled={running}
                    onCommit={(n) => setCounts((prev) => ({ ...prev, [query]: clampCap(n) }))}
                    className="w-16 shrink-0 min-h-10 rounded-lg border border-ink-200 bg-background px-2 text-center text-base" />
                  <Button type="button" variant="outline" size="icon" aria-label={`More photos for ${query}`} disabled={running || photoCounts[query] >= FIND_BEST_MAX_CAP}
                    onClick={() => setCounts((prev) => ({ ...prev, [query]: clampCap((photoCounts[query] ?? cap) + 1) }))} className="shrink-0 h-10 w-10"><Plus /></Button>
                </label>)}
              </div>
            </div>}
            <div className="space-y-1.5">
              <span className="text-xs text-ink-600">Search with</span>
              <div className="flex gap-1.5 overflow-x-auto pb-1" role="radiogroup" aria-label="Search service">
                {SERVICES.map((sv) => (
                  <Button key={sv.id} variant="outline" type="button" role="radio" aria-checked={source === sv.id} disabled={running} onClick={() => setSource(sv.id)}
                    className={`shrink-0 min-h-10 rounded-full px-4 text-xs font-medium ${ch(source === sv.id)}`}>{source === sv.id && <Check />}{sv.label}</Button>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Button variant="outline" type="button" role="switch" aria-checked={portraitOnly} disabled={running} onClick={() => setPortraitOnly((v) => !v)}
                className={`min-h-11 rounded-xl px-3 text-xs font-medium ${ch(portraitOnly)}`}>{portraitOnly && <Check />}Upright only</Button>
              <select aria-label="Minimum photo size" value={minSide} disabled={running} onChange={(e) => setMinSide(Number(e.target.value))} className={`${input} text-xs`}>
                {MIN_SIDES.map((m) => <option key={m} value={m}>{m ? `At least ${m}px` : 'Any size'}</option>)}
              </select>
            </div>
          </div>
        </details>

        {running
          ? <Button variant="outline" className="w-full h-12" onClick={() => { cancel.current = true; }}><Square />Stop</Button>
          : <Button className="w-full h-12 text-base" disabled={!queryCount || !restored} onClick={run}><Trophy />{queryCount ? `Find the best · ${totalPhotos} photos` : 'Type a name to start'}</Button>}
      </div>

      {outcome?.run.stopped && (
        <div role="status" className="flex items-start gap-2 p-3 rounded-xl bg-warning-50 border border-warning-200 text-sm text-warning-700">
          <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />
          <p><b>{outcome.run.stopped.provider}</b> stopped the run: {outcome.run.stopped.reason}. {outcome.run.stopped.provider === 'SerpAPI' ? 'Check the search key or plan.' : 'The AI keys are out of quota — try again later or add a key.'} Results so far are kept below.</p>
        </div>
      )}

      {outcome && outcome.results.length === 0 && !outcome.run.stopped && (
        <p className="text-sm text-ink-500 text-center">No photos could be analysed for these names.</p>
      )}

      {outcome && outcome.results.length > 0 && (() => {
        const shown = outcome.results.map((r, idx) => ({ r, e: outcome.run.ranked[idx] }))
          .filter(({ r }) => !deletingIds.has(r.id) && (!facesOnly || r.faceDetection?.detected) && r.scores.overall >= minScore)
          .sort((a, b) => sortBy === 'ai' ? (b.r.scores.aiLook?.attractiveness ?? -1) - (a.r.scores.aiLook?.attractiveness ?? -1) : b.r.scores.overall - a.r.scores.overall);
        return <div className="space-y-3">
          <div className="flex items-center gap-2 flex-wrap">
            <h4 className="text-sm font-semibold text-ink-800 flex-1">{shown.length} results · {okChecks} AI checked</h4>
            <select aria-label="Sort results" value={sortBy} onChange={(e) => setSortBy(e.target.value as 'overall' | 'ai')} className="min-h-9 rounded-lg border border-input bg-background px-2 text-xs">
              <option value="overall">Sort: score</option><option value="ai">Sort: AI look</option>
            </select>
            <select aria-label="Minimum score" value={minScore} onChange={(e) => setMinScore(Number(e.target.value))} className="min-h-9 rounded-lg border border-input bg-background px-2 text-xs">
              {MIN_SCORES.map((m) => <option key={m} value={m}>{m ? `${m}+` : 'Any score'}</option>)}
            </select>
            <Button variant="outline" type="button" role="switch" aria-checked={facesOnly} onClick={() => setFacesOnly((v) => !v)} className={`min-h-9 rounded-lg px-2.5 text-xs gap-1 ${ch(facesOnly)}`}>{facesOnly && <Check className="h-3 w-3" />}Faces</Button>
          </div>
          <ol className="grid gap-2 sm:grid-cols-2">
            {shown.map(({ r, e }, i) => {
              const busy = aiBusyIds.has(r.id);
              return (
                <BestResultRow key={r.id} first={i === 0} onDelete={() => { void deletePhoto(r); }} onRate={() => setRatingPhoto(r)}>
                  <Button variant="ghost" type="button" className="relative w-20 h-24 p-0 rounded-lg overflow-hidden shrink-0 bg-ink-100" aria-label={`Open analysis for ${r.searchLabel ?? e.image.alt}`} onClick={() => onOpen(r)}>
                    <img src={e.image.thumbUrl || e.image.url} data-search-label={r.searchLabel ?? ''} alt={e.image.alt} draggable={false} className="w-full h-full object-cover" />
                    <span className="absolute top-1 left-1 rounded-md bg-primary px-1.5 text-[10px] font-semibold text-primary-foreground">{i === 0 ? <Trophy className="h-3 w-3 inline" /> : `#${i + 1}`}</span>
                  </Button>
                  <div className="min-w-0 flex-1 space-y-1">
                    <PhotoHeading name={r.searchLabel ?? e.query} className="text-sm" />
                    {e.aiChecked
                      ? <p className="text-[11px] text-primary-600 inline-flex items-center gap-1"><Sparkles className="h-3 w-3" />AI checked{r.scores.aiLook ? ` · look ${Math.round(r.scores.aiLook.attractiveness)}` : ''}</p>
                      : <Button variant="link" type="button" disabled={busy} onClick={() => { void checkPhoto(r); }} className="h-auto p-0 text-[11px] text-warning-700 gap-1 whitespace-normal justify-start text-left">
                          {busy ? <Loader2 className="h-3 w-3 animate-spin" /> : <Sparkles className="h-3 w-3" />}{busy ? 'Checking…' : e.aiError || r.scores.aiLookError ? 'AI failed · retry' : 'Run AI check'}
                        </Button>}
                    <div className="flex items-center gap-1">
                      <Button variant="ghost" size="icon" className="h-8 w-8" aria-label={`Rate ${r.searchLabel ?? e.query}`} title="Rate" onClick={() => setRatingPhoto(r)}><Star className="h-4 w-4" /></Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" aria-label={`Delete ${r.searchLabel ?? e.query}`} title="Delete" onClick={() => { void deletePhoto(r); }}><Trash2 className="h-4 w-4" /></Button>
                    </div>
                  </div>
                  <Button variant="ghost" type="button" onClick={() => onOpen(r)} className="h-auto flex-col gap-0 shrink-0 text-right p-1" aria-label="View results">
                    <span className="block text-2xl font-bold text-ink-900 leading-none">{Math.round(r.scores.overall)}</span>
                    <span className="text-[10px] text-ink-400">/100</span>
                  </Button>
                </BestResultRow>
              );
            })}
          </ol>
        </div>;
      })()}

      {p && <LiveAgentView progress={p} running={running} />}
      <Dialog open={!!ratingPhoto} onOpenChange={(open) => { if (!open) setRatingPhoto(null); }}>
        <DialogContent aria-describedby={undefined} className="max-w-sm rounded-lg">
          <DialogTitle>{ratingPhoto?.searchLabel ?? 'Rate photo'}</DialogTitle>
          {ratingPhoto && <>
            <img src={ratingPhoto.thumbUrl ?? ratingPhoto.imageUrl} alt="Photo to rate" className="w-full h-52 object-contain rounded-lg" draggable={false} />
            <StarRating imageId={ratingPhoto.imageId} initialRating={ratings.find((r) => r.imageId === ratingPhoto.imageId)?.rating}
              onRate={(imageId, rating) => onRate(imageId, rating)} />
            <Button onClick={() => setRatingPhoto(null)}>Done</Button>
          </>}
        </DialogContent>
      </Dialog>
    </section>
  );
}

/** Number box that can be fully cleared while typing; the number is applied as you type and fixed on leaving the box. */
function NumberBox({ label, value, disabled, onCommit, className }: { label: string; value: number; disabled?: boolean; onCommit: (n: number) => void; className?: string }) {
  const [draft, setDraft] = useState<string | null>(null);
  return (
    <input aria-label={label} type="text" inputMode="numeric" pattern="[0-9]*" disabled={disabled} className={className}
      value={draft ?? String(value)}
      onFocus={(e) => e.target.select()}
      onChange={(e) => { const t = e.target.value.replace(/[^0-9]/g, ''); setDraft(t); if (t !== '' && Number(t) >= 1) onCommit(Number(t)); }}
      onBlur={() => setDraft(null)} />
  );
}
