import { useState } from 'react';
import type { DetectedFace } from '@/lib/types';

/** Visual explanation: marks eyes, jaw and the symmetry line on the photo, coloured by each zone's score. */
const LEFT_EYE = [33, 160, 158, 133, 153, 144];
const RIGHT_EYE = [263, 387, 385, 362, 380, 373];
const JAW = [234, 93, 132, 58, 172, 136, 150, 149, 176, 148, 152, 377, 400, 378, 379, 365, 397, 288, 361, 323, 454];
const MIDLINE = [10, 151, 9, 8, 168, 6, 197, 195, 5, 4, 1, 19, 94, 2, 164, 0, 17, 18, 200, 199, 175, 152];

const tone = (s: number) => (s >= 75 ? 'text-success-500' : s >= 50 ? 'text-warning-500' : 'text-error-500');
const avg = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : NaN);

export default function FaceZoneMap({ src, face }: { src: string; face?: DetectedFace }) {
  const [size, setSize] = useState({ w: 0, h: 0 });
  const mesh = face?.meshLandmarks;
  const g = face?.geometry;
  if (!mesh || mesh.length < 468 || !g) return null;

  const eyeScore = avg(g.ratios.filter(r => r.id.includes('eye')).map(r => r.score));
  const sym = g.groups.find(x => x.id === 'symmetry')?.score ?? g.symmetryPercent;
  const zones = [
    { id: 'eyes', label: 'Eyes', score: eyeScore, weight: g.groups.find(x => x.id === 'golden')?.weight },
    { id: 'jaw', label: 'Jaw & mouth', score: g.mouthJawScore, weight: g.groups.find(x => x.id === 'mouthJaw')?.weight },
    { id: 'sym', label: 'Symmetry', score: sym, weight: g.groups.find(x => x.id === 'symmetry')?.weight },
  ].filter(z => Number.isFinite(z.score));
  const score = (id: string) => zones.find(z => z.id === id)?.score ?? 0;

  const pts = (ids: number[]) => ids.map(i => `${mesh[i].x * size.w},${mesh[i].y * size.h}`).join(' ');
  const sw = Math.max(size.w, size.h) / 220;

  return (
    <div className="card p-4 space-y-3">
      <p className="text-2xs uppercase tracking-wide text-ink-400">Where the score comes from</p>
      <div className="relative rounded-xl overflow-hidden">
        <img src={src} alt="Face zones" className="block w-full" draggable={false}
          onLoad={e => setSize({ w: e.currentTarget.naturalWidth, h: e.currentTarget.naturalHeight })} />
        {size.w > 0 && (
          <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox={`0 0 ${size.w} ${size.h}`} preserveAspectRatio="xMidYMid meet">
            <g className={tone(score('sym'))}>
              <polyline points={pts(MIDLINE)} fill="none" stroke="currentColor" strokeWidth={sw * 0.7} strokeDasharray={`${sw * 2} ${sw * 1.5}`} />
            </g>
            <g className={tone(score('jaw'))}>
              <polyline points={pts(JAW)} fill="none" stroke="currentColor" strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" />
            </g>
            {zones.some(z => z.id === 'eyes') && (
              <g className={tone(score('eyes'))}>
                <polygon points={pts(LEFT_EYE)} fill="currentColor" fillOpacity={0.3} stroke="currentColor" strokeWidth={sw * 0.6} />
                <polygon points={pts(RIGHT_EYE)} fill="currentColor" fillOpacity={0.3} stroke="currentColor" strokeWidth={sw * 0.6} />
              </g>
            )}
          </svg>
        )}
      </div>
      <ul className="grid grid-cols-3 gap-2">
        {zones.map(z => (
          <li key={z.id} className="rounded-lg border border-ink-100 p-2 text-center">
            <span className={`block text-lg font-bold ${tone(z.score)}`}>{Math.round(z.score)}</span>
            <span className="block text-2xs text-ink-600">{z.label}</span>
            {z.weight != null && <span className="block text-2xs text-ink-400">{Math.round(z.weight * 100)}% weight</span>}
          </li>
        ))}
      </ul>
      <p className="text-2xs text-ink-400">Green = helps the score, amber = average, red = pulls it down.</p>
    </div>
  );
}
