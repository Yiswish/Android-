import { useState, useCallback, useEffect, useMemo, useRef } from 'react';
import { Sparkles, Search, BarChart3, Clock, GitCompare, User, AlertTriangle, Settings, ArrowLeft, Trophy, Compass } from 'lucide-react';
import DiscoverForYou from '@/components/DiscoverForYou';
import TasteCalibration from '@/components/TasteCalibration';
import BatchAnalysisPanel, { type BatchPhoto } from '@/components/BatchAnalysisPanel';
import { analyzeInParallel } from '@/lib/batchAnalysis';
import { Button } from '@/components/ui/button';
import SettingsPanel from '@/components/SettingsPanel';
import { useUserPrefs, applyLook } from '@/lib/userPrefs';
import type {
  SearchResultImage,
  AnalysisResult,
  AnalysisLogEntry,
  ViewMode,
  ComparisonItem,
  HistoryEntry,
  PreferenceProfile,
  SearchFilters,
} from '@/lib/types';
import { searchImages, createUploadedImage, applyFilters, defaultFilters } from '@/lib/search';
import { detectFaces, deriveMetricsFromFace, imageQualityOf } from '@/lib/faceDetection';
import { applyAiLook, applyFinalAnalyst, getBodyLook, withBodyLook, setBodyExamples, setFaceExamples } from '@/lib/aiLookClient';
import { faceExamples, liveFace, softTop } from '@/lib/faceTeaching';
import type { FaceCategory } from '@/lib/types';
import { bodyExamples, cleanUserBody, type BodyKey } from '@/lib/bodyTeaching';
import { computeAestheticScores, clampAestheticScores } from '@/lib/metrics';
import { buildPreferenceProfile } from '@/lib/preferenceEngine';
import { generateComparisonSummary } from '@/lib/explanations';
import homeHero from '@/assets/aesthetics_lock_home.jpg.asset.json';
import { saveAnalysis, updateAnalysis, loadFavourites, loadAllAnalyses, saveStarRating, loadStarRatings, deleteAnalyses, deleteAllAnalyses, resetEverything, deletedIds } from '@/lib/db';
import { faceTypeMatch } from '@/lib/faceType';
import { buildTasteModel, computeTasteMatch, tasteExtrasOf, suggestNextToRate, tasteSkill, TASTE_MIN_RATINGS } from '@/lib/preferenceEngine';
import type { StarRating as StarRatingRecord, SearchStatus, FavouriteRanking } from '@/lib/types';
import { toast } from 'sonner';
import { haptic } from '@/lib/haptics';
import { cacheHistoryEntry, loadCachedHistory, clearCachedHistory, removeCachedEntries } from '@/lib/offlineCache';
import SearchBar from '@/components/SearchBar';
import ImageGrid from '@/components/ImageGrid';
import AnalyzingView from '@/components/AnalyzingView';
import ResultsView from '@/components/ResultsView';
import HistoryView from '@/components/HistoryView';
import ComparisonView from '@/components/ComparisonView';
import InstallAppButton from '@/components/InstallAppButton';
import TasteProfile from '@/components/TasteProfile';
import ExportReport from '@/components/ExportReport';
import ErrorBoundary from '@/components/ErrorBoundary';
import FindBestPanel from '@/components/FindBestPanel';
import { loadLastRun, saveLastRun } from '@/lib/lastRun';
import PhotoDragLayer from '@/components/PhotoDragLayer';
import PhotoHeading, { PhotoNameSearchContext } from './PhotoHeading';
import { youngNameQuery } from '@/lib/photoLabel';
import { checkAnalysisAi } from '@/lib/analysisAi';
import { previousView } from '@/lib/viewNavigation';
import PhotoActions from './PhotoActions';

const PROVIDER_NAMES: Record<SearchStatus['provider'], string> = { serpapi: 'SerpAPI', serper: 'Serper', pexels: 'Pexels', unsplash: 'Unsplash', openverse: 'Openverse', wikimedia: 'Wikimedia Commons',
  elitebabes: 'Elite Babes', curated: 'the built-in curated set' };

function App() {
  const [view, setActiveView] = useState<ViewMode>('search');
  const viewRef = useRef<ViewMode>('search');
  const backStack = useRef<ViewMode[]>([]);
  const setView = useCallback((target: ViewMode) => {
    if (target === viewRef.current) return;
    if (viewRef.current !== 'analyzing') backStack.current.push(viewRef.current);
    viewRef.current = target;
    setActiveView(target);
  }, []);
  const goBack = useCallback(() => {
    const previous = previousView(backStack.current);
    backStack.current = previous.stack;
    viewRef.current = previous.view;
    setActiveView(previous.view);
    haptic('light');
  }, []);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const prefs = useUserPrefs();
  useEffect(() => { applyLook(prefs); }, [prefs]);
  const [batchPhotos, setBatchPhotos] = useState<BatchPhoto[]>([]);
  const [batchStopping, setBatchStopping] = useState(false);
  const batchRunning = useRef(false);
  const [images, setImages] = useState<SearchResultImage[]>([]);
  const [rawImages, setRawImages] = useState<SearchResultImage[]>([]);
  const [selectedImage, setSelectedImage] = useState<SearchResultImage | null>(null);
  const [searching, setSearching] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [nextPage, setNextPage] = useState(2);
  const [currentQuery, setCurrentQuery] = useState('');
  const [currentSource, setCurrentSource] = useState<SearchResultImage['source']>('google');
  const [filters, setFilters] = useState<SearchFilters>(defaultFilters);
  const [totalCount, setTotalCount] = useState(0);
  const [searchStatus, setSearchStatus] = useState<SearchStatus | undefined>();

  // Analysis state
  const [logs, setLogs] = useState<AnalysisLogEntry[]>([]);
  const [progress, setProgress] = useState(0);
  const [boundingBox, setBoundingBox] = useState<{ x: number; y: number; width: number; height: number } | undefined>();
  const [currentResult, setCurrentResult] = useState<AnalysisResult | null>(null);
  const pendingSaves = useRef(new Map<string, Promise<AnalysisResult>>());
  const aiChecking = useRef(new Set<string>());
  const [aiBusyIds, setAiBusyIds] = useState<Set<string>>(new Set());
  const [selectedFaceIndex, setSelectedFaceIndex] = useState(0);

  // History & comparison
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [allResults, setAllResults] = useState<AnalysisResult[]>([]);
  const [discoveryCandidates, setDiscoveryCandidates] = useState<AnalysisResult[]>([]);
  const photoNames = useMemo(() => {
    const names = new Map<string, string>();
    for (const result of allResults) if (result.searchLabel) names.set(result.imageId, result.searchLabel);
    return names;
  }, [allResults]);
  const [compareItems, setCompareItems] = useState<ComparisonItem[]>([]);
  const photoSearchNames = useMemo(() => {
    const names = new Map<string, string>();
    const add = (url: string | undefined, label: string | undefined) => {
      if (url && label?.trim()) names.set(url, label.trim());
    };
    for (const image of [...rawImages, ...images, ...(selectedImage ? [selectedImage] : [])]) {
      add(image.url, image.searchLabel); add(image.thumbUrl, image.searchLabel);
    }
    for (const result of [...allResults, ...compareItems.map((item) => item.result), ...batchPhotos.flatMap((photo) => photo.result ? [photo.result] : []), ...(currentResult ? [currentResult] : [])]) {
      add(result.imageUrl, result.searchLabel); add(result.thumbUrl, result.searchLabel);
    }
    for (const entry of history) add(entry.thumbnailUrl, entry.searchLabel);
    return names;
  }, [rawImages, images, selectedImage, allResults, compareItems, batchPhotos, currentResult, history]);

  // Profile
  const [profile, setProfile] = useState<PreferenceProfile | null>(null);
  const [ratings, setRatings] = useState<StarRatingRecord[]>([]);
  const [favourites, setFavourites] = useState<FavouriteRanking[]>([]);
  const tasteModel = useMemo(() => buildTasteModel(allResults, ratings, favourites), [allResults, ratings, favourites]);
  const tasteMatch = useMemo(
    () => (currentResult ? computeTasteMatch(currentResult.scores.metrics, tasteModel, currentResult.imageId, currentResult.scores.overall, tasteExtrasOf(currentResult)) : undefined),
    [currentResult, tasteModel],
  );

  // Minimum taste-match filter for the search grid (0 = off)
  const [minTaste, setMinTaste] = useState(0);
  const tasteByUrl = useMemo(() => {
    const m = new Map<string, number>();
    if (tasteModel.samples.length === 0) return m;
    for (const r of allResults) {
      if (m.has(r.imageUrl)) continue;
      const t = computeTasteMatch(r.scores.metrics, tasteModel, r.imageId, r.scores.overall, tasteExtrasOf(r));
      if (t) m.set(r.imageUrl, t.score);
    }
    return m;
  }, [allResults, tasteModel]);
  const scoreByUrl = useMemo(() => {
    const m = new Map<string, number>();
    for (const r of allResults) if (!m.has(r.imageUrl)) m.set(r.imageUrl, r.scores.overall);
    return m;
  }, [allResults]);
  const faceTypeByUrl = useMemo(() => {
    const m = new Map<string, number>();
    for (const r of allResults) {
      if (m.has(r.imageUrl)) continue;
      const f = faceTypeMatch(r.faceDetection?.geometry, r.scores?.metrics);
      if (f) m.set(r.imageUrl, f.score);
    }
    return m;
  }, [allResults]);
  const [sortBy, setSortBy] = useState<'none' | 'score' | 'taste' | 'facetype'>('none');
  const gridImages = useMemo(() => {
    const kept = minTaste <= 0 ? images : images.filter((img) => {
      const t = tasteByUrl.get(img.url);
      return t === undefined || t >= minTaste;
    });
    if (sortBy === 'none') return kept;
    const m = sortBy === 'score' ? scoreByUrl : sortBy === 'facetype' ? faceTypeByUrl : tasteByUrl;
    return [...kept].sort((a, b) => (m.get(b.url) ?? -1) - (m.get(a.url) ?? -1));
  }, [images, minTaste, tasteByUrl, scoreByUrl, faceTypeByUrl, sortBy]);

  // Export modal
  const [showExport, setShowExport] = useState(false);

  const navItems: Array<{ id: ViewMode; label: string; icon: typeof Search }> = [
    { id: 'search', label: 'Search', icon: Search },
    { id: 'best', label: 'Best', icon: Trophy },
    { id: 'discover', label: 'For You', icon: Compass },
    { id: 'history', label: 'History', icon: Clock },
    { id: 'compare', label: 'Compare', icon: GitCompare },
    { id: 'profile', label: 'Taste', icon: User },
  ];

  const activeNavViewRef = useRef<ViewMode>('search');
  const navOrder: ViewMode[] = ['search', 'best', 'discover', 'history', 'compare', 'profile'];

  const [slideDir, setSlideDir] = useState<'left' | 'right'>('left');
  const switchView = useCallback((target: ViewMode) => {
    haptic('selection');
    setSlideDir(navOrder.indexOf(target) >= navOrder.indexOf(activeNavViewRef.current) ? 'left' : 'right');
    setView(target);
  }, []);

  // Apply filters to raw images
  useEffect(() => {
    setImages(applyFilters(rawImages, filters));
  }, [rawImages, filters]);

  // Load history on mount — from IndexedDB cache first, then Supabase
  useEffect(() => {
    loadCachedHistory().then((cached) => {
      if (cached.length > 0) {
        const tomb = deletedIds();
        setHistory((cached as HistoryEntry[]).filter((e) => !tomb.has(e.id)));
      }
    });
    loadStarRatings().then(setRatings);
    loadFavourites().then(setFavourites);
    loadAllAnalyses().then((results) => {
      setAllResults(results);
      setHistory(results.filter((r) => !r.deletedAt).map((r) => ({ id: r.id, thumbnailUrl: r.thumbUrl ?? r.imageUrl, timestamp: r.timestamp, overallScore: r.scores.overall, topArchetype: '', searchLabel: r.searchLabel, source: r.source })));
      setProfile(buildPreferenceProfile(results));
    });
  }, []);

  const searchSeq = useRef(0);
  // Keep the last search + results until a new search is run (survives tab switches and reloads).
  const searchRestored = useRef(false);
  useEffect(() => {
    loadLastRun<{ query: string; source: SearchResultImage['source']; images: SearchResultImage[]; totalCount: number; hasMore: boolean; nextPage: number; status?: SearchStatus }>('search').then((v) => {
      if (v && searchSeq.current === 0) {
        setCurrentQuery(v.query); setCurrentSource(v.source); setRawImages(v.images ?? []);
        setTotalCount(v.totalCount ?? 0); setHasMore(!!v.hasMore); setNextPage(v.nextPage ?? 2); setSearchStatus(v.status);
      }
      searchRestored.current = true;
    });
  }, []);
  useEffect(() => {
    if (!searchRestored.current || searching || !currentQuery) return;
    void saveLastRun('search', { query: currentQuery, source: currentSource, images: rawImages.filter((i) => !i.url.startsWith('blob:')), totalCount, hasMore, nextPage, status: searchStatus });
  }, [rawImages, searching, currentQuery, currentSource, totalCount, hasMore, nextPage, searchStatus]);
  const handleSearch = useCallback(async (query: string, source: SearchResultImage['source']) => {
    haptic('light');
    const seq = ++searchSeq.current;
    setSearching(true);
    setCurrentQuery(query);
    setCurrentSource(source);
    setView('search');
    setFilters(defaultFilters);
    try {
      const resp = await searchImages({ query, source, page: 1 });
      if (seq !== searchSeq.current) return;
      setRawImages(dedupeImages([], resp.images));
      setSearchStatus(resp.status);
      setTotalCount(resp.totalCount);
      setHasMore(resp.hasMore);
      setNextPage(resp.nextPage ?? 2);
    } catch {
      if (seq !== searchSeq.current) return;
      // Search failed: keep the previous results on screen.
    }
    if (seq === searchSeq.current) setSearching(false);
  }, []);

  const handleLoadMore = useCallback(async () => {
    if (!currentQuery || loadingMore) return;
    haptic('light');
    setLoadingMore(true);
    const seq = searchSeq.current;
    try {
      const resp = await searchImages({ query: currentQuery, source: currentSource, page: nextPage });
      if (seq !== searchSeq.current) { setLoadingMore(false); return; }
      setRawImages((prev) => dedupeImages(prev, resp.images));
      if (resp.totalCount) setTotalCount((prev) => Math.max(prev, resp.totalCount));
      setHasMore(resp.hasMore && resp.images.length > 0);
      setNextPage(resp.nextPage ?? nextPage + 1);
    } catch {
      // ignore
    }
    setLoadingMore(false);
  }, [currentQuery, currentSource, nextPage, loadingMore]);

  function dedupeImages(prev: SearchResultImage[], next: SearchResultImage[]) {
    const seen = new Set(prev.map((i) => i.url));
    const out = [...prev];
    for (const img of next) if (img.url && !seen.has(img.url)) { seen.add(img.url); out.push(img); }
    return out;
  }

  const handleUpload = useCallback((file: File) => {
    const url = URL.createObjectURL(file);
    const img = createUploadedImage(url, file.name);
    setRawImages((prev) => [img, ...prev]);
    setSelectedImage(img);
    handleImageSelect(img);
  }, []);

  // ---- Batch analyse: score every photo in the current results without leaving the grid ----
  const [batch, setBatch] = useState<{ done: number; total: number } | null>(null);
  const batchCancel = useRef(false);
  const analyzeQuietly = useCallback(async (image: SearchResultImage): Promise<AnalysisResult> => {
    const t0 = performance.now();
    let face = await detectFaces(image.url, image.id, () => {});
    if (!face.detected) face = await detectFaces(image.url, image.id, () => {});
    const geoScores = clampAestheticScores(computeAestheticScores(deriveMetricsFromFace(face), face.geometry, imageQualityOf(face)));
    const [faceScores, body] = await Promise.all([applyAiLook(geoScores, image.url, { aiOnly: !face.detected }), getBodyLook(image.url)]);
    const scores = withBodyLook(faceScores, body);
    const warnings: string[] = [];
    if (!face.detected) warnings.push('No face mesh (side or angled view) — the score is the AI look check only.');
    if (face.geometry?.reliabilityNote) warnings.push(face.geometry.reliabilityNote);
    return {
      id: `analysis-${Date.now()}-${Math.random().toString(36).slice(2)}`,
      imageId: image.id, imageUrl: image.url, searchLabel: image.searchLabel, source: image.source, timestamp: Date.now(),
      faceDetection: face, scores, topArchetypes: [], warnings, duration: performance.now() - t0,
    };
  }, []);
  const runBatch = useCallback(async (list: SearchResultImage[]): Promise<AnalysisResult[]> => {
    if (batchRunning.current) return [];
    const known = new Set(allResults.map((r) => r.imageUrl));
    const todo = list.filter((i) => !known.has(i.url));
    if (!todo.length) { toast.info('These photos have already been analysed.'); return []; }
    batchRunning.current = true;
    batchCancel.current = false;
    setBatchStopping(false);
    setBatchPhotos(todo.map((image) => ({ image, status: 'queued' })));
    setBatch({ done: 0, total: todo.length });
    try {
      return await analyzeInParallel({
        items: todo,
        analyze: analyzeQuietly,
        shouldStop: () => batchCancel.current,
        onUpdate: (index, status, r, error) => {
          setBatchPhotos((prev) => prev.map((photo, i) => i === index ? { ...photo, status, result: r, error } : photo));
          if (status === 'complete' || status === 'failed' || status === 'cancelled') setBatch((prev) => prev ? { ...prev, done: prev.done + 1 } : prev);
          if (!r) return;
          saveAnalysis(r).catch(() => { toast.error('A photo result could not be saved.'); });
          setAllResults((prev) => { const u = [r, ...prev]; setProfile(buildPreferenceProfile(u)); return u; });
          const h: HistoryEntry = { id: r.id, thumbnailUrl: r.imageUrl, timestamp: r.timestamp, overallScore: r.scores.overall, topArchetype: '', searchLabel: r.searchLabel, source: r.source };
          setHistory((prev) => [h, ...prev]);
          cacheHistoryEntry(h).catch(() => {});
          // Do not keep submitting queued photos after an account/access block.
          const aiError = r.scores.aiLookError || r.scores.bodyLookError || '';
          if (/credits|disabled|denied|not enabled|not available|unavailable|permission|quota|rate limit|refus/i.test(aiError)) {
            batchCancel.current = true;
            setBatchStopping(true);
          }
        },
      });
    } finally {
      batchRunning.current = false;
      setBatch(null);
      haptic('success');
    }
  }, [allResults, analyzeQuietly]);

  const handleUploadMany = useCallback(async (files: File[]) => {
    if (batchRunning.current) { toast.info('Wait for the active photos to finish.'); return; }
    const imgs = files.map((f) => createUploadedImage(URL.createObjectURL(f), f.name));
    setRawImages((prev) => [...imgs, ...prev]);
    setView('search');
    const results = await runBatch(imgs);
    if (results.length) toast.success(`Analysed ${results.length} photo(s)`);
  }, [runBatch]);

  // Compare: analyse several photos and drop them straight into the comparison.
  const [compareBusy, setCompareBusy] = useState(false);
  const handleCompareUpload = useCallback(async (files: File[]) => {
    if (!files.length) return;
    if (batchRunning.current) { toast.info('Wait for the active photos to finish.'); return; }
    const imgs = files.map((f) => createUploadedImage(URL.createObjectURL(f), f.name));
    setRawImages((prev) => [...imgs, ...prev]);
    setCompareBusy(true);
    try {
      const results = await runBatch(imgs);
      setCompareItems((prev) => {
        const have = new Set(prev.map((p) => p.result.id));
        return [...prev, ...results.filter((r) => !have.has(r.id)).map((r) => ({ result: r, label: `${r.source} · ${r.scores.overall}` }))];
      });
      if (results.length) toast.success(`Added ${results.length} photo(s) to compare`);
    } finally { setCompareBusy(false); }
  }, [runBatch]);
  const toggleCompare = useCallback((r: AnalysisResult) => {
    setCompareItems((prev) => prev.some((p) => p.result.id === r.id)
      ? prev.filter((p) => p.result.id !== r.id)
      : [...prev, { result: r, label: `${r.source} · ${r.scores.overall}` }]);
  }, []);

  const handleImageSelect = useCallback(async (image: SearchResultImage) => {
    haptic('medium');
    setSelectedImage(image);
    setView('analyzing');
    setLogs([]);
    setProgress(0);
    setBoundingBox(undefined);
    setSelectedFaceIndex(0);

    const startTime = performance.now();
    const imageId = image.id;

    // Run face detection with live logging
    const face = await detectFaces(image.url, imageId, (entry) => {
      setLogs((prev) => [...prev, entry]);
      setProgress((prev) => Math.min(35, prev + 3));
    });

    if (face.boundingBox) {
      setBoundingBox(face.boundingBox);
    }
    setProgress(55);

    // Compute aesthetic scores
    const rawMetrics = deriveMetricsFromFace(face);
    const geoScores = clampAestheticScores(computeAestheticScores(rawMetrics, face.geometry, imageQualityOf(face)));
    setProgress(65);
    setLogs((prev) => [...prev, { step: prev.length + 1, label: 'AI look check', detail: 'Asking the vision model for a whole-face judgement (teeth, skin, weight, overall appeal)…', category: 'aesthetic' as const, value: '…', confidence: 1 }]);
    // Face AI check and whole-body rating run at the same time.
    const [faceScores, body] = await Promise.all([applyAiLook(geoScores, image.url, { aiOnly: !face.detected }), getBodyLook(image.url)]);
    const scores = withBodyLook(faceScores, body);

    setProgress(85);

    // Build warnings
    const warnings: string[] = [];
    if (!face.detected) warnings.push('No face mesh (side or angled view) — no measurements were possible, so the score is the AI look check only.');
    if (face.geometry?.reliabilityNote) warnings.push(face.geometry.reliabilityNote);
    if (face.focusQuality !== undefined && face.focusQuality < 0.3) warnings.push('Image focus quality is below optimal threshold.');
    if (scores.overall < 40) warnings.push('Low overall score — measured proportions deviate strongly from the reference ideals.');
    if (face.faceCount > 1) warnings.push(`${face.faceCount} faces detected. Analysis shown for primary subject.`);

    await new Promise((resolve) => setTimeout(resolve, 300));

    const result: AnalysisResult = {
      id: `analysis-${Date.now()}-${Math.random().toString(36).slice(2)}`,
      imageId,
      imageUrl: image.url,
      searchLabel: image.searchLabel,
      source: image.source,
      timestamp: Date.now(),
      faceDetection: face,
      scores,
      topArchetypes: [],
      warnings,
      duration: performance.now() - startTime,
    };

    setProgress(100);
    saveAnalysis(result).catch(() => {});

    setAllResults((prev) => {
      const updated = [result, ...prev];
      setProfile(buildPreferenceProfile(updated));
      return updated;
    });
    const historyEntry: HistoryEntry = {
      id: result.id,
      thumbnailUrl: result.imageUrl,
      timestamp: result.timestamp,
      overallScore: result.scores.overall,
      topArchetype: '',
      source: result.source,
      searchLabel: result.searchLabel,
    };
    setHistory((prev) => [historyEntry, ...prev]);
    cacheHistoryEntry(historyEntry).catch(() => {});

    await new Promise((resolve) => setTimeout(resolve, 500));
    haptic('success');
    if (viewRef.current === 'analyzing') {
      setCurrentResult(result);
      setView('results');
    }
  }, []);

  const handleAddToCompare = useCallback(() => {
    if (!currentResult) return;
    haptic('medium');
    const alreadyAdded = compareItems.some((item) => item.result.id === currentResult.id);
    if (alreadyAdded) {
      toast.info('This analysis is already in the comparison.');
    } else {
      const label = `${currentResult.source} · ${currentResult.scores.overall}`;
      setCompareItems((prev) => [...prev, { result: currentResult, label }]);
    }
    setView('compare');
  }, [currentResult, compareItems]);

  const handleRemoveFromCompare = useCallback((id: string) => {
    haptic('light');
    setCompareItems((prev) => prev.filter((item) => item.result.id !== id));
  }, []);

  const handleClearCompare = useCallback(() => {
    haptic('light');
    setCompareItems([]);
  }, []);

  // "Way off": a separate final analyst weighs AI + measurements and sets only the overall.
  const handleAnyAiCheck = async (target: AnalysisResult, opts: { bigBatch?: boolean; quiet?: boolean } = {}): Promise<AnalysisResult> => {
    if (aiChecking.current.has(target.id) || target.scores.aiLook) return target;
    aiChecking.current.add(target.id);
    setAiBusyIds(new Set(aiChecking.current));
    try {
      const saved = await pendingSaves.current.get(target.id);
      const updated = await checkAnalysisAi(saved ? { ...target, imageUrl: saved.imageUrl, thumbUrl: saved.thumbUrl } : target, (sc, url) => applyAiLook(sc, url, { bigBatch: opts.bigBatch }));
      setCurrentResult((cur) => cur?.id === target.id ? updated : cur);
      setAllResults((prev) => { const next = prev.map((r) => r.id === target.id ? updated : r); setProfile(buildPreferenceProfile(next)); return next; });
      setHistory((prev) => prev.map((h) => h.id === target.id ? { ...h, overallScore: updated.scores.overall } : h));
      setCompareItems((prev) => prev.map((item) => item.result.id === target.id ? { ...item, result: updated } : item));
      await updateAnalysis(updated);
      const historyEntry: HistoryEntry = { id: updated.id, thumbnailUrl: updated.thumbUrl ?? updated.imageUrl, timestamp: updated.timestamp, overallScore: updated.scores.overall, topArchetype: '', searchLabel: updated.searchLabel, source: updated.source };
      cacheHistoryEntry(historyEntry).catch(() => {});
      if (opts.quiet) { /* batch caller reports once */ }
      else if (updated.scores.aiLook) toast.success('AI check complete');
      else toast.error(updated.scores.aiLookError ?? 'AI check failed. You can retry this photo.');
      return updated;
    } finally {
      aiChecking.current.delete(target.id);
      setAiBusyIds(new Set(aiChecking.current));
    }
  };

  // History multi-select: photos without an AI check go out in groups of up to 10 per AI request.
  const handleHistoryAiBatch = async (ids: string[]) => {
    const targets = ids.map((id) => allResults.find((r) => r.id === id)).filter((r): r is AnalysisResult => !!r && !r.scores.aiLook);
    if (!targets.length) { toast.info('All selected photos already have an AI check.'); return; }
    toast.info(`Sending ${targets.length} photo${targets.length > 1 ? 's' : ''} to the AI in ${Math.ceil(targets.length / 10)} request${targets.length > 10 ? 's' : ''}…`);
    const done = await Promise.all(targets.map((t) => handleAnyAiCheck(t, { bigBatch: true, quiet: true })));
    const ok = done.filter((r) => r.scores.aiLook).length;
    if (ok === done.length) toast.success(`AI check complete for ${ok} photo${ok > 1 ? 's' : ''}`);
    else toast.error(`AI checked ${ok} of ${done.length}. You can retry the rest.`);
  };

  const [wayOffBusy, setWayOffBusy] = useState(false);
  const handleWayOff = useCallback(async () => {
    if (!currentResult || wayOffBusy) return;
    haptic('light');
    setWayOffBusy(true);
    const target = currentResult;
    const out = await applyFinalAnalyst(target.scores, target.imageUrl);
    setWayOffBusy(false);
    if ('error' in out) { toast.error(out.error); return; }
    const updated = { ...target, scores: out.scores };
    setCurrentResult((cur) => (cur?.id === target.id ? updated : cur));
    setAllResults((prev) => { const u = prev.map((r) => (r.id === target.id ? { ...updated, imageUrl: r.imageUrl, thumbUrl: r.thumbUrl } : r)); setProfile(buildPreferenceProfile(u)); return u; });
    setHistory((prev) => prev.map((h) => (h.id === target.id ? { ...h, overallScore: updated.scores.overall } : h)));
    const saved = allResults.find((r) => r.id === target.id);
    updateAnalysis(saved ? { ...updated, imageUrl: saved.imageUrl, thumbUrl: saved.thumbUrl } : updated);
    toast.success(`Final analyst: ${Math.round(updated.scores.overall)}/100`);
  }, [currentResult, wayOffBusy, allResults]);

  // Whole-body rating on demand (e.g. older saved scans that never had one).
  const [bodyBusy, setBodyBusy] = useState(false);
  const handleRateBody = useCallback(async () => {
    if (!currentResult || bodyBusy) return;
    haptic('light');
    setBodyBusy(true);
    const target = currentResult;
    const body = await getBodyLook(target.imageUrl);
    setBodyBusy(false);
    if ('bodyLookError' in body) { toast.error(body.bodyLookError); return; }
    const updated = { ...target, scores: withBodyLook(target.scores, body) };
    setCurrentResult((cur) => (cur?.id === target.id ? updated : cur));
    setAllResults((prev) => prev.map((r) => (r.id === target.id ? { ...updated, imageUrl: r.imageUrl, thumbUrl: r.thumbUrl } : r)));
    const saved = allResults.find((r) => r.id === target.id);
    updateAnalysis(saved ? { ...updated, imageUrl: saved.imageUrl, thumbUrl: saved.thumbUrl } : updated);
    toast.success(body.bodyLook.visible ? `Body: ${Math.round(body.bodyLook.overall)}/100` : 'Not enough of the body is in this photo.');
  }, [currentResult, bodyBusy, allResults]);

  useEffect(() => { setBodyExamples(bodyExamples(allResults)); }, [allResults]);
  const teachExamples = useMemo(() => faceExamples(allResults, ratings), [allResults, ratings]);
  useEffect(() => { setFaceExamples(teachExamples); }, [teachExamples]);
  // Your slider ratings re-shape the AI score (and the overall) of every other photo right away, not only future checks.
  const shownResult = useMemo(() => {
    const ai = currentResult?.scores.aiLook;
    if (!currentResult || !ai) return currentResult;
    const raw = ai.rawAttractiveness ?? ai.attractiveness;
    const cal = liveFace(raw, ai.typeMatch, currentResult.imageId, teachExamples);
    const next = Math.round(cal.score);
    const delta = next - ai.attractiveness;
    if (!delta && cal.used === (ai.tasteRatingsUsed ?? 0)) return currentResult;
    const overall = currentResult.scores.finalAnalyst ? currentResult.scores.overall
      : Math.max(0, Math.min(100, softTop(currentResult.scores.overall + delta * 0.5)));
    return { ...currentResult, scores: { ...currentResult.scores, overall, aiLook: { ...ai, attractiveness: next, tasteRatingsUsed: cal.used } } };
  }, [currentResult, teachExamples]);

  // The user's own Attractive / Cute / Beautiful labels: saved on the scan and taught to the AI.
  const handleCategories = useCallback((values: FaceCategory[], partly: FaceCategory[] = []) => {
    if (!currentResult) return;
    haptic('selection');
    const target = currentResult;
    const updated = { ...target, scores: { ...target.scores, userFaceCategories: values, userFacePartial: partly.filter((c) => !values.includes(c)) } };
    setCurrentResult((cur) => (cur?.id === target.id ? updated : cur));
    setAllResults((prev) => prev.map((r) => (r.id === target.id ? { ...updated, imageUrl: r.imageUrl, thumbUrl: r.thumbUrl } : r)));
    const saved = allResults.find((r) => r.id === target.id);
    updateAnalysis(saved ? { ...updated, imageUrl: saved.imageUrl, thumbUrl: saved.thumbUrl } : updated);
  }, [currentResult, allResults]);

  // The user's own 1-100 body ratings: saved on the scan and used to teach the AI body rater.
  const handleUserBody = useCallback((values: Record<BodyKey, number>) => {
    if (!currentResult) return;
    haptic('selection');
    const target = currentResult;
    const updated = { ...target, scores: { ...target.scores, userBody: cleanUserBody(values) } };
    setCurrentResult((cur) => (cur?.id === target.id ? updated : cur));
    setAllResults((prev) => prev.map((r) => (r.id === target.id ? { ...updated, imageUrl: r.imageUrl, thumbUrl: r.thumbUrl } : r)));
    const saved = allResults.find((r) => r.id === target.id);
    updateAnalysis(saved ? { ...updated, imageUrl: saved.imageUrl, thumbUrl: saved.thumbUrl } : updated);
    toast.success('Your body rating is saved — the AI will learn from it.');
  }, [currentResult, allResults]);

  const handleRate = useCallback((imageId: string, rating: number) => {
    haptic('selection');
    const rec = { imageId, rating, timestamp: Date.now() };
    setRatings((prev) => [rec, ...prev]);
    saveStarRating(rec).catch(() => {});
  }, []);

  const handleDelete = useCallback(async (ids: string[]) => {
    const idSet = new Set(ids);
    const imageIds = allResults.filter((r) => idSet.has(r.id)).map((r) => r.imageId);
    const imgSet = new Set(imageIds);
    const ok = await deleteAnalyses(ids);
    if (!ok) toast.message('Removed here — the cloud copy will be removed next time you open the app.');
    await removeCachedEntries(ids);
    setHistory((h) => h.filter((e) => !idSet.has(e.id)));
    void imgSet; // soft delete: ratings are kept for taste learning
    setCompareItems((c) => c.filter((x) => !idSet.has(x.result.id)));
    setAllResults((prev) => prev.map((r) => (idSet.has(r.id) ? { ...r, deletedAt: Date.now() } : r)));
  }, [allResults]);

  const handleDeleteAll = useCallback(async (withRatings: boolean) => {
    const ok = withRatings ? await resetEverything() : await deleteAllAnalyses(history.map((h) => h.id));
    if (!ok) { toast.error('Could not delete — please try again.'); return; }
    await clearCachedHistory();
    setHistory([]); setCompareItems([]);
    if (!withRatings) setAllResults((prev) => prev.map((r) => ({ ...r, deletedAt: r.deletedAt ?? Date.now() })));
    if (withRatings) { setAllResults([]); setProfile(buildPreferenceProfile([])); }
    if (withRatings) { setRatings([]); setCurrentResult(null); }
  }, [history]);

  // Multi-face: select primary subject
  const handleSelectFace = useCallback((faceIndex: number) => {
    haptic('selection');
    setSelectedFaceIndex(faceIndex);
  }, []);

  const comparisonSummary = useMemo(
    () => generateComparisonSummary(compareItems.map((c) => c.result)),
    [compareItems],
  );

  const activeNavView = view === 'analyzing' || view === 'results' ? 'search' : view;
  activeNavViewRef.current = activeNavView;

  return (
    <PhotoNameSearchContext.Provider value={(name) => { setShowExport(false); void handleSearch(youngNameQuery(name), prefs.defaultSource); }}>
    <PhotoActions names={photoSearchNames} onSearch={(name) => { setShowExport(false); void handleSearch(youngNameQuery(name), prefs.defaultSource); }} />
    <div className="min-h-screen mesh-bg">
      {/* Header */}
      <header className="sticky top-0 z-50 glass border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-gradient-primary flex items-center justify-center shadow-glow-primary">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-sm font-display font-bold text-ink-900 leading-none">
                Aesthetics Analyzer
              </h1>
              <p className="text-2xs text-ink-400 mt-0.5">Personalized visual analysis</p>
            </div>
          </div>

          <div className="sm:order-last ml-auto sm:ml-1 flex items-center">
            <InstallAppButton />
            <button
              aria-label="Settings"
              onClick={() => { haptic('selection'); setSettingsOpen(true); }}
              className="p-2 rounded-lg text-ink-500 hover:text-ink-700 hover:bg-ink-100 min-h-[40px] min-w-[40px] flex items-center justify-center"
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>

          {/* Nav — desktop */}
          <nav className="hidden sm:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = view === item.id || (item.id === 'search' && (view === 'analyzing' || view === 'results'));
              return (
                <button
                  key={item.id}
                  onClick={() => switchView(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                    active
                      ? 'bg-primary-500/10 text-primary-600'
                      : 'text-ink-500 hover:text-ink-700 hover:bg-ink-100'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                  {item.id === 'compare' && compareItems.length > 0 && (
                    <span className="w-4 h-4 rounded-full bg-primary-500 text-white text-2xs font-bold flex items-center justify-center">
                      {compareItems.length}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>
      </header>

      {/* Main content */}
      <main data-slide={slideDir} className="view-slide max-w-7xl mx-auto px-4 sm:px-6 py-6 pb-[calc(6.5rem+env(safe-area-inset-bottom))] sm:pb-6">
        {view !== 'results' && <Button variant="ghost" size="sm" onClick={goBack} disabled={backStack.current.length === 0} className="mb-4" aria-label="Back"><ArrowLeft />Back</Button>}
        {view === 'search' && (
          <div className="space-y-6 animate-fade-in">
            {/* Hero section */}
            <div className="overflow-hidden rounded-2xl border border-border">
              <img src={homeHero.url} alt="Aesthetics — a mosaic of portrait faces" className="block w-full h-56 sm:h-80 object-cover object-center" />
            </div>
            <div className="text-center pb-2 space-y-3">
              <h2 className="text-3xl font-display font-bold text-ink-900">
                Discover Your <span className="gradient-text">Aesthetic Identity</span>
              </h2>
              <p className="text-sm text-ink-500 max-w-md mx-auto">
                Search for images, upload your own, and get deep aesthetic analysis with face detection, and personalized recommendations.
              </p>
            </div>

            {/* Search bar */}
            <div className="card p-4">
              <SearchBar
                externalQuery={currentQuery}
                onSearch={handleSearch}
                onUpload={handleUpload}
                onUploadMany={handleUploadMany}
                analysisBusy={batch !== null}
                loading={searching}
                filters={filters}
                onFiltersChange={setFilters}
                resultCount={images.length}
              />
            </div>

            {searchStatus && searchStatus.provider !== 'serpapi' && (
              <div role="status" className="flex items-start gap-2 p-3 rounded-xl bg-warning-50 border border-warning-200 text-sm text-warning-700">
                <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <p>
                  Results come from <b>{PROVIDER_NAMES[searchStatus.provider]}</b>, not Google/Pinterest
                  {searchStatus.fallbackReason ? ` (reason: ${searchStatus.fallbackReason})` : ''}.
                  {(searchStatus.fallbackReason === 'missing key' || searchStatus.attempts?.[0]?.reason === 'missing key') && ' The SerpAPI key is not visible to the server — add or replace SERPAPI_API_KEY in the project secrets and try again.'}
                  {searchStatus.fallbackReason === 'quota' && ' The SerpAPI key is rejected or out of quota — check the plan or key in the project secrets.'}
                  {searchStatus.provider === 'curated' && ' All live providers failed, so a small built-in set is shown.'}
                </p>
              </div>
            )}

            {searchStatus?.diagnostics && (
              <p className="text-2xs font-mono text-ink-400 break-words" data-testid="search-diagnostics">
                Search diagnostics · SerpAPI key {searchStatus.diagnostics.serpapiKey}
                {searchStatus.diagnostics.serpapiHttpStatus ? ` · SerpAPI HTTP ${searchStatus.diagnostics.serpapiHttpStatus}` : ''}
                {' '}· provider {PROVIDER_NAMES[searchStatus.diagnostics.provider] ?? searchStatus.diagnostics.provider} · query sent: “{searchStatus.diagnostics.query}”
              </p>
            )}


            {batchPhotos.length > 0 && (
              <BatchAnalysisPanel photos={batchPhotos} busy={batch !== null} stopping={batchStopping}
                onStop={() => { batchCancel.current = true; setBatchStopping(true); }}
                onClose={() => setBatchPhotos([])}
                onOpen={(r) => { setCurrentResult(r); setSelectedFaceIndex(0); setView('results'); }} />
            )}

            {/* Image grid */}
            {rawImages.length > 0 && (
              <div className="card p-4 space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <label htmlFor="min-taste" className="font-medium text-ink-800">Minimum taste match</label>
                  <span className="font-mono font-semibold text-ink-700">{minTaste === 0 ? 'Off' : `${minTaste}+`}</span>
                </div>
                <input
                  id="min-taste"
                  type="range"
                  min={0}
                  max={95}
                  step={5}
                  value={minTaste}
                  onChange={(e) => setMinTaste(Number(e.target.value))}
                  className="w-full accent-primary-500"
                />
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  {batch ? (
                    <Button variant="ghost" size="sm" disabled={batchStopping} onClick={() => { batchCancel.current = true; setBatchStopping(true); }}>
                      Analysing {batch.done}/{batch.total} — stop
                    </Button>
                  ) : (
                    <Button size="sm" onClick={() => runBatch(images)}>
                      Analyse all {images.length}
                    </Button>
                  )}
                  <label htmlFor="sort-by" className="text-2xs text-ink-500 ml-auto">Sort</label>
                  <select id="sort-by" value={sortBy} onChange={(e) => setSortBy(e.target.value as typeof sortBy)} className="text-xs rounded-lg border border-ink-200 bg-white/80 px-2 py-1">
                    <option value="none">As found</option>
                    <option value="score">Highest score</option>
                    <option value="taste">Best taste match</option>
                    <option value="facetype">My face type</option>
                  </select>
                </div>
                <p className="text-2xs text-ink-400">
                  {tasteModel.samples.length === 0
                    ? 'Rate a few analysed photos with stars to unlock this filter.'
                    : minTaste > 0
                      ? `Hiding ${images.length - gridImages.length} photo(s) below ${minTaste}. Photos you haven't analysed yet stay visible.`
                      : 'Hide photos you have analysed that are unlikely to match your taste.'}
                </p>
              </div>
            )}
            {rawImages.length > 0 && (
              <ImageGrid
                images={gridImages}
                tasteScores={tasteByUrl}
                scores={scoreByUrl}
                onImageSelect={handleImageSelect}
                selectedImageId={selectedImage?.id}
                onLoadMore={handleLoadMore}
                hasMore={hasMore}
                loadingMore={loadingMore}
                totalCount={totalCount}
              />
            )}

          </div>
        )}

        {view === 'analyzing' && selectedImage && (
          <ErrorBoundary label="Analysis view">
            <AnalyzingView
              imageUrl={selectedImage.url}
              searchLabel={selectedImage.searchLabel}
              logs={logs}
              progress={progress}
              boundingBox={boundingBox}
            />
          </ErrorBoundary>
        )}

        {view === 'results' && currentResult && (
          <ResultsView
            onAiCheck={() => { void handleAnyAiCheck(currentResult); }}
            aiBusy={aiBusyIds.has(currentResult.id)}
            result={shownResult ?? currentResult}
            photoNames={photoNames}
            tasteMatch={tasteMatch}
            ratingsCount={tasteModel.samples.length}
            onReset={goBack}
            resetLabel="Back"
            onAddToCompare={handleAddToCompare}
            onRate={handleRate}
            currentRating={ratings.filter((x) => x.imageId === currentResult.imageId).sort((a, b) => b.timestamp - a.timestamp)[0]?.rating}
            onCategories={handleCategories}
            onWayOff={handleWayOff}
            wayOffBusy={wayOffBusy}
            onRateBody={handleRateBody}
            onUserBody={handleUserBody}
            bodyBusy={bodyBusy}
            onExport={() => setShowExport(true)}
            faceData={currentResult.faceDetection.faceCount > 1 ? {
              faces: currentResult.faceDetection.faces,
              selectedIndex: selectedFaceIndex,
              onSelect: handleSelectFace,
            } : undefined}
          />
        )}

        {view === 'best' && (
          <ErrorBoundary label="Find the best">
            <FindBestPanel
              onDelete={handleDelete}
              onRate={handleRate}
              ratings={ratings}
              onAiCheck={handleAnyAiCheck}
              aiBusyIds={aiBusyIds}
              onResults={(results) => {
                for (const r of results) {
                  const saving = saveAnalysis(r);
                  pendingSaves.current.set(r.id, saving);
                  saving.then((saved) => { setAllResults((prev) => prev.map((item) => item.id === saved.id ? { ...item, imageUrl: saved.imageUrl, thumbUrl: saved.thumbUrl } : item)); }).catch(() => { toast.error('A photo result could not be saved.'); });
                }
                setAllResults((prev) => { const u = [...results, ...prev]; setProfile(buildPreferenceProfile(u)); return u; });
                const hs: HistoryEntry[] = results.map((r) => ({ id: r.id, thumbnailUrl: r.imageUrl, timestamp: r.timestamp, overallScore: r.scores.overall, topArchetype: '', searchLabel: r.searchLabel, source: r.source }));
                setHistory((prev) => [...hs, ...prev]);
                for (const h of hs) cacheHistoryEntry(h).catch(() => {});
              }}
              onOpen={(r) => { setCurrentResult(allResults.find((item) => item.id === r.id) ?? r); setSelectedFaceIndex(0); setView('results'); }}
            />
          </ErrorBoundary>
        )}

        <div hidden={view !== 'discover'}>
          <ErrorBoundary label="Taste calibration">
            <div className="mb-4"><TasteCalibration results={allResults} tasteModel={tasteModel} onRate={handleRate} onGoRate={() => switchView(history.length ? 'history' : 'search')} /></div>
          </ErrorBoundary>
          <ErrorBoundary label="Discover for You">
            <DiscoverForYou results={allResults} ratings={ratings} tasteModel={tasteModel} candidates={discoveryCandidates}
              onCandidate={(r) => {
                setDiscoveryCandidates((prev) => [...prev, r]);
                const saving = saveAnalysis(r);
                pendingSaves.current.set(r.id, saving);
                saving.then((saved) => setAllResults((prev) => prev.map((item) => item.id === saved.id ? { ...item, imageUrl: saved.imageUrl, thumbUrl: saved.thumbUrl } : item))).catch(() => toast.error('A discovered portrait could not be saved.'));
                setAllResults((prev) => [...prev, r]);
                const entry: HistoryEntry = { id: r.id, thumbnailUrl: r.thumbUrl ?? r.imageUrl, timestamp: r.timestamp, overallScore: r.scores.overall, topArchetype: '', source: r.source };
                setHistory((prev) => [entry, ...prev]);
                void cacheHistoryEntry(entry);
              }}
              onOpen={(r) => { setCurrentResult(allResults.find((item) => item.id === r.id) ?? r); setSelectedFaceIndex(0); setView('results'); }}
              onRate={handleRate} onGoRate={() => switchView(history.length ? 'history' : 'search')} />
          </ErrorBoundary>
        </div>

        {view === 'history' && (
          <ErrorBoundary label="History view">
            <HistoryView entries={history} getFullUrl={(id) => allResults.find((r) => r.id === id)?.imageUrl} onSelect={(e) => { const r = allResults.find((x) => x.id === e.id); if (r) { haptic('light'); setCurrentResult(r); setSelectedFaceIndex(0); setView('results'); } }} onDelete={handleDelete} onDeleteAll={() => handleDeleteAll(false)} onReset={() => handleDeleteAll(true)} onAiBatch={handleHistoryAiBatch} />
          </ErrorBoundary>
        )}

        {view === 'compare' && (
          <div className="space-y-4 animate-fade-in">
            <div className="flex items-center gap-2">
              <GitCompare className="w-5 h-5 text-primary-500" />
              <h2 className="text-lg font-display font-semibold text-ink-900">Comparison</h2>
            </div>
            <div className="card p-4 space-y-3">
              <label className={`btn-primary w-full flex items-center justify-center gap-2 cursor-pointer ${compareBusy ? 'opacity-60 pointer-events-none' : ''}`}>
                {compareBusy ? `Analysing ${batch ? `${batch.done}/${batch.total}` : ''}…` : 'Upload 2 or more photos to compare'}
                <input type="file" accept="image/*" multiple className="hidden" disabled={compareBusy}
                  onChange={(e) => { const f = Array.from(e.target.files ?? []); e.target.value = ''; void handleCompareUpload(f); }} />
              </label>
              {allResults.length > 0 && (
                <div>
                  <p className="text-xs text-ink-500 mb-2">Or tap analysed photos to add / remove them:</p>
                  <div className="flex gap-2 overflow-x-auto pb-1">
                    {allResults.slice(0, 40).map((r) => {
                      const on = compareItems.some((c) => c.result.id === r.id);
                      return (
                        <div key={r.id} className="shrink-0 w-24 space-y-1"><PhotoHeading name={r.searchLabel} className="text-xs" /><button type="button" onClick={() => toggleCompare(r)} aria-pressed={on} aria-label={`Toggle ${r.searchLabel ?? r.source} in comparison`}
                          className={`relative shrink-0 w-24 h-16 rounded-lg overflow-hidden border-2 ${on ? 'border-primary-500' : 'border-transparent opacity-70'}`}>
                          <img src={r.imageUrl} alt="" className="w-full h-full object-cover" />
                          <span className="absolute bottom-0 inset-x-0 bg-ink-900/60 text-2xs text-center text-surface">{r.scores.overall}</span>
                        </button></div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
            {compareItems.length >= 2 && (
              <div className="card p-4">
                <p className="text-sm text-ink-600 leading-relaxed">{comparisonSummary}</p>
              </div>
            )}
            <ErrorBoundary label="Comparison view">
              <ComparisonView items={compareItems} onRemove={handleRemoveFromCompare} onAddMore={() => switchView('search')} onClear={handleClearCompare} />
            </ErrorBoundary>
          </div>
        )}

        {view === 'profile' && (
          <div className="space-y-4 animate-fade-in">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-primary-500" />
              <h2 className="text-lg font-display font-semibold text-ink-900">Your taste</h2>
            </div>
            <ErrorBoundary label="Taste view">
              <TasteProfile results={allResults} ratings={ratings} skill={tasteSkill(tasteModel)}
                next={suggestNextToRate(tasteModel, allResults)}
                onOpen={(r) => { setCurrentResult(r); setSelectedFaceIndex(0); setView('results'); }}
                onGoSearch={() => switchView('search')} />
            </ErrorBoundary>
          </div>
        )}
      </main>

      {settingsOpen && <SettingsPanel onClose={() => setSettingsOpen(false)} />}

      {/* Export modal */}
      {showExport && currentResult && (
        <ExportReport result={currentResult} onClose={() => setShowExport(false)} />
      )}

      {/* Mobile bottom navigation */}
      <nav className="sm:hidden fixed bottom-0 left-0 right-0 z-50 glass border-t border-white/10 px-2 py-2 flex items-center justify-around">
        <span aria-hidden className="nav-pill" style={{ ['--i' as string]: Math.max(0, navItems.findIndex((n) => n.id === activeNavView)), ['--n' as string]: navItems.length }} />
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = activeNavView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => switchView(item.id)}
              className={`relative flex flex-col items-center gap-0.5 px-1 py-2 rounded-lg transition-all flex-1 min-w-0 ${
                active ? 'text-primary-600' : 'text-ink-400'
              }`}
            >
              <Icon className={`w-5 h-5 transition-transform duration-300 ${active ? 'scale-110 -translate-y-0.5' : ''}`} />
              <span className="text-2xs font-medium">{item.label}</span>
              {item.id === 'compare' && compareItems.length > 0 && (
                <span className="absolute top-0 right-2 w-4 h-4 rounded-full bg-primary-500 text-white text-2xs font-bold flex items-center justify-center">
                  {compareItems.length}
                </span>
              )}
              {active && (
                <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-8 h-0.5 rounded-full bg-primary-500" />
              )}
            </button>
          );
        })}
      </nav>

      <PhotoDragLayer
        resolve={(id) => allResults.find((r) => r.id === id)}
        isIn={(id) => compareItems.some((c) => c.result.id === id)}
        onDrop={(r) => {
          if (compareItems.some((c) => c.result.id === r.id)) { toast('Already in Compare'); return; }
          setCompareItems((prev) => prev.some((p) => p.result.id === r.id) ? prev : [...prev, { result: r, label: `${r.searchLabel || r.source} · ${Math.round(r.scores.overall)}` }]);
          toast.success('Added to Compare');
        }}
      />

      {/* Footer */}
      <footer className="hidden sm:block border-t border-ink-200/50 py-4 text-center">
        <p className="text-2xs text-ink-400">
          Personalized Aesthetics Analyzer · Deep visual analysis engine
        </p>
      </footer>
    </div>
    </PhotoNameSearchContext.Provider>
  );
}

export default App;
