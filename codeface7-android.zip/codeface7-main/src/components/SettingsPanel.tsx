import { Button } from './ui/button';
import { useState } from 'react';
import { ArrowLeft, X, Plus, Trash2, RotateCcw, KeyRound } from 'lucide-react';
import ApiKeySettings from '@/components/ApiKeySettings';
import { HealthDot, lastHealth } from '@/components/AiKeyHealth';
import { useUserPrefs, updatePrefs, addFolder, removeFolder, DEFAULT_PREFS, type Accent, type TextSize } from '@/lib/userPrefs';
import type { ImageSource } from '@/lib/types';

const ACCENTS: Array<[Accent, string, string]> = [
  ['blue', 'Blue', 'rgb(45 156 255)'],
  ['rose', 'Rose', 'rgb(244 63 94)'],
  ['emerald', 'Emerald', 'rgb(16 185 129)'],
  ['amber', 'Amber', 'rgb(245 158 11)'],
  ['violet', 'Violet', 'rgb(139 92 246)'],
];

function Section({ title, hint, children }: { title: string; hint?: string; children: React.ReactNode }) {
  return (
    <section className="space-y-3 pb-5 border-b border-ink-100 last:border-0">
      <div>
        <h3 className="text-sm font-semibold text-ink-800">{title}</h3>
        {hint && <p className="text-2xs text-ink-400 mt-0.5">{hint}</p>}
      </div>
      {children}
    </section>
  );
}

function Pill({ active, onClick, children, label }: { active: boolean; onClick: () => void; children: React.ReactNode; label?: string }) {
  return (
    <button
      type="button"
      aria-label={label}
      aria-pressed={active}
      onClick={onClick}
      className={`px-3 py-1.5 rounded-lg text-xs font-medium min-h-[36px] transition-colors ${active ? 'bg-primary-500 text-white' : 'bg-ink-100 text-ink-600 hover:bg-ink-200'}`}
    >
      {children}
    </button>
  );
}

function WeightSlider({ id, label, value, onChange }: { id: string; label: string; value: number; onChange: (v: number) => void }) {
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs">
        <label htmlFor={id} className="text-ink-700 font-medium">{label}</label>
        <span className="font-mono text-ink-600">{value}</span>
      </div>
      <input id={id} type="range" min={0} max={100} step={5} value={value} onChange={(e) => onChange(Number(e.target.value))} className="w-full accent-primary-500" />
    </div>
  );
}

export default function SettingsPanel({ onClose }: { onClose: () => void }) {
  const p = useUserPrefs();
  const [newQuick, setNewQuick] = useState('');
  const [newFolder, setNewFolder] = useState('');
  const [keysOpen, setKeysOpen] = useState(false);
  const total = p.weights.face + p.weights.ai;
  const pct = (v: number) => (total > 0 ? Math.round((v / total) * 100) : 0);

  return (
    <>
    {!keysOpen && <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-ink-900/40 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div role="dialog" aria-label="Settings" className="relative w-full sm:max-w-lg max-h-[88vh] overflow-y-auto bg-white rounded-t-3xl sm:rounded-2xl p-5 pb-8 space-y-5 shadow-xl animate-slide-up">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-display font-bold text-ink-900">Settings</h2>
          <Button variant="ghost" aria-label="Back" onClick={onClose}><ArrowLeft />Back</Button>
        </div>

        <Section title="API keys" hint="Keys you paste are saved on this device and kept after reload. Serper is the default search.">
          <button type="button" className="btn-secondary w-full" onClick={() => setKeysOpen(true)}>
            <KeyRound className="w-4 h-4" /> Manage API keys <HealthDot level={keysOpen ? null : lastHealth()} />
          </button>
        </Section>

        <Section title="Look & theme">
          <div className="space-y-1">
            <div className="text-2xs font-medium text-ink-500">Colour</div>
            <div className="flex flex-wrap gap-2">
              {ACCENTS.map(([id, name, swatch]) => (
                <button
                  key={id}
                  type="button"
                  aria-label={name}
                  aria-pressed={p.accent === id}
                  onClick={() => updatePrefs({ accent: id })}
                  className={`w-9 h-9 rounded-full border-2 ${p.accent === id ? 'border-ink-900 scale-110' : 'border-transparent'}`}
                  style={{ background: swatch }}
                />
              ))}
            </div>
          </div>
          <div className="space-y-1">
            <div className="text-2xs font-medium text-ink-500">Text size</div>
            <div className="flex gap-2">
              {([['sm', 'Small'], ['md', 'Normal'], ['lg', 'Large']] as Array<[TextSize, string]>).map(([v, t]) => (
                <Pill key={v} active={p.textSize === v} onClick={() => updatePrefs({ textSize: v })}>{t}</Pill>
              ))}
            </div>
          </div>
          <label className="flex items-center gap-2 text-xs text-ink-700 cursor-pointer min-h-[36px]">
            <input type="checkbox" className="h-4 w-4 accent-primary-500" checked={p.reduceMotion} onChange={(e) => updatePrefs({ reduceMotion: e.target.checked })} />
            Less motion (turn off animations)
          </label>
        </Section>

        <Section title="Score weights" hint="Your balance of face measurements and AI look. The two sliders stay in sync — raising one lowers the other.">
          <WeightSlider id="w-face" label={`Face (${pct(p.weights.face)}%)`} value={p.weights.face} onChange={(v) => updatePrefs({ weights: { ...p.weights, face: v, ai: 100 - v } })} />
          <WeightSlider id="w-ai" label={`AI look (${pct(p.weights.ai)}%)`} value={p.weights.ai} onChange={(v) => updatePrefs({ weights: { ...p.weights, ai: v, face: 100 - v } })} />
          <button type="button" className="btn-ghost text-2xs" onClick={() => updatePrefs({ weights: DEFAULT_PREFS.weights })}><RotateCcw className="w-3 h-3" /> Reset weights</button>
        </Section>

        <Section title="Search defaults">
          <div className="space-y-1">
            <div className="text-2xs font-medium text-ink-500">Default source</div>
            <div className="flex gap-2">
              {([['google', 'Google']] as Array<[ImageSource, string]>).map(([v, t]) => (
                <Pill key={v} active={p.defaultSource === v} onClick={() => updatePrefs({ defaultSource: v })}>{t}</Pill>
              ))}
            </div>
          </div>
          <div className="space-y-2">
            <div className="text-2xs font-medium text-ink-500">Quick searches</div>
            <div className="flex flex-wrap gap-1.5">
              {p.quickSearches.map((q) => (
                <span key={q} className="inline-flex items-center gap-1 pl-2.5 pr-1 py-1 rounded-full bg-primary-50 text-primary-700 text-2xs">
                  {q}
                  <button aria-label={`Remove ${q}`} onClick={() => updatePrefs({ quickSearches: p.quickSearches.filter((x) => x !== q) })} className="p-0.5 rounded-full hover:bg-primary-100"><X className="w-3 h-3" /></button>
                </span>
              ))}
              {p.quickSearches.length === 0 && <span className="text-2xs text-ink-400">None yet.</span>}
            </div>
            <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); const q = newQuick.trim(); if (q && !p.quickSearches.includes(q)) updatePrefs({ quickSearches: [...p.quickSearches, q] }); setNewQuick(''); }}>
              <input value={newQuick} onChange={(e) => setNewQuick(e.target.value)} placeholder="Add a quick search…" className="input-field py-2 text-xs" />
              <button type="submit" className="btn-secondary text-xs" aria-label="Add quick search"><Plus className="w-4 h-4" /></button>
            </form>
            <button type="button" className="btn-ghost text-2xs" onClick={() => updatePrefs({ quickSearches: DEFAULT_PREFS.quickSearches })}><RotateCcw className="w-3 h-3" /> Restore the original list</button>
          </div>
        </Section>

        <Section title="Folders" hint="Save results into folders from the results screen, then filter History by folder.">
          <div className="space-y-1.5">
            {p.folders.map((f) => {
              const n = Object.values(p.saved).filter((v) => v.includes(f)).length;
              return (
                <div key={f} className="flex items-center justify-between text-xs bg-ink-50 rounded-lg px-3 py-2">
                  <span className="text-ink-700">{f} <span className="text-ink-400">· {n}</span></span>
                  <button aria-label={`Delete folder ${f}`} onClick={() => { if (confirm(`Delete folder “${f}”? The photos stay in History.`)) removeFolder(f); }} className="p-1 text-error-500"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              );
            })}
          </div>
          <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); addFolder(newFolder); setNewFolder(''); }}>
            <input value={newFolder} onChange={(e) => setNewFolder(e.target.value)} placeholder="New folder name…" className="input-field py-2 text-xs" />
            <button type="submit" className="btn-secondary text-xs" aria-label="Add folder"><Plus className="w-4 h-4" /></button>
          </form>
        </Section>
      </div>
    </div>}
    <ApiKeySettings open={keysOpen} onOpenChange={setKeysOpen} />
    </>
  );
}
