import { accentColor, useUserPrefs, weightedScore } from '@/lib/userPrefs';
import { useEffect, useState } from 'react';
import type { AestheticScores } from '@/lib/types';
import { clampScore } from '@/lib/metrics';
import { scoreLabel } from '@/lib/scoring';

interface ScoreDisplayProps {
  scores: AestheticScores;
  animated?: boolean;
  size?: 'sm' | 'md' | 'lg';
  weighted?: boolean;
}

export default function ScoreDisplay({ scores, animated = true, size = 'md', weighted = false }: ScoreDisplayProps) {
  const prefs = useUserPrefs();
  const selectedScore = weighted ? weightedScore(scores, prefs.weights) : scores.overall;
  const clampedOverall = clampScore(selectedScore ?? 0);
  const [displayedScore, setDisplayedScore] = useState(animated ? 0 : clampedOverall);

  useEffect(() => {
    if (!animated || prefs.reduceMotion) {
      setDisplayedScore(clampedOverall);
      return;
    }
    setDisplayedScore(0);
    const duration = 900;
    const startTime = performance.now();
    let raf: number;

    const tick = (now: number) => {
      const elapsed = now - startTime;
      const t = Math.min(1, elapsed / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      setDisplayedScore(Math.round(clampedOverall * eased));
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [clampedOverall, animated, prefs.reduceMotion]);

  const score = clampedOverall;
  const color = score >= 75 ? '#16a34a' : score >= 62 ? accentColor(500) : score >= 48 ? '#f59e0b' : '#ef4444';
  const colorLight = score >= 75 ? '#86efac' : score >= 62 ? accentColor(300) : score >= 48 ? '#fcd34d' : '#fca5a5';
  const label = scoreLabel(score);

  const dims = {
    sm: { svg: 100, r: 42, stroke: 6, font: 'text-2xl', sub: 'text-2xs' },
    md: { svg: 144, r: 60, stroke: 8, font: 'text-4xl', sub: 'text-2xs' },
    lg: { svg: 180, r: 76, stroke: 10, font: 'text-5xl', sub: 'text-xs' },
  };
  const d = dims[size];
  const circumference = 2 * Math.PI * d.r;

  return (
    <div className="flex flex-col items-center justify-center space-y-3">
      <div className="relative" role="meter" aria-label={weighted ? 'Your weighted score' : 'Overall score'} aria-valuemin={0} aria-valuemax={100} aria-valuenow={selectedScore === undefined ? undefined : clampedOverall} aria-valuetext={selectedScore === undefined ? 'No weighted parts available' : undefined} style={{ width: d.svg, height: d.svg }}>
        {/* Outer glow */}
        <div
          className="absolute inset-0 rounded-full blur-xl opacity-30"
          style={{ background: `radial-gradient(circle, ${color}, transparent 70%)` }}
        />
        <svg className="w-full h-full -rotate-90 relative" viewBox={`0 0 ${d.svg} ${d.svg}`}>
          <defs>
            <linearGradient id={`score-grad-${size}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor={color} />
              <stop offset="100%" stopColor={colorLight} />
            </linearGradient>
          </defs>
          {/* Track */}
          <circle cx={d.svg / 2} cy={d.svg / 2} r={d.r} fill="none" stroke="#e2e8f0" strokeWidth={d.stroke} />
          {/* Progress */}
          <circle
            cx={d.svg / 2}
            cy={d.svg / 2}
            r={d.r}
            fill="none"
            stroke={`url(#score-grad-${size})`}
            strokeWidth={d.stroke}
            strokeLinecap="round"
            strokeDasharray={`${(score / 100) * circumference} ${circumference}`}
            style={{ transition: 'stroke-dasharray 0.9s ease-out', filter: `drop-shadow(0 0 4px color-mix(in srgb, ${color} 25%, transparent))` }}
          />
          {/* Tick marks at 25, 50, 75 */}
          {[25, 50, 75].map((tick) => {
            const angle = (tick / 100) * 2 * Math.PI - Math.PI / 2;
            const x1 = d.svg / 2 + (d.r - d.stroke / 2) * Math.cos(angle);
            const y1 = d.svg / 2 + (d.r - d.stroke / 2) * Math.sin(angle);
            const x2 = d.svg / 2 + (d.r + d.stroke / 2) * Math.cos(angle);
            const y2 = d.svg / 2 + (d.r + d.stroke / 2) * Math.sin(angle);
            return <line key={tick} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#cbd5e1" strokeWidth="1" />;
          })}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className={`${d.font} font-display font-bold text-ink-900 animate-count-up`}>
            {selectedScore === undefined ? '—' : displayedScore}
          </span>
          <span className={`${d.sub} text-ink-400 font-mono`}>/ 100</span>
        </div>
      </div>
      <div className="flex flex-col items-center gap-1">
        <span
          className="badge px-3 py-1 font-medium"
          style={{ background: `color-mix(in srgb, ${color} 10%, transparent)`, color, boxShadow: `0 0 12px color-mix(in srgb, ${color} 13%, transparent)` }}
        >
          {selectedScore === undefined ? 'Not available' : label}
        </span>
        <span className="text-2xs text-ink-400 uppercase tracking-wide">{weighted ? 'Your weighted score' : 'Overall Score'}</span>
        {size === 'lg' && (
          <span className="text-2xs text-ink-400 text-center max-w-xs leading-snug">
            {weighted ? 'Your chosen balance of face measurements, AI look and photo quality — not a verdict on a person.' : 'How closely this face matches the measured proportion, symmetry and skin-detail model — not a verdict on a person.'}
          </span>
        )}
      </div>
    </div>
  );
}
