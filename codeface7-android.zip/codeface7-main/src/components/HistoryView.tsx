import PhotoHeading from './PhotoHeading';
import { dragProps } from '@/components/PhotoDragLayer';
import { useState, useMemo, useRef } from 'react';
import PhotoViewer from '@/components/PhotoViewer';
import { haptic } from '@/lib/haptics';
import { Clock, Trash2, Search, ChevronLeft, ChevronRight, ArrowUpDown, CheckSquare, Square, RotateCcw, X, Maximize2, Sparkles } from 'lucide-react';
import type { HistoryEntry, HistorySortMode } from '@/lib/types';
import { useUserPrefs, filterByFolder } from '@/lib/userPrefs';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

interface HistoryViewProps {
  entries: HistoryEntry[];
  onSelect?: (entry: HistoryEntry) => void;
  /** Delete the given analysis ids. */
  onDelete?: (ids: string[]) => Promise<void> | void;
  /** Delete every analysis. */
  onDeleteAll?: () => Promise<void> | void;
  /** Delete everything including star ratings — the taste model starts from zero. */
  onReset?: () => Promise<void> | void;
  /** Full-size photo for the viewer (falls back to the thumbnail). */
  getFullUrl?: (id: string) => string | undefined;
  /** Send the selected photos to the AI look check in batches (up to 10 per request). */
  onAiBatch?: (ids: string[]) => Promise<void> | void;
}

const PAGE_SIZE = 12;

export default function HistoryView({ entries, onSelect, onDelete, onDeleteAll, onReset, getFullUrl, onAiBatch }: HistoryViewProps) {
  const [search, setSearch] = useState('');
  const [minScore, setMinScore] = useState('');
  const [maxScore, setMaxScore] = useState('');
  const [sortMode, setSortMode] = useState<HistorySortMode>('newest');
  const [page, setPage] = useState(0);
  const [selecting, setSelecting] = useState(false);
  const [picked, setPicked] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);
  // In-app confirm: the browser's confirm() is blocked inside embedded previews, so deletes silently did nothing.
  const [ask, setAsk] = useState<{ message: string; action: () => void } | null>(null);
  const [viewerIndex, setViewerIndex] = useState<number | null>(null);
  const prefs = useUserPrefs();
  const [folder, setFolder] = useState<string | null>(null);
  const pressTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const longPressed = useRef(false);
  const startPress = (id: string) => {
    longPressed.current = false;
    if (!onDelete) return;
    pressTimer.current = setTimeout(() => {
      if (document.body.dataset.photoDrag) return; // a photo drag owns this hold
      longPressed.current = true;
      haptic('medium');
      setSelecting(true);
      setPicked((p) => new Set(p).add(id));
    }, 450);
  };
  const cancelPress = () => { if (pressTimer.current) clearTimeout(pressTimer.current); pressTimer.current = null; };

  const filtered = useMemo(() => {
    let result = filterByFolder([...entries], prefs.saved, folder);
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter((e) => (e.searchLabel ?? '').toLowerCase().includes(q) || e.source.toLowerCase().includes(q));
    }
    const lo = minScore.trim() === '' ? -Infinity : Number(minScore);
    const hi = maxScore.trim() === '' ? Infinity : Number(maxScore);
    if (Number.isFinite(lo) || Number.isFinite(hi)) result = result.filter((e) => e.overallScore >= lo && e.overallScore <= hi);
    result.sort((a, b) => {
      switch (sortMode) {
        case 'newest': return b.timestamp - a.timestamp;
        case 'oldest': return a.timestamp - b.timestamp;
        case 'highest': return b.overallScore - a.overallScore;
        case 'lowest': return a.overallScore - b.overallScore;
      }
    });
    return result;
  }, [entries, search, minScore, maxScore, sortMode, prefs.saved, folder]);

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const currentPage = Math.min(page, Math.max(0, totalPages - 1));
  const paged = filtered.slice(currentPage * PAGE_SIZE, (currentPage + 1) * PAGE_SIZE);

  const run = async (fn: () => Promise<void> | void) => {
    setBusy(true);
    try { await fn(); } finally { setBusy(false); setPicked(new Set()); setSelecting(false); }
  };
  const toggle = (id: string) => setPicked((p) => { const n = new Set(p); if (n.has(id)) n.delete(id); else n.add(id); return n; });

  const resetBtn = onReset && (
    <button
      disabled={busy}
      onClick={() => setAsk({ message: 'Reset everything? This deletes all analyses AND all your likes/ratings. Your taste learning starts over.', action: () => run(onReset) })}
      className="btn-ghost text-xs py-2 flex items-center gap-1"
    >
      <RotateCcw className="w-4 h-4" /> Reset
    </button>
  );

  const confirmDialog = (
      <AlertDialog open={!!ask} onOpenChange={(o) => { if (!o) setAsk(null); }}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Are you sure?</AlertDialogTitle>
          <AlertDialogDescription>{ask?.message}</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={() => { const a = ask; setAsk(null); a?.action(); }}>Delete</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );

  if (entries.length === 0) {
    return (
      <div className="card p-8 text-center space-y-3">
        <Clock className="w-10 h-10 text-ink-300 mx-auto" />
        <p className="text-sm text-ink-500">Your analysis history will appear here.</p>
        {resetBtn && <div className="flex justify-center">{resetBtn}</div>}
        {confirmDialog}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(0); }}
            placeholder="Search by name..."
            className="input-field pl-10 py-2"
          />
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-ink-500">Score</span>
          <input aria-label="Score from" type="number" inputMode="numeric" min={0} max={100} value={minScore} onChange={(e) => { setMinScore(e.target.value); setPage(0); }} placeholder="from" className="input-field py-2 w-20" />
          <span className="text-xs text-ink-400">–</span>
          <input aria-label="Score to" type="number" inputMode="numeric" min={0} max={100} value={maxScore} onChange={(e) => { setMaxScore(e.target.value); setPage(0); }} placeholder="to" className="input-field py-2 w-20" />
        </div>
        <div className="flex items-center gap-2">
          <ArrowUpDown className="w-4 h-4 text-ink-400" />
          <select value={sortMode} onChange={(e) => setSortMode(e.target.value as HistorySortMode)} className="input-field py-2 w-auto">
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
            <option value="highest">Highest Score</option>
            <option value="lowest">Lowest Score</option>
          </select>
          <select aria-label="Folder" value={folder ?? ''} onChange={(e) => { setFolder(e.target.value || null); setPage(0); }} className="input-field py-2 w-auto">
            <option value="">All folders</option>
            {prefs.folders.map((f) => <option key={f} value={f}>{f}</option>)}
          </select>
        </div>
      </div>

      {/* Delete toolbar */}
      <div className="flex flex-wrap items-center gap-2">
        {onDelete && (selecting ? (
          <>
            <button onClick={() => setPicked(new Set(paged.map((e) => e.id)))} className="btn-ghost text-xs py-2">Select page</button>
            <button onClick={() => setPicked(new Set(filtered.map((e) => e.id)))} className="btn-ghost text-xs py-2">Select all shown</button>
            {onAiBatch && (
              <button
                disabled={busy || picked.size === 0}
                onClick={() => run(() => onAiBatch([...picked]))}
                className="btn-primary text-xs py-2 flex items-center gap-1 disabled:opacity-40"
              >
                <Sparkles className="w-4 h-4" /> AI check ({picked.size})
              </button>
            )}
            <button
              disabled={busy || picked.size === 0}
              onClick={() => setAsk({ message: `Delete ${picked.size} selected?`, action: () => run(() => onDelete([...picked])) })}
              className="btn-primary text-xs py-2 flex items-center gap-1 disabled:opacity-40"
            >
              <Trash2 className="w-4 h-4" /> Delete selected ({picked.size})
            </button>
            <button onClick={() => { setSelecting(false); setPicked(new Set()); }} className="btn-ghost text-xs py-2 flex items-center gap-1"><X className="w-4 h-4" /> Cancel</button>
          </>
        ) : (
          <button onClick={() => setSelecting(true)} className="btn-ghost text-xs py-2 flex items-center gap-1"><CheckSquare className="w-4 h-4" /> Select</button>
        ))}
        {onDeleteAll && (
          <button
            disabled={busy}
            onClick={() => setAsk({ message: `Delete all ${entries.length} analyses? Your likes/ratings are kept.`, action: () => run(onDeleteAll) })}
            className="btn-ghost text-xs py-2 flex items-center gap-1 text-error-500"
          >
            <Trash2 className="w-4 h-4" /> Delete all
          </button>
        )}
        {resetBtn}
        <p className="text-2xs text-ink-400 ml-auto">
          {filtered.length} {filtered.length !== entries.length && `(of ${entries.length})`} analyses
        </p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3">
        {paged.map((entry, i) => {
          const isPicked = picked.has(entry.id);
          return (
            <div key={entry.id} className={`card glass-hover p-2 text-left group relative animate-fade-stagger ${isPicked ? 'ring-2 ring-primary-500' : ''}`} style={{ animationDelay: `${Math.min(i, 12) * 45}ms` }}>
              <PhotoHeading name={entry.searchLabel} className="mb-2" />
              <button
                onClick={() => { if (longPressed.current) { longPressed.current = false; return; } if (selecting) toggle(entry.id); else { haptic('light'); onSelect?.(entry); } }}
                onTouchStart={() => startPress(entry.id)}
                onTouchEnd={cancelPress}
                onTouchMove={cancelPress}
                onContextMenu={(e) => e.preventDefault()}
                className="block w-full text-left"
                {...(selecting ? {} : dragProps(entry.id))}
              >
                <div className="aspect-square rounded-lg overflow-hidden mb-2 bg-ink-100">
                  <img src={entry.thumbnailUrl} alt="" loading="lazy" className="w-full h-full object-cover transition-transform group-hover:scale-105" />
                </div>
                <div className="space-y-0.5">
                  <div className="flex items-center gap-1">
                    <span className="text-sm font-bold text-ink-800">{entry.overallScore}</span>
                    <span className="text-2xs text-ink-400">/100</span>
                    <span className="badge badge-primary text-2xs ml-auto capitalize">{entry.source}</span>
                  </div>
                  <p className="text-2xs text-ink-400">{new Date(entry.timestamp).toLocaleDateString()}</p>
                </div>
              </button>
              {!selecting && (
                <button
                  aria-label="View full screen"
                  onClick={() => { haptic('light'); setViewerIndex(filtered.findIndex((f) => f.id === entry.id)); }}
                  className="absolute bottom-16 left-3 p-1.5 rounded-full bg-white/90 text-ink-700 shadow"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                </button>
              )}
              {selecting ? (
                <span className="absolute bottom-16 left-3 bg-white/90 rounded p-0.5 pointer-events-none">
                  {isPicked ? <CheckSquare className="w-4 h-4 text-primary-600" /> : <Square className="w-4 h-4 text-ink-500" />}
                </span>
              ) : onDelete && (
                <button
                  aria-label="Delete this one"
                  disabled={busy}
                  onClick={() => setAsk({ message: 'Delete this analysis?', action: () => run(() => onDelete([entry.id])) })}
                  className="absolute bottom-16 right-3 p-1.5 rounded-full bg-white/90 text-error-500 shadow"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          );
        })}
      </div>

      {viewerIndex !== null && viewerIndex >= 0 && (
        <PhotoViewer
          items={filtered.map((e) => ({ id: e.id, src: getFullUrl?.(e.id) ?? e.thumbnailUrl, name: e.searchLabel, caption: `${e.overallScore}/100 · ${new Date(e.timestamp).toLocaleDateString()}` }))}
          index={viewerIndex}
          onClose={() => setViewerIndex(null)}
          onDetails={onSelect ? (id) => { const e = filtered.find((f) => f.id === id); setViewerIndex(null); if (e) onSelect(e); } : undefined}
        />
      )}

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 pt-2">
          <button onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={currentPage === 0} className="btn-ghost p-2 disabled:opacity-30"><ChevronLeft className="w-4 h-4" /></button>
          <span className="text-2xs text-ink-500 font-mono">{currentPage + 1} / {totalPages}</span>
          <button onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))} disabled={currentPage >= totalPages - 1} className="btn-ghost p-2 disabled:opacity-30"><ChevronRight className="w-4 h-4" /></button>
        </div>
      )}
      {confirmDialog}
    </div>
  );
}
