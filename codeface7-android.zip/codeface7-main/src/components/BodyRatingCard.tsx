import { PersonStanding, AlertCircle, Loader2 } from 'lucide-react';
import type { AestheticScores } from '@/lib/types';
import { fullLookScore } from '@/lib/aiLookClient';
import { useState } from 'react';
import { BODY_KEYS, BODY_GUIDE, type BodyKey } from '@/lib/bodyTeaching';

const LABELS: Record<BodyKey, string> = { overall: 'Overall', proportions: 'Proportions', physique: 'Physique', posture: 'Posture', presentation: 'Presentation' };

function YourRating({ scores, onSave }: { scores: AestheticScores; onSave: (v: Record<BodyKey, number>) => void }) {
  const start = scores.userBody ?? scores.bodyLook;
  const [v, setV] = useState<Record<BodyKey, number>>(() => Object.fromEntries(BODY_KEYS.map((k) => [k, Math.max(1, Math.round(start?.[k] || 50))])) as Record<BodyKey, number>);
  return (
    <div className="card p-4 space-y-3">
      <div>
        <h3 className="text-sm font-semibold text-ink-900">Your body rating</h3>
        <p className="text-2xs text-ink-500">Rate each part 1–100 (50 = average). Every saved rating teaches the AI your taste: it compares your numbers with its own, learns which body types and parts you score higher or lower, and adjusts future ratings.</p>
      </div>
      {BODY_KEYS.map((k) => (
        <div key={k} className="space-y-1">
          <div className="flex justify-between text-2xs">
            <label htmlFor={`ub-${k}`} className={`text-ink-700 ${k === 'overall' ? 'font-semibold' : 'font-medium'}`}>{LABELS[k]}</label>
            <span className="font-mono text-ink-900">{v[k]}</span>
          </div>
          <p className="text-2xs text-ink-500">{BODY_GUIDE[k]}</p>
          <input id={`ub-${k}`} type="range" min={1} max={100} step={1} value={v[k]} onChange={(e) => setV((p) => ({ ...p, [k]: Number(e.target.value) }))} className="w-full accent-primary-500" />
        </div>
      ))}
      <button type="button" className="btn-primary w-full justify-center" onClick={() => onSave(v)}>{scores.userBody ? 'Update my rating' : 'Save my rating'}</button>
    </div>
  );
}

function Bar({ label, value }: { label: string; value: number }) {
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-2xs text-ink-600">
        <span>{label}</span>
        <span className="font-semibold text-ink-900">{Math.round(value)}</span>
      </div>
      <div className="h-1.5 rounded-full bg-ink-100 overflow-hidden">
        <div className="h-full rounded-full bg-primary-500" style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
      </div>
    </div>
  );
}

function RateButton({ onRate, busy, again }: { onRate?: () => void; busy?: boolean; again?: boolean }) {
  if (!onRate) return null;
  return (
    <button onClick={onRate} disabled={busy} className="btn-secondary w-full justify-center disabled:opacity-60">
      {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <PersonStanding className="w-4 h-4" />}
      <span>{busy ? 'Rating the body…' : again ? 'Rate the body again' : 'Rate the whole body'}</span>
    </button>
  );
}

export default function BodyRatingCard({ onUserRate, ...props }: { scores: AestheticScores; onRate?: () => void; busy?: boolean; onUserRate?: (v: Record<BodyKey, number>) => void }) {
  return (
    <div className="space-y-3">
      {onUserRate && props.scores.bodyLook?.visible && <YourRating scores={props.scores} onSave={onUserRate} />}
      <AiBodyCard {...props} />
    </div>
  );
}

function AiBodyCard({ scores, onRate, busy }: { scores: AestheticScores; onRate?: () => void; busy?: boolean }) {
  const b = scores.bodyLook;
  if (!b) {
    return (
      <div className="card p-4 space-y-2">
        {scores.bodyLookError && (
          <p className="flex items-start gap-2 text-2xs text-ink-500">
            <AlertCircle className="w-4 h-4 text-warning-500 flex-shrink-0" />
            <span>Body rating skipped: {scores.bodyLookError}</span>
          </p>
        )}
        <RateButton onRate={onRate} busy={busy} />
      </div>
    );
  }
  const full = fullLookScore(scores);
  return (
    <div className="card p-5 space-y-3">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-2xs uppercase tracking-wide text-ink-400 flex items-center gap-1">
            <PersonStanding className="w-3.5 h-3.5 text-primary-500" /> Body rating
          </p>
          <h3 className="text-sm font-semibold text-ink-900">
            Whole-body judgement{b.bodyType ? <span className="font-normal text-ink-500"> · {b.bodyType}</span> : null}
          </h3>
        </div>
        {b.visible && <p className="text-2xl font-bold text-ink-900">{Math.round(b.overall)}<span className="text-xs text-ink-400">/100</span></p>}
      </div>
      {b.visible ? (
        <>
          <div className="space-y-2">
            <Bar label="Proportions" value={b.proportions} />
            <Bar label="Physique" value={b.physique} />
            <Bar label="Posture" value={b.posture} />
            <Bar label="Presentation" value={b.presentation} />
          </div>
          {full !== null && (
            <p className="text-2xs text-ink-600">
              Face + body together: <span className="font-semibold text-ink-900">{Math.round(full)}/100</span> (the face score above is not changed)
            </p>
          )}
        </>
      ) : (
        <p className="text-2xs text-ink-500">Not enough of the body is in this photo to rate it. Try a photo showing at least down to the hips.</p>
      )}
      {b.reasons.length > 0 && (
        <ul className="space-y-1 text-2xs text-ink-600 list-disc pl-4">
          {b.reasons.map((r) => <li key={r}>{r}</li>)}
        </ul>
      )}
      <RateButton onRate={onRate} busy={busy} again />
    </div>
  );
}
