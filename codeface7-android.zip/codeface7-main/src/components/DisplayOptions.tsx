import { useState } from 'react';
import { SlidersHorizontal, RotateCcw } from 'lucide-react';
import { useDisplaySettings, type RatioSort, type RatioFilter } from '@/lib/displaySettings';
import type { ErrorUnit } from '@/lib/rawError';

function Toggle({ label, hint, checked, onChange }: { label: string; hint?: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex items-start gap-2 cursor-pointer select-none min-h-[32px]">
      <input type="checkbox" className="mt-0.5 h-4 w-4 accent-primary-500" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      <span>
        <span className="text-2xs font-medium text-ink-700">{label}</span>
        {hint && <span className="block text-2xs text-ink-400 leading-snug">{hint}</span>}
      </span>
    </label>
  );
}

function Segmented<T extends string>({ label, value, options, onChange }: { label: string; value: T; options: Array<[T, string]>; onChange: (v: T) => void }) {
  return (
    <div className="space-y-1">
      <div className="text-2xs font-medium text-ink-600">{label}</div>
      <div className="inline-flex rounded-lg bg-ink-100 p-0.5">
        {options.map(([v, text]) => (
          <button
            key={v}
            type="button"
            onClick={() => onChange(v)}
            className={`px-2.5 py-1 rounded-md text-2xs font-medium transition-colors min-h-[28px] ${value === v ? 'bg-white text-ink-900 shadow-sm' : 'text-ink-500 hover:text-ink-700'}`}
          >
            {text}
          </button>
        ))}
      </div>
    </div>
  );
}

export default function DisplayOptions() {
  const [open, setOpen] = useState(false);
  const [s, set, reset] = useDisplaySettings();

  return (
    <div className="card p-3">
      <div className="flex items-center justify-between gap-2">
        <button type="button" onClick={() => setOpen((o) => !o)} className="flex items-center gap-2 text-sm font-semibold text-ink-800" aria-expanded={open}>
          <SlidersHorizontal className="w-4 h-4 text-primary-500" />
          Display options
        </button>
        <span className="text-2xs text-ink-400 font-mono">{s.showRawError ? 'raw errors on' : 'raw errors off'}</span>
      </div>
      {open && (
        <div className="mt-3 grid sm:grid-cols-2 gap-x-6 gap-y-3 animate-fade-in">
          <Toggle label="Show raw error beside scores" hint='e.g. "1.4% of eye distance" next to Symmetry' checked={s.showRawError} onChange={(v) => set({ showRawError: v })} />
          <Toggle label="Show formulas" hint="Arithmetic under the geometry breakdown" checked={s.showFormulas} onChange={(v) => set({ showFormulas: v })} />
          <Toggle label="Show frontalised mesh plot" checked={s.showMeshPlot} onChange={(v) => set({ showMeshPlot: v })} />
          <Toggle label="Compact metric bars" checked={s.compactMetrics} onChange={(v) => set({ compactMetrics: v })} />
          <Segmented<ErrorUnit> label="Proportion error units" value={s.errorUnit} onChange={(v) => set({ errorUnit: v })} options={[['ideal', '% of ideal'], ['absolute', 'absolute']]} />
          <Segmented<RatioSort> label="Sort proportions" value={s.ratioSort} onChange={(v) => set({ ratioSort: v })} options={[['default', 'Default'], ['worst', 'Worst first'], ['best', 'Best first']]} />
          <Segmented<RatioFilter> label="Proportions shown" value={s.ratioFilter} onChange={(v) => set({ ratioFilter: v })} options={[['all', 'All'], ['off-ideal', 'Off-ideal only']]} />
          <div className="flex items-end">
            <button type="button" onClick={reset} className="btn-ghost text-2xs flex items-center gap-1"><RotateCcw className="w-3 h-3" />Reset options</button>
          </div>
        </div>
      )}
    </div>
  );
}
