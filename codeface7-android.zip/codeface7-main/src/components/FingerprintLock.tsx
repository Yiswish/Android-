import { useEffect, useState, type ReactNode } from 'react';
import { Delete } from 'lucide-react';
import lockBg from '@/assets/aesthetics_lock_home.jpg.asset.json';
import InstallAppButton from '@/components/InstallAppButton';

const PIN_KEY = 'pin-lock-hash';
const SESSION_KEY = 'fp-lock-unlocked';
const PIN_LENGTH = 4;

async function hash(pin: string) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(`aesthetics-pin:${pin}`));
  return Array.from(new Uint8Array(buf), b => b.toString(16).padStart(2, '0')).join('');
}

/** PIN lock screen. First visit: choose a PIN and confirm it. Later: enter it. Stays unlocked until the tab closes. */
export default function FingerprintLock({ children }: { children: ReactNode }) {
  const [unlocked, setUnlocked] = useState<boolean | null>(null);
  const [saved, setSaved] = useState<string | null>(null);
  const [pin, setPin] = useState('');
  const [first, setFirst] = useState<string | null>(null);
  const [msg, setMsg] = useState('');
  const [shake, setShake] = useState(false);

  useEffect(() => {
    setSaved(localStorage.getItem(PIN_KEY));
    setUnlocked(sessionStorage.getItem(SESSION_KEY) === '1');
  }, []);

  const fail = (text: string) => {
    setMsg(text); setPin(''); setShake(true);
    setTimeout(() => setShake(false), 400);
  };

  const submit = async (value: string) => {
    if (!saved) {
      if (!first) { setFirst(value); setPin(''); setMsg(''); return; }
      if (value !== first) { setFirst(null); fail("PINs didn't match — choose again"); return; }
      const h = await hash(value);
      localStorage.setItem(PIN_KEY, h); setSaved(h);
    } else if ((await hash(value)) !== saved) {
      fail('Wrong PIN'); return;
    }
    sessionStorage.setItem(SESSION_KEY, '1'); setUnlocked(true);
  };

  const press = (d: string) => {
    if (pin.length >= PIN_LENGTH) return;
    const next = pin + d;
    setPin(next);
    if (next.length === PIN_LENGTH) setTimeout(() => submit(next), 120);
  };

  if (unlocked === null) return <div className="min-h-screen mesh-bg" />;
  if (unlocked) return <>{children}</>;

  const title = !saved ? (first ? 'Confirm your PIN' : 'Choose a 4-digit PIN') : 'Enter PIN';
  const now = new Date();
  const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', 'del'];

  return (
    <div className="relative min-h-screen flex flex-col items-center justify-between px-6 py-10 select-none bg-cover bg-center"
      style={{ backgroundImage: `linear-gradient(to bottom, rgb(0 0 0 / 0.5), rgb(0 0 0 / 0.1) 30%, rgb(0 0 0 / 0.45) 55%, rgb(0 0 0 / 0.75)), url(${lockBg.url})` }}>
      <div className="absolute top-3 right-3 rounded-lg bg-white/85 backdrop-blur">
        <InstallAppButton />
      </div>
      <div className="text-center">
        <p className="text-6xl font-light text-white drop-shadow tabular-nums">{now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
        <p className="mt-2 text-sm text-white/85 drop-shadow">{now.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' })}</p>
      </div>
      <h1 className="sr-only">Aesthetics Analyzer — locked</h1>
      <div className="flex flex-col items-center gap-5 w-full max-w-xs">
        <p className="text-sm font-medium text-white drop-shadow">{title}</p>
        <div className={`flex gap-4 ${shake ? 'animate-[shake_0.4s]' : ''}`} aria-label={`${pin.length} of ${PIN_LENGTH} digits entered`}>
          {Array.from({ length: PIN_LENGTH }, (_, i) => (
            <span key={i} className={`w-3.5 h-3.5 rounded-full border-2 border-white ${i < pin.length ? 'bg-white' : 'bg-transparent'}`} />
          ))}
        </div>
        <p className="text-xs text-white/90 min-h-4">{msg}</p>
        <div className="grid grid-cols-3 gap-4 w-full">
          {keys.map((k, i) => k === '' ? <span key={i} /> : (
            <button key={i} aria-label={k === 'del' ? 'Delete' : k}
              onClick={() => (k === 'del' ? setPin(p => p.slice(0, -1)) : press(k))}
              className="h-16 rounded-full bg-white/15 backdrop-blur border border-white/25 text-white text-2xl font-light flex items-center justify-center active:bg-white/35 transition-colors">
              {k === 'del' ? <Delete className="w-6 h-6" /> : k}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
