import { AlertTriangle } from 'lucide-react';

interface WarningBannerProps {
  warnings: string[];
}

export default function WarningBanner({ warnings }: WarningBannerProps) {
  if (!warnings || warnings.length === 0) return null;

  return (
    <div className="space-y-2">
      {warnings.map((warning, i) => (
        <div
          key={i}
          className="flex items-start gap-2 p-3 rounded-xl bg-warning-50 border border-warning-200 animate-fade-in-down"
          style={{ animationDelay: `${i * 50}ms` }}
        >
          <AlertTriangle className="w-4 h-4 text-warning-600 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-warning-700">{warning}</p>
        </div>
      ))}
    </div>
  );
}
