import { Heart, Star, TrendingUp, TrendingDown, Sparkles } from 'lucide-react';
import type { TasteMatch } from '@/lib/types';
import { TASTE_MIN_RATINGS } from '@/lib/preferenceEngine';
import PhotoHeading from './PhotoHeading';

function Stars({ value }: { value: number }) {
  return (
    <div className="flex gap-0.5" aria-label={`${value.toFixed(1)} stars`}>
      {[1, 2, 3, 4, 5].map((i) => {
        const fill = Math.max(0, Math.min(1, value - (i - 1)));
        return (
          <span key={i} className="relative w-5 h-5">
            <Star className="absolute inset-0 w-5 h-5 text-ink-200" />
            <span className="absolute inset-0 overflow-hidden" style={{ width: `${fill * 100}%` }}>
              <Star className="w-5 h-5 text-warning-500 fill-current" />
            </span>
          </span>
        );
      })}
    </div>
  );
}

const confLabel = (c: number) => (c >= 0.6 ? 'High' : c >= 0.3 ? 'Medium' : 'Low');

export default function TasteMatchCard({ match, ratingsCount, photoNames }: { match?: TasteMatch; ratingsCount: number; photoNames?: Map<string, string> }) {
  if (!match) {
    const left = Math.max(0, TASTE_MIN_RATINGS - ratingsCount);
    return (
      <div className="card p-5 space-y-3">
        <h3 className="text-sm font-semibold text-ink-800 flex items-center gap-1.5">
          <Heart className="w-4 h-4 text-primary-500" /> Your taste
        </h3>
        <p className="text-sm text-ink-600">
          Rate {left} more image{left === 1 ? '' : 's'} with stars and I'll start predicting how much you'll like new ones.
        </p>
        <div className="h-1.5 rounded-full bg-ink-100 overflow-hidden">
          <div className="h-full bg-primary-500 rounded-full" style={{ width: `${(Math.min(ratingsCount, TASTE_MIN_RATINGS) / TASTE_MIN_RATINGS) * 100}%` }} />
        </div>
      </div>
    );
  }
  return (
    <div className="card p-5 space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-1">
          <p className="text-2xs uppercase tracking-wide text-ink-400 flex items-center gap-1">
            <Heart className="w-3.5 h-3.5 text-primary-500" /> Your taste
          </p>
          <h3 className="text-lg font-semibold text-ink-900 leading-tight">{match.verdict}</h3>
        </div>
        <div className="text-right shrink-0">
          <Stars value={match.predictedStars} />
        </div>
      </div>

      <div className="space-y-1.5">
        <div className="relative h-2 rounded-full bg-ink-100">
          <div className="absolute inset-y-0 left-0 rounded-full bg-primary-500" style={{ width: `${match.score}%` }} />
        </div>
        <p className="text-2xs text-ink-500">Would rank above <b className="text-ink-700">{match.score}%</b> of the {match.ratingsUsed} images you rated</p>
      </div>

      {(match.pros?.length || match.cons?.length) ? (
        <div className="flex flex-wrap gap-1.5">
          {match.pros?.map((p) => (
            <span key={p} className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-success-50 text-success-700 text-2xs"><TrendingUp className="w-3 h-3" />{p}</span>
          ))}
          {match.cons?.map((c) => (
            <span key={c} className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-warning-50 text-warning-700 text-2xs"><TrendingDown className="w-3 h-3" />{c}</span>
          ))}
        </div>
      ) : (
        <p className="text-2xs text-ink-500">{match.summary}</p>
      )}

      {match.neighbours && match.neighbours.length > 0 && (
        <div className="space-y-1.5">
          <p className="text-2xs text-ink-400 flex items-center gap-1"><Sparkles className="w-3 h-3" /> Most like these you rated</p>
          <div className="flex gap-2 overflow-x-auto">
            {match.neighbours.map((n) => (
              <div key={n.imageId} className="w-20 shrink-0 space-y-1"><PhotoHeading name={photoNames?.get(n.imageId)} className="text-xs" /><div className="relative w-20 h-16 rounded-xl overflow-hidden bg-ink-100">
                {n.imageUrl && <img src={n.imageUrl} alt="" className="w-full h-full object-cover" loading="lazy" />}
                <span className="absolute bottom-0.5 right-0.5 px-1 rounded bg-ink-900/70 text-white text-2xs">{n.stars}★</span>
              </div></div>
            ))}
          </div>
        </div>
      )}

      <p className="text-2xs text-ink-400">
        {confLabel(match.confidence)} confidence · separate from the face score
      </p>
    </div>
  );
}
