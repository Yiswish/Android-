import { useEffect, useState } from 'react';
import { Slider } from './ui/slider';
import { ratingToScore, scoreToRating } from '@/lib/faceTeaching';

interface StarRatingProps {
  imageId: string;
  initialRating?: number;
  onRate: (imageId: string, rating: number) => void;
}

export default function StarRating({ imageId, initialRating = 0, onRate }: StarRatingProps) {
  const [value, setValue] = useState(initialRating ? ratingToScore(initialRating) : 50);
  const [rated, setRated] = useState(initialRating > 0);
  useEffect(() => { setValue(initialRating ? ratingToScore(initialRating) : 50); setRated(initialRating > 0); }, [imageId, initialRating]);

  return (
    <div data-no-swipe className="w-full min-w-0 space-y-2 py-2">
      <div className="flex justify-between text-xs text-muted-foreground"><span>Your face rating</span><span className="font-mono">{rated ? `${value}/100` : 'Not rated'}</span></div>
      <Slider aria-label="Your face rating" min={0} max={100} step={1} value={[value]} className="min-h-8"
        onValueChange={([next]) => { setValue(next); setRated(true); }}
        onValueCommit={([next]) => onRate(imageId, scoreToRating(next))} />
    </div>
  );
}
