import { Eye, AlertCircle, ScanSearch, Loader2, Gavel } from 'lucide-react';
import type { AestheticScores } from '@/lib/types';

function WayOffButton({ onWayOff, busy, again }: { onWayOff?: () => void; busy?: boolean; again?: boolean }) {
  if (!onWayOff) return null;
  return (
    <div className="space-y-1">
      <button onClick={onWayOff} disabled={busy} className="btn-secondary w-full justify-center disabled:opacity-60">
        {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <ScanSearch className="w-4 h-4" />}
        <span>{busy ? 'Final analyst is weighing (3 passes)…' : again ? 'Ask the final analyst again' : 'Overall way off? Ask the final analyst'}</span>
      </button>
      <p className="text-2xs text-ink-400 text-center">A third analyst looks at the photo, the AI score and the measurements, and sets only the overall score.</p>
    </div>
  );
}

function FinalAnalystCard({ scores }: { scores: AestheticScores }) {
  const f = scores.finalAnalyst;
  if (!f) return null;
  return (
    <div className="rounded-xl border border-ink-100 p-4 space-y-2">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-2xs uppercase tracking-wide text-ink-400 flex items-center gap-1">
            <Gavel className="w-3.5 h-3.5 text-primary-500" /> Final analyst
          </p>
          <h4 className="text-sm font-semibold text-ink-900">Overall verdict</h4>
        </div>
        <p className="text-2xl font-bold text-ink-900">{Math.round(f.overall)}<span className="text-xs text-ink-400">/100</span></p>
      </div>
      {f.reasons.length > 0 && (
        <ul className="space-y-1 text-2xs text-ink-600 list-disc pl-4">
          {f.reasons.map((r) => <li key={r}>{r}</li>)}
        </ul>
      )}
    </div>
  );
}

export default function AiLookCard({ scores, onWayOff, busy }: { scores: AestheticScores; onWayOff?: () => void; busy?: boolean }) {
  if (scores.aiLookError && !scores.aiLook) {
    return (
      <div className="card p-4 flex items-start gap-2 text-2xs text-ink-500">
        <AlertCircle className="w-4 h-4 text-warning-500 flex-shrink-0" />
        <span className="block">AI look check skipped: {scores.aiLookError} The score above uses measurements only.</span>
      </div>
    );
  }
  const a = scores.aiLook;
  if (!a) return null;
  return (
    <div className="card p-5 space-y-3">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-2xs uppercase tracking-wide text-ink-400 flex items-center gap-1">
            <Eye className="w-3.5 h-3.5 text-primary-500" /> AI look check
          </p>
          <h3 className="text-sm font-semibold text-ink-900">Whole-face judgement</h3>
        </div>
        <p className="text-2xl font-bold text-ink-900">{Math.round(a.attractiveness)}<span className="text-xs text-ink-400">/100</span></p>
      </div>
      <div className="h-2 rounded-full bg-ink-100 overflow-hidden">
        <div className="h-full rounded-full bg-primary-500" style={{ width: `${a.attractiveness}%` }} />
      </div>
      {(a.tasteRatingsUsed ?? 0) > 0 && a.rawAttractiveness !== undefined && Math.round(a.rawAttractiveness) !== Math.round(a.attractiveness) && (
        <p className="text-2xs text-primary-600">Adjusted from {Math.round(a.rawAttractiveness)} using your {a.tasteRatingsUsed} slider rating{a.tasteRatingsUsed === 1 ? '' : 's'}.</p>
      )}
      {a.description && <p className="text-xs text-ink-700 italic">{a.description}</p>}
      {a.reasons.length > 0 && (
        <ul className="space-y-1 text-2xs text-ink-600 list-disc pl-4">
          {a.reasons.map((r) => <li key={r}>{r}</li>)}
        </ul>
      )}
      <FinalAnalystCard scores={scores} />
      <WayOffButton onWayOff={onWayOff} busy={busy} again={!!scores.finalAnalyst} />
    </div>
  );
}
