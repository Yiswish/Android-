import PhotoHeading from './PhotoHeading';
import { Check, Loader2, Square, X, AlertTriangle, Images } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { AnalysisResult, SearchResultImage } from '@/lib/types';
import type { BatchStatus } from '@/lib/batchAnalysis';
import { WeightedScore } from './CollectionTools';

export interface BatchPhoto {
  image: SearchResultImage;
  status: BatchStatus;
  result?: AnalysisResult;
  error?: string;
}

export default function BatchAnalysisPanel({ photos, busy, stopping, onStop, onClose, onOpen }: {
  photos: BatchPhoto[];
  busy: boolean;
  stopping: boolean;
  onStop: () => void;
  onClose: () => void;
  onOpen: (result: AnalysisResult) => void;
}) {
  const finished = photos.filter((p) => ['complete', 'failed', 'cancelled'].includes(p.status)).length;
  const labels: Record<BatchStatus, string> = { queued: 'Queued', analyzing: 'Analysing…', complete: 'Complete', failed: 'Failed', cancelled: 'Stopped' };
  return (
    <section className="space-y-3 border-y border-ink-200 py-4" aria-label="Multi-photo analysis" data-testid="batch-ranking">
      <div className="flex items-center gap-2">
        <Images className="h-4 w-4 text-primary-500 shrink-0" />
        <h3 className="text-sm font-semibold text-ink-800 flex-1">Photo analyses</h3>
        {busy ? <Button variant="outline" size="sm" disabled={stopping} onClick={onStop}><Square />{stopping ? 'Stopping…' : 'Stop'}</Button> : <Button variant="ghost" size="icon" aria-label="Close photo analyses" onClick={onClose}><X /></Button>}
      </div>
      <p role="status" className="text-xs text-ink-500">{finished}/{photos.length} finished{stopping ? ' · Finishing active photos' : ''}</p>
      <progress aria-label="Photos finished" value={finished} max={Math.max(1, photos.length)} className="w-full h-2 accent-primary-500" />
      <ul className="grid gap-2 sm:grid-cols-2">
        {photos.map((photo) => (
          <li key={photo.image.id} className="flex gap-3 items-start border border-ink-200 rounded-lg p-3 min-w-0">
            <div className="w-24 shrink-0 space-y-1"><PhotoHeading name={photo.image.searchLabel} className="text-xs" /><Button
              variant="ghost"
              className="w-24 h-16 p-0 rounded-md overflow-hidden shrink-0"
              aria-label={`Open analysis for ${photo.image.alt}`}
              disabled={!photo.result}
              onClick={() => { if (photo.result) onOpen(photo.result); }}
            >
              <img src={photo.image.url} alt={photo.image.alt} className="w-full h-full object-cover bg-ink-100" />
            </Button></div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-medium text-ink-800 truncate" title={photo.image.alt}>{photo.image.alt}</p>
              <p className="flex items-center gap-1.5 text-xs text-ink-500 mt-1">
                {photo.status === 'analyzing' && <Loader2 className="w-3 h-3 animate-spin motion-reduce:animate-none" />}
                {photo.status === 'complete' && <Check className="w-3 h-3 text-primary-600" />}
                {photo.status === 'failed' && <AlertTriangle className="w-3 h-3 text-warning-700" />}
                {labels[photo.status]}
              </p>
              {photo.error && <p className="text-xs text-warning-700 break-words mt-1">{photo.error}</p>}
              {photo.result && <>
                <p className="text-xs text-ink-600 mt-1">Overall {Math.round(photo.result.scores.overall)}/100{photo.result.scores.bodyLook?.visible ? ` · Body ${Math.round(photo.result.scores.bodyLook.overall)}/100` : ''}</p>
                <WeightedScore scores={photo.result.scores} compact />
                {(photo.result.scores.aiLookError || photo.result.scores.bodyLookError) && <p className="text-xs text-warning-700 break-words mt-1">{photo.result.scores.aiLookError || photo.result.scores.bodyLookError}</p>}
                <Button variant="link" size="sm" className="px-0 text-primary-600" onClick={() => { if (photo.result) onOpen(photo.result); }}>View results</Button>
              </>}
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}