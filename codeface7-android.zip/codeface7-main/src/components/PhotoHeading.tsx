import { createContext, useContext } from 'react';
import { Button } from './ui/button';

export const PhotoNameSearchContext = createContext<((name: string) => void) | undefined>(undefined);

export default function PhotoHeading({ name, className = '', onSearch }: { name?: string; className?: string; onSearch?: (name: string) => void }) {
  const sharedSearch = useContext(PhotoNameSearchContext);
  const search = onSearch ?? sharedSearch;
  if (!name?.trim()) return null;
  if (search) return <Button type="button" variant="link" title={`Search young portraits of ${name}`} className={`h-auto min-h-9 p-0 justify-start whitespace-normal text-left text-sm font-semibold text-ink-800 break-words ${className}`} onPointerDown={(e) => e.stopPropagation()} onClick={(e) => { e.stopPropagation(); search(name); }}>{name}</Button>;
  return <p className={`text-sm font-semibold text-ink-800 break-words ${className}`}>{name}</p>;
}