import { useEffect, useState } from 'react';
import { Download } from 'lucide-react';
import { toast } from 'sonner';

// Chrome/Edge fire this when the app is installable as a PWA.
interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

function isStandalone(): boolean {
  return (
    window.matchMedia('(display-mode: standalone)').matches ||
    (navigator as unknown as { standalone?: boolean }).standalone === true
  );
}

// Captured at module load so the prompt isn't missed while the app is still locked.
let earlyPrompt: BeforeInstallPromptEvent | null = null;
if (typeof window !== 'undefined') {
  window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); earlyPrompt = e as BeforeInstallPromptEvent; });
}

export default function InstallAppButton() {
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(() => earlyPrompt);
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    if (isStandalone()) { setInstalled(true); return; }
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setDeferred(e as BeforeInstallPromptEvent);
    };
    const onInstalled = () => { setInstalled(true); setDeferred(null); };
    window.addEventListener('beforeinstallprompt', onPrompt);
    window.addEventListener('appinstalled', onInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', onPrompt);
      window.removeEventListener('appinstalled', onInstalled);
    };
  }, []);

  if (installed) return null;

  const handleClick = async () => {
    if (deferred) {
      await deferred.prompt();
      const choice = await deferred.userChoice;
      if (choice.outcome === 'accepted') setInstalled(true);
      earlyPrompt = null;
      setDeferred(null);
      return;
    }
    // iOS Safari and browsers without the prompt: explain the manual steps.
    const isIos = /iphone|ipad|ipod/i.test(navigator.userAgent);
    toast.info(
      isIos
        ? 'To install: tap the Share button, then "Add to Home Screen".'
        : 'To install: open the browser menu and choose "Install app" or "Add to Home Screen".',
      { duration: 6000 },
    );
  };

  return (
    <button
      aria-label="Download app"
      onClick={handleClick}
      className="p-2 rounded-lg text-ink-500 hover:text-ink-700 hover:bg-ink-100 min-h-[40px] min-w-[40px] flex items-center justify-center"
      title="Download app"
    >
      <Download className="w-5 h-5" />
    </button>
  );
}
