import { useState } from 'react';
import { FolderPlus, Check, Plus } from 'lucide-react';
import type { AestheticScores } from '@/lib/types';
import { useUserPrefs, weightedScore, weightedParts, toggleSaved, addFolder } from '@/lib/userPrefs';

/** Personal score; the results ring uses detailsOnly to avoid a duplicate number. */
export function WeightedScore({ scores, compact = false, detailsOnly = false }: { scores: AestheticScores; compact?: boolean; detailsOnly?: boolean }) {
  const p = useUserPrefs();
  const w = weightedScore(scores, p.weights);
  if (w === undefined) return null;
  if (compact) return <span className="text-xs font-semibold text-primary-700" title="Your weighted score (from your weight sliders)">Weighted {w}/100</span>;
  const parts = weightedParts(scores, p.weights);
  const missing = parts.filter((x) => x.value === undefined && x.weight > 0);
  return (
    <div className={detailsOnly ? 'mt-4 w-full text-primary-800' : 'mt-4 w-full rounded-xl bg-primary-50 p-3 text-primary-800'}>
      {!detailsOnly && <div className="flex items-baseline justify-between gap-2">
        <span className="text-xs font-medium">Your weighted score</span>
        <span className="text-2xl font-bold">{w}<span className="text-xs font-normal">/100</span></span>
      </div>}
      <details className="mt-1.5">
        <summary className="text-2xs text-primary-700 cursor-pointer select-none">See the mix</summary>
        <ul className="mt-1 space-y-1">
          {parts.map((x) => (
            <li key={x.key} className="flex justify-between text-2xs font-mono">
              <span>{x.label} {x.value === undefined ? '—' : Math.round(x.value)}</span>
              <span>{x.value === undefined ? 'not available' : `× ${x.share}%`}</span>
            </li>
          ))}
        </ul>
      {missing.length > 0 && (
        <p className="mt-2 text-2xs text-primary-700">{missing.map((m) => m.label).join(' and ')} missing for this photo, so {missing.length > 1 ? 'those sliders have' : 'that slider has'} no effect here.</p>
      )}
      </details>
    </div>
  );
}

/** Save the current analysis into one or more named folders. */
export function FolderPicker({ analysisId }: { analysisId: string }) {
  const p = useUserPrefs();
  const [name, setName] = useState('');
  const mine = p.saved[analysisId] ?? [];
  return (
    <div className="card p-4 space-y-2">
      <div className="flex items-center gap-2 text-sm font-semibold text-ink-800"><FolderPlus className="w-4 h-4 text-primary-500" /> Save to folder</div>
      <div className="flex flex-wrap gap-1.5">
        {p.folders.map((f) => {
          const on = mine.includes(f);
          return (
            <button key={f} type="button" aria-pressed={on} onClick={() => toggleSaved(analysisId, f)}
              className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-xs min-h-[32px] ${on ? 'bg-primary-500 text-white' : 'bg-ink-100 text-ink-600 hover:bg-ink-200'}`}>
              {on && <Check className="w-3 h-3" />}{f}
            </button>
          );
        })}
        {p.folders.length === 0 && <span className="text-2xs text-ink-400">No folders yet — create one below.</span>}
      </div>
      <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); const n = name.trim(); if (!n) return; addFolder(n); if (!mine.includes(n)) toggleSaved(analysisId, n); setName(''); }}>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="New folder…" className="input-field py-2 text-xs" />
        <button type="submit" className="btn-secondary text-xs" aria-label="Create folder and save"><Plus className="w-4 h-4" /></button>
      </form>
    </div>
  );
}
