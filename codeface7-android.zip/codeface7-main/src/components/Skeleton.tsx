import type React from 'react';
interface SkeletonProps {
  className?: string;
  style?: React.CSSProperties;
}

export function SkeletonBar({ className = '', style }: SkeletonProps) {
  return (
    <div style={style} className={`relative overflow-hidden bg-ink-100 rounded-full ${className}`}>
      <div className="absolute inset-0 shimmer" />
    </div>
  );
}

export function SkeletonCircle({ size = 144 }: { size?: number }) {
  return (
    <div
      className="relative overflow-hidden bg-ink-100 rounded-full"
      style={{ width: size, height: size }}
    >
      <div className="absolute inset-0 shimmer" />
    </div>
  );
}

export function SkeletonCard({ className = '' }: SkeletonProps) {
  return (
    <div className={`card p-4 space-y-3 ${className}`}>
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-ink-100 relative overflow-hidden">
          <div className="absolute inset-0 shimmer" />
        </div>
        <div className="flex-1 space-y-1.5">
          <SkeletonBar className="h-3 w-1/2" />
          <SkeletonBar className="h-2 w-1/3" />
        </div>
      </div>
    </div>
  );
}

export function SkeletonScoreDisplay() {
  return (
    <div className="flex flex-col items-center justify-center space-y-3">
      <SkeletonCircle size={144} />
      <div className="space-y-1.5 flex flex-col items-center">
        <SkeletonBar className="h-5 w-20" />
        <SkeletonBar className="h-3 w-16" />
      </div>
    </div>
  );
}

export function SkeletonMetricsPanel({ count = 10 }: { count?: number }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="space-y-2" style={{ animationDelay: `${i * 50}ms` }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-ink-200" />
              <SkeletonBar className="h-3 w-20" />
            </div>
            <SkeletonBar className="h-3 w-6" />
          </div>
          <SkeletonBar className="h-2.5 w-full" style={{ animationDelay: `${i * 60}ms` } as React.CSSProperties} />
        </div>
      ))}
    </div>
  );
}

export function SkeletonFeatureChart() {
  return (
    <div className="space-y-3">
      <div className="flex items-end gap-1.5 h-52 px-2">
        {Array.from({ length: 10 }).map((_, i) => (
          <div
            key={i}
            className="flex-1 flex flex-col items-center justify-end"
          >
            <div
              className="w-full max-w-[2.2rem] rounded-t-lg bg-ink-100 relative overflow-hidden"
              style={{ height: `${30 + Math.random() * 60}%` }}
            >
              <div className="absolute inset-0 shimmer" />
            </div>
          </div>
        ))}
      </div>
      <div className="flex items-center gap-1.5 px-2">
        {Array.from({ length: 10 }).map((_, i) => (
          <SkeletonBar key={i} className="h-3 flex-1" />
        ))}
      </div>
    </div>
  );
}
