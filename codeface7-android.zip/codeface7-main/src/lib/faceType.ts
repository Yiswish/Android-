// ============================================================================
// FACE TYPE SEED — the owner's preferred face type, taught to the engine with
// plain shape words only (no real names). Works from the first scan, before any
// star ratings exist, and is shown beside — never blended into — the face score.
//
// Preferred look: soft heart-to-oval face, high full cheekbones, big open almond
// eyes, a small refined nose with fuller lips, and smooth youthful skin.
//
// Every target and σ below is a GUESS (not calibrated on any photo).
// ============================================================================
import type { FaceGeometryReport } from './faceGeometry';
import type { MetricScores } from './types';

export interface FaceTrait {
  ratioId: string;
  label: string;
  target: number;
  sigma: number;
  weight: number;
}

export const FACE_TYPE_NAME = 'Soft doll-like heart face';

export const FACE_TYPE_TRAITS: FaceTrait[] = [
  { ratioId: 'eye-aspect', label: 'Big open almond eyes', target: 0.36, sigma: 0.04, weight: 0.25 },
  { ratioId: 'fwhr', label: 'High, wide cheekbones', target: 1.95, sigma: 0.12, weight: 0.2 },
  { ratioId: 'face-length', label: 'Soft heart / oval shape', target: 1.2, sigma: 0.06, weight: 0.2 },
  { ratioId: 'mouth-nose', label: 'Small nose, fuller lips', target: 1.65, sigma: 0.15, weight: 0.15 },
];
/** Skin smoothness (the `skin` metric, 0–100) carries the remaining weight. */
export const FACE_TYPE_SKIN_WEIGHT = 0.2;

export interface FaceTypeMatch {
  score: number;
  hits: string[];
  misses: string[];
  measured: number;
}

const closeness = (z: number) => 100 * Math.exp(-0.5 * z * z);

export function faceTypeMatch(geometry: Pick<FaceGeometryReport, 'ratios'> | undefined, metrics?: Partial<MetricScores>): FaceTypeMatch | undefined {
  const ratios = geometry?.ratios ?? [];
  let sum = 0, wSum = 0, measured = 0;
  const hits: string[] = [], misses: string[] = [];
  for (const t of FACE_TYPE_TRAITS) {
    const r = ratios.find((x) => x.id === t.ratioId);
    if (!r || !Number.isFinite(r.measured)) continue;
    const s = closeness((r.measured - t.target) / t.sigma);
    sum += s * t.weight; wSum += t.weight; measured++;
    if (s >= 65) hits.push(t.label); else if (s < 35) misses.push(t.label);
  }
  if (measured === 0) return undefined;
  const skin = metrics?.skin;
  if (typeof skin === 'number' && Number.isFinite(skin)) {
    sum += skin * FACE_TYPE_SKIN_WEIGHT; wSum += FACE_TYPE_SKIN_WEIGHT;
    if (skin >= 75) hits.push('Smooth youthful skin'); else if (skin < 45) misses.push('Smooth youthful skin');
  }
  return { score: Math.round(sum / wSum), hits, misses, measured };
}

/** Descriptive searches for this face type — no real names. */
export const FACE_TYPE_SEARCHES = [
  'doll face model big eyes full lips',
  'heart shaped face model high cheekbones',
  'soft feminine face close up portrait',
  'fresh face model natural makeup',
];
