/** Bounded parallel photo work; synchronous mesh calls remain on the browser thread. */
export type BatchStatus = 'queued' | 'analyzing' | 'complete' | 'failed' | 'cancelled';

export async function analyzeInParallel<T, R>(options: {
  items: T[];
  analyze: (item: T) => Promise<R>;
  concurrency?: number;
  shouldStop: () => boolean;
  onUpdate: (index: number, status: BatchStatus, result?: R, error?: string) => void;
}) {
  let next = 0;
  const results: R[] = [];
  async function worker() {
    while (next < options.items.length && !options.shouldStop()) {
      const index = next++;
      options.onUpdate(index, 'analyzing');
      try {
        const result = await options.analyze(options.items[index]);
        results.push(result);
        options.onUpdate(index, 'complete', result);
      } catch (error) {
        options.onUpdate(index, 'failed', undefined, error instanceof Error ? error.message : 'This photo could not be analysed.');
      }
    }
  }
  await Promise.all(Array.from({ length: Math.min(options.items.length, Math.max(1, options.concurrency ?? 2)) }, worker));
  while (next < options.items.length) options.onUpdate(next++, 'cancelled');
  return results;
}