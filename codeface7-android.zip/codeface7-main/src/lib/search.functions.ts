import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { searchChain } from './search.providers';
import { personalKeysAllowed } from './keySettings.server';

// Server function: runs the provider chain on the server (no CORS, key stays server-side).
//   SerpAPI (needs the SERPAPI_API_KEY secret) → Openverse → Wikimedia Commons → curated (client).
// The key is read in search.providers.ts as
//   globalThis.Netlify?.env?.get('SERPAPI_API_KEY') ?? process.env.SERPAPI_API_KEY
// and is never returned, logged or bundled for the client. The query is sent exactly as typed.
// The provider logic lives in search.providers.ts so it can be unit-tested with a mocked fetch.

const Input = z.object({
  query: z.string().min(1).max(200),
  page: z.number().int().min(1).max(50),
  perPage: z.number().int().min(1).max(50),
  source: z.enum(['google', 'pinterest', 'upload', 'curated', 'pexels', 'unsplash', 'openverse', 'wikimedia', 'elitebabes']),
  portraitMode: z.enum(['young', 'all-ages']).optional(),
  personalKey: z.string().trim().min(1).max(512).optional(),
  personalKeys: z.object({
    serpapi: z.string().trim().min(1).max(512).optional(),
    serper: z.string().trim().min(1).max(512).optional(),
    pexels: z.string().trim().min(1).max(512).optional(),
    unsplash: z.string().trim().min(1).max(512).optional(),
  }).optional(),
});

export type { Provider, FallbackReason } from './search.providers';
export { isFaceQuery } from './search.providers';

export const searchImagesServer = createServerFn({ method: 'POST' })
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data }) => {
    const { personalKey, personalKeys, ...input } = data;
    const keys = { ...personalKeys, ...(personalKey ? { serpapi: personalKey } : {}) };
    for (const provider of ['serpapi', 'serper', 'pexels', 'unsplash'] as const) {
      if (keys[provider] && !await personalKeysAllowed(provider)) throw new Error('Personal search keys are locked by the owner.');
    }
    return searchChain(input, keys);
  });
