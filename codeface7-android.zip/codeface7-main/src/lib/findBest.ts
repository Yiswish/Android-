// "Find the best" run: several queries → one shared candidate pool → cheap measurement on up to `cap`
// photos → the AI look check only on the top N → re-ranked result. Pure orchestration; every
// expensive step is injected so the cap, fairness and quota stops are unit-tested.
import { analyzeInParallel } from './batchAnalysis';
import { portraitBias } from './search.providers';
import type { AestheticScores, SearchResponse, SearchResultImage } from './types';

export const FIND_BEST_DEFAULT_CAP = 10;
export const FIND_BEST_DEFAULT_TOP_N = 3;
export const FIND_BEST_MAX_CAP = 300;

export interface FindBestProgress {
  phase: 'search' | 'measure' | 'ai' | 'complete';
  activeQueries: string[];
  photos: Array<{ image: SearchResultImage; query: string; status: 'queued' | 'measuring' | 'measured' | 'checking' | 'complete' | 'failed' | 'cancelled'; detail?: string; score?: number; aiScore?: number }>;
  /** Live agent log, newest last (capped). */
  log: string[];
  /** Image id of the current best candidate. */
  leaderId?: string;
  selected: number;
  searchesDone: number;
  searchesTotal: number;
  candidates: number;
  analysed: number;
  cap: number;
  aiChecks: number;
  topN: number;
}

export interface FindBestStop { provider: 'SerpAPI' | 'Groq'; reason: string }

export interface FindBestEntry<M> {
  image: SearchResultImage;
  query: string;
  measured: M;
  scores: AestheticScores;
  /** true = AI look check blended in; false = measurement-only (not checked, or the check failed). */
  aiChecked: boolean;
  aiError?: string;
}

export interface FindBestResult<M> {
  best?: FindBestEntry<M>;
  ranked: FindBestEntry<M>[];
  stopped?: FindBestStop;
  progress: FindBestProgress;
}

export interface FindBestDeps<M> {
  search: (query: string) => Promise<SearchResponse>;
  /** Measurement-only analysis (no Gemini call). */
  measure: (image: SearchResultImage) => Promise<{ measured: M; scores: AestheticScores }>;
  /** Existing AI look check + blend; returns scores with aiLook or aiLookError. */
  aiCheck: (image: SearchResultImage, scores: AestheticScores) => Promise<AestheticScores>;
  onProgress?: (p: FindBestProgress) => void;
  shouldCancel?: () => boolean;
  concurrency?: number;
  searchConcurrency?: number;
  /** Parallel AI checks (kept low so per-minute AI limits are not hit). */
  aiConcurrency?: number;
  sleep?: (ms: number) => Promise<void>;
}

const AI_TEMPORARY = /rate limit|429|busy/i;
const AI_EXHAUSTED = /out of quota|quota.*exhaust|credits.*run out|key rejected|not set up|not available for this workspace/i;
/** Waits before retrying a busy/rate-limited AI check (GUESSED to fit per-minute limits). */
export const AI_RETRY_WAITS = [8000, 20000, 40000];
const defaultSleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

/** Splits pasted text into queries, keeping each line exactly as typed (only empty lines dropped). */
export function parseQueries(text: string): string[] {
  // Lines, commas, semicolons or bullets all separate queries, so a pasted list is used in full.
  const seen = new Set<string>();
  return text.split(/\r?\n|[,;،]|\s+[•·|]\s+/).map((l) => l.replace(/^\s*(?:[-*•]|\d+[.)])\s*/, '').trim()).filter((l) => l.length > 0 && !seen.has(l.toLowerCase()) && !!seen.add(l.toLowerCase()));
}

export function clampCap(cap: number): number {
  return Math.max(1, Math.min(FIND_BEST_MAX_CAP, Math.floor(Number.isFinite(cap) ? cap : FIND_BEST_DEFAULT_CAP)));
}

export function clampTopN(topN: number, cap: number): number {
  return Math.max(1, Math.min(Math.max(1, cap), Math.floor(Number.isFinite(topN) ? topN : FIND_BEST_DEFAULT_TOP_N)));
}

export function queryPhotoCounts(queries: string[], defaultCount: number, overrides: Record<string, number> = {}): Record<string, number> {
  return Object.fromEntries(queries.map((query) => [query, clampCap(overrides[query] ?? defaultCount)]));
}

/** Round-robin across query buckets, up to `limit` items. */
export function roundRobin<T>(buckets: T[][], limit: number): T[] {
  const out: T[] = [];
  for (let i = 0; out.length < limit; i++) {
    let any = false;
    for (const b of buckets) {
      if (i < b.length) { any = true; out.push(b[i]); if (out.length >= limit) break; }
    }
    if (!any) break;
  }
  return out;
}

export async function findBest<M>(queries: string[], opts: { cap?: number; topN?: number; photosPerQuery?: Record<string, number>; aiMode?: 'top' | 'all' }, deps: FindBestDeps<M>): Promise<FindBestResult<M>> {
  // Every query on the list gets at least one measured photo (within the hard maximum).
  const limits = opts.photosPerQuery ? queryPhotoCounts(queries, FIND_BEST_DEFAULT_CAP, opts.photosPerQuery) : undefined;
  const cap = limits ? Object.values(limits).reduce((sum, count) => sum + count, 0) : clampCap(Math.max(opts.cap ?? FIND_BEST_DEFAULT_CAP, queries.length));
  const topN = opts.aiMode === 'all' ? cap : clampTopN(opts.topN ?? FIND_BEST_DEFAULT_TOP_N, cap);
  const progress: FindBestProgress = { phase: 'search', activeQueries: [], photos: [], log: [], selected: 0, searchesDone: 0, searchesTotal: queries.length, candidates: 0, analysed: 0, cap, aiChecks: 0, topN };
  const emit = () => deps.onProgress?.({ ...progress, log: [...progress.log], activeQueries: [...progress.activeQueries], photos: progress.photos.map((p) => ({ ...p })) });
  const say = (m: string) => { progress.log.push(m); if (progress.log.length > 60) progress.log.shift(); };
  const lead = () => { let b: FindBestProgress['photos'][number] | undefined; for (const p of progress.photos) if (p.score != null && (!b || p.score > (b.score ?? -1))) b = p; progress.leaderId = b?.image.id; };
  let stopped: FindBestStop | undefined;
  const cancelled = () => !!stopped || !!deps.shouldCancel?.();

  // 1. Search: one call per query; stop once the fair shares can fill the cap.
  const seen = new Set<string>();
  const buckets: Array<{ query: string; items: SearchResultImage[] }> = [];
  emit();
  for (let offset = 0; offset < queries.length;) {
    if (cancelled()) break; // always search the whole list
    const batchSize = Math.min(Math.max(1, Math.min(4, deps.searchConcurrency ?? 1)), queries.length - offset);
    const batch = queries.slice(offset, offset + batchSize);
    offset += batchSize;
    progress.activeQueries = batch;
    say(`Searching: ${batch.map((b) => `“${b}”`).join(', ')}`);
    emit();
    const responses = await Promise.all(batch.map(async (query) => {
      try { return { query, resp: await deps.search(query) }; }
      catch { return { query, resp: { images: [] } as unknown as SearchResponse }; }
    }));
    for (const { query, resp } of responses) {
    progress.searchesDone++;
    const serp = resp.status?.attempts?.find((a) => a.provider === 'serpapi' && a.reason === 'quota');
    if (serp) {
      stopped = { provider: 'SerpAPI', reason: serp.message || 'the SerpAPI key is rejected or out of quota' };
      emit();
      break;
    }
    // 2. Dedupe by URL or id across the whole run.
    const items: SearchResultImage[] = [];
    for (const img of resp.images) {
      // Dedupe by URL only: provider ids (e.g. serp-1-0) repeat across different queries.
      if (!img.url || seen.has(img.url)) continue;
      seen.add(img.url);
      const id = seen.has(`id:${img.id}`) ? `${img.id}-q${buckets.length}` : img.id;
      seen.add(`id:${id}`);
      items.push(id === img.id ? img : { ...img, id });
    }
    // 3. Portrait-first, no AI cost.
    buckets.push({ query, items: portraitBias(items) });
    progress.candidates += items.length;
    say(`Found ${items.length} new photos for “${query}”`);
    emit();
    }
  }
  progress.activeQueries = [];
  progress.searchesTotal = progress.searchesDone;

  // Round-robin pick, hard-capped.
  const tagged = buckets.map((b) => (limits ? b.items.slice(0, limits[b.query]) : b.items).map((image) => ({ image, query: b.query })));
  const picked = roundRobin(tagged, cap).slice(0, cap);
  progress.selected = picked.length;
  progress.photos = picked.map((p) => ({ ...p, status: 'queued' }));
  progress.phase = 'measure';
  say(`Picked ${picked.length} photos to measure`);
  emit();

  // 4. Stage 1: measurement only, never more than `cap` analyses.
  const measured: FindBestEntry<M>[] = [];
  let started = 0;
  if (!stopped) {
    await analyzeInParallel({
      items: picked,
      concurrency: deps.concurrency,
      shouldStop: () => cancelled() || started >= cap,
      analyze: async (c) => {
        if (started >= cap) throw new Error('cap reached');
        started++;
        // A photo that fails to measure gets one more try before it is skipped.
        let m;
        try { m = await deps.measure(c.image); }
        catch { if (cancelled()) throw new Error('stopped'); m = await deps.measure(c.image); }
        return { image: c.image, query: c.query, measured: m.measured, scores: m.scores, aiChecked: !!m.scores.aiLook } as FindBestEntry<M>;
      },
      onUpdate: (i, status, r, error) => {
        progress.photos[i].status = status === 'analyzing' ? 'measuring' : status === 'complete' ? 'measured' : status === 'cancelled' ? 'cancelled' : 'failed';
        progress.photos[i].detail = error;
        if (status === 'complete' || status === 'failed') { progress.analysed++; emit(); }
        if (r) { measured.push(r); progress.photos[i].score = Math.round(r.scores.overall); say(`Measured #${i + 1}: ${progress.photos[i].score}/100`); lead(); }
        else if (error) say(`Photo #${i + 1} skipped: ${error}`);
        emit();
      },
    });
  }

  // 5. Stage 2: AI look check on the top N by the existing overall score.
  measured.sort((a, b) => b.scores.overall - a.scores.overall);
  // Keep going down the ranking until `topN` photos have a successful AI check
  // (a failed check is replaced by the next photo), unless the run is stopped.
  const top: FindBestEntry<M>[] = [];
  progress.topN = Math.min(topN, measured.length);
  progress.phase = 'ai';
  say(measured.length ? `Sending the top ${progress.topN} to the AI look check` : 'No photo could be measured');
  emit();
  let next = 0;
  while (!cancelled() && next < measured.length) {
    const okCount = top.filter((e) => e.aiChecked).length;
    const need = topN - okCount;
    if (need <= 0) break;
    const round = measured.slice(next, next + need);
    next += round.length;
    top.push(...round);
    await analyzeInParallel({
      items: round,
      concurrency: deps.aiConcurrency ?? deps.concurrency,
      shouldStop: cancelled,
      analyze: async (e) => {
        if (e.aiChecked) return;
        // Busy / rate-limited: wait and retry the same photo instead of ending the run.
        let s = await deps.aiCheck(e.image, e.scores);
        for (let retry = 0; !s.aiLook && AI_TEMPORARY.test(s.aiLookError ?? '') && retry < AI_RETRY_WAITS.length && !cancelled(); retry++) {
          say(`AI busy — retrying in ${Math.round(AI_RETRY_WAITS[retry] / 1000)}s`); emit();
          await (deps.sleep ?? defaultSleep)(AI_RETRY_WAITS[retry]);
          if (cancelled()) break;
          s = await deps.aiCheck(e.image, e.scores);
        }
        // Any other failure (not a refusal / quota end): one more try on the same photo.
        if (!s.aiLook && !cancelled() && !AI_TEMPORARY.test(s.aiLookError ?? '') && !AI_EXHAUSTED.test(s.aiLookError ?? '') && !/declined|credits|locked|tried twice/i.test(s.aiLookError ?? '')) {
          say('AI check failed — trying a second time'); emit();
          s = await deps.aiCheck(e.image, e.scores);
        }
        if (s.aiLook) { e.scores = s; e.aiChecked = true; e.aiError = undefined; } else {
          e.aiError = s.aiLookError ?? 'The AI look check failed.';
          // A busy fallback may still work on the next photo even when Gemini keys
          // reported quota errors. Only confirmed exhaustion ends the whole run.
          if (AI_EXHAUSTED.test(e.aiError) && !AI_TEMPORARY.test(e.aiError) && !stopped) stopped = { provider: 'Groq', reason: e.aiError };
        }
        return e;
      },
      onUpdate: (i, status, _result, error) => {
        if (error) round[i].aiError = error;
        const photo = progress.photos.find((p) => p.image.id === round[i].image.id);
        if (photo && status !== 'cancelled') photo.status = status === 'analyzing' ? 'checking' : round[i].aiChecked ? 'complete' : 'failed';
        if (photo) photo.detail = round[i].aiError;
        if (photo && status === 'complete' && round[i].aiChecked) { photo.score = Math.round(round[i].scores.overall); photo.aiScore = round[i].scores.aiLook?.attractiveness; say(`AI checked: now ${photo.score}/100`); lead(); }
        if (status === 'complete' && round[i].aiChecked) progress.aiChecks++;
        emit();
      },
    });
  }
  const okTotal = top.filter((e) => e.aiChecked).length;
  if (okTotal < Math.min(topN, measured.length)) say(`Only ${okTotal} of ${Math.min(topN, measured.length)} AI checks succeeded${stopped ? ` — ${stopped.reason}` : ''}`);

  // 6. Re-rank: checked top N first by blended overall, then the measurement-only rest.
  const ranked = [...measured].sort((a, b) => {
    const at = a.aiChecked ? 1 : 0, bt = b.aiChecked ? 1 : 0;
    return bt - at || b.scores.overall - a.scores.overall;
  });
  progress.phase = 'complete';
  progress.leaderId = ranked[0]?.image.id;
  say(ranked[0] ? `Winner: ${Math.round(ranked[0].scores.overall)}/100` : 'No winner');
  emit();
  return { best: ranked[0], ranked, stopped, progress: { ...progress } };
}
