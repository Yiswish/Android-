import { useSyncExternalStore } from 'react';
import type { ErrorUnit } from './rawError';

export type RatioSort = 'default' | 'worst' | 'best';
export type RatioFilter = 'all' | 'off-ideal';

export interface DisplaySettings {
  /** Show the raw measurement error beside every score. */
  showRawError: boolean;
  /** Proportion errors as % of ideal, or as absolute difference. */
  errorUnit: ErrorUnit;
  ratioSort: RatioSort;
  /** 'off-ideal' hides proportions that are within 1σ (z < 1). */
  ratioFilter: RatioFilter;
  showFormulas: boolean;
  showMeshPlot: boolean;
  compactMetrics: boolean;
}

export const DEFAULT_SETTINGS: DisplaySettings = {
  // Raw errors and formulas default OFF: the results page stays lean (owner's rule).
  showRawError: false,
  errorUnit: 'ideal',
  ratioSort: 'default',
  ratioFilter: 'all',
  showFormulas: false,
  showMeshPlot: true,
  compactMetrics: false,
};

const KEY = 'aesthetics.displaySettings.v1';
let state: DisplaySettings = load();
const listeners = new Set<() => void>();

function load(): DisplaySettings {
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(KEY) : null;
    if (raw) return { ...DEFAULT_SETTINGS, ...(JSON.parse(raw) as Partial<DisplaySettings>) };
  } catch { /* storage unavailable or corrupt: fall back to defaults */ }
  return { ...DEFAULT_SETTINGS };
}

function persist() {
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* ignore */ }
}

export function getSettings(): DisplaySettings { return state; }

export function updateSettings(patch: Partial<DisplaySettings>) {
  state = { ...state, ...patch };
  persist();
  listeners.forEach((l) => l());
}

export function resetSettings() {
  state = { ...DEFAULT_SETTINGS };
  persist();
  listeners.forEach((l) => l());
}

function subscribe(cb: () => void) {
  listeners.add(cb);
  return () => { listeners.delete(cb); };
}

export function useDisplaySettings(): [DisplaySettings, typeof updateSettings, typeof resetSettings] {
  const s = useSyncExternalStore(subscribe, getSettings, () => DEFAULT_SETTINGS);
  return [s, updateSettings, resetSettings];
}
