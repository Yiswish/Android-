import { useEffect, useRef } from 'react';

interface SwipeConfig {
  onSwipeLeft?: () => void;
  onSwipeRight?: () => void;
  threshold?: number;
  /** When false, swipes are ignored (e.g. while a full-screen overlay handles its own swipes). */
  enabled?: boolean;
  /** Element that follows the finger while dragging. */
  dragSelector?: string;
}

/** Interactive drag between screens: the page follows the finger, then snaps or switches. */
export function useSwipe({ onSwipeLeft, onSwipeRight, threshold = 70, enabled = true, dragSelector = 'main.view-slide' }: SwipeConfig) {
  const cb = useRef({ onSwipeLeft, onSwipeRight });
  cb.current = { onSwipeLeft, onSwipeRight };

  useEffect(() => {
    if (!enabled) return;
    let sx = 0, sy = 0, dx = 0, mode: 'none' | 'h' | 'v' = 'none', el: HTMLElement | null = null;
    const skip = (t: EventTarget | null) => t instanceof Element && !!t.closest('input,textarea,select,[data-no-swipe],.overflow-x-auto');

    const start = (e: TouchEvent) => {
      if (e.touches.length !== 1 || skip(e.target)) { mode = 'v'; return; }
      sx = e.touches[0].clientX; sy = e.touches[0].clientY; dx = 0; mode = 'none';
      el = document.querySelector<HTMLElement>(dragSelector);
    };
    const move = (e: TouchEvent) => {
      if (mode === 'v' || !el) return;
      if (document.body.dataset.photoDrag) { mode = 'v'; el.style.transform = ''; el.style.opacity = ''; return; }
      dx = e.touches[0].clientX - sx;
      const dy = e.touches[0].clientY - sy;
      if (mode === 'none') {
        if (Math.abs(dx) < 10 && Math.abs(dy) < 10) return;
        mode = Math.abs(dx) > Math.abs(dy) * 1.2 ? 'h' : 'v';
        if (mode !== 'h') return;
        el.style.animation = 'none';
        el.style.transition = 'none';
      }
      const r = dx * 0.6; // rubber-band resistance
      el.style.transform = `translateX(${r}px) rotate(${r / 120}deg)`;
      el.style.opacity = String(1 - Math.min(0.4, Math.abs(r) / 600));
    };
    const end = () => {
      if (mode !== 'h' || !el) { mode = 'none'; return; }
      const target = el;
      const go = dx < -threshold ? cb.current.onSwipeLeft : dx > threshold ? cb.current.onSwipeRight : undefined;
      target.style.transition = 'transform .3s cubic-bezier(.22,1,.36,1), opacity .3s';
      target.style.transform = '';
      target.style.opacity = '';
      if (go) navigator.vibrate?.(8);
      go?.();
      mode = 'none';
    };

    window.addEventListener('touchstart', start, { passive: true });
    window.addEventListener('touchmove', move, { passive: true });
    window.addEventListener('touchend', end, { passive: true });
    window.addEventListener('touchcancel', end, { passive: true });
    return () => {
      window.removeEventListener('touchstart', start);
      window.removeEventListener('touchmove', move);
      window.removeEventListener('touchend', end);
      window.removeEventListener('touchcancel', end);
    };
  }, [threshold, enabled, dragSelector]);

  return { isSwiping: false };
}
