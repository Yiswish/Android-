// Plain-words description of the owner's preferred face type (no real names). Shared by the AI look check.
export const FACE_TYPE_DESCRIPTION =
  'a soft heart-to-oval face, big open almond eyes, high wide cheekbones, a small refined nose with fuller lips, a defined jaw and chin, and smooth youthful skin.';
