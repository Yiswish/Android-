// Keeps the last Search and last "Find the best" run in IndexedDB so results survive tab
// switches and reloads, and are only replaced when a new search is started.
const DB = 'aesthetics-last-run';
const STORE = 'kv';

function open(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function saveLastRun(key: 'search' | 'best', value: unknown): Promise<void> {
  try {
    const db = await open();
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put(JSON.parse(JSON.stringify(value)), key);
    await new Promise<void>((res, rej) => { tx.oncomplete = () => res(); tx.onerror = () => rej(tx.error); });
    db.close();
  } catch (e) { console.warn('Could not keep last results:', e); }
}

export async function loadLastRun<T>(key: 'search' | 'best'): Promise<T | null> {
  try {
    const db = await open();
    const req = db.transaction(STORE, 'readonly').objectStore(STORE).get(key);
    const v = await new Promise<T | undefined>((res, rej) => { req.onsuccess = () => res(req.result as T); req.onerror = () => rej(req.error); });
    db.close();
    return v ?? null;
  } catch { return null; }
}
