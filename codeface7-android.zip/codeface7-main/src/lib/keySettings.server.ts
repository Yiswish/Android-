import { createClient } from '@supabase/supabase-js';
import { allowPersonalKeys, type KeyProvider } from './personalKeys';

/** Public lock read only. Personal keys are allowed unless the owner has explicitly locked them (no lock row = unlocked). */
export async function personalKeysAllowed(provider: KeyProvider): Promise<boolean> {
  const url = process.env['SUPABASE_URL'];
  const key = process.env['SUPABASE_PUBLISHABLE_KEY'];
  if (!url || !key) return true;
  const client = createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { fetch: (input, init) => {
      const headers = new Headers(init?.headers);
      headers.delete('Authorization');
      headers.set('apikey', key);
      return fetch(input, { ...init, headers, signal: AbortSignal.timeout(5000) });
    } },
  });
  try {
    const { data, error } = await client.from('api_key_locks').select('locked').eq('provider', provider).maybeSingle();
    if (error) return true;
    return allowPersonalKeys(data?.locked === true);
  } catch { return true; }
}