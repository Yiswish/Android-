const DB_NAME = 'aesthetics-offline';
const DB_VERSION = 1;
const STORE_NAME = 'history';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('timestamp', 'timestamp', { unique: false });
        store.createIndex('overallScore', 'overallScore', { unique: false });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function cacheHistoryEntry(entry: {
  id: string;
  thumbnailUrl: string;
  timestamp: number;
  overallScore: number;
  topArchetype: string;
  source: string;
}): Promise<void> {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).put(entry);
    await new Promise<void>((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch {
    // IndexedDB may be unavailable in some contexts
  }
}

export async function loadCachedHistory(): Promise<Array<{
  id: string;
  thumbnailUrl: string;
  timestamp: number;
  overallScore: number;
  topArchetype: string;
  source: string;
}>> {
  try {
    const db = await openDB();
    type cached = Array<{
      id: string;
      thumbnailUrl: string;
      timestamp: number;
      overallScore: number;
      topArchetype: string;
      source: string;
    }>;
    const tx = db.transaction(STORE_NAME, 'readonly');
    const req = tx.objectStore(STORE_NAME).getAll();
    const result = await new Promise<cached>((resolve, reject) => {
      req.onsuccess = () => resolve(req.result as cached);
      req.onerror = () => reject(req.error);
    });
    db.close();
    return result.sort((a, b) => b.timestamp - a.timestamp);
  } catch {
    return [];
  }
}

export async function clearCachedHistory(): Promise<void> {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).clear();
    await new Promise<void>((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch {
    // ignore
  }
}

export async function removeCachedEntries(ids: string[]): Promise<void> {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const s = tx.objectStore(STORE_NAME);
    ids.forEach((id) => s.delete(id));
    await new Promise<void>((resolve, reject) => { tx.oncomplete = () => resolve(); tx.onerror = () => reject(tx.error); });
    db.close();
  } catch {
    // ignore
  }
}
