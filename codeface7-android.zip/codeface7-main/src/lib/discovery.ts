import type { AnalysisResult, StarRating, FaceCategory, SearchResponse, SearchResultImage } from './types';
import { ratingToScore } from './faceTeaching';
import { computeTasteMatch, tasteExtrasOf, type TasteModel } from './preferenceEngine';
import { analyzeInParallel } from './batchAnalysis';

export const DISCOVERY_MIN_RATINGS = 3;
// GUESSED matching vocabulary and weights, not calibrated predictions or semantic embeddings.
const TRAITS: Record<string, RegExp> = {
  'soft jaw': /soft (?:jaw|chin|facial|features)|delicate (?:jaw|chin|features)/i,
  'defined jaw': /strong jaw|defined jaw|angular (?:jaw|features)|sculpted/i,
  'almond eyes': /almond/i,
  'large eyes': /large eyes|big eyes|wide eyes|open eyes/i,
  'full lips': /full lips|fuller lips|plump lips/i,
  'high cheekbones': /high cheekbones|prominent cheekbones/i,
  'warm expression': /warm|gentle|welcoming/i,
  'delicate features': /delicate|soft features|feminine/i,
};
const CATEGORIES: FaceCategory[] = ['Attractive', 'Cute', 'Beautiful'];
const noteText = (r: AnalysisResult) => [r.scores.aiLook?.description, ...(r.scores.aiLook?.reasons ?? [])].join('. ');
export function discoveryTraits(r: AnalysisResult): string[] {
  // Ignore explicitly negative observations rather than treating 'not a soft jaw' as a match.
  const sentences = noteText(r).split(/[.!?;]/).filter((s) => !/\b(?:not|lacks?|without|no)\b/i.test(s));
  return Object.entries(TRAITS).filter(([, pattern]) => sentences.some((s) => pattern.test(s))).map(([trait]) => trait);
}
const categoriesOf = (r: AnalysisResult) => r.scores.userFaceCategories ?? r.scores.aiLook?.categories ?? [];
export interface DiscoveryReference { result: AnalysisResult; rating: number; traits: string[]; categories: FaceCategory[] }
export interface DiscoveryProfile { references: DiscoveryReference[]; top: DiscoveryReference[]; traits: string[]; categories: FaceCategory[]; queries: string[]; ready: boolean }
export function buildDiscoveryProfile(results: AnalysisResult[], ratings: StarRating[]): DiscoveryProfile {
  const latest = new Map<string, StarRating>();
  for (const r of ratings) if (r.timestamp >= (latest.get(r.imageId)?.timestamp ?? -1)) latest.set(r.imageId, r);
  const seen = new Set<string>();
  const references: DiscoveryReference[] = [];
  for (const result of [...results].sort((a, b) => b.timestamp - a.timestamp)) {
    const rating = latest.get(result.imageId);
    if (!rating || !result.scores.aiLook || !noteText(result).trim() || seen.has(result.imageId)) continue;
    seen.add(result.imageId);
    references.push({ result, rating: ratingToScore(rating.rating), traits: discoveryTraits(result), categories: categoriesOf(result) });
  }
  references.sort((a, b) => b.rating - a.rating);
  const top = references.filter((r) => r.rating >= 80).slice(0, 12);
  const mass = (value: string, key: 'traits' | 'categories') => top.reduce((s, r) => s + (r[key].some((v) => v === value) ? r.rating : 0), 0);
  const traits = [...new Set(top.flatMap((r) => r.traits))].sort((a, b) => mass(b, 'traits') - mass(a, 'traits')).slice(0, 4);
  const categories = CATEGORIES.filter((c) => top.some((r) => r.categories.includes(c))).sort((a, b) => mass(b, 'categories') - mass(a, 'categories'));
  const queries = [...new Set([
    ...traits.slice(0, 3).map((t) => `adult face portrait ${t} ${categories[0]?.toLowerCase() ?? ''}`.trim()),
    ...categories.slice(0, 2).map((c) => `adult ${c.toLowerCase()} face portrait ${traits[0] ?? ''}`.trim()),
    'adult close up face portrait natural expression',
  ])].slice(0, 4);
  return { references, top, traits, categories, queries, ready: references.length >= DISCOVERY_MIN_RATINGS && top.length > 0 };
}
export interface DiscoveryPrediction { score: number; confidence: 'Early estimate' | 'Tentative match'; explanation: string; sharedTraits: string[]; geometryWeight: number }
export function predictDiscovery(result: AnalysisResult, profile: DiscoveryProfile, tasteModel?: TasteModel): DiscoveryPrediction | undefined {
  const ai = result.scores.aiLook;
  if (!ai || !Number.isFinite(ai.attractiveness) || !profile.ready) return undefined;
  const traits = discoveryTraits(result);
  const categories = categoriesOf(result);
  let mass = 0, weightedRating = 0;
  for (const reference of profile.references) {
    const traitUnion = new Set([...traits, ...reference.traits]).size;
    const overlap = traitUnion ? traits.filter((t) => reference.traits.includes(t)).length / traitUnion : 0;
    const categoryMatch = reference.categories.length ? categories.filter((c) => reference.categories.includes(c)).length / reference.categories.length : 0;
    const scoreMatch = Math.exp(-((((ai.rawAttractiveness ?? ai.attractiveness) - (reference.result.scores.aiLook?.rawAttractiveness ?? reference.result.scores.aiLook?.attractiveness ?? 50)) / 25) ** 2));
    const weight = Math.exp(4 * (0.65 * overlap + 0.25 * categoryMatch + 0.10 * scoreMatch));
    weightedRating += reference.rating * weight; mass += weight;
  }
  const personal = mass ? weightedRating / mass : 50;
  const support = profile.references.length / (profile.references.length + 5);
  const mean = profile.references.reduce((s, r) => s + r.rating, 0) / profile.references.length;
  const aiFirst = 0.75 * (mean + support * (personal - mean)) + 0.25 * ai.attractiveness;
  const reliable = result.faceDetection.detected && result.faceDetection.pose === 'frontal' && result.faceDetection.poseConfidence >= 0.8;
  const taste = reliable && tasteModel ? computeTasteMatch(result.scores.metrics, tasteModel, result.imageId, result.scores.overall, tasteExtrasOf(result)) : undefined;
  const geometryWeight = taste ? 0.05 * taste.confidence : 0;
  const sharedTraits = traits.filter((t) => profile.traits.includes(t));
  const matchingCategories = categories.filter((c) => profile.categories.includes(c));
  const explanation = sharedTraits.length
    ? `AI notes mention ${sharedTraits.slice(0, 2).join(' and ')}, also present in your 80+ references — a likely taste match.`
    : matchingCategories.length ? `The AI's ${matchingCategories.join(' / ').toLowerCase()} labels overlap with your top-rated photos; the match is tentative.`
    : 'AI appeal and your rating history support this estimate, but the notes show little specific overlap.';
  return { score: Math.round(aiFirst * (1 - geometryWeight) + (taste?.score ?? 50) * geometryWeight), confidence: profile.references.length < 10 ? 'Early estimate' : 'Tentative match', explanation, sharedTraits, geometryWeight };
}

/** AI checks every selected candidate; measurements never select or gate the pool. */
export async function discoverPortraits(profile: DiscoveryProfile, excluded: { ids: Set<string>; urls: Set<string> }, deps: {
  search: (query: string, page: number) => Promise<SearchResponse>;
  analyze: (image: SearchResultImage) => Promise<AnalysisResult>;
  shouldStop: () => boolean;
  onResult: (result: AnalysisResult) => void;
  onProgress: (message: string) => void;
}, limit = 12): Promise<{ results: AnalysisResult[]; errors: string[] }> {
  if (!profile.ready) return { results: [], errors: ['Rate at least three AI-checked photos, including one at 80 or above, first.'] };
  const urls = new Set(excluded.urls);
  const buckets: SearchResultImage[][] = [];
  const errors: string[] = [];
  for (const query of profile.queries) {
    if (deps.shouldStop()) break;
    const bucket: SearchResultImage[] = [];
    for (let page = 1; page <= 2 && bucket.length < limit; page++) {
      if (deps.shouldStop()) break;
      deps.onProgress(`Finding portraits · ${buckets.length + 1}/${profile.queries.length}`);
      try {
        const response = await deps.search(query, page);
        if (response.status?.provider === 'curated') { errors.push('Live portrait search is unavailable; built-in photos were not used as discoveries.'); break; }
        for (const image of response.images) {
          if (!image.url || urls.has(image.url) || excluded.ids.has(image.id)) continue;
          urls.add(image.url);
          bucket.push({ ...image, id: `discover-${buckets.length}-${page}-${bucket.length}-${image.id}` });
        }
        if (!response.hasMore) break;
      } catch { errors.push('A portrait search failed.'); break; }
    }
    buckets.push(bucket);
  }
  const candidates: SearchResultImage[] = [];
  for (let i = 0; candidates.length < limit && buckets.some((b) => i < b.length); i++) {
    for (const bucket of buckets) { if (bucket[i]) candidates.push(bucket[i]); if (candidates.length === limit) break; }
  }
  let blocked = false, done = 0;
  const results: AnalysisResult[] = [];
  await analyzeInParallel({ items: candidates, concurrency: 2, shouldStop: () => blocked || deps.shouldStop(),
    analyze: deps.analyze,
    onUpdate: (_i, status, result, error) => {
      if (status !== 'complete' && status !== 'failed') return;
      done++; deps.onProgress(`AI checked ${done}/${candidates.length} portraits`);
      if (result?.scores.aiLook) { results.push(result); deps.onResult(result); }
      else {
        const message = result?.scores.aiLookError ?? error ?? 'An AI check failed.';
        errors.push(message);
        if (/credits|quota|rate limit|429|denied|disabled|key rejected|not set up/i.test(message)) blocked = true;
      }
    },
  });
  return { results, errors: [...new Set(errors)] };
}