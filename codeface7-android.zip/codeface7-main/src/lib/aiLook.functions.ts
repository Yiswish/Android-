import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { judgeLook, judgeLookBatch, judgeFinal, judgeBody, LOOK_BATCH_MAX } from './aiLook.server';
import { personalKeysAllowed } from './keySettings.server';

// Public (no sign-in, like the rest of the app). Input is a small JPEG data URL made in the browser.
const image = z.string().startsWith('data:image/').max(1_500_000);
const start = z.number().int().min(0).max(1e9).default(0);
const score = z.number().min(0).max(100);
const personalKeys = z.array(z.string().trim().min(1).max(512)).min(1).max(5).optional();

const cat = z.enum(['Attractive', 'Cute', 'Beautiful']);
const FaceExamples = z.array(z.object({ ai: score, user: score.optional(), typeMatch: score, imageId: z.string().max(200).optional(), categories: z.array(cat).max(3), partly: z.array(cat).max(3).optional(), features: z.array(z.string().max(300)).max(4) })).max(25).default([]);

export const judgeLookServer = createServerFn({ method: 'POST' })
  .inputValidator((d: unknown) => z.object({ image, start, personalKeys, examples: FaceExamples }).parse(d))
  .handler(async ({ data }) => {
    if (data.personalKeys && !await personalKeysAllowed('gemini')) return { ok: false as const, error: 'Personal AI keys are locked by the owner.' };
    return judgeLook(data.image, '', data.start, data.personalKeys, data.examples);
  });

/** Several photos in one request (Best section batching). */
export const judgeLookBatchServer = createServerFn({ method: 'POST' })
  .inputValidator((d: unknown) => z.object({ images: z.array(image).min(1).max(LOOK_BATCH_MAX), start, personalKeys, examples: FaceExamples }).parse(d))
  .handler(async ({ data }) => {
    if (data.personalKeys && !await personalKeysAllowed('gemini')) return { ok: false as const, error: 'Personal AI keys are locked by the owner.' };
    return { ok: true as const, results: await judgeLookBatch(data.images, data.start, data.personalKeys, data.examples) };
  });

const FinalInput = z.object({
  image, start, personalKeys,
  aiScore: score,
  aiReasons: z.array(z.string().max(300)).max(6),
  measurementOverall: score,
  faceScore: score.optional(),
  photoScore: score.optional(),
  metrics: z.record(z.string().max(40), score),
});

/** "Way off" button: the final analyst weighs AI + measurements and sets only the overall. */
export const judgeFinalServer = createServerFn({ method: 'POST' })
  .inputValidator((d: unknown) => FinalInput.parse(d))
  .handler(async ({ data }) => {
    const { image: img, start: s, personalKeys: keys, ...input } = data;
    if (keys && !await personalKeysAllowed('gemini')) return { ok: false as const, error: 'Personal AI keys are locked by the owner.' };
    return judgeFinal(img, input, s, keys);
  });

const bodyScores = z.object({ overall: score, proportions: score, physique: score, posture: score, presentation: score });
const BodyExamples = z.array(z.object({ bodyType: z.string().max(40), ai: bodyScores, user: bodyScores })).max(25).default([]);

/** Whole-body rating: separate from the face score, never blended into it. */
export const judgeBodyServer = createServerFn({ method: 'POST' })
  .inputValidator((d: unknown) => z.object({ image, start, personalKeys, examples: BodyExamples }).parse(d))
  .handler(async ({ data }) => {
    if (data.personalKeys && !await personalKeysAllowed('gemini')) return { ok: false as const, error: 'Personal AI keys are locked by the owner.' };
    return judgeBody(data.image, data.start, data.personalKeys, data.examples);
  });

/** Key health check: lists models per key (free), returns only statuses. */
export const checkAiKeysServer = createServerFn({ method: 'POST' })
  .inputValidator((d: unknown) => z.object({ personalKeys }).parse(d))
  .handler(async ({ data }) => {
    if (data.personalKeys && !await personalKeysAllowed('gemini')) return { ok: false as const, error: 'Personal AI keys are locked by the owner.' };
    const { checkAiKeyHealth } = await import('./aiLook.server');
    return { ok: true as const, report: await checkAiKeyHealth(data.personalKeys) };
  });
