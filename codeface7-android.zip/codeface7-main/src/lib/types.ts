import type { FaceGeometryReport } from './faceGeometry';
// ============================================================================
// TYPE SYSTEM — Personalized Aesthetics Analyzer
// ============================================================================

// --- Search & Images --------------------------------------------------------

export type ImageSource = 'google' | 'pinterest' | 'upload' | 'curated' | 'openverse' | 'wikimedia' | 'pexels' | 'unsplash' | 'elitebabes';

export type SearchProvider = 'serpapi' | 'serper' | 'pexels' | 'unsplash' | 'openverse' | 'wikimedia' | 'elitebabes' | 'curated';
export type SearchFallbackReason = 'missing key' | 'quota' | 'network' | 'empty';
/** Which provider produced the results, and why it was not the primary one. */
export interface SearchStatus {
  provider: SearchProvider;
  fallbackReason?: SearchFallbackReason;
  attempts?: Array<{ provider: string; reason: SearchFallbackReason; message: string }>;
  faceQuery?: boolean;
  /** Safe-to-show diagnostics. Never contains the API key or any URL carrying it. */
  diagnostics?: SearchDiagnostics;
}
export interface SearchDiagnostics {
  /** Whether SERPAPI_API_KEY was visible to the server function. */
  serpapiKey: 'present' | 'missing';
  /** The exact query text sent to the provider (the user's own query; Pinterest adds site:pinterest.com only). */
  query: string;
  /** Provider that answered. */
  provider: SearchProvider;
  /** HTTP status of the SerpAPI call when one was made. */
  serpapiHttpStatus?: number;
}

export type OrientationFilter = 'all' | 'landscape' | 'portrait' | 'square';
export type StyleCategoryFilter = 'all' | 'minimalist' | 'warm-earth' | 'moody-noir' | 'vibrant-pop' | 'natural-organic' | 'editorial-chic' | 'vintage-film' | 'architectural';

export interface SearchFilters {
  orientation: OrientationFilter;
  category: StyleCategoryFilter;
}

export interface SearchResultImage {
  /** Known search context; never inferred from the face. */
  searchLabel?: string;
  id: string;
  url: string;
  thumbUrl: string;
  width: number;
  height: number;
  alt: string;
  source: ImageSource;
  photographer?: string;
  photographerUrl?: string;
  category?: string;
  orientation?: 'landscape' | 'portrait' | 'square';
}

export interface SearchResponse {
  images: SearchResultImage[];
  totalCount: number;
  hasMore: boolean;
  nextPage?: number;
  source: ImageSource;
  cached?: boolean;
  status?: SearchStatus;
}

// --- Search Cache -----------------------------------------------------------

export interface CacheEntry {
  key: string;
  response: SearchResponse;
  timestamp: number;
  expiresAt: number;
}

// --- Face Detection ---------------------------------------------------------

export type ExpressionLabel =
  | 'neutral'
  | 'happy'
  | 'surprised'
  | 'thoughtful'
  | 'confident'
  | 'serene';

export type PoseLabel =
  | 'frontal'
  | 'slight-left'
  | 'slight-right'
  | 'profile-left'
  | 'profile-right'
  | 'tilted-up'
  | 'tilted-down';

export interface BoundingBox {
  x: number; // 0–1 normalized
  y: number;
  width: number;
  height: number;
}

export interface FacialLandmarks {
  leftEye: { x: number; y: number };
  rightEye: { x: number; y: number };
  noseTip: { x: number; y: number };
  mouthLeft: { x: number; y: number };
  mouthRight: { x: number; y: number };
  chin: { x: number; y: number };
  forehead: { x: number; y: number };
  leftCheek: { x: number; y: number };
  rightCheek: { x: number; y: number };
  leftEar: { x: number; y: number };
  rightEar: { x: number; y: number };
  noseBridge: { x: number; y: number };
  leftBrow: { x: number; y: number };
  rightBrow: { x: number; y: number };
}

export type ClothingStyle =
  | 'casual'
  | 'formal'
  | 'artistic'
  | 'minimalist'
  | 'bohemian'
  | 'streetwear'
  | 'vintage'
  | 'athletic';

export type BackgroundType =
  | 'studio'
  | 'outdoor'
  | 'indoor'
  | 'urban'
  | 'nature'
  | 'abstract'
  | 'minimal';

export interface DetectedFace {
  index: number;
  boundingBox: BoundingBox;
  landmarks: FacialLandmarks;
  /** Complete detected mesh in original normalised photo coordinates; absent in older saved scans. */
  meshLandmarks?: Array<{ x: number; y: number; z: number }>;
  expression: ExpressionLabel;
  expressionConfidence: number;
  pose: PoseLabel;
  poseConfidence: number;
  ageEstimate?: number;
  genderEstimate?: 'masculine' | 'feminine' | 'ambiguous';
  lightingDirection?: 'front' | 'side' | 'back' | 'top' | 'diffuse';
  focusQuality?: number;
  clothingStyle?: ClothingStyle;
  isPrimary: boolean;
  geometry?: FaceGeometryReport;
}

export interface FaceDetectionResult {
  detected: boolean;
  faceCount: number;
  faces: DetectedFace[];
  primaryFaceIndex: number;
  boundingBox?: BoundingBox;
  landmarks?: FacialLandmarks;
  expression: ExpressionLabel;
  expressionConfidence: number;
  pose: PoseLabel;
  poseConfidence: number;
  ageEstimate?: number;
  genderEstimate?: 'masculine' | 'feminine' | 'ambiguous';
  lightingDirection?: 'front' | 'side' | 'back' | 'top' | 'diffuse';
  focusQuality?: number; // 0–1
  clothingStyle?: ClothingStyle;
  backgroundType?: BackgroundType;
  backgroundDescription?: string;
  clothingDescription?: string;
  geometry?: FaceGeometryReport;
  pixelStats?: unknown;
  logs: AnalysisLogEntry[];
}

export interface AnalysisLogEntry {
  step: number;
  label: string;
  detail: string;
  category: 'detection' | 'landmarks' | 'expression' | 'pose' | 'lighting' | 'aesthetic' | 'preference' | 'composition' | 'color' | 'background' | 'clothing';
  value?: string;
  confidence?: number;
}

// --- Metrics & Scores -------------------------------------------------------

export type MetricKey =
  // Facial geometry (80% of the overall score)
  | 'symmetry'
  | 'proportions'
  | 'structure'
  | 'skin'
  // Photography (≤20% of the overall score). Colour-dependent metrics were
  // removed on purpose: monochrome photos, paintings and drawings are never
  // judged on colour.
  | 'composition'
  | 'lighting'
  | 'texture'
  | 'contrast'
  | 'naturalness';

export type MetricScores = Record<MetricKey, number>;

export interface ScoreBreakdown {
  /** Facial-geometry score 0–100 (power mean of symmetry, structure, golden, alignment, mouth/jaw integrity, expression, skin & age) */
  faceScore?: number;
  /** Photography score 0–100 (weighted mean of lighting, composition, image sharpness, contrast, photo processing) */
  photoScore: number;
  faceShare: number;
  photoShare: number;
  confidence: number;
  overall: number;
  formula: string;
}

export interface TasteMatch {
  /** 0–100: how well this image matches what the user rated highly */
  score: number;
  /** 0–1: how much rating data supports the estimate */
  confidence: number;
  ratingsUsed: number;
  predictedStars: number;
  drivers: Array<{ metric: MetricKey; label: string; direction: 'likes-high' | 'likes-low'; agreement: number }>;
  summary: string;
  /** Short human verdict ("Likely your type") */
  verdict?: string;
  /** Predicted stars minus the user's average rating */
  deltaStars?: number;
  meanStars?: number;
  /** Rated images most similar to this one */
  neighbours?: Array<{ imageId: string; imageUrl?: string; stars: number; similarity: number }>;
  /** Leave-one-out mean absolute error of the model, in stars */
  errorStars?: number;
  /** Plain-language reasons: what pushes the prediction up / down */
  pros?: string[];
  cons?: string[];
}

export interface AiLook {
  categories?: FaceCategory[];
  /** Categories the AI says fit only partly. */
  partialCategories?: FaceCategory[];
  rawAttractiveness?: number;
  tasteRatingsUsed?: number;
  /** 0–100 holistic facial appeal judged by a vision model */
  attractiveness: number;
  /** Short AI description of the photo (older saved results may not have one). */
  description?: string;
  /** 0–100 closeness to the owner's preferred face type (AI's view) */
  typeMatch: number;
  reasons: string[];
  /** Overall from geometry + photography alone, before the AI look was blended in */
  geometryOverall: number;
  /** v2: pure geometry face score used in the blend */
  faceScore?: number;
  /** v2: points removed because AI and geometry disagreed by > 25 */
  disagreementPenalty?: number;
  /** 1-based number of the Gemini key that answered, out of keyCount. */
  keyIndex?: number;
  keyCount?: number;
  /** Old saves only: the previous Way off re-check (no longer produced). */
  deep?: { passes: number[]; spread: number; previousOverall: number; at: number };
}

/** "Way off" final analyst: weighs the AI look and the measurements; its verdict is the overall. */
export interface FinalAnalyst {
  overall: number;
  passes: number[];
  spread: number;
  reasons: string[];
  /** Key number used by each pass */
  keys: number[];
  keyCount: number;
  previousOverall: number;
  at: number;
}

/** AI whole-body rating. Shown beside the face score, never blended into `overall`. */
export interface BodyLook {
  visible: boolean;
  overall: number;
  proportions: number;
  physique: number;
  posture: number;
  presentation: number;
  bodyType: string;
  reasons: string[];
  at: number;
}

/** The user's own 1-100 body ratings; used to teach the AI body rater. */
export interface UserBodyRating {
  overall: number;
  proportions: number;
  physique: number;
  posture: number;
  presentation: number;
  at: number;
}

export interface AestheticScores {
  userFaceCategories?: FaceCategory[];
  /** The user's "partly" labels (e.g. a bit cute). Never overlaps userFaceCategories. */
  userFacePartial?: FaceCategory[];
  /** User's own body ratings (sliders). */
  userBody?: UserBodyRating;
  overall: number;
  /** Scoring model version (absent = v1, the pre-overhaul scores kept on old saves). */
  scoringVersion?: number;
  /** Present when the AI look check succeeded; `overall` already includes it. */
  aiLook?: AiLook;
  /** Set when the AI look check was attempted but failed (overall = geometry only). */
  aiLookError?: string;
  /** Present after Way off; `overall` equals its verdict. */
  finalAnalyst?: FinalAnalyst;
  /** Whole-body rating (separate from the face overall). */
  bodyLook?: BodyLook;
  bodyLookError?: string;
  breakdown?: ScoreBreakdown;
  tasteMatch?: TasteMatch;
  metrics: MetricScores;
  archetypeMatch: Record<string, number>;
}

// --- Archetypes -------------------------------------------------------------

export interface Archetype {
  id: string;
  name: string;
  description: string;
  icon: string; // lucide icon name
  color: string;
  gradient: string;
  metricProfile: MetricScores;
  keywords: string[];
  palette: string[];
  sampleQueries: string[];
}

// --- Analysis Results -------------------------------------------------------

export interface AnalysisResult {
  searchLabel?: string;
  id: string;
  imageId: string;
  imageUrl: string;
  source: ImageSource;
  timestamp: number;
  faceDetection: FaceDetectionResult;
  scores: AestheticScores;
  topArchetypes: Array<{ archetype: Archetype; match: number }>;
  warnings: string[];
  duration: number;
  /** Persistent thumbnail (Netlify Blobs) — present on analyses saved after the overhaul. */
  thumbUrl?: string;
  /** Soft-deleted from History; still used by the taste model. */
  deletedAt?: number;
}

// --- Preference Profile -----------------------------------------------------

export interface PreferenceProfile {
  totalImagesAnalyzed: number;
  averageScores: MetricScores;
  topArchetypes: Array<{ archetypeId: string; name: string; avgMatch: number }>;
  preferredMetrics: Array<{ metric: MetricKey; label: string; value: number }>;
  preferredExpressions: Array<{ label: ExpressionLabel; count: number }>;
  preferredPoses: Array<{ label: PoseLabel; count: number }>;
  preferredSources: Array<{ source: ImageSource; count: number }>;
  preferenceStrength: number; // 0–1, how decisive the preferences are
  lastUpdated: number;
}

// --- Comparison -------------------------------------------------------------

export interface ComparisonItem {
  result: AnalysisResult;
  label: string;
}

// --- History ----------------------------------------------------------------

export interface HistoryEntry {
  searchLabel?: string;
  id: string;
  thumbnailUrl: string;
  timestamp: number;
  overallScore: number;
  topArchetype: string;
  source: ImageSource;
}

// --- Export Report ----------------------------------------------------------

export interface ExportReport {
  result: AnalysisResult;
  explanations: string[];
  exportedAt: number;
}

// --- UI State ---------------------------------------------------------------

export type ViewMode = 'search' | 'best' | 'discover' | 'analyzing' | 'results' | 'history' | 'profile' | 'compare';

export type HistorySortMode = 'newest' | 'oldest' | 'highest' | 'lowest';

/** Result of the "What I actually like most" test for one highly rated photo. */
export interface FavouriteRanking {
  imageId: string;
  /** Elo-style strength (1500 = neutral) */
  strength: number;
  comparisons: number;
  wins: number;
}

export interface StarRating {
  imageId: string;
  rating: number; // continuous 1–5 internal scale; slider displays 0–100
  timestamp: number;
}

export type FaceCategory = 'Attractive' | 'Cute' | 'Beautiful';
