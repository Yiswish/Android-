// "Find the body first": a pose detector must see shoulders and hips before the AI body rater runs.
import { withTimeout } from './faceDetection';

const IS_APP = import.meta.env.VITE_MOBILE === '1'; // Android app build: files are bundled in the APK
const WASM_URL = IS_APP ? '/mediapipe/wasm' : 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@1.2.2/wasm';
const MODEL_URL = IS_APP ? '/mediapipe/pose_landmarker_lite.task' : 'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task';

export interface PosePoint { x: number; y: number; visibility?: number }
export type BodyFound = { found: true; people: number } | { found: false; reason: string };

/** Shoulders (11, 12) and hips (23, 24) must all be clearly visible and inside the photo. Pure; tested. */
export function bodyCheck(poses: PosePoint[][], minVis = 0.5): BodyFound {
  if (!poses.length) return { found: false, reason: 'No body was found in this photo.' };
  const ok = poses.filter((p) => [11, 12, 23, 24].every((i) => {
    const q = p[i];
    return q && (q.visibility ?? 1) >= minVis && q.x >= -0.02 && q.x <= 1.02 && q.y >= -0.02 && q.y <= 1.02;
  }));
  if (!ok.length) return { found: false, reason: 'A person was found, but not enough of the body (shoulders down to hips) is visible.' };
  return { found: true, people: ok.length };
}

let poser: Promise<{ detect: (img: HTMLImageElement) => { landmarks: PosePoint[][] } }> | null = null;
function getPoser() {
  if (!poser) {
    poser = withTimeout((async () => {
      const { PoseLandmarker, FilesetResolver } = await import('@mediapipe/tasks-vision');
      const fileset = await FilesetResolver.forVisionTasks(WASM_URL);
      return PoseLandmarker.createFromOptions(fileset, { baseOptions: { modelAssetPath: MODEL_URL, delegate: 'CPU' }, runningMode: 'IMAGE', numPoses: 3 });
    })(), 30000, 'Body detector load').catch((e) => { poser = null; throw e; });
  }
  return poser;
}

function load(src: string): Promise<HTMLImageElement> {
  return new Promise((res, rej) => { const i = new Image(); i.crossOrigin = 'anonymous'; i.onload = () => res(i); i.onerror = () => rej(new Error('image')); i.src = src; });
}

/** Runs the pose detector on a data/blob/same-origin image URL. */
export async function findBody(imageSrc: string): Promise<BodyFound> {
  const [p, img] = await Promise.all([getPoser(), withTimeout(load(imageSrc), 20000, 'Image load')]);
  return bodyCheck(p.detect(img).landmarks);
}
