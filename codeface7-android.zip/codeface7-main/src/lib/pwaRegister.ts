// Registers the minimal install service worker (/sw.js) only in the real
// published app. Never registers in dev, iframes, or Lovable preview hosts —
// a service worker there can keep serving stale pages after code changes.
// In any refused context, stale registrations for /sw.js are removed.

const PREVIEW_LABEL = /^(?:id-preview|preview)(?:-[a-z0-9]+)?--.+$/;

function isRefusedContext(): boolean {
  if (!import.meta.env.PROD) return true;
  if (typeof window === "undefined") return true;
  if (window.self !== window.top) return true;

  const host = window.location.hostname.toLowerCase();
  const previewDomains = [".lovable.app", ".gpt-eng.com", ".gptengineer.run"];
  for (const domain of previewDomains) {
    if (host.endsWith(domain)) {
      const firstLabel = host.slice(0, -domain.length).split(".")[0] ?? "";
      if (PREVIEW_LABEL.test(firstLabel)) return true;
    }
  }
  if (host === "lovableproject.com" || host.endsWith(".lovableproject.com")) return true;
  if (host === "lovableproject-dev.com" || host.endsWith(".lovableproject-dev.com")) return true;
  if (host === "beta.lovable.dev" || host.endsWith(".beta.lovable.dev")) return true;
  if (new URLSearchParams(window.location.search).get("sw") === "off") return true;
  return false;
}

async function unregisterStale(): Promise<void> {
  try {
    const regs = await navigator.serviceWorker.getRegistrations();
    await Promise.all(
      regs
        .filter((r) => r.active?.scriptURL.endsWith("/sw.js") || r.installing?.scriptURL.endsWith("/sw.js") || r.waiting?.scriptURL.endsWith("/sw.js"))
        .map((r) => r.unregister()),
    );
  } catch {
    // ignore
  }
}

export function registerInstallServiceWorker(): void {
  if (!("serviceWorker" in navigator)) return;
  if (isRefusedContext()) {
    void unregisterStale();
    return;
  }
  navigator.serviceWorker.register("/sw.js").catch(() => {});
}
