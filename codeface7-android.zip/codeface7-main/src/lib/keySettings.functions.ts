import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { personalKeysAllowed } from './keySettings.server';
import { KEY_PROVIDERS, type KeyProvider } from './personalKeys';

export const getKeyLocks = createServerFn({ method: 'GET' }).handler(async () => {
  const allowed = await Promise.all(KEY_PROVIDERS.map((p) => personalKeysAllowed(p)));
  return Object.fromEntries(KEY_PROVIDERS.map((p, i) => [p, !allowed[i]])) as Record<KeyProvider, boolean>;
});

export const getKeyOwner = createServerFn({ method: 'POST' })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase.from('user_roles').select('role').eq('user_id', context.userId).eq('role', 'owner').maybeSingle();
    if (error) throw new Error('Could not check owner access.');
    return { owner: !!data };
  });

export const setKeyLock = createServerFn({ method: 'POST' })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ provider: z.enum(['gemini', 'serpapi', 'serper', 'pexels', 'unsplash']), locked: z.boolean() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: role, error: roleError } = await context.supabase.from('user_roles').select('role').eq('user_id', context.userId).eq('role', 'owner').maybeSingle();
    if (roleError || !role) throw new Error('Only the owner can change key locks.');
    const { error } = await context.supabase.from('api_key_locks').upsert(data);
    if (error) throw new Error('Could not update the lock.');
    return { ok: true };
  });