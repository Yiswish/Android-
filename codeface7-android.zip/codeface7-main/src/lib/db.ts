// Browser-side persistence API. Talks to the server functions in store.functions.ts
// (Netlify Database + Netlify Blobs). Every function is fail-soft: a network error
// never breaks the analysis flow, it only logs.
import { normalizeMetrics } from './metricKeys';
import { loadPixelSafeImage } from './faceDetection';
import type { AnalysisResult, FavouriteRanking, StarRating } from './types';
import { localPut, localGet, localAll, localClear } from './localStore';
import {
  storeImageServer, saveAnalysisServer, loadAnalysesServer, softDeleteAnalysesServer, resetEverythingServer,
  saveRatingServer, loadRatingsServer, updateAnalysisServer, loadFavouritesServer, saveFavouritesServer, clearFavouritesServer,
} from './store.functions';

const TOMB_KEY = 'deleted-analysis-ids';
/** Locally remembered deletions: a delete that races an unfinished save must still stick after reload. */
export function deletedIds(): Set<string> {
  try { return new Set(JSON.parse(localStorage.getItem(TOMB_KEY) || '[]') as string[]); } catch { return new Set(); }
}
function rememberDeleted(ids: string[]) {
  try { const s = deletedIds(); ids.forEach((i) => s.add(i)); localStorage.setItem(TOMB_KEY, JSON.stringify([...s].slice(-2000))); } catch { /* ignore */ }
}
function forgetDeleted() { try { localStorage.removeItem(TOMB_KEY); } catch { /* ignore */ } }

const THUMB_SIDE = 480;
const FULL_SIDE = 1280;

async function toJpeg(url: string, maxSide: number, quality: number): Promise<string> {
  const img = await loadPixelSafeImage(url);
  const k = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(img.naturalWidth * k));
  c.height = Math.max(1, Math.round(img.naturalHeight * k));
  c.getContext('2d')!.drawImage(img, 0, 0, c.width, c.height);
  return c.toDataURL('image/jpeg', quality);
}

const safeKey = (id: string, suffix: string) => `${id.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 100)}-${suffix}.jpg`;

/**
 * Keep a thumbnail of every analysed photo (so History is a real gallery even when the
 * original web image disappears) and the full photo for uploads (their blob: URL dies on reload).
 */
async function persistImages(result: AnalysisResult): Promise<{ imageUrl: string; thumbUrl?: string }> {
  let imageUrl = result.imageUrl;
  let thumbUrl: string | undefined;
  let thumbData: string | undefined;
  try {
    thumbData = await toJpeg(result.imageUrl, THUMB_SIDE, 0.82);
    thumbUrl = thumbData;
    thumbUrl = (await storeImageServer({ data: { key: safeKey(result.id, 'thumb'), dataUrl: thumbData } })).url;
  } catch (e) { console.warn('Thumbnail upload failed (kept on device):', e); }
  if (imageUrl.startsWith('blob:') || imageUrl.startsWith('data:')) {
    let fullData: string | undefined;
    try {
      fullData = await toJpeg(result.imageUrl, FULL_SIDE, 0.88);
      imageUrl = fullData; // blob: URLs die on reload; a data URL survives on the device
      imageUrl = (await storeImageServer({ data: { key: safeKey(result.id, 'full'), dataUrl: fullData } })).url;
    } catch (e) { console.warn('Photo upload failed (kept on device):', e); }
  }
  return { imageUrl, thumbUrl };
}

/** Saves the analysis (and its images). Returns the result with persistent image URLs. */
export async function saveAnalysis(result: AnalysisResult): Promise<AnalysisResult> {
  const { imageUrl, thumbUrl } = await persistImages(result);
  const saved: AnalysisResult = { ...result, imageUrl, thumbUrl };
  await localPut('analyses', saved.id, JSON.parse(JSON.stringify(saved)));
  try {
    await saveAnalysisServer({
      data: {
        id: saved.id, imageId: saved.imageId, imageUrl, thumbUrl: thumbUrl ?? null, source: saved.source,
        overallScore: saved.scores.overall, scoringVersion: saved.scores.scoringVersion ?? 1,
        metrics: saved.scores.metrics as unknown as Record<string, number>,
        result: JSON.parse(JSON.stringify(saved)) as Record<string, unknown>,
        timestamp: saved.timestamp,
      },
    });
    if (deletedIds().has(saved.id)) await softDeleteAnalysesServer({ data: { ids: [saved.id] } });
  } catch (e) { console.warn('Failed to save analysis:', e); }
  return saved;
}

/** Saves new scores on an already-saved analysis (fail-soft). */
export async function updateAnalysis(result: AnalysisResult): Promise<void> {
  const prev = await localGet<AnalysisResult>('analyses', result.id);
  await localPut('analyses', result.id, JSON.parse(JSON.stringify({ ...prev, ...result })));
  try {
    await updateAnalysisServer({ data: { id: result.id, overallScore: result.scores.overall, scoringVersion: result.scores.scoringVersion ?? 1, result: JSON.parse(JSON.stringify(result)) as Record<string, unknown> } });
  } catch (e) { console.warn('Failed to update analysis:', e); }
}

/** All analyses, newest first. Soft-deleted ones are included (with `deletedAt`) for the taste model. */
export async function loadAllAnalyses(): Promise<AnalysisResult[]> {
  const tombLocal = deletedIds();
  const local = (await localAll<AnalysisResult>('analyses')).map((r) => ({
    ...r, warnings: r.warnings ?? [], topArchetypes: r.topArchetypes ?? [],
    deletedAt: r.deletedAt ?? (tombLocal.has(r.id) ? Date.now() : undefined),
    scores: { ...r.scores, metrics: normalizeMetrics(r.scores?.metrics ?? {}) },
  }));
  const remote = await loadRemoteAnalyses();
  const byId = new Map<string, AnalysisResult>();
  local.forEach((r) => byId.set(r.id, r));
  remote.forEach((r) => { if (!byId.has(r.id)) { byId.set(r.id, r); localPut('analyses', r.id, JSON.parse(JSON.stringify(r))); } });
  return [...byId.values()].sort((a, b) => b.timestamp - a.timestamp);
}

async function loadRemoteAnalyses(): Promise<AnalysisResult[]> {
  try {
    const rows = await loadAnalysesServer();
    const tomb = deletedIds();
    const stale = rows.filter((r) => !r.deletedAt && tomb.has(r.id)).map((r) => r.id);
    if (stale.length) softDeleteAnalysesServer({ data: { ids: stale } }).catch(() => {});
    return rows.map((row) => ({ ...row, deletedAt: row.deletedAt ?? (tomb.has(row.id) ? Date.now() : null) })).map((row) => {
      const r = JSON.parse(row.result) as AnalysisResult;
      return {
        ...r,
        id: row.id, imageId: row.imageId, imageUrl: row.imageUrl, thumbUrl: row.thumbUrl ?? undefined,
        timestamp: row.timestamp, deletedAt: row.deletedAt ?? undefined,
        warnings: r.warnings ?? [], topArchetypes: r.topArchetypes ?? [],
        // Old rows may lack newer metrics (skin): default them so nothing downstream sees NaN.
        scores: { ...r.scores, overall: row.overallScore, metrics: normalizeMetrics(r.scores?.metrics ?? (row.metrics as Partial<AnalysisResult['scores']['metrics']>)) },
      };
    });
  } catch (e) {
    console.warn('Failed to load analyses:', e);
    return [];
  }
}

export async function saveStarRating(rating: StarRating): Promise<void> {
  await localPut('ratings', rating.imageId, rating);
  try { await saveRatingServer({ data: rating }); } catch (e) { console.warn('Failed to save rating:', e); }
}

export async function loadStarRatings(): Promise<StarRating[]> {
  const local = await localAll<StarRating>('ratings');
  let remote: StarRating[] = [];
  try { remote = await loadRatingsServer(); } catch { /* offline: device copy only */ }
  const m = new Map<string, StarRating>();
  remote.forEach((r) => m.set(r.imageId, r));
  local.forEach((r) => { const o = m.get(r.imageId); if (!o || (r.timestamp ?? 0) >= (o.timestamp ?? 0)) m.set(r.imageId, r); });
  return [...m.values()];
}

/** Soft-delete from History: image + analysis disappear, ratings and score vectors stay for taste learning. */
export async function deleteAnalyses(ids: string[]): Promise<boolean> {
  if (!ids.length) return true;
  rememberDeleted(ids);
  try { await softDeleteAnalysesServer({ data: { ids } }); return true; } catch (e) { console.warn('Delete failed:', e); return false; }
}

/** Soft-delete every analysis from History (taste learning is kept). */
export async function deleteAllAnalyses(ids: string[] = []): Promise<boolean> {
  rememberDeleted(ids);
  try { await softDeleteAnalysesServer({ data: { all: true } }); return true; } catch (e) { console.warn('Delete all failed:', e); return false; }
}

/** Removes everything — analyses, ratings, favourite test — so the taste model starts from zero. */
export async function resetEverything(): Promise<boolean> {
  await Promise.all([localClear('analyses'), localClear('ratings'), localClear('favourites')]);
  try { await resetEverythingServer(); forgetDeleted(); return true; } catch (e) { console.warn('Reset failed:', e); return false; }
}

export async function loadFavourites(): Promise<FavouriteRanking[]> {
  try {
    const remote = (await loadFavouritesServer()).map(({ imageId, strength, comparisons, wins }) => ({ imageId, strength, comparisons, wins }));
    if (remote.length) return remote;
  } catch { /* offline */ }
  return (await localGet<FavouriteRanking[]>('favourites', 'all')) ?? [];
}

export async function saveFavourites(items: FavouriteRanking[]): Promise<void> {
  await localPut('favourites', 'all', items);
  try { await saveFavouritesServer({ data: { items } }); } catch (e) { console.warn('Failed to save favourites:', e); }
}

export async function clearFavourites(): Promise<void> {
  await localClear('favourites');
  try { await clearFavouritesServer(); } catch (e) { console.warn('Failed to clear favourites:', e); }
}
