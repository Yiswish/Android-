import type { ViewMode } from './types';

export function previousView(stack: ViewMode[]): { view: ViewMode; stack: ViewMode[] } {
  const remaining = [...stack];
  let view = remaining.pop();
  while (view === 'analyzing') view = remaining.pop();
  return { view: view ?? 'search', stack: remaining };
}