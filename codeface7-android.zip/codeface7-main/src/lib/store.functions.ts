// Server functions for persistence: Lovable Cloud database (analyses, ratings, favourite test)
// and Cloud storage (photo thumbnails / uploaded originals). Public, no sign-in — the app is a
// single-user tool. Tables are locked to the browser; only these server functions touch them.
import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';

const BUCKET = 'analysis-images';
const imageKey = z.string().regex(/^[a-zA-Z0-9_-]{1,120}\.jpg$/);

const admin = async () => (await import('@/integrations/supabase/client.server')).supabaseAdmin;
const must = <T,>(r: { data: T; error: { message: string } | null }) => {
  if (r.error) throw new Error(r.error.message);
  return r.data;
};

// ---- Images ---------------------------------------------------------------------
export const storeImageServer = createServerFn({ method: 'POST' })
  .inputValidator((d: unknown) => z.object({ key: imageKey, dataUrl: z.string().startsWith('data:image/jpeg;base64,').max(4_000_000) }).parse(d))
  .handler(async ({ data }) => {
    const b64 = data.dataUrl.slice('data:image/jpeg;base64,'.length);
    const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
    const db = await admin();
    const { error } = await db.storage.from(BUCKET).upload(data.key, bytes, { contentType: 'image/jpeg', upsert: true });
    if (error) throw new Error(error.message);
    return { url: `/api/images/${data.key}` };
  });

async function deleteImagesFor(urls: Array<string | null | undefined>) {
  const keys = urls.map((u) => u?.match(/^\/api\/images\/([a-zA-Z0-9_-]+\.jpg)$/)?.[1]).filter((k): k is string => !!k);
  if (keys.length) await (await admin()).storage.from(BUCKET).remove(keys).catch(() => {});
}

// ---- Analyses -------------------------------------------------------------------
const AnalysisInput = z.object({
  id: z.string().min(1).max(200),
  imageId: z.string().min(1).max(2000),
  imageUrl: z.string().min(1).max(4000),
  thumbUrl: z.string().max(4000).nullable(),
  source: z.string().max(40),
  overallScore: z.number(),
  scoringVersion: z.number().int(),
  metrics: z.record(z.string(), z.number()),
  result: z.record(z.string(), z.unknown()),
  timestamp: z.number(),
});

export const saveAnalysisServer = createServerFn({ method: 'POST' })
  .inputValidator((d: unknown) => AnalysisInput.parse(d))
  .handler(async ({ data }) => {
    const db = await admin();
    must(await db.from('analyses').upsert({
      id: data.id, image_id: data.imageId, image_url: data.imageUrl, thumb_url: data.thumbUrl, source: data.source,
      overall_score: data.overallScore, scoring_version: data.scoringVersion, metrics: data.metrics as never,
      result: data.result as never, timestamp: data.timestamp, deleted_at: null,
    }, { onConflict: 'id', ignoreDuplicates: true }));
    return { ok: true };
  });

/** Replace a saved analysis's score + stored result (used by the "Way off" careful re-check). */
export const updateAnalysisServer = createServerFn({ method: 'POST' })
  .inputValidator((d: unknown) => z.object({ id: z.string().min(1).max(200), overallScore: z.number(), scoringVersion: z.number().int(), result: z.record(z.string(), z.unknown()) }).parse(d))
  .handler(async ({ data }) => {
    const db = await admin();
    must(await db.from('analyses').update({ overall_score: data.overallScore, scoring_version: data.scoringVersion, result: data.result as never }).eq('id', data.id));
    return { ok: true };
  });

/** Every analysis, including soft-deleted ones (`deletedAt` set) — the taste model still learns from those. */
export const loadAnalysesServer = createServerFn({ method: 'GET' }).handler(async () => {
  const db = await admin();
  const rows = must(await db.from('analyses').select('*').order('timestamp', { ascending: false }).limit(500)) ?? [];
  return rows.map((r) => ({
    id: r.id, imageId: r.image_id, imageUrl: r.image_url, thumbUrl: r.thumb_url, source: r.source,
    overallScore: r.overall_score, scoringVersion: r.scoring_version, timestamp: r.timestamp, deletedAt: r.deleted_at,
    result: JSON.stringify(r.result), metrics: r.metrics as Record<string, number>,
  }));
});

/** Soft delete: hide from History and drop the images, keep the scores and ratings. */
export const softDeleteAnalysesServer = createServerFn({ method: 'POST' })
  .inputValidator((d: unknown) => z.object({ ids: z.array(z.string().max(200)).max(500).optional(), all: z.boolean().optional() }).parse(d))
  .handler(async ({ data }) => {
    if (!data.all && !data.ids?.length) return { ok: true };
    const db = await admin();
    let sel = db.from('analyses').select('image_url, thumb_url').is('deleted_at', null);
    if (!data.all) sel = sel.in('id', data.ids!);
    const rows = must(await sel) ?? [];
    let upd = db.from('analyses').update({ deleted_at: Date.now() }).is('deleted_at', null);
    if (!data.all) upd = upd.in('id', data.ids!);
    must(await upd);
    await deleteImagesFor(rows.flatMap((r) => [r.image_url, r.thumb_url]));
    return { ok: true };
  });

/** Full reset: analyses, ratings, favourite test and images are all removed. */
export const resetEverythingServer = createServerFn({ method: 'POST' }).handler(async () => {
  const db = await admin();
  const rows = must(await db.from('analyses').select('image_url, thumb_url')) ?? [];
  must(await db.from('analyses').delete().neq('id', ''));
  must(await db.from('star_ratings').delete().gte('id', 0));
  must(await db.from('favourite_rankings').delete().neq('image_id', ''));
  await deleteImagesFor(rows.flatMap((r) => [r.image_url, r.thumb_url]));
  return { ok: true };
});

// ---- Ratings --------------------------------------------------------------------
export const saveRatingServer = createServerFn({ method: 'POST' })
  .inputValidator((d: unknown) => z.object({ imageId: z.string().min(1).max(2000), rating: z.number().min(1).max(5), timestamp: z.number() }).parse(d))
  .handler(async ({ data }) => {
    must(await (await admin()).from('star_ratings').insert({ image_id: data.imageId, rating: data.rating, timestamp: data.timestamp }));
    return { ok: true };
  });

export const loadRatingsServer = createServerFn({ method: 'GET' }).handler(async () => {
  const rows = must(await (await admin()).from('star_ratings').select('image_id, rating, timestamp').order('timestamp', { ascending: false })) ?? [];
  return rows.map((r) => ({ imageId: r.image_id, rating: r.rating, timestamp: r.timestamp }));
});

// ---- "What I actually like most" test ---------------------------------------------
export const loadFavouritesServer = createServerFn({ method: 'GET' }).handler(async () => {
  const rows = must(await (await admin()).from('favourite_rankings').select('*')) ?? [];
  return rows.map((r) => ({ imageId: r.image_id, strength: r.strength, comparisons: r.comparisons, wins: r.wins, updatedAt: r.updated_at }));
});

export const saveFavouritesServer = createServerFn({ method: 'POST' })
  .inputValidator((d: unknown) =>
    z.object({ items: z.array(z.object({ imageId: z.string().min(1).max(2000), strength: z.number(), comparisons: z.number().int(), wins: z.number().int() })).max(200) }).parse(d),
  )
  .handler(async ({ data }) => {
    if (!data.items.length) return { ok: true };
    const now = Date.now();
    must(await (await admin()).from('favourite_rankings').upsert(
      data.items.map((it) => ({ image_id: it.imageId, strength: it.strength, comparisons: it.comparisons, wins: it.wins, updated_at: now })),
      { onConflict: 'image_id' },
    ));
    return { ok: true };
  });

export const clearFavouritesServer = createServerFn({ method: 'POST' }).handler(async () => {
  must(await (await admin()).from('favourite_rankings').delete().neq('image_id', ''));
  return { ok: true };
});
