// ============================================================================
// "WHAT I ACTUALLY LIKE MOST" — a pairwise test over the photos you rated 4–5★.
// ----------------------------------------------------------------------------
// Ranking is driven ONLY by (a) your own high ratings and (b) the AI look check
// (whole-face appeal + "your type"). Geometry has zero weight here on purpose:
// the goal is to surface your real preference, not geometric purity.
// Each round shows two favourites; your pick updates an Elo-style strength.
// Deterministic: same inputs → same pairs and same ranking.
// ============================================================================
import type { AnalysisResult, FavouriteRanking, StarRating } from './types';

export const FAVOURITE_MIN_CANDIDATES = 3;
/** Prior strength = 1500 + PRIOR_SCALE × (prior − 60). GUESS. */
export const PRIOR_SCALE = 4;
export const ELO_K = 40;
/** Weights inside the prior (geometry = 0 by design). GUESS. */
export const PRIOR_WEIGHTS = { aiLook: 0.55, aiType: 0.25, stars: 0.2 };

export interface FavouriteCandidate {
  imageId: string;
  imageUrl: string;
  stars: number;
  aiLook?: number;
  aiType?: number;
  reasons: string[];
  /** 0–100 prior from AI look + your stars only */
  prior: number;
}

export function latestRatings(ratings: StarRating[]): Map<string, StarRating> {
  const m = new Map<string, StarRating>();
  for (const r of ratings) { const p = m.get(r.imageId); if (!p || r.timestamp > p.timestamp) m.set(r.imageId, r); }
  return m;
}

/** Photos you rated 4–5★ that are still in History (soft-deleted ones have no image to show). */
export function favouriteCandidates(results: AnalysisResult[], ratings: StarRating[]): FavouriteCandidate[] {
  const latest = latestRatings(ratings);
  const seen = new Set<string>();
  const out: FavouriteCandidate[] = [];
  for (const a of results) {
    const r = latest.get(a.imageId);
    if (!r || r.rating < 4 || a.deletedAt || seen.has(a.imageId)) continue;
    seen.add(a.imageId);
    const ai = a.scores.aiLook;
    const starsPart = 50 + (r.rating - 4) * 50; // 4★ → 50, 5★ → 100
    const parts: Array<[number, number]> = [[starsPart, PRIOR_WEIGHTS.stars]];
    if (ai && Number.isFinite(ai.attractiveness)) parts.push([ai.attractiveness, PRIOR_WEIGHTS.aiLook]);
    if (ai && Number.isFinite(ai.typeMatch)) parts.push([ai.typeMatch, PRIOR_WEIGHTS.aiType]);
    const w = parts.reduce((s, [, x]) => s + x, 0);
    out.push({
      imageId: a.imageId, imageUrl: a.thumbUrl ?? a.imageUrl, stars: r.rating,
      aiLook: ai?.attractiveness, aiType: ai?.typeMatch, reasons: ai?.reasons ?? [],
      prior: parts.reduce((s, [v, x]) => s + v * x, 0) / w,
    });
  }
  return out;
}

export const priorStrength = (c: FavouriteCandidate) => 1500 + PRIOR_SCALE * (c.prior - 60);

/** Current strengths: saved test results where they exist, the AI + stars prior otherwise. */
export function initialStrengths(cands: FavouriteCandidate[], saved: FavouriteRanking[]): Map<string, FavouriteRanking> {
  const s = new Map(saved.map((f) => [f.imageId, f]));
  return new Map(cands.map((c) => [c.imageId, s.get(c.imageId) ?? { imageId: c.imageId, strength: priorStrength(c), comparisons: 0, wins: 0 }]));
}

/**
 * Next pair to show: the least-compared photo against its closest-strength neighbour
 * it has not just been paired with. Close matchups are the most informative.
 */
export function nextPair(state: Map<string, FavouriteRanking>, recent: Array<[string, string]> = []): [string, string] | null {
  const items = [...state.values()];
  if (items.length < 2) return null;
  const recentKey = new Set(recent.slice(-3).map(([a, b]) => [a, b].sort().join('|')));
  const first = [...items].sort((a, b) => a.comparisons - b.comparisons || b.strength - a.strength || a.imageId.localeCompare(b.imageId))[0];
  const rivals = items
    .filter((x) => x.imageId !== first.imageId)
    .sort((a, b) => Math.abs(a.strength - first.strength) - Math.abs(b.strength - first.strength) || a.imageId.localeCompare(b.imageId));
  const rival = rivals.find((r) => !recentKey.has([first.imageId, r.imageId].sort().join('|'))) ?? rivals[0];
  return [first.imageId, rival.imageId];
}

export function applyPick(state: Map<string, FavouriteRanking>, winner: string, loser: string): Map<string, FavouriteRanking> {
  const w = state.get(winner), l = state.get(loser);
  if (!w || !l) return state;
  const expected = 1 / (1 + 10 ** ((l.strength - w.strength) / 400));
  const delta = ELO_K * (1 - expected);
  const next = new Map(state);
  next.set(winner, { ...w, strength: w.strength + delta, comparisons: w.comparisons + 1, wins: w.wins + 1 });
  next.set(loser, { ...l, strength: l.strength - delta, comparisons: l.comparisons + 1 });
  return next;
}

/** Rounds in one sitting: enough for every photo to appear ~2–3 times, capped so it stays quick. */
export const roundsFor = (n: number) => Math.max(3, Math.min(15, Math.round(n * 1.5)));

export interface FavouriteInsights {
  ranking: Array<FavouriteCandidate & { strength: number; wins: number; comparisons: number }>;
  /** Which signal your picks follow: AI appeal, AI "your type", or your original stars */
  follows: { label: string; r: number } | null;
  /** Recurring words in the AI notes of your top picks */
  themes: string[];
  summary: string;
}

const pearson = (xs: number[], ys: number[]) => {
  const n = xs.length; if (n < 3) return 0;
  const mx = xs.reduce((a, b) => a + b, 0) / n, my = ys.reduce((a, b) => a + b, 0) / n;
  let c = 0, vx = 0, vy = 0;
  for (let i = 0; i < n; i++) { c += (xs[i] - mx) * (ys[i] - my); vx += (xs[i] - mx) ** 2; vy += (ys[i] - my) ** 2; }
  return vx > 1e-9 && vy > 1e-9 ? c / Math.sqrt(vx * vy) : 0;
};

const STOP = new Set(['the', 'and', 'with', 'a', 'an', 'of', 'to', 'is', 'are', 'in', 'on', 'face', 'facial', 'features', 'slightly', 'very', 'well', 'appear', 'appears', 'visible', 'overall', 'good', 'some', 'that', 'this', 'has', 'have', 'look', 'looks', 'fairly', 'quite', 'clear', 'clearly', 'more', 'less', 'mild', 'mildly', 'which', 'gives', 'give', 'its']);

export function favouriteInsights(cands: FavouriteCandidate[], state: Map<string, FavouriteRanking>): FavouriteInsights {
  const ranking = cands
    .map((c) => { const s = state.get(c.imageId); return { ...c, strength: s?.strength ?? priorStrength(c), wins: s?.wins ?? 0, comparisons: s?.comparisons ?? 0 }; })
    .sort((a, b) => b.strength - a.strength || a.imageId.localeCompare(b.imageId));
  const str = ranking.map((r) => r.strength);
  const signals = [
    { label: 'the AI’s whole-face appeal score', xs: ranking.map((r) => r.aiLook) },
    { label: 'the AI’s “your type” score', xs: ranking.map((r) => r.aiType) },
    { label: 'your original star ratings', xs: ranking.map((r) => r.stars) },
  ].map((s) => {
    const idx = s.xs.map((x, i) => (Number.isFinite(x) ? i : -1)).filter((i) => i >= 0);
    return { label: s.label, r: pearson(idx.map((i) => s.xs[i] as number), idx.map((i) => str[i])) };
  });
  const tested = ranking.some((r) => r.comparisons > 0);
  const best = tested ? signals.sort((a, b) => b.r - a.r)[0] : null;
  const follows = best && best.r > 0.2 ? best : null;

  const top = ranking.slice(0, Math.max(2, Math.ceil(ranking.length / 3)));
  const counts = new Map<string, number>();
  for (const c of top) {
    const words = new Set(c.reasons.join(' ').toLowerCase().replace(/[^a-z\s-]/g, ' ').split(/\s+/).filter((w) => w.length > 3 && !STOP.has(w)));
    for (const w of words) counts.set(w, (counts.get(w) ?? 0) + 1);
  }
  const themes = [...counts.entries()].filter(([, n]) => n >= 2).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).slice(0, 5).map(([w]) => w);

  const summary = !tested
    ? 'Ranked by your stars and the AI look check so far. Take the test to find out which of your favourites you really prefer.'
    : [
        `Your #1 is the photo you picked most often in head-to-heads.`,
        follows ? `Your picks line up best with ${follows.label} (r = ${follows.r.toFixed(2)}).` : 'Your picks don’t follow any single score closely — your preference is your own.',
        themes.length ? `The AI notes on your top picks keep mentioning: ${themes.join(', ')}.` : '',
      ].filter(Boolean).join(' ');
  return { ranking, follows, themes, summary };
}
