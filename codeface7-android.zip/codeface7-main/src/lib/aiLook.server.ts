import { bodyExamplesPrompt, calibrateBody, type BodyExample } from './bodyTeaching';
// Server-only: asks a vision model for a holistic "how does this face look" judgement,
// and (Way off) a separate final analyst that sets the overall score.
// Why: the landmark mesh only measures ratios and left/right balance; it cannot see
// teeth, weight, skin age, puffiness or overall appeal, so it over-rates many faces.
import { FACE_TYPE_DESCRIPTION } from './faceTypeText';
import { softTop, calibrateFace, cleanCategories, faceExamplesPrompt, type FaceExample } from './faceTeaching';
import type { FaceCategory } from './types';
import { findGroqKeys, findGeminiEnvKeys, keyOrder, passStarts, orderedAiKeys, providerOfKey, type AiKey } from './aiKeys';

export { rotateKeys } from './aiKeys';

export interface AiLookResult {
  ok: true;
  attractiveness: number;
  typeMatch: number;
  reasons: string[];
  /** One or two sentence plain description of the photo. */
  description: string;
  /** 1-based number of the key that answered, out of keyCount. */
  keyIndex: number;
  keyCount: number;
  categories: FaceCategory[];
  /** AI score before the user's-taste correction. */
  rawAttractiveness: number;
  tasteRatingsUsed: number;
}
export interface AiLookFailure { ok: false; error: string }

const PROMPT = `You are a strict, experienced casting director scoring photos for a top beauty / modelling agency.
Score the main face in this photo for holistic facial appeal by mainstream fashion-model standards, 0-100.
Look slowly and carefully before deciding. Use the whole scale honestly. The TOP of the scale is extremely rare:
- 95-100: once-in-a-generation face, the level of the most celebrated faces in the world (fewer than 1 in 100,000 people). Almost never give this.
- 90-94: elite supermodel / top beauty-campaign face with no visible weak feature. Rare even among professional models.
- 80-89: clearly very attractive; typical working professional model or striking person.
- 65-79: attractive, above average, good features with one or two ordinary ones.
- 45-64: average to pleasant.
- 25-44: below average.
- 0-24: far from the standard.
Being a model, being well-lit, wearing make-up, or having a nice photo does NOT put a face above 89. An ordinary
professional model or influencer usually belongs in 75-88. Before giving 90+, name what makes this face exceptional
compared with other professional models; if you cannot, the score must stay below 90.
Work in clear steps before answering (take your time):
Step 1 – check the photo: is there one clear adult face, how much is turned, hidden, blurred or filtered?
Step 2 – go feature by feature: eyes, brows, nose, lips and teeth, cheekbones, jaw and chin, skin. Note the weakest feature honestly.
Step 3 – judge overall harmony and proportions of the whole face together.
Step 4 – pick the band, then place the face inside the band by its weakest feature.
Step 5 – re-check: does the number match your notes and the rarity of the band?
Take into account everything visible: proportions, symmetry, skin and age signs, teeth, jawline, eyes, nose and harmony.
Facial expression NEVER changes the score: judge the underlying face the same whether it smiles or is neutral.
Ignore photo quality, clothing, background and watermarks; see through heavy filters and make-up.
CATEGORIES — judge each one separately with these exact definitions; they can overlap. Answer from visible features only, do not guess:
- "Cute": youthful softness — rounder face, fuller cheeks, larger eyes relative to the face, small or button nose, soft jaw, sweet look. A sharp, angular, mature face is NOT cute.
- "Attractive": sexual / striking appeal — defined cheekbones and jaw, intense or almond eyes, full lips, confident adult look. A sweet childlike face alone is NOT this.
- "Beautiful": classic refined harmony — balanced proportions, elegant features, clear skin, graceful whole-face balance that works in any light. Requires high overall harmony, not just one strong feature.
For each category: put it in categories ONLY if it clearly and strongly fits (most traits present); put it in partialCategories if it fits a little (some traits); otherwise leave it out. An average face usually gets none or only partial categories.
Separately score typeMatch 0-100: how close the face is to this preferred type: ${FACE_TYPE_DESCRIPTION}
Also write description: 1-2 short neutral sentences describing the photo itself (setting, pose, lighting, hair, expression, clothing). Never name or guess who the person is.
Give 2-4 short, factual, non-insulting observations about visible features, including the weakest one. Never name or guess who the person is.
If there is no clear human face, return 0 for both scores and say so in reasons.`;

const clamp = (n: unknown) => (typeof n === 'number' && Number.isFinite(n) ? Math.max(0, Math.min(100, n)) : NaN);

/** Vision-capable models only; older accounts may still expose Llama 4. */
const GROQ_MODELS = ['qwen/qwen3.8-27b', 'meta-llama/llama-4-scout-17b-16e-instruct', 'meta-llama/llama-4-maverick-17b-128e-instruct'];
/** Gemini model used with the owner's / personal Gemini keys (free tier ≈ 15 requests per minute). */
/** Tried in order; Google retires old model names (404), so we fall through to newer ones. */
const GEMINI_MODELS = ['gemini-flash-latest', 'gemini-3.8-flash', 'gemini-2.5-flash'];
/** Built-in Lovable AI model (no key needed). Same Gemini Flash family; ~3 s per photo in testing. */
const GATEWAY_MODEL = 'google/gemini-3.8-flash';
const GATEWAY_URL = 'https://ai.gateway.lovable.dev/v1/chat/completions';

type Schema = { type: string; properties?: Record<string, Schema>; items?: Schema; required?: string[] };

const LOOK_SCHEMA: Schema = {
  type: 'object',
  required: ['attractiveness', 'typeMatch', 'reasons', 'description', 'categories', 'partialCategories'],
  properties: {
    attractiveness: { type: 'number' },
    categories: { type: 'array', items: { type: 'string' } },
    partialCategories: { type: 'array', items: { type: 'string' } },
    typeMatch: { type: 'number' },
    reasons: { type: 'array', items: { type: 'string' } },
    description: { type: 'string' },
  },
};

/** Strict JSON schema for the gateway: every object closes its properties. */
function toStrictSchema(s: Schema): Record<string, unknown> {
  return {
    type: s.type,
    ...(s.items ? { items: toStrictSchema(s.items) } : {}),
    ...(s.properties ? {
      properties: Object.fromEntries(Object.entries(s.properties).map(([k, v]) => [k, toStrictSchema(v)])),
      required: Object.keys(s.properties), additionalProperties: false,
    } : {}),
  };
}

/** All env vars visible to the server (Netlify runtime first, then process.env). */
function serverEnv(): Record<string, string | undefined> {
  const g = globalThis as { Netlify?: { env?: { toObject?: () => Record<string, string> } } };
  let netlify: Record<string, string> = {};
  try { netlify = g.Netlify?.env?.toObject?.() ?? {}; } catch { /* not on Netlify */ }
  const proc = typeof process !== 'undefined' ? process.env : {};
  return { ...proc, ...netlify };
}

/** Collects the Groq keys even when named slightly differently (GROQ_API_KEY_2, GROQ_API_KEY3, GROQ_KEY_4 …). */
export function getGroqKeys(): string[] {
  return findGroqKeys(serverEnv());
}

/** Gemini keys first, then Groq keys. Personal keys are split by their prefix. */
export function getAiKeys(personalKeys?: string[]): AiKey[] {
  if (personalKeys) return orderedAiKeys(personalKeys.filter((k) => providerOfKey(k) === 'gemini'), personalKeys.filter((k) => providerOfKey(k) === 'groq'));
  const env = serverEnv();
  return orderedAiKeys(findGeminiEnvKeys(env), findGroqKeys(env));
}

type Attempt<T> = { ok: true; value: T } | { ok: false; error: string; final?: boolean };
type ModelCall = (image: { mime: string; data: string }, text: string, schema: Schema) => Promise<Attempt<Record<string, unknown>>>;
/** How hard the model thinks, and an optional hard time limit per call. */
export interface Thinking { effort: 'low' | 'medium' | 'high'; geminiBudget: number; timeoutMs?: number }
/** First look check: a few more steps, a little more time. */
export const LOOK_THINKING: Thinking = { effort: 'medium', geminiBudget: 2048, timeoutMs: 20_000 };
/** "Way off" re-check: strong thinking, capped at 10 seconds per pass. */
export const FINAL_THINKING: Thinking = { effort: 'high', geminiBudget: 8192, timeoutMs: 10_000 };
const DEFAULT_THINKING: Thinking = { effort: 'low', geminiBudget: 0, timeoutMs: 15_000 };

/** Runs a model fetch with an optional time limit; a timeout is reported per attempt so the next key/model can try. */
async function timed(t: Thinking, go: (signal?: AbortSignal) => Promise<Attempt<Record<string, unknown>>>): Promise<Attempt<Record<string, unknown>>> {
  if (!t.timeoutMs) return go();
  try { return await go(AbortSignal.timeout(t.timeoutMs)); }
  catch (e) { if ((e as Error)?.name === 'TimeoutError' || (e as Error)?.name === 'AbortError') return { ok: false, error: `took longer than ${t.timeoutMs / 1000} s` }; throw e; }
}

/**
 * Tries personal / owner Groq keys first (round-robin from `start`), then the built-in Lovable AI
 * model, so the check works even with no key or when every key is out of quota.
 * keyIndex/keyCount are 0 when the built-in model answered.
 */
async function withKeysOnce<T>(start: number, run: (call: ModelCall) => Promise<Attempt<T>>, personalKeys?: string[], think: Thinking = DEFAULT_THINKING): Promise<{ ok: true; value: T; keyIndex: number; keyCount: number } | AiLookFailure> {
  const keys = getAiKeys(personalKeys);
  const notes: string[] = [];
  // Rotate within each provider, but always try every Gemini key before falling back to Groq.
  const gem = keys.filter((k) => k.provider === 'gemini').length;
  const order = [...keyOrder(gem, start), ...keyOrder(keys.length - gem, start).map((i) => i + gem)];
  for (const i of order) {
    let r: Attempt<T>;
    const k = keys[i];
    try { r = await run((img, text, schema) => timed(think, (signal) => k.provider === 'gemini' ? callGemini(k.key, [img], text, schema, think, signal) : callGroq(k.key, img, text, schema, think, signal))); } catch { r = { ok: false, error: 'request failed' }; }
    if (r.ok) return { ok: true, value: r.value, keyIndex: i + 1, keyCount: keys.length };
    notes.push(`${k.provider === 'gemini' ? 'Gemini' : 'Groq'} key ${i + 1}: ${r.error}`);
    if (r.final) return { ok: false, error: r.error };
  }
  let r: Attempt<T>;
  try { r = await run((img, text, schema) => timed(think, (signal) => callGateway(img, text, schema, think, signal))); } catch { r = { ok: false, error: 'request failed' }; }
  if (r.ok) return { ok: true, value: r.value, keyIndex: 0, keyCount: 0 };
  notes.push(`built-in AI: ${r.error}`);
  return { ok: false, error: notes.length > 1 ? `The AI check failed (${notes.join('; ')}).` : `The AI check failed: ${r.error}.` };
}

/** Runs the whole key chain, and if everything failed (not a refusal / no credits), tries once more after a short pause. */
async function withKeys<T>(start: number, run: (call: ModelCall) => Promise<Attempt<T>>, personalKeys?: string[], think: Thinking = DEFAULT_THINKING) {
  const first = await withKeysOnce(start, run, personalKeys, think);
  if (first.ok || /declined/i.test(first.error)) return first;
  // An exhausted built-in backup must not suppress recovery of a temporary personal-provider failure.
  const transient = /server error|request failed|took longer/i.test(first.error);
  if (!transient && /credits|not available/i.test(first.error)) return first;
  await new Promise((r) => setTimeout(r, 1500));
  const second = await withKeysOnce(start + 1, run, personalKeys, think);
  return second.ok ? second : { ok: false as const, error: `${second.error} (tried twice)` };
}

/** One call to the built-in Lovable AI model (OpenAI-compatible chat endpoint). */
async function callGateway(image: { mime: string; data: string }, text: string, schema: Schema, think: Thinking = DEFAULT_THINKING, signal?: AbortSignal): Promise<Attempt<Record<string, unknown>>> {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) return { ok: false, error: 'built-in AI is not set up' };
  const res = await fetch(GATEWAY_URL, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: `Bearer ${key}`, 'X-Lovable-AIG-SDK': 'fetch' },
    signal,
    body: JSON.stringify({
      model: GATEWAY_MODEL,
      reasoning_effort: think.effort,
      temperature: 0.2,
      messages: [{ role: 'user', content: [{ type: 'text', text }, { type: 'image_url', image_url: { url: `data:${image.mime};base64,${image.data}` } }] }],
      response_format: { type: 'json_schema', json_schema: { name: 'result', strict: true, schema: toStrictSchema(schema) } },
    }),
  });
  if (!res.ok) {
    console.error('[ai-look] gateway HTTP', res.status);
    if (res.status === 402) return { ok: false, error: 'AI credits have run out', final: true };
    if (res.status === 429) return { ok: false, error: 'the AI is busy right now, try again in a minute' };
    if (res.status === 403) return { ok: false, error: 'the AI is not available for this workspace', final: true };
    if (res.status >= 500) return { ok: false, error: 'AI server error' };
    return { ok: false, error: `unexpected error ${res.status}` };
  }
  const json = (await res.json()) as { choices?: Array<{ finish_reason?: string; message?: { content?: string; refusal?: string } }> };
  const c = json.choices?.[0];
  if (c?.message?.refusal || c?.finish_reason === 'content_filter') return { ok: false, error: 'the AI declined to judge this photo', final: true };
  const out = (c?.message?.content ?? '').replace(/^```(?:json)?\s*|\s*```$/g, '');
  try { return { ok: true, value: JSON.parse(out || '{}') as Record<string, unknown> }; } catch { return { ok: false, error: 'unreadable answer' }; }
}

/** Describes the wanted JSON shape in words (Groq gets json_object mode, not a strict schema). */
function describeSchema(s: Schema): string {
  if (s.type === 'array') return `[${s.items ? describeSchema(s.items) : 'any'}]`;
  if (s.type === 'object' && s.properties) return `{${Object.entries(s.properties).map(([k, v]) => `"${k}": ${describeSchema(v)}`).join(', ')}}`;
  return s.type;
}

/** One Groq call with one key. HTTP problems are reported per key so the next key can be tried. */
async function callGroq(key: string, image: { mime: string; data: string }, text: string, schema: Schema, _think: Thinking = DEFAULT_THINKING, signal?: AbortSignal): Promise<Attempt<Record<string, unknown>>> {
  for (const model of GROQ_MODELS) {
    const result = await callGroqModel(model, key, image, text, schema, signal);
    if (result !== 'not-found') return result;
  }
  return { ok: false, error: 'no supported Groq vision model is available for this key' };
}

async function callGroqModel(model: string, key: string, image: { mime: string; data: string }, text: string, schema: Schema, signal?: AbortSignal): Promise<Attempt<Record<string, unknown>> | 'not-found'> {
  const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: `Bearer ${key}` },
    signal,
    body: JSON.stringify({
      model,
      temperature: 0.2,
      messages: [{ role: 'user', content: [
        { type: 'text', text: `${text}\n\nReply with ONLY a JSON object of exactly this shape: ${describeSchema(schema)}` },
        { type: 'image_url', image_url: { url: `data:${image.mime};base64,${image.data}` } },
      ] }],
      response_format: { type: 'json_object' },
    }),
  });
  if (!res.ok) {
    console.error('[ai-look] Groq HTTP', res.status);
    if (res.status === 404) return 'not-found';
    if (res.status === 429) return { ok: false, error: 'out of quota' };
    if (res.status === 401 || res.status === 403) return { ok: false, error: 'key rejected' };
    if (res.status === 400 || res.status === 413) return { ok: false, error: 'Groq could not read this photo' };
    if (res.status >= 500) return { ok: false, error: 'Groq server error' };
    return { ok: false, error: `unexpected error ${res.status}` };
  }
  const json = (await res.json()) as { choices?: Array<{ finish_reason?: string; message?: { content?: string } }> };
  const c = json.choices?.[0];
  if (c?.finish_reason === 'content_filter') return { ok: false, error: 'the AI declined to judge this photo', final: true };
  const out = (c?.message?.content ?? '').replace(/^```(?:json)?\s*|\s*```$/g, '');
  try { return { ok: true, value: JSON.parse(out || '{}') as Record<string, unknown> }; } catch { return { ok: false, error: 'unreadable answer' }; }
}

/** Gemini wants upper-case OpenAPI types. */
function toGeminiSchema(s: Schema): Record<string, unknown> {
  return {
    type: s.type.toUpperCase(),
    ...(s.items ? { items: toGeminiSchema(s.items) } : {}),
    ...(s.properties ? { properties: Object.fromEntries(Object.entries(s.properties).map(([k, v]) => [k, toGeminiSchema(v)])), required: s.required ?? Object.keys(s.properties) } : {}),
  };
}

/** One Gemini call with one key; several images can go in one request (batching). */
async function callGemini(key: string, images: Array<{ mime: string; data: string }>, text: string, schema: Schema, think: Thinking = DEFAULT_THINKING, signal?: AbortSignal): Promise<Attempt<Record<string, unknown>>> {
  let lastError = 'no Gemini model available for this key';
  for (const model of GEMINI_MODELS) {
    const r = await callGeminiModel(model, key, images, text, schema, think, signal);
    if (r === 'not-found') continue;
    if (r.ok || r.final || r.error !== 'Gemini server error') return r;
    lastError = r.error;
  }
  return { ok: false, error: lastError };
}

async function callGeminiModel(model: string, key: string, images: Array<{ mime: string; data: string }>, text: string, schema: Schema, think: Thinking, signal?: AbortSignal): Promise<Attempt<Record<string, unknown>> | 'not-found'> {
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-goog-api-key': key },
    signal,
    body: JSON.stringify({
      contents: [{ role: 'user', parts: [{ text }, ...images.map((im) => ({ inline_data: { mime_type: im.mime, data: im.data } }))] }],
      generationConfig: {
        temperature: 0.2, responseMimeType: 'application/json', responseSchema: toGeminiSchema(schema),
        // Fixed token budgets belong to Gemini 2.5; current Flash models use thinking levels.
        thinkingConfig: model.startsWith('gemini-2.5') ? { thinkingBudget: think.geminiBudget } : { thinkingLevel: think.effort.toUpperCase() },
      },
    }),
  });
  if (!res.ok) {
    console.error('[ai-look] Gemini HTTP', res.status);
    if (res.status === 404) return 'not-found';
    if (res.status === 429) return { ok: false, error: 'out of quota' };
    if (res.status === 401 || res.status === 403) return { ok: false, error: 'key rejected' };
    if (res.status === 400) return { ok: false, error: 'Gemini could not read this photo' };
    if (res.status >= 500) return { ok: false, error: 'Gemini server error' };
    return { ok: false, error: `unexpected error ${res.status}` };
  }
  const json = (await res.json()) as { promptFeedback?: { blockReason?: string }; candidates?: Array<{ finishReason?: string; content?: { parts?: Array<{ text?: string; thought?: boolean }> } }> };
  const c = json.candidates?.[0];
  if (json.promptFeedback?.blockReason || c?.finishReason === 'SAFETY' || c?.finishReason === 'PROHIBITED_CONTENT') return { ok: false, error: 'the AI declined to judge this photo', final: true };
  const out = (c?.content?.parts ?? []).filter((p) => !p.thought).map((p) => p.text ?? '').join('').replace(/^```(?:json)?\s*|\s*```$/g, '');
  try { return { ok: true, value: JSON.parse(out || '{}') as Record<string, unknown> }; } catch { return { ok: false, error: 'unreadable answer' }; }
}

function parseImage(imageDataUrl: string) {
  const m = imageDataUrl.match(/^data:(image\/[a-z+]+);base64,(.+)$/);
  return m ? { mime: m[1], data: m[2] } : null;
}

const strings = (x: unknown, n: number) => (Array.isArray(x) ? x.filter((r): r is string => typeof r === 'string').slice(0, n) : []);

/** AI look check. `start` = the browser's check counter, so each check starts on the next key. */
export async function judgeLook(imageDataUrl: string, extraPrompt = '', start = 0, personalKeys?: string[], examples: FaceExample[] = []): Promise<AiLookResult | AiLookFailure> {
  const image = parseImage(imageDataUrl);
  extraPrompt = `${extraPrompt}${faceExamplesPrompt(examples)}`.trim();
  if (!image) return { ok: false, error: 'The AI look check could not read this photo.' };
  const r = await withKeys(start, async (call) => {
    const g = await call(image, extraPrompt ? `${PROMPT}\n\n${extraPrompt}` : PROMPT, LOOK_SCHEMA);
    if (!g.ok) return g;
    const a = softTop(clamp(g.value.attractiveness)), t = clamp(g.value.typeMatch);
    if (!Number.isFinite(a)) return { ok: false, error: 'no usable score' };
    return { ok: true, value: { attractiveness: a, typeMatch: Number.isFinite(t) ? t : 0, reasons: strings(g.value.reasons, 4), description: typeof g.value.description === 'string' ? g.value.description.slice(0, 400) : '', categories: cleanCategories(g.value.categories), partialCategories: cleanCategories(g.value.partialCategories).filter((c) => !cleanCategories(g.value.categories).includes(c)) } };
  }, personalKeys, LOOK_THINKING);
  if (!r.ok) return r;
  const cal = calibrateFace(r.value.attractiveness, r.value.typeMatch, examples);
  return { ok: true, ...r.value, attractiveness: Math.round(cal.score), rawAttractiveness: r.value.attractiveness, tasteRatingsUsed: cal.used, keyIndex: r.keyIndex, keyCount: r.keyCount };
}

/** Max photos sent to Gemini in one request (keeps answers reliable and requests small). */
/** Server cap per batched request; the Best section uses 4, History selection up to 10. */
export const LOOK_BATCH_MAX = 10;

/**
 * Batched AI look check: several photos in ONE Gemini request, so a free key's ~15 requests/minute
 * covers up to 4× more photos. Any photo the batch could not answer falls back to its own single check
 * (Gemini → Groq → built-in AI), so a batch failure never loses a photo.
 */
export async function judgeLookBatch(images: string[], start = 0, personalKeys?: string[], examples: FaceExample[] = []): Promise<Array<AiLookResult | AiLookFailure>> {
  const parsed = images.map(parseImage);
  const out: Array<AiLookResult | AiLookFailure | undefined> = images.map(() => undefined);
  const gemKeys = getAiKeys(personalKeys).filter((k) => k.provider === 'gemini');
  const valid = parsed.map((p, i) => (p ? i : -1)).filter((i) => i >= 0);
  if (gemKeys.length && valid.length > 1) {
    const extra = faceExamplesPrompt(examples).trim();
    const text = `${PROMPT}${extra ? `\n\n${extra}` : ''}\n\nBATCH MODE: you get ${valid.length} separate photos of (usually) different people. Judge EACH photo completely on its own, as if it were the only one — never compare them or rank them against each other. Return "results" with exactly ${valid.length} entries in the same order as the photos, each with "photo" = its 1-based position.`;
    const schema: Schema = { type: 'object', required: ['results'], properties: { results: { type: 'array', items: { ...LOOK_SCHEMA, required: ['photo', ...(LOOK_SCHEMA.required ?? [])], properties: { photo: { type: 'number' }, ...LOOK_SCHEMA.properties } } } } };
    for (const ki of keyOrder(gemKeys.length, start)) {
      let r: Attempt<Record<string, unknown>>;
      const batchImages = valid.flatMap((i) => { const image = parsed[i]; return image ? [image] : []; });
      try { r = await timed(LOOK_THINKING, (signal) => callGemini(gemKeys[ki].key, batchImages, text, schema, LOOK_THINKING, signal)); } catch { r = { ok: false, error: 'request failed' }; }
      if (!r.ok) { if (r.final) break; continue; }
      const list = Array.isArray(r.value.results) ? (r.value.results as Array<Record<string, unknown>>) : [];
      list.forEach((v, n) => {
        const pos = typeof v.photo === 'number' && v.photo >= 1 && v.photo <= valid.length ? Math.round(v.photo) - 1 : n;
        const idx = valid[pos];
        if (idx === undefined || out[idx]) return;
        const a = softTop(clamp(v.attractiveness)), t = clamp(v.typeMatch);
        if (!Number.isFinite(a)) return;
        const cats = cleanCategories(v.categories);
        const cal = calibrateFace(a, Number.isFinite(t) ? t : 0, examples);
        out[idx] = { ok: true, attractiveness: Math.round(cal.score), rawAttractiveness: a, tasteRatingsUsed: cal.used, typeMatch: Number.isFinite(t) ? t : 0, reasons: strings(v.reasons, 4), description: typeof v.description === 'string' ? v.description.slice(0, 400) : '', categories: cats, partialCategories: cleanCategories(v.partialCategories).filter((c) => !cats.includes(c)), keyIndex: ki + 1, keyCount: gemKeys.length } as AiLookResult;
      });
      break;
    }
  }
  // Fallback: anything still unanswered gets its own single check.
  for (let i = 0; i < images.length; i++) if (!out[i]) out[i] = await judgeLook(images[i], '', start + i, personalKeys, examples);
  return out as Array<AiLookResult | AiLookFailure>;
}

// ---------------- Final analyst (Way off) ----------------

export interface FinalInput {
  aiScore: number;
  aiReasons: string[];
  measurementOverall: number;
  faceScore?: number;
  photoScore?: number;
  metrics: Record<string, number>;
}

/** Focus for each of the 3 final-analyst passes. */
export const CAREFUL_PASSES = [
  'Pass 1 of 3: start from the whole face and overall harmony.',
  'Pass 2 of 3: start feature by feature (eyes, brows, nose, lips, teeth, jaw, skin).',
  'Pass 3 of 3: start from where the AI score and the measurements disagree, and decide which is right for this photo.',
];

export function finalPrompt(i: FinalInput, focus: string): string {
  const metrics = Object.entries(i.metrics).map(([k, v]) => `${k} ${Math.round(v)}`).join(', ');
  return `You are the FINAL ANALYST for a face-scoring app. Two analysts already scored this photo:
1) AI look check (whole-face judgement): ${Math.round(i.aiScore)}/100. Its notes: ${i.aiReasons.length ? i.aiReasons.join(' | ') : 'none'}.
2) Measurements (landmark symmetry / proportions / skin detail): overall ${Math.round(i.measurementOverall)}/100${i.faceScore !== undefined ? `, face ${Math.round(i.faceScore)}` : ''}${i.photoScore !== undefined ? `, photo ${Math.round(i.photoScore)}` : ''}. Details: ${metrics || 'none'}.
The user says the overall score is way off. Think hard (you have up to 10 seconds): look at the photo yourself, slowly, feature by feature. Weigh both analysts against what you see
and give ONE overall score 0-100 (strict model-agency scale: 95+ only once-in-a-generation world-famous faces, 90-94 elite supermodel, 80-89 typical professional model, 45-64 average).
Facial expression must never change the score. Measurements cannot see teeth, weight, skin age or overall appeal; the AI can be swayed by lighting and tends to under-score. Do not simply average.
90+ is rare: give it only if you can name what makes this face exceptional even among professional models. An ordinary model belongs in 75-88.
Never give a mid score while your own reasons are all praise, and never a top score without naming why it is exceptional.
${focus}
Give 2-3 short, neutral reasons for your verdict. Never name or guess who the person is.`;
}

const FINAL_SCHEMA: Schema = {
  type: 'object',
  required: ['overall', 'reasons'],
  properties: { overall: { type: 'number' }, reasons: { type: 'array', items: { type: 'string' } } },
};

export interface FinalResult { ok: true; overall: number; passes: number[]; spread: number; reasons: string[]; keys: number[]; keyCount: number }

export const median = (xs: number[]) => { const s = [...xs].sort((a, b) => a - b); const m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };

/** Way off: a separate third analyst, 3 passes each starting on a different key; the median is the overall. Needs ≥2 good passes. */
export async function judgeFinal(imageDataUrl: string, input: FinalInput, start = 0, personalKeys?: string[]): Promise<FinalResult | AiLookFailure> {
  const image = parseImage(imageDataUrl);
  if (!image) return { ok: false, error: 'The final analyst could not read this photo.' };
  const starts = passStarts(start, CAREFUL_PASSES.length);
  const good: Array<{ overall: number; reasons: string[]; key: number }> = [];
  let keyCount = 0;
  let lastError = 'The final analyst failed.';
  // The 3 passes run at the same time (was one after another: ~3× slower).
  const results = await Promise.all(CAREFUL_PASSES.map((focus, p) => withKeys(starts[p], async (call) => {
    const g = await call(image, finalPrompt(input, focus), FINAL_SCHEMA);
    if (!g.ok) return g;
    const o = softTop(clamp(g.value.overall));
    if (!Number.isFinite(o)) return { ok: false as const, error: 'no usable score' };
    return { ok: true as const, value: { overall: o, reasons: strings(g.value.reasons, 3) } };
  }, personalKeys, FINAL_THINKING)));
  for (const r of results) {
    if (r.ok) { good.push({ ...r.value, key: r.keyIndex }); keyCount = r.keyCount; } else lastError = r.error;
  }
  if (good.length < 2) return { ok: false, error: `Only ${good.length} of ${CAREFUL_PASSES.length} final-analyst passes worked. ${lastError}` };
  const passes = good.map((g) => g.overall);
  return {
    ok: true, overall: median(passes), passes, spread: Math.max(...passes) - Math.min(...passes),
    reasons: [...new Set(good.flatMap((g) => g.reasons))].slice(0, 4), keys: good.map((g) => g.key), keyCount,
  };
}

// ---------------- Whole-body rating ----------------

export interface BodyLookResult {
  ok: true;
  /** false when too little of the body is in the photo to judge */
  visible: boolean;
  overall: number;
  proportions: number;
  physique: number;
  posture: number;
  presentation: number;
  bodyType: string;
  reasons: string[];
}

export const BODY_PROMPT = `You are a strict model-agency scout rating the WHOLE BODY of the main person in this photo, 0-100,
by mainstream fashion / fitness model standards. Be strict and use the full range (90+ top runway / campaign body, 35-54 average).
Score these parts 0-100:
- proportions: shoulder-waist-hip balance, leg-to-torso ratio, limb length, overall silhouette.
- physique: visible muscle tone, body-fat level, firmness, fitness.
- posture: stance, spine and shoulder alignment, how the body is carried.
- presentation: how the body is shown off by pose and fit of clothing (not the brand or the background).
overall: your single whole-body score (not a plain average: weigh proportions and physique most).
bodyType: a short neutral label such as "athletic", "slim", "hourglass", "V-shape", "pear", "rectangle", "curvy", "muscular".
visible: true only if at least the torso down to the hips is visible; otherwise false, all scores 0 and say so in reasons.
Give 2-4 short, factual, non-insulting observations. Never name or guess who the person is. Ignore the face.
ADULTS ONLY: if the person could be under 18, set visible false, all scores 0 and reason "Only adults can be rated".`;

const BODY_SCHEMA: Schema = {
  type: 'object',
  required: ['visible', 'overall', 'proportions', 'physique', 'posture', 'presentation', 'bodyType', 'reasons'],
  properties: {
    visible: { type: 'boolean' },
    overall: { type: 'number' }, proportions: { type: 'number' }, physique: { type: 'number' },
    posture: { type: 'number' }, presentation: { type: 'number' },
    bodyType: { type: 'string' },
    reasons: { type: 'array', items: { type: 'string' } },
  },
};

/** Parses one body answer; exported for tests. */
export function parseBodyAnswer(v: Record<string, unknown>): Omit<BodyLookResult, 'ok'> | null {
  const o = clamp(v.overall);
  if (!Number.isFinite(o)) return null;
  const part = (x: unknown) => { const n = clamp(x); return Number.isFinite(n) ? n : o; };
  const visible = v.visible !== false && o > 0;
  return {
    visible, overall: visible ? o : 0,
    proportions: visible ? part(v.proportions) : 0, physique: visible ? part(v.physique) : 0,
    posture: visible ? part(v.posture) : 0, presentation: visible ? part(v.presentation) : 0,
    bodyType: typeof v.bodyType === 'string' ? v.bodyType.slice(0, 40) : '',
    reasons: strings(v.reasons, 4),
  };
}

export async function judgeBody(imageDataUrl: string, start = 0, personalKeys?: string[], examples: BodyExample[] = []): Promise<BodyLookResult | AiLookFailure> {
  const image = parseImage(imageDataUrl);
  if (!image) return { ok: false, error: 'The body rating could not read this photo.' };
  const prompt = BODY_PROMPT + bodyExamplesPrompt(examples);
  const r = await withKeys(start, async (call) => {
    const g = await call(image, prompt, BODY_SCHEMA);
    if (!g.ok) return g;
    const b = parseBodyAnswer(g.value);
    return b ? { ok: true as const, value: b } : { ok: false as const, error: 'no usable score' };
  }, personalKeys);
  if (!r.ok) return r;
  if (!r.value.visible) return { ok: true, ...r.value };
  const { value, shift } = calibrateBody(r.value, examples);
  const reasons = shift ? [...value.reasons, `Adjusted ${shift > 0 ? '+' : ''}${shift} to match your past ratings`] : value.reasons;
  return { ok: true, ...value, reasons };
}

export type KeyHealthStatus = 'ok' | 'rejected' | 'quota' | 'no-model' | 'error';
export interface KeyHealth { provider: 'gemini' | 'groq'; index: number; status: KeyHealthStatus; detail: string; model?: string }
export interface AiHealthReport { personal: boolean; keys: KeyHealth[]; builtIn: 'set-up' | 'missing' }

/** Free model-list request per key (no photo, no generation quota): checks the key works and a supported model is reachable. Keys are never returned. */
export async function checkAiKeyHealth(personalKeys?: string[]): Promise<AiHealthReport> {
  const keys = getAiKeys(personalKeys);
  const one = async (k: AiKey, i: number): Promise<KeyHealth> => {
    const gem = k.provider === 'gemini';
    try {
      const res = await fetch(gem ? 'https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000' : 'https://api.groq.com/openai/v1/models', {
        headers: gem ? { 'x-goog-api-key': k.key } : { authorization: `Bearer ${k.key}` }, signal: AbortSignal.timeout(8000),
      });
      if (res.status === 400 || res.status === 401 || res.status === 403) return { provider: k.provider, index: i + 1, status: 'rejected', detail: 'Key rejected — check it was copied fully' };
      if (res.status === 429) return { provider: k.provider, index: i + 1, status: 'quota', detail: 'Out of quota right now — wait a minute' };
      if (!res.ok) return { provider: k.provider, index: i + 1, status: 'error', detail: `Service error ${res.status}` };
      const json = (await res.json()) as { models?: Array<{ name?: string }>; data?: Array<{ id?: string }> };
      const ids = new Set(gem ? (json.models ?? []).map((m) => (m.name ?? '').replace(/^models\//, '')) : (json.data ?? []).map((m) => m.id ?? ''));
      const model = (gem ? GEMINI_MODELS : GROQ_MODELS).find((m) => ids.has(m));
      return model ? { provider: k.provider, index: i + 1, status: 'ok', detail: 'Working', model }
        : { provider: k.provider, index: i + 1, status: 'no-model', detail: 'Key works, but no photo-reading model is offered to it' };
    } catch (e) {
      const slow = (e as Error)?.name === 'TimeoutError';
      return { provider: k.provider, index: i + 1, status: 'error', detail: slow ? 'No answer within 8 s' : 'Could not reach the service' };
    }
  };
  return { personal: !!personalKeys, keys: await Promise.all(keys.map(one)), builtIn: process.env.LOVABLE_API_KEY ? 'set-up' : 'missing' };
}
