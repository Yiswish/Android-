// ============================================================================
// SEARCH PROVIDER CHAIN — plain functions (no framework import) so the chain is
// unit-tested with a mocked fetch. search.functions.ts wraps this in a
// TanStack server function.
//
//   SerpAPI (needs SERPAPI_API_KEY) → Openverse → Wikimedia Commons → curated (client)
//
// RULES
//  • Search defaults to young portrait photos; Best uses age-neutral portraits.
//    Both add missing portrait/photo terms and Google's face image type.
//    Pinterest additionally gets `site:pinterest.com `.
//  • The SerpAPI key is read ONLY from the environment, never logged, never
//    returned, never put in a URL that is logged. Error text is redacted.
//  • Nothing fails silently: every response carries a status naming the provider
//    that answered and why the earlier ones did not (+ safe diagnostics).
// ============================================================================

export type Provider = 'serpapi' | 'serper' | 'pexels' | 'unsplash' | 'openverse' | 'wikimedia' | 'elitebabes';
/** Optional keys a visitor can supply for this tab (never stored). */
export interface SearchKeys { serpapi?: string; serper?: string; pexels?: string; unsplash?: string }
export type FallbackReason = 'missing key' | 'quota' | 'network' | 'empty';
export type SearchSource = 'google' | 'pinterest' | 'upload' | 'curated' | 'pexels' | 'unsplash' | 'openverse' | 'wikimedia' | 'elitebabes';

export interface SearchInput { query: string; page: number; perPage: number; source: SearchSource; portraitMode?: 'young' | 'all-ages' }
export interface Img { id: string; url: string; thumbUrl: string; width: number; height: number; alt: string; source: 'google' | 'pinterest' | 'openverse' | 'wikimedia' | 'pexels' | 'unsplash' | 'elitebabes'; photographer?: string }
export interface ProviderResult { images: Img[]; totalCount: number; hasMore: boolean }

export class ProviderError extends Error {
  constructor(public reason: FallbackReason, msg: string, public httpStatus?: number) { super(msg); }
}

const FACE_WORDS = /\b(face|faces|portrait|portraits|person|people|woman|women|man|men|model|models|headshot|selfie|girl|boy|beauty|smile|smiling|actress|actor|celebrity|lady|gentleman|child|kid)\b/i;
export const isFaceQuery = (q: string) => FACE_WORDS.test(q);
/** Tall results first for face queries (ordering only — the query text is untouched). */
export const portraitBias = <T extends { width: number; height: number }>(imgs: T[]): T[] => [...imgs].sort((a, b) => Number(b.height >= b.width) - Number(a.height >= a.width));

export const TIMEOUT_MS = 8000;

/**
 * Netlify Functions expose env through `Netlify.env`; Node / bun dev use process.env.
 * (A Netlify env var set with `netlify env:set` only reaches NEW deploys.)
 */
export function getSerpApiKey(): string | undefined {
  const g = globalThis as { Netlify?: { env?: { get?: (name: string) => string | undefined } } };
  const key = g.Netlify?.env?.get?.('SERPAPI_API_KEY') ?? (typeof process !== 'undefined' ? process.env?.SERPAPI_API_KEY : undefined);
  const k = key?.trim();
  return k ? k : undefined;
}

/** Generic env key reader (same Netlify/process fallback as SerpAPI). */
export function envKey(name: string): string | undefined {
  const g = globalThis as { Netlify?: { env?: { get?: (name: string) => string | undefined } } };
  const key = g.Netlify?.env?.get?.(name) ?? (typeof process !== 'undefined' ? process.env?.[name] : undefined);
  const k = key?.trim();
  return k ? k : undefined;
}
export const getSerperKey = () => envKey('SERPER_API_KEY');
export const getPexelsKey = () => envKey('PEXELS_API_KEY');
export const getUnsplashKey = () => envKey('UNSPLASH_ACCESS_KEY');

/** Remove the key and any `api_key=…` fragment from text that might be logged or returned. */
export function redact(text: string, key?: string): string {
  let out = text.replace(/api_key=[^&\s"']*/gi, 'api_key=[redacted]');
  if (key) out = out.split(key).join('[redacted]');
  return out;
}

/** Google: the query exactly as typed. Pinterest: `site:pinterest.com <query>`. */
export const buildSerpQuery = (source: SearchSource, query: string) => (source === 'pinterest' ? `site:pinterest.com ${query}` : query);

/** One retry for transient failures; quota / auth problems never heal inside one request, so no retry. */
async function fetchJson<T>(provider: string, url: string, redactKey?: string, init?: { method?: string; headers?: Record<string, string>; body?: string }): Promise<T> {
  let last: ProviderError | null = null;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      const resp = await fetch(url, { method: init?.method, body: init?.body, headers: { Accept: 'application/json', 'User-Agent': 'FaceGeometryLab/1.0 (image search)', ...init?.headers }, signal: AbortSignal.timeout(TIMEOUT_MS) });
      if (resp.status === 429 || resp.status === 402 || resp.status === 401 || resp.status === 403) {
        console.error(`[search:${provider}] HTTP ${resp.status}`);
        throw new ProviderError('quota', `${provider} HTTP ${resp.status}`, resp.status);
      }
      if (!resp.ok) throw new ProviderError('network', `${provider} HTTP ${resp.status}`, resp.status);
      return (await resp.json()) as T;
    } catch (e) {
      if (e instanceof ProviderError && e.reason === 'quota') throw e;
      last = e instanceof ProviderError ? e : new ProviderError('network', redact(`${provider}: ${(e as Error).message}`, redactKey));
      console.error(`[search:${provider}] attempt ${attempt} failed: ${last.message}`);
    }
  }
  throw last!;
}

// ---- SerpAPI (Google Images / Pinterest via Google) ----------------------------
/** Hosts whose image URLs need cookies/sessions and cannot be relayed. */
export const BLOCKED_IMAGE_HOST = /^https?:\/\/([^/]*\.)?(tiktok\.com|tiktokcdn\.com|instagram\.com|cdninstagram\.com|facebook\.com|fbsbx\.com|fbcdn\.net)\//i;
interface SerpImageResult { thumbnail: string; original: string; title: string; original_width?: number; original_height?: number; source?: string }
export async function serpapi(d: SearchInput, face: boolean, personalKey?: string): Promise<ProviderResult> {
  const apiKey = personalKey ?? getSerpApiKey();
  if (!apiKey) throw new ProviderError('missing key', 'SERPAPI_API_KEY is not set in the server environment');
  const pinterest = d.source === 'pinterest';
  const q = buildSerpQuery(d.source, d.query);
  const params = new URLSearchParams({ engine: 'google_images', q, api_key: apiKey, ijn: String(d.page - 1) });
  if (face) { params.set('imgar', 't'); params.set('tbs', 'itp:face'); } // tall + Google's "face" image type
  const json = await fetchJson<{ images_results?: SerpImageResult[]; error?: string; search_information?: { total_results?: number } }>('serpapi', `https://serpapi.com/search.json?${params}`, apiKey);
  if (json.error && !json.images_results) {
    const msg = redact(json.error, apiKey);
    console.error(`[search:serpapi] API error: ${msg}`);
    throw new ProviderError(/limit|quota|run out|plan|invalid api key/i.test(msg) ? 'quota' : 'empty', msg, 200);
  }
  const images = (json.images_results ?? []).slice(0, d.perPage).map((img, i): Img => ({
    id: `${pinterest ? 'pinterest' : 'serp'}-${d.page}-${i}`,
    // Some hosts (TikTok, Instagram, Facebook) refuse server-side image fetches; use Google's cached copy instead.
    url: (img.original && !BLOCKED_IMAGE_HOST.test(img.original) ? img.original : '') || img.thumbnail || img.original, thumbUrl: img.thumbnail || img.original,
    width: img.original_width ?? 800, height: img.original_height ?? 800,
    alt: img.title || d.query, source: pinterest ? 'pinterest' : 'google', photographer: img.source,
  }));
  return { images, totalCount: json.search_information?.total_results ?? images.length, hasMore: images.length >= d.perPage };
}

// ---- Serper.dev (Google Images, key in X-API-KEY header) ---------------------
interface SerperImage { title?: string; imageUrl: string; imageWidth?: number; imageHeight?: number; thumbnailUrl?: string; source?: string; domain?: string }
export async function serper(d: SearchInput, _face: boolean, personalKey?: string): Promise<ProviderResult> {
  const apiKey = personalKey ?? getSerperKey();
  if (!apiKey) throw new ProviderError('missing key', 'SERPER_API_KEY is not set');
  const pinterest = d.source === 'pinterest';
  const json = await fetchJson<{ images?: SerperImage[]; message?: string }>('serper', 'https://google.serper.dev/images', apiKey, {
    method: 'POST', headers: { 'X-API-KEY': apiKey, 'Content-Type': 'application/json' },
    body: JSON.stringify({ q: buildSerpQuery(d.source, d.query), num: Math.min(100, d.perPage), page: d.page }),
  });
  if (!json.images && json.message) throw new ProviderError(/credit|limit|quota|unauthor|invalid/i.test(json.message) ? 'quota' : 'empty', redact(json.message, apiKey), 200);
  const images = (json.images ?? []).slice(0, d.perPage).map((img, i): Img => ({
    id: `serper-${d.page}-${i}`,
    url: (img.imageUrl && !BLOCKED_IMAGE_HOST.test(img.imageUrl) ? img.imageUrl : '') || img.thumbnailUrl || img.imageUrl, thumbUrl: img.thumbnailUrl || img.imageUrl,
    width: img.imageWidth ?? 800, height: img.imageHeight ?? 800,
    alt: img.title || d.query, source: pinterest ? 'pinterest' : 'google', photographer: img.source ?? img.domain,
  }));
  return { images, totalCount: images.length, hasMore: images.length >= d.perPage };
}

// ---- elitebabes.com (no API: reads the public search page, images from cdn.elitebabes.com) ----
export async function elitebabes(d: SearchInput): Promise<ProviderResult> {
  const q = encodeURIComponent(d.query.trim());
  const pageUrl = d.page > 1 ? `https://www.elitebabes.com/page/${d.page}/?s=${q}` : `https://www.elitebabes.com/?s=${q}`;
  const resp = await fetch(pageUrl, { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36', Accept: 'text/html' }, signal: AbortSignal.timeout(10000) });
  if (!resp.ok) throw new ProviderError('network', `elitebabes HTTP ${resp.status}`, resp.status);
  const html = await resp.text();
  const bases = [...new Set([...html.matchAll(/https:\/\/cdn\.elitebabes\.com\/content\/\d+\/\d+_masonry_/g)].map((m) => m[0]))];
  const images = bases.slice(0, d.perPage).map((b, i): Img => ({ id: `eb-${d.page}-${i}-${b.slice(-20)}`, url: `${b}1200.jpg`, thumbUrl: `${b}400.jpg`, width: 800, height: 1200, alt: d.query, source: 'elitebabes', photographer: 'elitebabes.com' }));
  if (!images.length) throw new ProviderError('empty', 'elitebabes returned no images');
  return { images, totalCount: images.length, hasMore: bases.length >= 20 };
}

// ---- Pexels (key in Authorization header) --------------------------------------
interface PexelsPhoto { id: number; width: number; height: number; alt?: string; photographer?: string; src: { large2x?: string; large: string; medium: string; original: string } }
export async function pexels(d: SearchInput, face: boolean, personalKey?: string): Promise<ProviderResult> {
  const apiKey = personalKey ?? getPexelsKey();
  if (!apiKey) throw new ProviderError('missing key', 'PEXELS_API_KEY is not set');
  const params = new URLSearchParams({ query: d.query, page: String(d.page), per_page: String(d.perPage) });
  if (face) params.set('orientation', 'portrait');
  const json = await fetchJson<{ photos?: PexelsPhoto[]; total_results?: number; next_page?: string }>('pexels', `https://api.pexels.com/v1/search?${params}`, apiKey, { headers: { Authorization: apiKey } });
  const images = (json.photos ?? []).map((p): Img => ({ id: `px-${p.id}`, url: p.src.large2x || p.src.large || p.src.original, thumbUrl: p.src.medium, width: p.width, height: p.height, alt: p.alt || d.query, source: 'pexels', photographer: p.photographer }));
  return { images, totalCount: json.total_results ?? images.length, hasMore: !!json.next_page };
}

// ---- Unsplash (Client-ID access key) -------------------------------------------
interface UnsplashPhoto { id: string; width: number; height: number; alt_description?: string | null; description?: string | null; user?: { name?: string }; urls: { regular: string; small: string } }
export async function unsplash(d: SearchInput, face: boolean, personalKey?: string): Promise<ProviderResult> {
  const apiKey = personalKey ?? getUnsplashKey();
  if (!apiKey) throw new ProviderError('missing key', 'UNSPLASH_ACCESS_KEY is not set');
  const params = new URLSearchParams({ query: d.query, page: String(d.page), per_page: String(Math.min(30, d.perPage)), content_filter: 'high' });
  if (face) params.set('orientation', 'portrait');
  const json = await fetchJson<{ results?: UnsplashPhoto[]; total?: number; total_pages?: number }>('unsplash', `https://api.unsplash.com/search/photos?${params}`, apiKey, { headers: { Authorization: `Client-ID ${apiKey}`, 'Accept-Version': 'v1' } });
  const images = (json.results ?? []).map((p): Img => ({ id: `us-${p.id}`, url: p.urls.regular, thumbUrl: p.urls.small, width: p.width, height: p.height, alt: p.alt_description || p.description || d.query, source: 'unsplash', photographer: p.user?.name }));
  return { images, totalCount: json.total ?? images.length, hasMore: d.page < (json.total_pages ?? d.page) };
}

// ---- Openverse (no key) --------------------------------------------------------
interface OpenverseItem { id: string; url: string; thumbnail?: string; title?: string; width?: number; height?: number; creator?: string }
export async function openverse(d: SearchInput, face: boolean): Promise<ProviderResult> {
  const params = new URLSearchParams({ q: d.query, page: String(d.page), page_size: String(d.perPage), mature: 'false' });
  if (face) params.set('aspect_ratio', 'tall');
  const json = await fetchJson<{ results?: OpenverseItem[]; result_count?: number; page_count?: number }>('openverse', `https://api.openverse.org/v1/images/?${params}`);
  const images = (json.results ?? []).filter((r) => r.url).map((r): Img => ({
    id: `ov-${r.id}`, url: r.url, thumbUrl: r.thumbnail || r.url, width: r.width ?? 800, height: r.height ?? 800,
    alt: r.title || d.query, source: 'openverse', photographer: r.creator,
  }));
  return { images, totalCount: json.result_count ?? images.length, hasMore: d.page < (json.page_count ?? d.page) };
}

// ---- Wikimedia Commons (no key) ------------------------------------------------
interface WikiPage { pageid: number; title: string; imageinfo?: Array<{ url: string; thumburl?: string; width: number; height: number; mime: string; extmetadata?: { Artist?: { value: string } } }> }
export async function wikimedia(d: SearchInput): Promise<ProviderResult> {
  const params = new URLSearchParams({
    action: 'query', format: 'json', generator: 'search', gsrnamespace: '6',
    gsrsearch: `${d.query} filetype:bitmap`,
    gsrlimit: String(d.perPage), gsroffset: String((d.page - 1) * d.perPage),
    prop: 'imageinfo', iiprop: 'url|size|mime|extmetadata', iiurlwidth: '480',
  });
  const json = await fetchJson<{ query?: { pages?: Record<string, WikiPage & { index?: number }> } }>('wikimedia', `https://commons.wikimedia.org/w/api.php?${params}`);
  const pages = Object.values(json.query?.pages ?? {}).sort((a, b) => (a.index ?? 0) - (b.index ?? 0));
  const images = pages.flatMap((p): Img[] => {
    const ii = p.imageinfo?.[0];
    if (!ii || !/^image\/(jpeg|png|webp)$/.test(ii.mime)) return [];
    return [{
      id: `wm-${p.pageid}`, url: ii.url, thumbUrl: ii.thumburl || ii.url, width: ii.width, height: ii.height,
      alt: p.title.replace(/^File:/, '').replace(/\.[a-z]+$/i, ''), source: 'wikimedia',
      photographer: ii.extmetadata?.Artist?.value?.replace(/<[^>]+>/g, '').slice(0, 80),
    }];
  });
  return { images, totalCount: images.length, hasMore: images.length >= Math.min(d.perPage, 10) };
}

export interface ChainResponse {
  images: Img[];
  totalCount: number;
  hasMore: boolean;
  status: {
    provider: Provider | 'curated';
    fallbackReason?: FallbackReason;
    attempts: Array<{ provider: Provider; reason: FallbackReason; message: string }>;
    faceQuery: boolean;
    diagnostics: { serpapiKey: 'present' | 'missing'; query: string; provider: Provider | 'curated'; serpapiHttpStatus?: number };
  };
}

/** Owner's rule (replaces the old "query exactly as typed" rule): every search returns only
 *  photos of young-looking portraits, so "young portrait photo" is added unless already present. */
export const YOUNG_PORTRAIT_TERMS = ['young', 'portrait', 'photo'] as const;
export function youngPortraitQuery(query: string): string {
  const q = query.trim();
  const missing = YOUNG_PORTRAIT_TERMS.filter((t) => !new RegExp(`\\b${t}s?\\b`, 'i').test(q));
  return missing.length ? `${q} ${missing.join(' ')}`.trim() : q;
}

/** Best does not infer or add an age restriction; explicit user wording is kept. */
export function portraitQuery(query: string): string {
  const q = query.trim();
  const missing = ['portrait', 'photo'].filter((t) => !new RegExp(`\\b${t}s?\\b`, 'i').test(q));
  return missing.length ? `${q} ${missing.join(' ')}`.trim() : q;
}

export async function searchChain(rawData: SearchInput, keysOrSerp?: string | SearchKeys): Promise<ChainResponse> {
  const keys: SearchKeys = typeof keysOrSerp === 'string' ? { serpapi: keysOrSerp } : (keysOrSerp ?? {});
  const personalKey = keys.serpapi;
  const data = rawData.source === 'elitebabes' ? { ...rawData, query: rawData.query.trim() } : { ...rawData, query: rawData.portraitMode === 'all-ages' ? portraitQuery(rawData.query) : youngPortraitQuery(rawData.query) };
  const face = true;
  const keyPresent = !!(personalKey ?? getSerpApiKey());
  const chain: Array<[Provider, (d: SearchInput, f: boolean) => Promise<ProviderResult>]> = [
    // Serper is the default (owner's choice); SerpAPI is the first fallback.
    ['serper', (d, f) => serper(d, f, keys.serper)],
    ['serpapi', (d, f) => serpapi(d, f, personalKey)],
    ['pexels', (d, f) => pexels(d, f, keys.pexels)],
    ['unsplash', (d, f) => unsplash(d, f, keys.unsplash)],
    ['openverse', openverse], ['wikimedia', (d) => wikimedia(d)],
  ];
  const optional = new Set<Provider>(['serper', 'pexels', 'unsplash']);
  // An explicit service selection is tried first, followed by the existing fallbacks.
  if (data.source === 'elitebabes') chain.unshift(['elitebabes', (d) => elitebabes(d)]);
  const preferred = chain.findIndex(([provider]) => provider === data.source);
  if (preferred > 0) chain.unshift(...chain.splice(preferred, 1));
  const attempts: ChainResponse['status']['attempts'] = [];
  let serpapiHttpStatus: number | undefined;
  const diag = (provider: Provider | 'curated') => ({ serpapiKey: keyPresent ? ('present' as const) : ('missing' as const), query: buildSerpQuery(data.source, data.query), provider, serpapiHttpStatus });
  for (const [provider, run] of chain) {
    try {
      const r = await run(data, face);
      if (!r.images.length) throw new ProviderError('empty', `${provider} returned no images`);
      const images = face ? portraitBias(r.images) : r.images;
      return { images, totalCount: r.totalCount, hasMore: r.hasMore, status: { provider, fallbackReason: attempts[0]?.reason, attempts, faceQuery: face, diagnostics: diag(provider) } };
    } catch (e) {
      const pe = e instanceof ProviderError ? e : new ProviderError('network', redact((e as Error).message, (provider === 'serpapi' ? personalKey ?? getSerpApiKey() : provider === 'serper' ? keys.serper ?? getSerperKey() : provider === 'pexels' ? keys.pexels ?? getPexelsKey() : provider === 'unsplash' ? keys.unsplash ?? getUnsplashKey() : undefined)));
      if (provider === 'serpapi' && pe.httpStatus) serpapiHttpStatus = pe.httpStatus;
      if (optional.has(provider) && pe.reason === 'missing key') continue; // optional providers without a key are skipped quietly
      if (pe.reason !== 'missing key') console.error(`[search] ${provider} failed (${pe.reason}): ${pe.message}`);
      attempts.push({ provider, reason: pe.reason, message: pe.message });
    }
  }
  // Every live provider failed: the client shows the curated pool and says so.
  return { images: [], totalCount: 0, hasMore: false, status: { provider: 'curated', fallbackReason: attempts[0]?.reason ?? 'network', attempts, faceQuery: face, diagnostics: diag('curated') } };
}
