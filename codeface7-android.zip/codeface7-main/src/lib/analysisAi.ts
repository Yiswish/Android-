import type { AestheticScores, AnalysisResult } from './types';

/** Manual checking is available regardless of the photo's rank, without remeasuring it. */
export async function checkAnalysisAi(result: AnalysisResult, check: (scores: AestheticScores, url: string) => Promise<AestheticScores>): Promise<AnalysisResult> {
  if (result.scores.aiLook) return result;
  const scores = await check(result.scores, result.imageUrl);
  if (!scores.aiLook) return { ...result, scores };
  const { aiLookError: _error, ...cleanScores } = scores;
  return { ...result, scores: cleanScores, warnings: result.warnings.filter((warning) => !warning.startsWith('Measurement-only score')) };
}