import type { SearchResultImage } from './types';

/** Repeated name clicks must not accumulate the young-portrait suffix. */
export function youngNameQuery(name: string): string {
  return `${name.trim().replace(/(?:\s+young\s+portraits?\s*(?:photos?)?)+$/i, '').trim()} young portraits`;
}

/** Search context is a label, not an identification inferred from pixels. */
export function searchPhotoLabel(image: SearchResultImage, query: string): string | undefined {
  if (image.source === 'upload' || image.source === 'curated') return undefined;
  return image.searchLabel?.trim() || query.trim() || undefined;
}