// ============================================================================
// RAW ERROR — the unscaled measurement behind every score.
// ----------------------------------------------------------------------------
// A score such as "Symmetry 92" hides how far the face really is from the ideal.
// These helpers expose that distance in plain units so you can judge it
// yourself: "1.4% of eye distance" (IPD = inter-pupillary distance) for
// landmark offsets, "3.2% of ideal" for proportions. No tuning constants (σ,
// tolerances, power means) are applied here: this is the measurement itself.
// ============================================================================
import type { FaceGeometryReport, RatioMeasurement, HarmonyGroupId, MouthJawTerm } from './faceGeometry';
import { SYMMETRY_WEIGHTS } from './faceGeometry';
import type { MetricKey } from './types';

export type ErrorUnit = 'ideal' | 'absolute';

export interface RawError {
  /** Short text shown beside the score, e.g. "1.4% of eye distance". */
  short: string;
  /** Longer explanation for a tooltip / the breakdown. */
  detail: string;
  /** Numeric value behind `short` (percent), when one exists. */
  value?: number;
}

const f = (n: number, d = 1) => (Number.isFinite(n) ? n.toFixed(d) : '—');

/** Landmark offset (already in IPD units) → "1.4% of eye distance". */
export const ipdPercent = (ipdUnits: number, digits = 1) => `${f(ipdUnits * 100, digits)}% of eye distance`;

/** Signed error of one proportion, in the measurement's own units. */
export const signedError = (r: Pick<RatioMeasurement, 'measured' | 'ideal'>) => r.measured - r.ideal;

/** Error of one proportion as text: "+0.082 (5.3% of ideal)" or "+0.082". */
export function ratioErrorText(r: RatioMeasurement, unit: ErrorUnit = 'ideal'): string {
  const e = signedError(r);
  const sign = e >= 0 ? '+' : '−';
  if (unit === 'absolute') return `${sign}${Math.abs(e).toFixed(3)}`;
  return `${sign}${f(r.deviation * 100)}% of ideal`;
}

/** Mean |m − ideal| / ideal of the ratios in a group, in percent. */
export function meanRatioDeviation(g: FaceGeometryReport, groups: RatioMeasurement['group'][]): number {
  const rs = g.ratios.filter((r) => groups.includes(r.group));
  if (!rs.length) return NaN;
  return (rs.reduce((s, r) => s + r.deviation, 0) / rs.length) * 100;
}

export function worstRatio(rs: RatioMeasurement[]): RatioMeasurement | undefined {
  return rs.reduce<RatioMeasurement | undefined>((w, r) => (!w || r.deviation > w.deviation ? r : w), undefined);
}

/** Weighted mean of the three symmetry measurements, IPD units. */
export function symmetryErrorIpd(g: FaceGeometryReport): number {
  const w = SYMMETRY_WEIGHTS;
  return w.pair3D * g.pairAsymmetry + w.frontal2D * g.frontalAsymmetry + w.mesh * g.meshMirrorDistance;
}

export function mouthJawWorst(terms: MouthJawTerm[]): MouthJawTerm | undefined {
  return terms.reduce<MouthJawTerm | undefined>((w, t) => (!w || t.measured > w.measured ? t : w), undefined);
}

/** Raw error for each metric bar that has a geometric measurement behind it. */
export function metricRawErrors(g: FaceGeometryReport | undefined): Partial<Record<MetricKey, RawError>> {
  if (!g) return {};
  const out: Partial<Record<MetricKey, RawError>> = {};

  const sym = symmetryErrorIpd(g);
  out.symmetry = {
    short: ipdPercent(sym),
    value: sym * 100,
    detail: `Mean left/right mismatch after pose removal: 3D ${ipdPercent(g.pairAsymmetry, 2)}, 2D ${ipdPercent(g.frontalAsymmetry, 2)}, mesh ${ipdPercent(g.meshMirrorDistance, 2)} (weighted ${SYMMETRY_WEIGHTS.pair3D}/${SYMMETRY_WEIGHTS.frontal2D}/${SYMMETRY_WEIGHTS.mesh}).`,
  };

  const golden = g.ratios.filter((r) => r.group === 'golden');
  if (golden.length) {
    const d = meanRatioDeviation(g, ['golden']);
    const w = worstRatio(golden)!;
    out.proportions = { short: `${f(d)}% off ideal`, value: d, detail: `Mean |measured − ideal| / ideal over ${golden.length} golden-ratio measurements. Largest: ${w.label} ${ratioErrorText(w)}.` };
  }

  const structural = g.ratios.filter((r) => r.group === 'structure' || r.group === 'alignment');
  if (structural.length) {
    const d = meanRatioDeviation(g, ['structure', 'alignment']);
    const w = worstRatio(structural)!;
    out.structure = { short: `${f(d)}% off ideal`, value: d, detail: `Mean |measured − ideal| / ideal over ${structural.length} structure/alignment measurements. Largest: ${w.label} ${ratioErrorText(w)}.` };
  }

  if (g.skin) {
    out.skin = {
      short: `detail ratio ${f(g.skin.ratio, 3)}`,
      value: g.skin.ratio,
      detail: `Cheek micro-detail ÷ eye micro-detail = ${f(g.skin.ratio, 3)} (luminance only; lower = smoother). Confidence ${f(g.skin.confidence * 100, 0)}%.`,
    };
  }
  return out;
}

/** Raw error for a harmony group row. */
export function groupRawError(g: FaceGeometryReport, id: HarmonyGroupId): RawError | undefined {
  switch (id) {
    case 'symmetry': {
      const v = symmetryErrorIpd(g);
      return { short: ipdPercent(v), value: v * 100, detail: 'Weighted mean left/right mismatch' };
    }
    case 'golden':
    case 'structure':
    case 'alignment': {
      const d = meanRatioDeviation(g, [id]);
      return Number.isFinite(d) ? { short: `${f(d)}% of ideal`, value: d, detail: 'Mean relative deviation' } : undefined;
    }
    case 'mouthJaw': {
      const w = mouthJawWorst(g.mouthJaw.terms);
      return w ? { short: `worst ${ipdPercent(w.measured)}`, value: w.measured * 100, detail: w.label } : undefined;
    }
    case 'skin':
      return g.skin ? { short: `ratio ${f(g.skin.ratio, 3)}`, value: g.skin.ratio, detail: 'Cheek ÷ eye micro-detail' } : undefined;
    case 'expression':
      return g.expression ? { short: `load ${f(g.expressionLoad, 2)}`, value: g.expressionLoad, detail: 'Expression load (informational)' } : undefined;
    default:
      return undefined;
  }
}

/** One-line summary shown under the overall score. */
export function overallRawError(g: FaceGeometryReport | undefined): string | undefined {
  if (!g) return undefined;
  return `raw: asymmetry ${ipdPercent(symmetryErrorIpd(g))} · proportions ${f(g.proportionDeviation)}% off ideal`;
}

// ---- Exports ---------------------------------------------------------------
export interface RawMeasurementRow {
  section: string;
  id: string;
  label: string;
  measured: number;
  ideal?: number;
  signedError?: number;
  errorPercentOfIdeal?: number;
  errorPercentOfIpd?: number;
  z?: number;
  score: number;
}

export function rawMeasurementRows(g: FaceGeometryReport): RawMeasurementRow[] {
  const rows: RawMeasurementRow[] = [];
  rows.push({ section: 'symmetry', id: 'pair3D', label: '3D pair asymmetry', measured: g.pairAsymmetry, errorPercentOfIpd: g.pairAsymmetry * 100, score: g.pairSymmetry });
  rows.push({ section: 'symmetry', id: 'frontal2D', label: '2D frontal asymmetry', measured: g.frontalAsymmetry, errorPercentOfIpd: g.frontalAsymmetry * 100, score: g.frontalSymmetry });
  rows.push({ section: 'symmetry', id: 'mesh', label: 'Mesh mirror distance', measured: g.meshMirrorDistance, errorPercentOfIpd: g.meshMirrorDistance * 100, score: g.meshSymmetry });
  for (const r of g.ratios) {
    rows.push({ section: r.group, id: r.id, label: r.label, measured: r.measured, ideal: r.ideal, signedError: signedError(r), errorPercentOfIdeal: r.deviation * 100, z: r.z, score: r.score });
  }
  for (const t of g.mouthJaw.terms) {
    rows.push({ section: 'mouthJaw', id: t.id, label: t.label, measured: t.measured, errorPercentOfIpd: t.measured * 100, z: t.z, score: t.score });
  }
  return rows;
}

export function rowsToCsv(rows: RawMeasurementRow[]): string {
  const head = ['section', 'id', 'label', 'measured', 'ideal', 'signed_error', 'error_pct_of_ideal', 'error_pct_of_eye_distance', 'z', 'score'];
  const esc = (v: unknown) => {
    const s = v === undefined || v === null ? '' : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const body = rows.map((r) => [r.section, r.id, r.label, r.measured, r.ideal, r.signedError, r.errorPercentOfIdeal, r.errorPercentOfIpd, r.z, r.score].map(esc).join(','));
  return [head.join(','), ...body].join('\n');
}
