// ============================================================================
// PURE LANDMARK GEOMETRY — MediaPipe Face Mesh (468 mesh points + 10 iris)
// ----------------------------------------------------------------------------
// Every number produced here is a deterministic function of the landmark
// coordinates. No randomness, no hidden bonuses. Each score is
//     score = 100 × max(0, 1 − deviation / tolerance)
// where `deviation` is the relative distance from a published ideal and
// `tolerance` is the deviation at which the score reaches 0. Both are listed
// alongside every result so the UI can show the exact arithmetic.
// ============================================================================

import type { SkinReport } from './skin';

export interface Vec3 { x: number; y: number; z: number }

/** Mesh points on the facial midline (forehead → chin). */
export const MIDLINE = [10, 151, 9, 8, 168, 6, 197, 195, 5, 4, 1, 19, 94, 2, 164, 0, 11, 12, 13, 14, 15, 16, 17, 18, 200, 199, 175, 152];

/** Bilateral pairs [subject-right, subject-left] from the Face Mesh topology. */
export const BILATERAL_PAIRS: Array<[number, number]> = [
  // eyes
  [33, 263], [133, 362], [159, 386], [145, 374], [160, 387], [158, 385], [153, 380], [144, 373],
  [163, 390], [7, 249], [246, 466], [161, 388], [157, 384], [173, 398], [155, 382], [154, 381],
  // brows
  [70, 300], [63, 293], [105, 334], [66, 296], [107, 336], [46, 276], [53, 283], [52, 282], [65, 295], [55, 285],
  // nose
  [48, 278], [64, 294], [98, 327], [129, 358], [102, 331], [219, 439], [115, 344], [49, 279], [131, 360], [209, 429],
  // mouth
  [61, 291], [40, 270], [37, 267], [39, 269], [185, 409], [146, 375], [91, 321], [84, 314], [78, 308],
  [95, 324], [88, 318], [178, 402], [87, 317], [80, 310], [81, 311], [82, 312], [191, 415], [57, 287],
  // cheeks / zygoma
  [116, 345], [123, 352], [50, 280], [205, 425], [187, 411], [147, 376], [117, 346], [118, 347], [119, 348],
  [101, 330], [36, 266], [206, 426], [207, 427], [216, 436],
  // face oval / jaw
  [234, 454], [127, 356], [93, 323], [132, 361], [58, 288], [172, 397], [136, 365], [150, 379], [149, 378],
  [176, 400], [148, 377], [162, 389], [21, 251], [54, 284], [103, 332], [67, 297], [109, 338],
  // temples / forehead
  [71, 301], [68, 298], [104, 333], [69, 299], [108, 337], [139, 368], [156, 383], [124, 353],
];

export const IRIS_RIGHT = 468; // subject-right iris centre
export const IRIS_LEFT = 473;
export const PHI = (1 + Math.sqrt(5)) / 2;

const sub = (a: Vec3, b: Vec3): Vec3 => ({ x: a.x - b.x, y: a.y - b.y, z: a.z - b.z });
const dot = (a: Vec3, b: Vec3) => a.x * b.x + a.y * b.y + a.z * b.z;
const cross = (a: Vec3, b: Vec3): Vec3 => ({ x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x });
const len = (a: Vec3) => Math.sqrt(dot(a, a));
const scale = (a: Vec3, s: number): Vec3 => ({ x: a.x * s, y: a.y * s, z: a.z * s });
const norm = (a: Vec3) => scale(a, 1 / (len(a) || 1));
const mean = (pts: Vec3[]): Vec3 => scale(pts.reduce((s, p) => ({ x: s.x + p.x, y: s.y + p.y, z: s.z + p.z }), { x: 0, y: 0, z: 0 }), 1 / pts.length);
const dist2D = (a: Vec3, b: Vec3) => Math.hypot(a.x - b.x, a.y - b.y);

/** Linear: 100 × max(0, 1 − deviation / tolerance). Used for image (pixel) metrics. */
export const lineScore = (deviation: number, tolerance: number) =>
  Math.max(0, Math.min(100, 100 * (1 - deviation / tolerance)));

/**
 * Quadratic: 100 × max(0, 1 − (deviation / tolerance)²). Used for every
 * landmark score. Small deviations (landmark noise, normal human variation)
 * cost little — ¼ of tolerance costs 6 pts, ½ costs 25 — while deviations
 * approaching the tolerance fall steeply to 0.
 */
export const curveScore = (deviation: number, tolerance: number) =>
  Math.max(0, Math.min(100, 100 * (1 - (deviation / tolerance) ** 2)));

// ---- 3×3 rotation helpers ---------------------------------------------------
type Mat3 = [number, number, number, number, number, number, number, number, number]; // row-major
const apply = (R: Mat3, p: Vec3): Vec3 => ({
  x: R[0] * p.x + R[1] * p.y + R[2] * p.z,
  y: R[3] * p.x + R[4] * p.y + R[5] * p.z,
  z: R[6] * p.x + R[7] * p.y + R[8] * p.z,
});

/** Largest eigenvector of a symmetric 4×4 matrix (cyclic Jacobi). */
function maxEigenvector4(A: number[][]): number[] {
  const a = A.map((r) => [...r]);
  const V = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]];
  for (let sweep = 0; sweep < 50; sweep++) {
    let off = 0;
    for (let p = 0; p < 4; p++) for (let q = p + 1; q < 4; q++) off += a[p][q] ** 2;
    if (off < 1e-20) break;
    for (let p = 0; p < 4; p++) for (let q = p + 1; q < 4; q++) {
      if (Math.abs(a[p][q]) < 1e-30) continue;
      const theta = (a[q][q] - a[p][p]) / (2 * a[p][q]);
      const t = Math.sign(theta || 1) / (Math.abs(theta) + Math.sqrt(theta * theta + 1));
      const c = 1 / Math.sqrt(t * t + 1), s = t * c;
      for (let k = 0; k < 4; k++) {
        const akp = a[k][p], akq = a[k][q];
        a[k][p] = c * akp - s * akq; a[k][q] = s * akp + c * akq;
      }
      for (let k = 0; k < 4; k++) {
        const apk = a[p][k], aqk = a[q][k];
        a[p][k] = c * apk - s * aqk; a[q][k] = s * apk + c * aqk;
      }
      for (let k = 0; k < 4; k++) {
        const vkp = V[k][p], vkq = V[k][q];
        V[k][p] = c * vkp - s * vkq; V[k][q] = s * vkp + c * vkq;
      }
    }
  }
  let best = 0;
  for (let i = 1; i < 4; i++) if (a[i][i] > a[best][best]) best = i;
  return V.map((r) => r[best]);
}

/**
 * Optimal rigid rotation + translation mapping `src` onto `dst` (Horn 1987,
 * quaternion closed form). Minimises Σ|dst_i − (R·src_i + t)|².
 */
export function rigidAlign(dst: Vec3[], src: Vec3[]): { R: Mat3; t: Vec3 } {
  const cd = mean(dst), cs = mean(src);
  let Sxx = 0, Sxy = 0, Sxz = 0, Syx = 0, Syy = 0, Syz = 0, Szx = 0, Szy = 0, Szz = 0;
  for (let i = 0; i < dst.length; i++) {
    const a = sub(src[i], cs), b = sub(dst[i], cd);
    Sxx += a.x * b.x; Sxy += a.x * b.y; Sxz += a.x * b.z;
    Syx += a.y * b.x; Syy += a.y * b.y; Syz += a.y * b.z;
    Szx += a.z * b.x; Szy += a.z * b.y; Szz += a.z * b.z;
  }
  const N = [
    [Sxx + Syy + Szz, Syz - Szy, Szx - Sxz, Sxy - Syx],
    [Syz - Szy, Sxx - Syy - Szz, Sxy + Syx, Szx + Sxz],
    [Szx - Sxz, Sxy + Syx, -Sxx + Syy - Szz, Syz + Szy],
    [Sxy - Syx, Szx + Sxz, Syz + Szy, -Sxx - Syy + Szz],
  ];
  const [w, x, y, z] = maxEigenvector4(N);
  const R: Mat3 = [
    w * w + x * x - y * y - z * z, 2 * (x * y - w * z), 2 * (x * z + w * y),
    2 * (x * y + w * z), w * w - x * x + y * y - z * z, 2 * (y * z - w * x),
    2 * (x * z - w * y), 2 * (y * z + w * x), w * w - x * x - y * y + z * z,
  ];
  return { R, t: sub(cd, apply(R, cs)) };
}

/**
 * Pose-invariant mirror transform. The face is reflected (x → −x), its
 * left/right labels are swapped, and the reflected copy is rigidly
 * Procrustes-aligned back onto the original. Because the alignment absorbs
 * any 3D rotation, yaw / pitch / roll of the head cannot create asymmetry;
 * only genuine shape differences between the two halves remain.
 */
export function mirrorProcrustes(P: Vec3[]) {
  const partner = new Map<number, number>();
  for (const [r, l] of BILATERAL_PAIRS) { partner.set(r, l); partner.set(l, r); }
  for (const m of MIDLINE) partner.set(m, m);
  const idx = [...partner.keys()];
  const reflect = (p: Vec3): Vec3 => ({ x: -p.x, y: p.y, z: p.z });
  const dst = idx.map((i) => P[i]);
  const src = idx.map((i) => reflect(P[partner.get(i)!]));
  const { R, t } = rigidAlign(dst, src);
  /** Mirror image of any point under the fitted symmetry plane. */
  const mirrorPoint = (p: Vec3): Vec3 => { const q = apply(R, reflect(p)); return { x: q.x + t.x, y: q.y + t.y, z: q.z + t.z }; };
  /** Residual of point i against its mirrored partner. */
  const residual = (i: number) => len(sub(P[i], mirrorPoint(P[partner.get(i)!])));
  return { mirrorPoint, residual, R, t };
}

/** Euler angles (deg) from MediaPipe's column-major 4×4 facial transformation matrix. */
export function poseFromMatrix(m: ArrayLike<number>) {
  const r = (row: number, col: number) => m[col * 4 + row];
  const toDeg = 180 / Math.PI;
  return {
    pitch: Math.atan2(r(2, 1), r(2, 2)) * toDeg,
    yaw: Math.asin(Math.max(-1, Math.min(1, -r(2, 0)))) * toDeg,
    roll: Math.atan2(r(1, 0), r(0, 0)) * toDeg,
  };
}

export interface RatioMeasurement {
  id: string;
  label: string;
  group: 'golden' | 'structure' | 'alignment';
  formula: string;
  measured: number;
  ideal: number;
  /** |measured − ideal| / ideal */
  deviation: number;
  /** σ: natural human variation, in the units of `measured` */
  tolerance: number;
  /** |measured − ideal| / σ */
  z: number;
  score: number;
  reference: string;
}

export type HarmonyGroupId = 'symmetry' | 'structure' | 'golden' | 'alignment' | 'expression' | 'mouthJaw' | 'skin';
export interface HarmonyGroup { id: HarmonyGroupId; label: string; score: number; weight: number }

export interface ExpressionReport {
  /** Smooth aggregate of the strongest blendshape activations (0 = neutral, ~1 = extreme) */
  intensity: number;
  /** RMS left/right blendshape difference */
  asymmetry: number;
  intensityScore: number;
  asymmetryScore: number;
  score: number;
  /** Activation of each blendshape feature used (L/R averaged), for the UI / logs */
  activations: Record<string, number>;
}

export interface MouthJawTerm { id: string; label: string; measured: number; sigma: number; z: number; score: number; weight: number }
/** `mouthOpenness` is informational only: it is NOT a term of the mouth/jaw score (expression is not a flaw). */
export interface MouthJawReport { score: number; mouthOpenness: number; terms: MouthJawTerm[] }

export interface PairAsymmetry { right: number; left: number; region: string; asymmetry: number }

export interface FaceGeometryReport {
  landmarkCount: number;
  meshPointsUsed: number;
  pairsUsed: number;
  /** Head pose recovered from the 3D mesh, degrees */
  yaw: number; pitch: number; roll: number;
  /** Mean pair asymmetry in units of inter-pupillary distance */
  pairAsymmetry: number;
  /** Mean pair asymmetry on the pose-normalised 2D face, IPD units */
  frontalAsymmetry: number;
  frontalSymmetry: number;
  /** Pose/expression measurement confidence, 0–1 (smooth, no hard gate) */
  confidence: number;
  /** Mean mirror (Chamfer) distance of all 468 points, IPD units */
  meshMirrorDistance: number;
  pairSymmetry: number;
  meshSymmetry: number;
  symmetryPercent: number;
  structuralBalanceIndex: number;
  goldenRatioIndex: number;
  alignmentIndex: number;
  /** Mean relative deviation across every proportion, in percent */
  proportionDeviation: number;
  facialHarmony: number;
  /** v2: power mean of the groups before the broken-group penalty (absent on old saves). */
  harmonyMean?: number;
  /** v2: smooth broken-group multiplier (1 = no group below BROKEN_GROUP_KNEE). */
  brokenPenalty?: number;
  /** Nominal harmony weights (sum = 1). */
  harmonyWeights: Record<HarmonyGroupId, number>;
  /** Every group that entered the harmony, with its score and its effective (renormalised) weight. */
  groups: HarmonyGroup[];
  /** Blendshape-based expression report: scored in the harmony (HARMONY_WEIGHTS.expression) (undefined when the model returned no blendshapes). */
  expression?: ExpressionReport;
  /** 0–1 load that widens σ of the ratios expression physically moves (see expressionLoad). */
  expressionLoad: number;
  /** Skin & age report (undefined when pixels were unavailable or the face was too small); then the group drops out. */
  skin?: SkinReport;
  /** Mouth + jaw landmark group score (0–100) and its terms. */
  mouthJawScore: number;
  /** 'angled' when |yaw| > ANGLED_YAW_DEG: bilateral groups are excluded from the harmony. */
  viewMode?: 'frontal' | 'angled';
  mouthJaw: MouthJawReport;
  ratios: RatioMeasurement[];
  worstPairs: PairAsymmetry[];
  /** Frontalised 2D mesh (IPD-normalised) for visualisation */
  frontalMesh: Array<[number, number]>;
  reliable: boolean;
  reliabilityNote?: string;
}

// ---- Smooth scoring helpers -------------------------------------------------
/**
 * Soft score: 100 / (1 + (deviation / half)²). Kept for pixel-level helpers.
 */
export const softScore = (deviation: number, half: number) => {
  if (!Number.isFinite(deviation) || !(half > 0)) return 0;
  return 100 / (1 + (Math.abs(deviation) / half) ** 2);
};

/**
 * Non-linear deviation curve used for EVERY landmark score.
 *   z = |measured − ideal| / σ        (σ = normal human variation)
 *   score = 100 / (1 + (z / 2)⁴)
 * z ≤ 1 (ordinary variation) costs ≤ 6 pts, z = 2 → 50, z = 3 → 16, z = 4 → 6.
 * Tiny natural differences are almost free; severe structural flaws fall hard.
 */
// Ratio curve kept at 2: tightening it broke the ±15° head-turn stability test (owner wanted stricter scoring).
export const DEVIATION_HALF_Z = 2;
export const deviationScore = (z: number) => {
  if (!Number.isFinite(z)) return 0;
  return 100 / (1 + (Math.abs(z) / DEVIATION_HALF_Z) ** 4);
};

/**
 * Symmetry σ (IPD units). RE-CALIBRATED on the real landmarks in public/_verify.
 * Measured raw mean asymmetry of undistorted, well-regarded portraits is 0.75–2.9 %
 * of eye distance (3D pair), 0.7–2.6 % (2D) and 1.3–4.8 % (mesh). The previous σ
 * (0.8 / 0.75 / 1.3 %) put z = 2 (score 50) at only 1.6 % — below what ordinary faces
 * measure — so typical faces scored 10–40. Now z = 2 sits at 3.5 / 3.2 / 6 %: ordinary
 * faces land roughly 60–95, while the synthetic "wave" / "bulge" distortions
 * (4–9 % raw) still fall to single digits.
 * KNOWN LIMIT: the raw error still grows a little with head yaw (landmark depth is
 * noisy), so a turned head can read slightly more asymmetric than it is. The raw
 * error shown beside the score lets you judge that yourself.
 * HONESTY NOTE: because the mesh regularises every face, mesh-based symmetry is
 * a LOWER BOUND on real asymmetry. Re-run src/test/verifyImages.test.ts after changing them.
 */
export const SYMMETRY_SIGMA_PAIR = 0.0175;
export const SYMMETRY_SIGMA_2D = 0.016;
export const SYMMETRY_SIGMA_MESH = 0.03;
/** Back-compat aliases (UI text). */
export const SYMMETRY_HALF_PAIR = SYMMETRY_SIGMA_PAIR;
export const SYMMETRY_HALF_2D = SYMMETRY_SIGMA_2D;
export const SYMMETRY_HALF_MESH = SYMMETRY_SIGMA_MESH;
export const SYMMETRY_TOLERANCE_PAIR = SYMMETRY_SIGMA_PAIR;
export const SYMMETRY_TOLERANCE_MESH = SYMMETRY_SIGMA_MESH;
export const SYMMETRY_WEIGHTS = { pair3D: 0.4, frontal2D: 0.2, mesh: 0.4 };
/**
 * Proportion σ multipliers. UNCALIBRATED hand-set guesses: the earlier ×0.75 golden σ
 * rewarded the population-average face and punished long / narrow / wide-set faces.
 * Alignment and symmetry stay tight. Re-tune on real data (README → Calibration).
 */
export const GOLDEN_SIGMA_SCALE = 0.95;
export const STRUCTURE_SIGMA_SCALE = 1.25;
export const ALIGNMENT_SIGMA_SCALE = 1;
/** Ratios whose landmarks an expression physically moves: their σ widens with expressionLoad. */
export const EXPRESSION_SENSITIVE_RATIOS = ['mouth-nose', 'lower-face-split', 'thirds', 'face-length', 'fwhr', 'eye-aspect'];
/** σ is multiplied by (1 + EXPRESSION_SIGMA_GAIN·load). GUESS. Kept small: an extreme expression must not excuse the ratios it distorts (was 1.5). */
export const EXPRESSION_SIGMA_GAIN = 0.25;
/** expressionLoad = clamp(0.8·smile + 1.0·jawOpen + 0.5·mouthStretch + 0.3·cheekSquint, 0, 1) — blendshape activations 0–1. GUESS weights. */
export const EXPRESSION_LOAD_WEIGHTS = { smile: 0.8, jawOpen: 1.0, mouthStretch: 0.5, cheekSquint: 0.3 };
export function expressionLoad(bs?: Record<string, number>): number {
  if (!bs) return 0;
  const g = (k: string) => { const v = bs[k]; return Number.isFinite(v) ? Math.max(0, v) : 0; };
  const avg = (a: string, b: string) => (g(a) + g(b)) / 2;
  const w = EXPRESSION_LOAD_WEIGHTS;
  const load = w.smile * avg('mouthSmileLeft', 'mouthSmileRight') + w.jawOpen * g('jawOpen') + w.mouthStretch * avg('mouthStretchLeft', 'mouthStretchRight') + w.cheekSquint * avg('cheekSquintLeft', 'cheekSquintRight');
  return Math.max(0, Math.min(1, load));
}

/**
 * Harmony weights (sum = 1). HAND-SET, UNCALIBRATED.
 *  • skin carries the most because it is the only group that can see age,
 *    wrinkles and rough skin; the mesh template saturates symmetry for almost
 *    every detected face.
 *  • expression now counts (0.12): neutral and gentle smiles cost ~nothing, but an extreme
 *    expression (wide-open mouth, grimace) pulls the score down, as human raters do.
 *  • If pixels are unavailable the skin group drops out and the rest renormalise.
 */
// v2: expression 0.20 → 0.14 (a mild smile is not a flaw); the share went to structure / golden / symmetry.
export const HARMONY_WEIGHTS: Record<HarmonyGroupId, number> = {
  // Expression is permanently excluded (owner's rule). Remaining shares renormalise.
  symmetry: 0.14 / 0.86, structure: 0.18 / 0.86, golden: 0.12 / 0.86, alignment: 0.08 / 0.86, mouthJaw: 0.10 / 0.86, skin: 0.24 / 0.86, expression: 0,
};
/** Within a group (e.g. several golden ratios): strict, so large deviations in one ratio are not averaged away. */
export const GROUP_POWER = -2;
/**
 * Harmony is a weighted power mean. v2 (scoring overhaul): p = −2 instead of −6.
 * At −6 a single ordinary weak group (e.g. structure 50 from landmark noise) dragged
 * normal attractive faces into the 20s–30s. At −2 a moderately weak group costs a few
 * points; a genuinely BROKEN group (below BROKEN_GROUP_KNEE) is handled separately by
 * `brokenGroupPenalty`, so distortions still cannot be averaged away. GUESS.
 */
export const HARMONY_POWER = -2;
/** Groups below this score count as "broken" and add a smooth extra penalty. GUESS. */
export const BROKEN_GROUP_KNEE = 45;
/** Maximum share of the face score a fully broken group (score → 0) removes. GUESS. */
export const BROKEN_GROUP_STRENGTH = 0.6;
/**
 * Smooth multiplier in (1 − BROKEN_GROUP_STRENGTH, 1]: 1 while every group is ≥ the knee,
 * then falls with the weakest group's shortfall (weighted by that group's share).
 * Why: keeps extreme / distorted faces low without the p = −6 collapse of normal faces.
 */
export function brokenGroupPenalty(groups: Array<{ score: number; weight: number }>): number {
  let worst = 0;
  for (const g of groups) {
    const short = Math.max(0, BROKEN_GROUP_KNEE - g.score) / BROKEN_GROUP_KNEE;
    worst = Math.max(worst, short ** 1.2 * Math.min(1, 0.4 + 4 * g.weight));
  }
  return 1 - BROKEN_GROUP_STRENGTH * worst;
}
/** Mouth/jaw terms: mild bottleneck (v2: −2 → −1, GUESS) so one noisy term cannot dominate. */
export const MOUTH_JAW_POWER = -1;
export function weightedPowerMean(parts: Array<[number, number]>, p = GROUP_POWER) {
  const wSum = parts.reduce((s, [, w]) => s + w, 0) || 1;
  const v = (x: number) => Math.max(1, Math.min(100, Number.isFinite(x) ? x : 1));
  return (parts.reduce((s, [x, w]) => s + w * v(x) ** p, 0) / wSum) ** (1 / p);
}

// ---- Expression (MediaPipe blendshapes) -------------------------------------
/** Per-feature weight of a blendshape activation in the expression intensity. */
export const EXPRESSION_FEATURES: Array<{ id: string; keys: string[]; weight: number }> = [
  { id: 'jawOpen', keys: ['jawOpen'], weight: 1.0 },
  { id: 'mouthStretch', keys: ['mouthStretchLeft', 'mouthStretchRight'], weight: 0.8 },
  { id: 'mouthFunnel', keys: ['mouthFunnel'], weight: 1.0 },
  { id: 'mouthPucker', keys: ['mouthPucker'], weight: 0.8 },
  { id: 'eyeSquint', keys: ['eyeSquintLeft', 'eyeSquintRight'], weight: 0.6 },
  { id: 'browDown', keys: ['browDownLeft', 'browDownRight'], weight: 0.8 },
  { id: 'cheekSquint', keys: ['cheekSquintLeft', 'cheekSquintRight'], weight: 0.5 },
  { id: 'noseSneer', keys: ['noseSneerLeft', 'noseSneerRight'], weight: 1.0 },
  { id: 'mouthUpperUp', keys: ['mouthUpperUpLeft', 'mouthUpperUpRight'], weight: 0.7 },
];
/** Blendshapes with a left/right twin, for the asymmetry term. */
export const EXPRESSION_LR_BASES = ['mouthSmile', 'mouthFrown', 'mouthStretch', 'mouthUpperUp', 'mouthLowerDown', 'mouthPress', 'mouthDimple', 'eyeSquint', 'eyeBlink', 'eyeWide', 'browDown', 'browOuterUp', 'cheekSquint', 'noseSneer'];
/** σ of the intensity (neutral ≈ 0.05, gentle smile ≈ 0.2, grimace / wide laugh ≥ 0.6). */
// v2: 0.21 → 0.28 so mild expressions (soft smile, slight squint) are effectively free. GUESS.
export const EXPRESSION_SIGMA_INTENSITY = 0.28;
export const EXPRESSION_SIGMA_ASYMMETRY = 0.08;
export const EXPRESSION_POWER = -2;
/** Norm order of the smooth aggregate: p = 3 lets several moderate activations add up, one strong one dominate. */
export const EXPRESSION_NORM = 3;

/** 0–1 smile strength (mean of mouthSmileLeft/Right). */
export function smileLevel(bs?: Record<string, number>): number {
  if (!bs) return 0;
  const g = (k: string) => { const v = bs[k]; return Number.isFinite(v) ? Math.max(0, v) : 0; };
  return Math.max(0, Math.min(1, (g('mouthSmileLeft') + g('mouthSmileRight')) / 2));
}
/**
 * A smile is NOT a flaw (owner's rule: a smiling supermodel is not less attractive or asymmetric).
 * The muscles a smile recruits (cheek/eye squint, raised upper lip, stretch, some jaw-open)
 * are discounted by this much × smile strength. GUESS.
 */
export const SMILE_DISCOUNT: Record<string, number> = { eyeSquint: 1.0, cheekSquint: 1.0, mouthUpperUp: 0.9, mouthStretch: 0.8, jawOpen: 0.6 };
/**
 * The smile discount fades as the activation itself gets extreme
 * (× (1 − raw)): a gentle smile is fully excused, but a wide-open laugh
 * (jawOpen / stretch / squint near 1) keeps almost its full intensity.
 * Why: an extreme expression distorts the measured face and must cost points.
 */
export const smileDiscounted = (raw: number, featureId: string, smile: number) =>
  Math.max(0, raw - (SMILE_DISCOUNT[featureId] ?? 0) * smile * (1 - raw));
/** Natural smiles are rarely perfectly even: L/R tolerance widens by (1 + gain·smile). GUESS. */
export const SMILE_ASYMMETRY_GAIN = 2;
/** Mouth & cheek landmark pairs lose this share of their symmetry weight at full smile. GUESS. */
export const SMILE_SYMMETRY_RELIEF = 0.85;
/** Mouth-corner / lip-contour σ widens by (1 + gain·smile). GUESS. */
export const SMILE_MOUTH_SIGMA_GAIN = 2;

export function expressionFromBlendshapes(bs: Record<string, number>): ExpressionReport {
  const g = (k: string) => { const v = bs[k]; return Number.isFinite(v) ? Math.max(0, v) : 0; };
  const smile = smileLevel(bs);
  const activations: Record<string, number> = {};
  let acc = 0;
  for (const f of EXPRESSION_FEATURES) {
    const raw = f.keys.reduce((s, k) => s + g(k), 0) / f.keys.length;
    const a = smileDiscounted(raw, f.id, smile);
    activations[f.id] = a;
    acc += (f.weight * a) ** EXPRESSION_NORM;
  }
  const intensity = acc ** (1 / EXPRESSION_NORM);
  let sq = 0;
  for (const b of EXPRESSION_LR_BASES) sq += (g(`${b}Left`) - g(`${b}Right`)) ** 2;
  const asymmetry = Math.sqrt(sq / EXPRESSION_LR_BASES.length);
  const intensityScore = deviationScore(intensity / EXPRESSION_SIGMA_INTENSITY);
  const asymmetryScore = deviationScore(asymmetry / (EXPRESSION_SIGMA_ASYMMETRY * (1 + SMILE_ASYMMETRY_GAIN * smile)));
  const score = weightedPowerMean([[intensityScore, 0.75], [asymmetryScore, 0.25]], EXPRESSION_POWER);
  return { intensity, asymmetry, intensityScore, asymmetryScore, score, activations };
}

// ---- Mouth + jaw (frontalised landmarks, IPD-normalised) ----------------------
/**
 * Mouth / jaw INTEGRITY: bilateral residuals only (σ in IPD units, GUESSES). There is no
 * "mouth openness" term — opening the mouth or smiling is expression, not distortion.
 */
// v2: every σ ×1.3 — the old values put ordinary in-browser landmark noise at z ≈ 2. GUESS.
export const MOUTH_JAW_SIGMA = { corners: 0.039, lips: 0.026, centre: 0.033, jaw: 0.033, chin: 0.039 };
/** Mouth/jaw σ also widens by (1 + gain·expressionLoad): an open or stretched mouth moves these points. GUESS. */
export const MOUTH_JAW_LOAD_GAIN = 0.8;
export const MOUTH_JAW_WEIGHTS = { corners: 0.25, lips: 0.2, centre: 0.15, jaw: 0.25, chin: 0.15 };
/** Ids of the scored mouth/jaw terms, in order (no `open` term — openness is informational). */
export const MOUTH_JAW_TERM_IDS = ['corners', 'lips', 'centre', 'jaw', 'chin'];
export const JAW_PAIRS: Array<[number, number]> = [[172, 397], [136, 365], [150, 379], [149, 378]];
/** Lip-contour pairs (outer + inner lip) from BILATERAL_PAIRS. */
export const LIP_PAIRS: Array<[number, number]> = [[40, 270], [37, 267], [39, 269], [185, 409], [146, 375], [91, 321], [84, 314], [78, 308], [95, 324], [88, 318], [178, 402], [87, 317], [80, 310], [81, 311], [82, 312], [191, 415]];

function regionOf(i: number): string {
  const p = BILATERAL_PAIRS.findIndex(([r]) => r === i);
  if (p < 16) return 'eye';
  if (p < 26) return 'brow';
  if (p < 36) return 'nose';
  if (p < 54) return 'mouth';
  if (p < 68) return 'cheek';
  if (p < 85) return 'jaw/oval';
  return 'forehead';
}

const toPixels = (raw: Vec3[], imgW: number, imgH: number) =>
  raw.map((p) => ({ x: p.x * imgW, y: p.y * imgH, z: p.z * imgW }));

/**
 * Pose normalisation from the face's own symmetry plane.
 * The mirror-Procrustes fit gives M(p) = H·p + t with H a reflection
 * (I − 2nnᵀ). Its normal n is the true left/right axis of the head in 3D,
 * independent of yaw, pitch and roll. We build an orthonormal face frame
 * (X = n, Y = chin→forehead ⟂ n, Z = X × Y) and express every landmark in it,
 * so 2D measurements are taken on a frontalised face instead of the
 * perspective-distorted image projection.
 */
export function symmetryFrame(P: Vec3[]) {
  const { mirrorPoint, residual, R, t } = mirrorProcrustes(P);
  // H = R·S, S = diag(−1,1,1). I − H = 2nnᵀ → pick its strongest column.
  const H = [-R[0], R[1], R[2], -R[3], R[4], R[5], -R[6], R[7], R[8]];
  const cols = [0, 1, 2].map((c) => ({ x: (c === 0 ? 1 : 0) - H[c], y: (c === 1 ? 1 : 0) - H[3 + c], z: (c === 2 ? 1 : 0) - H[6 + c] }));
  let n = cols.reduce((a, b) => (len(b) > len(a) ? b : a));
  if (len(n) < 1e-9) n = { x: 1, y: 0, z: 0 };
  n = norm(n);
  // orient toward subject-left (landmark 263 side)
  if (dot(n, sub(P[263], P[33])) < 0) n = scale(n, -1);
  const d = dot(n, t) / 2; // plane: n·p = d  (t = 2d·n for a pure reflection)
  const upRaw = sub(P[10], P[152]);
  const yAxis = norm(sub(upRaw, scale(n, dot(upRaw, n))));
  const zAxis = cross(n, yAxis);
  const origin = mean(MIDLINE.map((i) => P[i]));
  const oX = dot(n, origin) - d; // offset so x = signed distance to the symmetry plane
  const F = P.map((p) => {
    const q = sub(p, origin);
    return { x: dot(q, n) + oX, y: dot(q, yAxis), z: dot(q, zAxis) };
  });
  // Image coords: x right, y down, z away from camera (MediaPipe). Face looks toward −z.
  const yaw = (Math.asin(Math.max(-1, Math.min(1, n.z))) * 180) / Math.PI;
  const pitch = (Math.asin(Math.max(-1, Math.min(1, -yAxis.z))) * 180) / Math.PI;
  const roll = (Math.atan2(n.y, n.x) * 180) / Math.PI;
  return { F, n, yaw, pitch, roll, mirrorPoint, residual };
}

/** Back-compat: frontalised landmark frame. */
export function frontalize(raw: Vec3[], imgW: number, imgH: number) {
  const { F, yaw, pitch, roll } = symmetryFrame(toPixels(raw, imgW, imgH));
  return { F, yaw, pitch, roll };
}

/**
 * Pose confidence in (0, 1]. Head pose ONLY: expression / open mouth is scored
 * by its own groups and must not also relax the measurement. Smooth: no
 * penalty within ±8°, then a Gaussian fall-off (≈0.6 at 25° yaw).
 */
/** Beyond this |yaw| the face is scored as an angled / 3/4 / side view. GUESS (v2: 20 → 25). */
export const ANGLED_YAW_DEG = 25;
/** Bilateral groups fade out between these |yaw| values (smooth cosine). GUESS (v2: 15–32 → 22–38). */
export const ANGLED_FADE_START = 22;
export const ANGLED_FADE_END = 38;
/**
 * v2 yaw tolerance for the bilateral groups (symmetry, mouth & jaw): σ × (1 + YAW_TOLERANCE_GAIN·min(1, |yaw|/YAW_TOLERANCE_DEG)²).
 * Why: landmark depth gets noisier as the head turns, so raw residuals grow with yaw even on a
 * symmetric face (KNOWN LIMIT above). Capped at 25°, so turning further never keeps loosening. GUESS.
 */
export const YAW_TOLERANCE_DEG = 25;
export const YAW_TOLERANCE_GAIN = 0.6;
export const yawTolerance = (yaw: number) => 1 + YAW_TOLERANCE_GAIN * Math.min(1, Math.abs(Number.isFinite(yaw) ? yaw : 0) / YAW_TOLERANCE_DEG) ** 2;

export function measurementConfidence(yaw: number, pitch: number) {
  const y = Math.max(0, Math.abs(yaw) - 8) / 25;
  const p = Math.max(0, Math.abs(pitch) - 8) / 28;
  return Math.exp(-0.5 * (y * y + p * p));
}

/** Reject damaged model output rather than treating corrupt coordinates as face traits. */
export function isValidFaceMesh(raw: Vec3[]): boolean {
  return Array.isArray(raw) && raw.length >= 468 && Array.from(raw).every((p) =>
    p != null && Number.isFinite(p.x) && Number.isFinite(p.y) && Number.isFinite(p.z));
}

export function analyzeFaceGeometry(raw: Vec3[], imgW: number, imgH: number, poseMatrix?: ArrayLike<number>, blendshapes?: Record<string, number>, skin?: SkinReport): FaceGeometryReport {
  if (!raw || raw.length < 468) throw new Error(`Expected ≥468 landmarks, got ${raw?.length ?? 0}`);
  if (!isValidFaceMesh(raw)) throw new Error('Face landmarks contain missing or non-finite coordinates');
  if (!Number.isFinite(imgW) || !Number.isFinite(imgH) || imgW <= 0 || imgH <= 0) throw new Error('Face measurement requires positive finite image dimensions');
  const P = toPixels(raw, imgW, imgH);
  const frame = symmetryFrame(P);
  const { F, residual, mirrorPoint } = frame;
  const matrixPose = poseMatrix && poseMatrix.length >= 16 ? poseFromMatrix(poseMatrix) : null;
  const okPose = matrixPose && [matrixPose.yaw, matrixPose.pitch, matrixPose.roll].every(Number.isFinite);
  const { yaw, pitch, roll } = okPose && matrixPose ? matrixPose : frame;

  const mesh = F.slice(0, 468);
  const hasIris = F.length >= 478;
  const pupilR = hasIris ? F[IRIS_RIGHT] : mean([F[33], F[133]]);
  const pupilL = hasIris ? F[IRIS_LEFT] : mean([F[263], F[362]]);
  const ipd = dist2D(pupilR, pupilL) || 1;
  const ipd3 = (hasIris ? len(sub(P[IRIS_RIGHT], P[IRIS_LEFT])) : ipd) || 1;
  const midX = 0; // symmetry plane is x = 0 in the face frame

  // Pose does NOT widen σ any more. The pose-normalised residuals are rotation-invariant, and
  // widening σ with yaw made a face score HIGHER the further it turned (an extrapolated, occluded
  // side looks more tolerant). Pose is handled only by `measurementConfidence`, which shrinks
  // high scores toward neutral — never up. (Kept as a constant so the formulas stay readable.)
  const poseNoise = 1;

  // ---- 3D mirror-Procrustes pair asymmetry -------------------------------
  const smile = smileLevel(blendshapes);
  const load = expressionLoad(blendshapes);
  // The smile relief fades as the expression gets extreme: a gentle smile is
  // excused, a wide-open laugh is (mostly) measured as-is. GUESS factor 0.7.
  const smileEase = Math.max(smile, load); // expression never costs points (owner's rule)
  // Smiles move mouth & cheek points unevenly; that is expression, not facial asymmetry.
  const pairW = (region: string) => (region === 'mouth' || region === 'cheek' ? 1 - SMILE_SYMMETRY_RELIEF * smileEase : 1);
  const pairs: PairAsymmetry[] = BILATERAL_PAIRS.map(([r, l]) => ({
    right: r, left: l, region: regionOf(r),
    asymmetry: (residual(r) + residual(l)) / 4 / ipd3,
  }));
  const pwSum = pairs.reduce((s, p) => s + pairW(p.region), 0) || 1;
  const pairAsymmetry = pairs.reduce((s, p) => s + pairW(p.region) * p.asymmetry, 0) / pwSum;

  // ---- 2D symmetry on the pose-normalised (frontalised) face --------------
  let a2 = 0;
  for (const [r, l] of BILATERAL_PAIRS) a2 += pairW(regionOf(r)) * Math.hypot(F[r].x + F[l].x, F[r].y - F[l].y) / 2;
  const frontalAsymmetry = a2 / pwSum / ipd;

  // ---- Full-mesh mirror (Chamfer) distance -------------------------------
  const meshP = P.slice(0, 468);
  let chamfer = 0;
  for (const p of meshP) {
    const m = mirrorPoint(p);
    let best = Infinity;
    for (const q of meshP) {
      const dd = (q.x - m.x) ** 2 + (q.y - m.y) ** 2 + (q.z - m.z) ** 2;
      if (dd < best) best = dd;
    }
    chamfer += Math.sqrt(best);
  }
  const meshMirrorDistance = chamfer / meshP.length / ipd3;

  // Pose-normalised: σ widens smoothly with residual rotation (no hard caps).
  // v2: yaw tolerance + a little expression tolerance (mild expressions move many pairs).
  const symTol = poseNoise * yawTolerance(yaw) * (1 + 0.3 * load);
  const pairSymmetry = deviationScore(pairAsymmetry / (SYMMETRY_SIGMA_PAIR * symTol));
  const frontalSymmetry = deviationScore(frontalAsymmetry / (SYMMETRY_SIGMA_2D * symTol));
  const meshSymmetry = deviationScore(meshMirrorDistance / (SYMMETRY_SIGMA_MESH * symTol * (1 + 0.5 * smile)));
  const sw = SYMMETRY_WEIGHTS;
  // Soft band [4, 97] like every other metric: a near-perfect face reads ≤ 97, never a pinned 100.
  const symmetryPercent = 4 + 0.93 * (sw.pair3D * pairSymmetry + sw.frontal2D * frontalSymmetry + sw.mesh * meshSymmetry);

  // ---- Classical proportions (on the frontalised face) -------------------
  const W = (a: number, b: number) => dist2D(F[a], F[b]);
  const vy = (a: number, b: number) => Math.abs(F[a].y - F[b].y);
  const safe = (x: number) => (Number.isFinite(x) && x > 1e-9 ? x : 1e-9);
  const stomion = mean([F[13], F[14]]);
  const eyeR = W(33, 133), eyeL = W(263, 362), eyeW = safe((eyeR + eyeL) / 2);
  const intercanthal = safe(W(133, 362));
  const noseW = safe(W(64, 294));
  const mouthW = safe(W(61, 291));
  const cheekW = safe(W(234, 454));
  const jawW = W(172, 397);
  const midThird = vy(9, 2);
  const lowThird = safe(vy(2, 152));
  const upperLip = safe(Math.abs(F[2].y - stomion.y));
  const lowerFace = Math.abs(stomion.y - F[152].y);

  // Ratio score: z = |measured − ideal| / σ, then the non-linear deviation curve.
  // Ideals are the canonical proportions expressed in Face Mesh landmark space
  // (mesh point 10 sits below the hairline, 234/454 at the tragion edge, so
  // e.g. the "oval" face length reads ≈1.23 rather than the skin-surface 1.38).
  const R = (id: string, label: string, group: RatioMeasurement['group'], formula: string, measured: number, ideal: number, sigma: number, reference: string): RatioMeasurement => {
    const m = Number.isFinite(measured) ? measured : ideal * 3;
    const deviation = Math.abs(m - ideal) / Math.abs(ideal || 1);
    const groupScale = group === 'golden' ? GOLDEN_SIGMA_SCALE : group === 'structure' ? STRUCTURE_SIGMA_SCALE : ALIGNMENT_SIGMA_SCALE;
    // v2: alignment terms are left/right comparisons too, so they get the same capped yaw tolerance.
    const sg = sigma * groupScale * (EXPRESSION_SENSITIVE_RATIOS.includes(id) ? 1 + EXPRESSION_SIGMA_GAIN * load : 1) * (group === 'alignment' ? yawTolerance(yaw) : 1);
    const z = Math.abs(m - ideal) / (sg * Math.sqrt(poseNoise));
    return { id, label, group, formula, measured: m, ideal, deviation, tolerance: sg, z, score: deviationScore(z), reference };
  };

  const tiltR = Math.atan2(F[133].y - F[33].y, Math.abs(F[133].x - F[33].x));
  const tiltL = Math.atan2(F[362].y - F[263].y, Math.abs(F[362].x - F[263].x));
  const ratios: RatioMeasurement[] = [
    R('mouth-nose', 'Mouth width ÷ nose width', 'golden', '|61–291| / |64–294|', mouthW / noseW, 1.55, 0.15, 'Golden ratio φ (Marquardt), mesh-space'),
    R('lower-face-split', 'Chin height ÷ upper-lip height', 'golden', '|stomion–152| / |2–stomion|', lowerFace / upperLip, 1.95, 0.22, 'Neoclassical canon 1 : 2'),
    R('thirds', 'Middle third ÷ lower third', 'structure', '|9–2|y / |2–152|y', midThird / lowThird, 0.95, 0.05, 'Vertical facial thirds 1 : 1'),
    R('fifths-eye', 'Eye width ÷ intercanthal width', 'structure', 'mean(|33–133|,|263–362|) / |133–362|', eyeW / intercanthal, 0.8, 0.06, 'Rule of fifths, mesh-space'),
    R('fifths-face', 'Cheek width ÷ eye width', 'structure', '|234–454| / eye width', cheekW / eyeW, 5, 0.25, 'Rule of fifths (face = 5 eyes)'),
    R('ipd-width', 'Inter-pupillary ÷ cheek width', 'structure', '|468–473| / |234–454|', ipd / cheekW, 0.465, 0.025, 'Pallett et al. 2010 (46%)'),
    R('jaw-cheek', 'Jaw width ÷ cheek width', 'structure', '|172–397| / |234–454|', jawW / cheekW, 0.795, 0.03, 'Bigonial ≈ 80% bizygomatic'),
    R('nose-intercanthal', 'Nose width ÷ intercanthal width', 'alignment', '|64–294| / |133–362|', noseW / intercanthal, 1.12, 0.1, 'Alae align with inner canthi'),
    R('eye-tilt', 'Canthal-tilt difference', 'alignment', '|θ(33→133) − θ(263→362)| (deg) + 1', 1 + Math.abs((tiltR - tiltL) * 180 / Math.PI), 1, 1.2, 'Equal left/right canthal tilt'),
    R('nose-midline', 'Nose-tip offset from midline', 'alignment', '1 + |x(1) − midline| / IPD', 1 + Math.abs(F[1].x - midX) / ipd, 1, 0.025, 'Nasal tip on facial midline'),
    R('alar-balance', 'Alar offset balance', 'alignment', '1 + ||x(64)−mid| − |x(294)−mid|| / IPD', 1 + Math.abs(Math.abs(F[64].x - midX) - Math.abs(F[294].x - midX)) / ipd, 1, 0.03, 'Equal alar distance from midline'),
    R('fwhr', 'Face width ÷ upper-face height', 'structure', '|234–454| / |y(9) − y(0)|', cheekW / safe(vy(9, 0)), 1.8, 0.08, 'fWHR (Carré & McCormick), mesh-space'),
    R('eye-aspect', 'Eye height ÷ eye width', 'golden', 'mean(|159–145|,|386–374|) / eye width', ((W(159, 145) + W(386, 374)) / 2) / eyeW, 0.31, 0.035, 'Almond eye ≈ 1 : 3'),
    R('face-length', 'Face height ÷ face width', 'golden', '|10–152|y / |234–454|', vy(10, 152) / cheekW, 1.23, 0.05, 'Oval face (φ-scaled), mesh-space'),
  ];

  const groupIndex = (g: RatioMeasurement['group']) =>
    weightedPowerMean(ratios.filter((x) => x.group === g).map((x) => [x.score, 1] as [number, number]));
  const goldenRatioIndex = groupIndex('golden');
  const structuralBalanceIndex = groupIndex('structure');
  const alignmentIndex = groupIndex('alignment');
  const proportionDeviation = (ratios.reduce((s, r) => s + r.deviation, 0) / ratios.length) * 100;

  // ---- Mouth + jaw INTEGRITY group (frontalised, IPD-normalised bilateral residuals) ----
  // Informational only: how open the mouth is. Not scored.
  const mouthOpen = W(13, 14) / mouthW;
  const cornerMid = mean([F[61], F[291]]);
  const pairDev = (prs: Array<[number, number]>) => prs.reduce((s, [r, l]) => s + Math.hypot(F[r].x + F[l].x, F[r].y - F[l].y) / 2, 0) / prs.length / ipd;
  const jawDev = pairDev(JAW_PAIRS), lipDev = pairDev(LIP_PAIRS);
  const sgm = MOUTH_JAW_SIGMA, mw = MOUTH_JAW_WEIGHTS;
  const mjTol = poseNoise * yawTolerance(yaw) * (1 + MOUTH_JAW_LOAD_GAIN * load);
  const mjTerm = (id: string, label: string, measured: number, sigma: number, weight: number): MouthJawTerm => {
    const z = measured / (sigma * mjTol);
    return { id, label, measured, sigma, z, score: deviationScore(z), weight };
  };
  const mouthJawTerms: MouthJawTerm[] = [
    mjTerm('corners', 'Mouth-corner height difference (61 vs 291)', Math.abs(F[61].y - F[291].y) / ipd, sgm.corners * (1 + SMILE_MOUTH_SIGMA_GAIN * smileEase), mw.corners),
    mjTerm('lips', 'Lip-contour left/right residual (16 outer + inner lip pairs)', lipDev, sgm.lips * (1 + SMILE_MOUTH_SIGMA_GAIN * smileEase), mw.lips),
    mjTerm('centre', 'Mouth-centre offset from symmetry plane', (Math.abs(cornerMid.x) + Math.abs(stomion.x)) / 2 / ipd, sgm.centre, mw.centre),
    mjTerm('jaw', 'Jaw-line left/right residual (172/397, 136/365, 150/379, 149/378)', jawDev, sgm.jaw, mw.jaw),
    mjTerm('chin', 'Chin offset (152)', Math.abs(F[152].x) / ipd, sgm.chin, mw.chin),
  ];
  const mouthJawScore = weightedPowerMean(mouthJawTerms.map((t) => [t.score, t.weight] as [number, number]), MOUTH_JAW_POWER);
  const mouthJaw: MouthJawReport = { score: mouthJawScore, mouthOpenness: mouthOpen, terms: mouthJawTerms };

  // ---- Expression group (blendshapes) ------------------------------------
  const hasBs = !!blendshapes && Object.keys(blendshapes).length > 0;
  const expression = hasBs ? expressionFromBlendshapes(blendshapes!) : undefined;

  // ---- Facial harmony: weighted power mean (p = HARMONY_POWER) × broken-group penalty ----
  const w = HARMONY_WEIGHTS;
  const labels: Record<HarmonyGroupId, string> = { symmetry: 'Symmetry', structure: 'Structure', golden: 'Golden ratios', alignment: 'Alignment', expression: 'Expression', mouthJaw: 'Mouth & jaw integrity', skin: 'Skin & age' };
  const raws: Array<[HarmonyGroupId, number | undefined]> = [
    ['symmetry', symmetryPercent], ['structure', structuralBalanceIndex], ['golden', goldenRatioIndex],
    ['alignment', alignmentIndex], ['mouthJaw', mouthJawScore], ['skin', skin?.score],
  ];
  // Angled / 3/4 / profile: left–right comparisons are not visible, so symmetry, alignment and
  // mouth/jaw balance drop out and the visible-side groups (proportions, structure, skin,
  // expression) carry the score. GUESS threshold.
  const angled = Math.abs(yaw) > ANGLED_YAW_DEG;
  const BILATERAL_GROUPS: HarmonyGroupId[] = ['symmetry', 'alignment', 'mouthJaw'];
  // Smooth hand-over (no jump): bilateral weight fades from full at ANGLED_FADE_START to 0 at ANGLED_FADE_END.
  const t = Math.max(0, Math.min(1, (Math.abs(yaw) - ANGLED_FADE_START) / (ANGLED_FADE_END - ANGLED_FADE_START)));
  const bilateralKeep = 0.5 * (1 + Math.cos(Math.PI * t));
  const wEff = (id: HarmonyGroupId) => w[id] * (BILATERAL_GROUPS.includes(id) ? bilateralKeep : 1);
  const present = raws.filter((r): r is [HarmonyGroupId, number] => r[1] !== undefined && wEff(r[0]) > 1e-6);
  const wTotal = present.reduce((s, [id]) => s + wEff(id), 0);
  const groups: HarmonyGroup[] = present.map(([id, score]) => ({ id, label: labels[id], score, weight: wEff(id) / wTotal }));
  const harmonyMean = weightedPowerMean(groups.map((g) => [g.score, g.weight] as [number, number]), HARMONY_POWER);
  const brokenPenalty = brokenGroupPenalty(groups);
  const facialHarmony = harmonyMean * brokenPenalty;

  // Owner's decision: a turned head is never penalised. Angled faces are scored on the
  // visible side instead (see `angled` above), so confidence no longer shrinks the score.
  const confidence = 1;
  const reliable = true;
  const issues = [
    Math.max(Math.abs(yaw), Math.abs(pitch)) > 15 && `head rotation (yaw ${yaw.toFixed(0)}°, pitch ${pitch.toFixed(0)}°)`,
  ].filter(Boolean);
  return {
    landmarkCount: raw.length,
    meshPointsUsed: mesh.length,
    pairsUsed: pairs.length,
    yaw, pitch, roll,
    pairAsymmetry, frontalAsymmetry, meshMirrorDistance, pairSymmetry, frontalSymmetry, meshSymmetry, symmetryPercent,
    structuralBalanceIndex, goldenRatioIndex, alignmentIndex, proportionDeviation,
    facialHarmony, harmonyMean, brokenPenalty,
    harmonyWeights: w,
    groups, expression, expressionLoad: load, skin, mouthJawScore, mouthJaw,
    ratios,
    worstPairs: [...pairs].sort((a, b) => b.asymmetry - a.asymmetry).slice(0, 5),
    // Every detected point (478 incl. irises), y flipped so the forehead is on top in screen coords.
    frontalMesh: F.map((p) => [p.x / ipd, -p.y / ipd]),
    confidence,
    reliable,
    viewMode: angled ? 'angled' : 'frontal',
    reliabilityNote: angled ? `Angled view (${issues.join(' and ') || `yaw ${yaw.toFixed(0)}°`}): scored on the visible side — symmetry, alignment and mouth/jaw balance are not measured.` : undefined,
  };
}
