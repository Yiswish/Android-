import type { SearchResultImage } from './types';

/** Context is literal search text, not instructions for identity recognition. */
export function bestSearchQuery(query: string, context: string): string {
  return [query.trim(), context.trim().replace(/\s+/g, ' ')].filter(Boolean).join(' ');
}

/** Preserve the original list label, not the appended search qualifiers. */
export function bestSearchLabels(images: SearchResultImage[], query: string): SearchResultImage[] {
  return images.map((image) => ({ ...image, searchLabel: image.source === 'curated' || image.source === 'upload' || !image.searchLabel?.trim() ? undefined : query.trim() }));
}