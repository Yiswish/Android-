// ============================================================================
// SKIN & AGE — pure, deterministic, luminance-only.
// ----------------------------------------------------------------------------
// The 478-point mesh is a smooth statistical template: it cannot see wrinkles,
// hollow cheeks or rough skin. This module measures fine-scale detail on the
// cheeks directly from pixels, using the face's OWN eyes as the sharpness
// reference so the number does not depend on resolution, blur, exposure or
// colour.
//
//   band        = Gaussian(σ1 = 0.012·IPD) − Gaussian(σ2 = 0.03·IPD)   (difference of Gaussians)
//   skinDetail  = 1.4826·MAD(band over two cheek discs) ÷ mean luminance of the cheek discs
//   eyeDetail   = P95(|band| over two pupil discs)        ÷ mean luminance of the eye discs
//   ratio       = skinDetail ÷ eyeDetail
//   rawScore    = 100·exp(−(ratio / τ)^k),  τ = 0.25, k = 1.5
//   score       = confidence·soft(rawScore) + (1 − confidence)·70
//
// MEASURED vs GUESSED
//  • Measured (hand-placed patches on 4 phone screenshots, UI overlay lines
//    present, sanity check only): portraits ratio ≈ 0.03–0.07, an aged
//    painting ≈ 0.19–0.34.
//  • GUESSED / uncalibrated: τ, k, the confidence constants, the obstruction
//    (dark-pixel) heuristic, the eye-reference confidence, and the soft band.
//    Calibrate on real data (see README → Calibration).
//
// KNOWN WEAKNESSES: heavy retouching lowers the ratio (inflates the score);
// unretouched high-resolution natural skin may score too harshly; hair or
// glasses over the cheek patches; heavy make-up or beards; JPEG artefacts;
// closed eyes / sunglasses (weak eye reference → confidence drops).
// No colour is read anywhere: monochrome art is not penalised for being mono.
// ============================================================================

export const SKIN_PARAMS = {
  /** Fine / coarse Gaussian of the band-pass, in IPD units. */
  sigmaFine: 0.012,
  sigmaCoarse: 0.03,
  /** Cheek / eye disc radii, in IPD units. */
  skinRadius: 0.2,
  eyeRadius: 0.28,
  /** Cheek centre = pupil + cheekAlong·(mouthCorner − pupil) + cheekOutward·IPD along the eye line, outward. */
  cheekAlong: 0.65,
  cheekOutward: 0.18,
  /** GUESS: score curve 100·exp(−(ratio/τ)^k). */
  tau: 0.25,
  k: 1.5,
  /** Confidence = sigmoid((IPD_px − ipdCentre)/ipdWidth) · min(1, samples/samplesFull). */
  ipdCentre: 36,
  ipdWidth: 8,
  samplesFull: 450,
  /** Fewer samples than this in either patch group → no measurement at all. */
  minSamples: 150,
  /** Score used where confidence is missing (also the display value when not measured). */
  neutral: 70,
  /** Pixel darker than this × the patch median (at σ1) = hair / beard / shadow, dropped. Value tuned on the 19 public/_verify controls (0.6 masked 20–28% of turned / shadowed cheeks) — a fit, not a validation. */
  darkFraction: 0.5,
  /** Masked fraction at which confidence has fallen to exp(−1). Tuned together with darkFraction on the same 19 controls (0.15 collapsed confidence to ≈0.03 on shadowed faces). */
  obstructionScale: 0.3,
  /** GUESS: eye reference must carry at least this much detail (relative), else confidence drops (closed eyes, sunglasses). */
  eyeRefCentre: 0.03,
  eyeRefWidth: 0.012,
  /** Same soft band as the image metrics so the metric never pins to 0 / 100. */
  floor: 4,
  ceil: 97,
} as const;

export interface SkinReport {
  /** Final metric, 0–100 (confidence-blended, soft-banded). */
  score: number;
  /** 100·exp(−(ratio/τ)^k), before banding / blending. */
  rawScore: number;
  /** skinDetail ÷ eyeDetail */
  ratio: number;
  skinDetail: number;
  eyeDetail: number;
  /** 0–1 */
  confidence: number;
  /** Inter-pupillary distance in the pixels that were measured. */
  ipdPx: number;
  skinSamples: number;
  eyeSamples: number;
  /** Fraction of cheek-patch pixels dropped as hair / beard / shadow. */
  maskedFraction: number;
  /** Cheek-patch centres in pixel coordinates (right, left) — for overlays and tests. */
  patches: Array<{ x: number; y: number; r: number }>;
}

export interface SkinLandmark { x: number; y: number }

const sigmoid = (x: number) => 1 / (1 + Math.exp(-x));

// ---- small numeric helpers (exported for tests) ------------------------------
export function median(a: ArrayLike<number>): number {
  const n = a.length;
  if (!n) return 0;
  const s = Float64Array.from(a as ArrayLike<number>).sort();
  return n % 2 ? s[(n - 1) / 2] : 0.5 * (s[n / 2 - 1] + s[n / 2]);
}
/** Robust σ estimate: 1.4826 · median(|x − median(x)|). A single outlier cannot move it. */
export function madSigma(a: ArrayLike<number>): number {
  const m = median(a);
  const d = new Float64Array(a.length);
  for (let i = 0; i < a.length; i++) d[i] = Math.abs(a[i] - m);
  return 1.4826 * median(d);
}
export function percentile(a: ArrayLike<number>, p: number): number {
  const n = a.length;
  if (!n) return 0;
  const s = Float64Array.from(a as ArrayLike<number>).sort();
  const pos = Math.max(0, Math.min(1, p)) * (n - 1);
  const lo = Math.floor(pos), hi = Math.ceil(pos);
  return s[lo] + (s[hi] - s[lo]) * (pos - lo);
}

/** score = 100·exp(−(ratio/τ)^k); strictly decreasing in the ratio. */
export const skinRawScore = (ratio: number) =>
  !Number.isFinite(ratio) || ratio < 0 ? 0 : 100 * Math.exp(-((ratio / SKIN_PARAMS.tau) ** SKIN_PARAMS.k));
/** Soft band [floor, ceil]: no metric pins to 0 or 100. */
export const skinSoftScore = (raw: number) => SKIN_PARAMS.floor + ((SKIN_PARAMS.ceil - SKIN_PARAMS.floor) / 100) * raw;

/** Pixel luminance (0–255 scale, Rec. 709 weights) from RGBA bytes. */
export function lumaFromRGBA(rgba: ArrayLike<number>, w: number, h: number): Float32Array {
  const out = new Float32Array(w * h);
  for (let i = 0; i < w * h; i++) out[i] = 0.2126 * rgba[i * 4] + 0.7152 * rgba[i * 4 + 1] + 0.0722 * rgba[i * 4 + 2];
  return out;
}

function gaussianKernel(sigma: number): Float64Array {
  const r = Math.max(1, Math.ceil(3 * sigma));
  const k = new Float64Array(2 * r + 1);
  let s = 0;
  for (let i = -r; i <= r; i++) { k[i + r] = Math.exp(-(i * i) / (2 * sigma * sigma)); s += k[i + r]; }
  for (let i = 0; i < k.length; i++) k[i] /= s;
  return k;
}

/** Separable Gaussian blur of a w×h crop, clamp-to-edge borders. */
function blur(src: Float32Array, w: number, h: number, sigma: number): Float32Array {
  const k = gaussianKernel(sigma), r = (k.length - 1) / 2;
  const tmp = new Float32Array(w * h), out = new Float32Array(w * h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let s = 0;
      for (let i = -r; i <= r; i++) s += k[i + r] * src[y * w + Math.min(w - 1, Math.max(0, x + i))];
      tmp[y * w + x] = s;
    }
  }
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let s = 0;
      for (let i = -r; i <= r; i++) s += k[i + r] * tmp[Math.min(h - 1, Math.max(0, y + i)) * w + x];
      out[y * w + x] = s;
    }
  }
  return out;
}

interface DiscSamples { band: number[]; fine: number[]; lum: number[] }

/**
 * Band-pass (σ1 − σ2) values, σ1-blurred luminance and raw luminance for every
 * in-bounds pixel whose centre lies within `r` of (cx, cy). The blur is run on
 * a crop with a 3σ2 margin, so only the disc's neighbourhood is touched.
 */
export function sampleDisc(luma: ArrayLike<number>, w: number, h: number, cx: number, cy: number, r: number, s1: number, s2: number): DiscSamples {
  const margin = Math.ceil(3 * s2) + 1;
  const x0 = Math.max(0, Math.floor(cx - r) - margin), x1 = Math.min(w - 1, Math.ceil(cx + r) + margin);
  const y0 = Math.max(0, Math.floor(cy - r) - margin), y1 = Math.min(h - 1, Math.ceil(cy + r) + margin);
  const cw = x1 - x0 + 1, ch = y1 - y0 + 1;
  const out: DiscSamples = { band: [], fine: [], lum: [] };
  if (cw < 2 || ch < 2) return out;
  const crop = new Float32Array(cw * ch);
  for (let y = 0; y < ch; y++) for (let x = 0; x < cw; x++) crop[y * cw + x] = luma[(y0 + y) * w + (x0 + x)];
  const g1 = blur(crop, cw, ch, s1), g2 = blur(crop, cw, ch, s2);
  const r2 = r * r;
  for (let y = Math.max(y0, Math.ceil(cy - r)); y <= Math.min(y1, Math.floor(cy + r)); y++) {
    for (let x = Math.max(x0, Math.ceil(cx - r)); x <= Math.min(x1, Math.floor(cx + r)); x++) {
      if ((x - cx) ** 2 + (y - cy) ** 2 > r2) continue;
      const i = (y - y0) * cw + (x - x0);
      out.band.push(g1[i] - g2[i]); out.fine.push(g1[i]); out.lum.push(crop[i]);
    }
  }
  return out;
}

const mean = (a: ArrayLike<number>) => { let s = 0; for (let i = 0; i < a.length; i++) s += a[i]; return a.length ? s / a.length : 0; };

/** Cheek-patch centre for one side (pixel coordinates). */
export function cheekCentre(pupil: { x: number; y: number }, otherPupil: { x: number; y: number }, mouthCorner: { x: number; y: number }, ipd: number) {
  const ux = (pupil.x - otherPupil.x) / (ipd || 1), uy = (pupil.y - otherPupil.y) / (ipd || 1); // outward along the eye line
  return {
    x: pupil.x + SKIN_PARAMS.cheekAlong * (mouthCorner.x - pupil.x) + SKIN_PARAMS.cheekOutward * ipd * ux,
    y: pupil.y + SKIN_PARAMS.cheekAlong * (mouthCorner.y - pupil.y) + SKIN_PARAMS.cheekOutward * ipd * uy,
  };
}

/**
 * @param luma      luminance, row-major, w×h (any positive scale — the result is scale-free)
 * @param landmarks normalised (0–1) landmarks; needs the iris centres (468, 473) and mouth corners (61, 291)
 * @returns undefined when the face is too small / out of frame to measure honestly.
 */
export function analyzeSkin(luma: ArrayLike<number>, w: number, h: number, landmarks: SkinLandmark[]): SkinReport | undefined {
  if (!landmarks || landmarks.length < 478 || !(w > 0) || !(h > 0) || luma.length < w * h) return undefined;
  const px = (i: number) => ({ x: landmarks[i].x * w, y: landmarks[i].y * h });
  const pR = px(468), pL = px(473), mR = px(61), mL = px(291);
  const ipd = Math.hypot(pR.x - pL.x, pR.y - pL.y);
  if (!(ipd > 1) || [pR, pL, mR, mL].some((p) => !Number.isFinite(p.x) || !Number.isFinite(p.y))) return undefined;

  const P = SKIN_PARAMS;
  // GUESS: σ1 is kept ≥ 0.5 px so the kernel is never degenerate on tiny faces (the confidence sigmoid handles those).
  const s1 = Math.max(0.5, P.sigmaFine * ipd), s2 = Math.max(s1 * 1.5, P.sigmaCoarse * ipd);
  const cR = cheekCentre(pR, pL, mR, ipd), cL = cheekCentre(pL, pR, mL, ipd);
  const rSkin = P.skinRadius * ipd, rEye = P.eyeRadius * ipd;

  // --- cheeks ---
  const cheeks = [sampleDisc(luma, w, h, cR.x, cR.y, rSkin, s1, s2), sampleDisc(luma, w, h, cL.x, cL.y, rSkin, s1, s2)];
  const fineAll = cheeks.flatMap((c) => c.fine);
  const total = fineAll.length;
  if (total < P.minSamples) return undefined;
  // Hair / beard / shadow: pixels far darker than the patch's own median are dropped, and the
  // dropped fraction lowers confidence (a patch that is mostly hair says nothing about skin).
  const fineMedian = median(fineAll);
  const keptBand: number[] = [], keptLum: number[] = [];
  for (const c of cheeks) {
    for (let i = 0; i < c.band.length; i++) {
      if (c.fine[i] < P.darkFraction * fineMedian) continue;
      keptBand.push(c.band[i]); keptLum.push(c.lum[i]);
    }
  }
  const skinSamples = keptBand.length;
  const maskedFraction = 1 - skinSamples / total;
  if (skinSamples < P.minSamples) return undefined;
  const skinLum = mean(keptLum);
  if (!(skinLum > 1e-6)) return undefined;
  const skinDetail = madSigma(keptBand) / skinLum;

  // --- eyes: the face's own sharpness reference ---
  const eyes = [sampleDisc(luma, w, h, pR.x, pR.y, rEye, s1, s2), sampleDisc(luma, w, h, pL.x, pL.y, rEye, s1, s2)];
  const eyeBand = eyes.flatMap((e) => e.band.map(Math.abs));
  const eyeLum = mean(eyes.flatMap((e) => e.lum));
  const eyeSamples = eyeBand.length;
  if (eyeSamples < P.minSamples || !(eyeLum > 1e-6)) return undefined;
  const eyeDetail = percentile(eyeBand, 0.95) / eyeLum;
  if (!(eyeDetail > 1e-9)) return undefined;

  const ratio = skinDetail / eyeDetail;
  const rawScore = skinRawScore(ratio);
  const confidence =
    sigmoid((ipd - P.ipdCentre) / P.ipdWidth) *
    Math.min(1, skinSamples / P.samplesFull) *
    Math.exp(-((maskedFraction / P.obstructionScale) ** 2)) *
    sigmoid((eyeDetail - P.eyeRefCentre) / P.eyeRefWidth);
  const score = confidence * skinSoftScore(rawScore) + (1 - confidence) * P.neutral;
  return {
    score, rawScore, ratio, skinDetail, eyeDetail, confidence, ipdPx: ipd, skinSamples, eyeSamples, maskedFraction,
    patches: [{ ...cR, r: rSkin }, { ...cL, r: rSkin }],
  };
}
