// Pure helpers for picking which Groq key answers a check. Shared by server, browser and tests.

/** Matches GROQ_API_KEY, GROQ_API_KEY_2, GROQ_API_KEY3, GROQ_KEY_4, groq-key-5 … (case-insensitive). */
const KEY_NAME = /^GROQ[_-]?(?:API[_-]?)?KEY[_-]?(\d*)$/i;

/** Picks the Groq keys out of an env object, ordered by their number (no number = 1). Duplicated values are dropped. */
export function findGroqKeys(env: Record<string, string | undefined>): string[] {
  const found: Array<{ n: number; name: string; value: string }> = [];
  for (const [name, raw] of Object.entries(env)) {
    const m = name.match(KEY_NAME);
    const value = raw?.trim();
    if (!m || !value) continue;
    found.push({ n: m[1] ? Number(m[1]) : 1, name, value });
  }
  found.sort((a, b) => a.n - b.n || a.name.localeCompare(b.name));
  const seen = new Set<string>();
  return found.filter((k) => (seen.has(k.value) ? false : (seen.add(k.value), true))).map((k) => k.value);
}

/** Key positions (0-based) to try, starting at `start` and wrapping around. Every key stays as a fallback. */
export function keyOrder(count: number, start: number): number[] {
  if (count <= 0) return [];
  const s = ((Math.floor(start) % count) + count) % count;
  return Array.from({ length: count }, (_, i) => (s + i) % count);
}

/** Returns the items starting at position `start`, wrapping around (round-robin order). */
export function rotateKeys<T>(keys: T[], start: number): T[] {
  return keyOrder(keys.length, start).map((i) => keys[i]);
}

/** Start positions for the Way off passes: each pass starts on a different key. */
export function passStarts(start: number, passes: number): number[] {
  return Array.from({ length: passes }, (_, i) => start + i);
}

const COUNTER_KEY = 'ai-key-counter';

/** Browser: returns the current check number and saves the next one, so each check starts on the next key, even after a reload. */
export function takeKeyTurns(storage: Pick<Storage, 'getItem' | 'setItem'> | undefined, turns = 1): number {
  let n = 0;
  try {
    n = Number(storage?.getItem(COUNTER_KEY) ?? 0);
    if (!Number.isFinite(n) || n < 0) n = 0;
    storage?.setItem(COUNTER_KEY, String(n + turns));
  } catch { /* private mode: still works for this page */ }
  return n;
}

/** Old name kept for existing callers. */
export const findGeminiKeys = (env: Record<string, string | undefined>) => findGeminiEnvKeys(env);

/** Matches GEMINI_API_KEY, GEMINI_API_KEY_2, GOOGLE_GEMINI_KEY3, GEMINI_KEY_4 … (case-insensitive). */
const GEMINI_NAME = /^(?:GOOGLE[_-]?)?GEMINI[_-]?(?:API[_-]?)?KEY[_-]?(\d*)$/i;

/** Picks the Gemini keys out of an env object, ordered by number. */
export function findGeminiEnvKeys(env: Record<string, string | undefined>): string[] {
  const found: Array<{ n: number; name: string; value: string }> = [];
  for (const [name, raw] of Object.entries(env)) {
    const m = name.match(GEMINI_NAME);
    const value = raw?.trim();
    if (m && value) found.push({ n: m[1] ? Number(m[1]) : 1, name, value });
  }
  found.sort((a, b) => a.n - b.n || a.name.localeCompare(b.name));
  return [...new Set(found.map((k) => k.value))];
}

export type AiProvider = 'gemini' | 'groq';
export interface AiKey { provider: AiProvider; key: string }

/** Personal keys are typed in one list: Groq keys start with "gsk_", everything else is treated as Gemini. */
export function providerOfKey(key: string): AiProvider {
  return /^gsk_/i.test(key.trim()) ? 'groq' : 'gemini';
}

/** Gemini keys first (preferred), Groq keys after as fallback. */
export function orderedAiKeys(gemini: string[], groq: string[]): AiKey[] {
  return [...gemini.map((key) => ({ provider: 'gemini' as const, key })), ...groq.map((key) => ({ provider: 'groq' as const, key }))];
}
