## Search + secret
- Provider chain lives in `src/lib/search.providers.ts` (plain functions, unit-tested with mocked fetch in `src/test/search.test.ts`); `search.functions.ts` only wraps it: SerpAPI → Openverse → Wikimedia → curated. The UI banner names the provider and the reason (missing key / quota / network / empty) and a diagnostics line shows key present/missing and the exact query sent.
- The key is read ONLY as `globalThis.Netlify?.env?.get('SERPAPI_API_KEY') ?? process.env.SERPAPI_API_KEY`. Never hardcode, commit, log, return or bundle it; error text is passed through `redact()`. Stored as a Lovable Cloud project secret (`SERPAPI_API_KEY`); `.env.local` only for local dev outside Lovable.
- Pass `portraitMode: 'all-ages'` for Best, preserving the young-portrait default for Search; include mode in cache keys. Why: Best must not silently restrict age or reuse age-biased cached searches.


## Face analysis
- Smiles are not flaws (owner's rule): smile strength discounts smile muscles in the expression score, widens L/R expression and mouth-corner/lip tolerance, and down-weights mouth/cheek pairs in symmetry (`SMILE_*` constants in faceGeometry.ts, GUESSED). The discount/relief FADES as the expression gets extreme (`smileDiscounted` ×(1−raw), `smileEase` ×(1−0.7·load)): a gentle smile is free, a wide-open laugh is measured and costs points.
- Precision mode: the main face is re-detected on several zoomed crops (`PRECISION_CROP_FACTORS`) and all 478 points + blendshapes are averaged; outlier passes are rejected. Why: single-pass landmark jitter is the main noise source.
- Validate every mesh coordinate before scoring or averaging precision passes, and preserve original model indexes when excluding damaged faces. Why: a corrupt pass must not poison a valid mesh or mix one face's expression/pose with another's geometry; this is input protection, not calibration.

## Scoring design (read before touching constants)
- Overall = face × (0.8 + 0.2 × photo/100). Photography is a multiplier and can never rescue a distorted face. No colour statistic enters any score.
- AI look check (`aiLook.server.ts`, Groq via the owner GROQ_API_KEY): a whole-face 0–100 judgement blended into the overall with `blendWithAiLook` (power mean, lower value dominates; weight/power GUESSED in scoring.ts). Why: the landmark mesh cannot see teeth, weight, puffiness or overall appeal and over-rated unattractive faces. If the check fails, the overall stays measurements-only and the card says so.
- Face = weighted power mean (p = −6, stricter on the weakest group — owner found −3 too forgiving) of groups: symmetry 0.15, structure 0.17, golden 0.10, alignment 0.07, mouth/jaw integrity 0.10, **skin & age 0.29**, expression 0.12 (scored). If pixels are unavailable / the face is tiny, skin drops out and the rest renormalise. A turned head is never penalised (confidence = 1, owner's decision); beyond ~15–32° yaw, symmetry/alignment/mouth-jaw fade out smoothly and the visible-side groups carry the score (`viewMode: 'angled'`).
- Expression: scored, weight 0.12 (σ_intensity 0.25: gentle smile ≈ free, wide-open mouth / grimace costs heavily). `expressionLoad` = clamp(0.8·smile + 1.0·jawOpen + 0.5·mouthStretch + 0.3·cheekSquint, 0, 1) widens σ by only (1 + 0.25·load) only for mouth-nose, lower-face-split, thirds, face-length, fwhr, eye-aspect. Mouth openness is informational; genuine distortion is caught by bilateral residuals (corners, lip contour, jaw, chin) and symmetry.
- Skin & age (`skin.ts`): difference-of-Gaussians detail on two cheek discs ÷ the eyes' own detail (ratio), score = 100·exp(−(ratio/0.25)^1.5), confidence-blended toward 70, soft band [4, 97]. The old photo metric "Texture" is now labelled "Image sharpness" (key `texture`, subject focus only).
- Photo metrics (≤20%, GUESSED weights in scoring.ts). Simplicity, Depth and Warm/Cool tags are removed for good; no colour statistic is used anywhere. Archetypes are removed from all UI (`topArchetypes` stays `[]` for storage compatibility).
- Landmark ratio score = 100 / (1 + (z/2)^4). σ multipliers: golden ×0.95, structure ×1.25, alignment ×1; symmetry σ 0.008 / 0.0075 / 0.013 (IPD). Flat-top band deliberately NOT added: the quartic is already ≤6 points for z ≤ 1.
- Old saved analyses lack `metrics.skin`: always pass metrics through `normalizeMetrics()` (defaults skin to 70) before bars, taste kernel or cosine similarity.

- Search chain is Serper → SerpAPI → Pexels → Unsplash → Openverse → Wikimedia; Serper/Pexels/Unsplash are optional and skipped silently (not listed in attempts) when no key exists. Keys travel only in headers or the SerpAPI query, never logged. Why: more fallbacks without noisy banners.

- Personal API keys entered in the keys menu persist in browser localStorage (`personalKeys.ts`) and travel only in request bodies/headers to server functions. Why: owner wants keys kept after reload.
- elitebabes.com has no API: `elitebabes()` reads its public search page and returns `cdn.elitebabes.com` masonry images; it runs only when the user picks that source (no age/portrait terms added). Why: keep adult content out of default searches.

## Body rating
- A MediaPipe pose detector (`bodyDetection.ts`) must find shoulders and hips before the AI body rater is called; otherwise the rating is skipped with a plain reason. Why: no AI rating without a real body in the photo.
- After the AI answers, `calibrateBody` nudges scores toward the user's slider ratings (same body type first). Why: the AI must learn the user's scale.
