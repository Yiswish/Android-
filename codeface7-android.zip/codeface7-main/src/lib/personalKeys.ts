// Personal keys are saved in this browser's localStorage (owner's request) so they survive reloads.
// Never include them in URLs, logs or diagnostics.
export type SearchKeyProvider = 'serper' | 'serpapi' | 'pexels' | 'unsplash';
export type KeyProvider = 'gemini' | SearchKeyProvider;
export const SEARCH_KEY_PROVIDERS: SearchKeyProvider[] = ['serper', 'serpapi', 'pexels', 'unsplash'];
export const KEY_PROVIDERS: KeyProvider[] = ['gemini', ...SEARCH_KEY_PROVIDERS];
export interface PersonalKeys { gemini?: string[]; serpapi?: string; serper?: string; pexels?: string; unsplash?: string }
const STORAGE_KEY = 'getsclose.personalKeys.v1';
let keys: PersonalKeys = {};
let loaded = false;
let revision = 0;

function storage(): Storage | null {
  try { return typeof window !== 'undefined' ? window.localStorage : null; } catch { return null; }
}
function load() {
  if (loaded) return;
  const s = storage();
  if (!s) return;
  loaded = true;
  try { const raw = s.getItem(STORAGE_KEY); if (raw) keys = { ...JSON.parse(raw), ...keys }; } catch { /* ignore corrupt */ }
}
function persist() {
  const s = storage();
  if (!s) return;
  try {
    const clean = Object.fromEntries(Object.entries(keys).filter(([, v]) => (Array.isArray(v) ? v.length : !!v)));
    if (Object.keys(clean).length) s.setItem(STORAGE_KEY, JSON.stringify(clean)); else s.removeItem(STORAGE_KEY);
  } catch { /* storage full or blocked */ }
}

export function personalKeyRevision() { load(); return revision; }
export function personalKeys(): PersonalKeys { load(); return { ...keys, gemini: keys.gemini ? [...keys.gemini] : undefined }; }
export function personalSearchKeys(): Partial<Record<SearchKeyProvider, string>> {
  load();
  const out: Partial<Record<SearchKeyProvider, string>> = {};
  for (const p of SEARCH_KEY_PROVIDERS) if (keys[p]) out[p] = keys[p];
  return out;
}
export function savePersonalKeys(next: PersonalKeys) {
  load();
  revision += 1;
  keys = { ...keys, ...next };
  persist();
}
export function removePersonalKey(provider: KeyProvider) {
  load();
  revision += 1;
  const { [provider]: _removed, ...rest } = keys;
  keys = rest;
  persist();
}
export function clearPersonalKeys() { load(); keys = {}; revision += 1; persist(); }
export function personalKeyStatus(): Record<KeyProvider, boolean> {
  load();
  return { gemini: !!keys.gemini?.length, serpapi: !!keys.serpapi, serper: !!keys.serper, pexels: !!keys.pexels, unsplash: !!keys.unsplash };
}
/** Last 4 characters only, for recognising which saved key is in use. */
export function maskKey(key?: string) { return key ? `••••${key.slice(-4)}` : ''; }
export function allowPersonalKeys(locked: boolean) { return !locked; }
