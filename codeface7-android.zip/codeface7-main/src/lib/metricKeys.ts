import type { MetricKey, MetricScores } from './types';
import { SKIN_PARAMS } from './skin';

/** Facial-geometry metrics — together 80% of the overall score. */
export const FACE_METRICS: MetricKey[] = ['symmetry', 'proportions', 'structure', 'skin'];
/** Photography metrics — together at most 20% of the overall score. */
export const PHOTO_METRICS: MetricKey[] = ['lighting', 'composition', 'texture', 'contrast', 'naturalness'];
/** Photo metrics were removed from the score and the UI (owner's decision); only face metrics are shown and scored. */
export const METRIC_KEYS: MetricKey[] = [...FACE_METRICS];
/** Every stored key, kept only so old saved analyses still normalise cleanly. */
const ALL_METRIC_KEYS: MetricKey[] = [...FACE_METRICS, ...PHOTO_METRICS];

export const METRIC_LABELS: Record<MetricKey, string> = {
  symmetry: 'Symmetry',
  proportions: 'Golden Proportions',
  structure: 'Structural Balance',
  skin: 'Skin & age',
  composition: 'Composition',
  lighting: 'Lighting',
  texture: 'Image sharpness',
  contrast: 'Contrast',
  naturalness: 'Photo processing',
};

export const emptyMetrics = (v = 0): Record<MetricKey, number> =>
  Object.fromEntries(ALL_METRIC_KEYS.map((k) => [k, v])) as Record<MetricKey, number>;

/**
 * Migration for analyses saved before a metric existed (e.g. `skin`). Missing or
 * non-finite values are defaulted — `skin` to the neutral value 70 (that old
 * score never measured skin), everything else to 0 — so no bar, taste-match
 * kernel distance or cosine similarity ever sees undefined / NaN.
 */
export function normalizeMetrics(m: Partial<Record<MetricKey, number>> | null | undefined): MetricScores {
  const out = {} as MetricScores;
  for (const k of ALL_METRIC_KEYS) {
    const v = m?.[k];
    out[k] = typeof v === 'number' && Number.isFinite(v) ? v : k === 'skin' ? SKIN_PARAMS.neutral : 0;
  }
  return out;
}
