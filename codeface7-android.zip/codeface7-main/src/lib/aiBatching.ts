// Pure helpers for pacing AI requests: a sliding-window rate limiter and a micro-batcher.
// Why: free Gemini keys allow ~15 requests per minute; batching several photos per request
// and spacing requests keeps multi-photo runs fast without hitting "out of quota".

/** Allows at most `limit` takes per `windowMs`; extra callers wait (in order) for a free slot. */
export function createRateLimiter(limit: number, windowMs: number, now: () => number = Date.now, sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms))) {
  const stamps: number[] = [];
  let chain: Promise<void> = Promise.resolve();
  return {
    take(): Promise<void> {
      const turn = chain.then(async () => {
        for (;;) {
          const t = now();
          while (stamps.length && t - stamps[0] >= windowMs) stamps.shift();
          if (stamps.length < limit) { stamps.push(t); return; }
          await sleep(windowMs - (t - stamps[0]) + 5);
        }
      });
      chain = turn.catch(() => undefined);
      return turn;
    },
  };
}

/** Groups items added close together into one `run` call of up to `maxSize`; each caller gets its own answer. */
export function createMicroBatcher<I, O>(opts: { maxSize: number; waitMs: number; run: (items: I[]) => Promise<O[]> }) {
  let pending: Array<{ item: I; resolve: (o: O) => void; reject: (e: unknown) => void }> = [];
  let timer: ReturnType<typeof setTimeout> | undefined;
  const flush = () => {
    if (timer) { clearTimeout(timer); timer = undefined; }
    const group = pending.splice(0, opts.maxSize);
    if (pending.length) timer = setTimeout(flush, opts.waitMs);
    if (!group.length) return;
    opts.run(group.map((g) => g.item)).then(
      (outs) => group.forEach((g, i) => (i < outs.length ? g.resolve(outs[i]) : g.reject(new Error('missing batch answer')))),
      (e) => group.forEach((g) => g.reject(e)),
    );
  };
  return {
    add(item: I): Promise<O> {
      return new Promise<O>((resolve, reject) => {
        pending.push({ item, resolve, reject });
        if (pending.length >= opts.maxSize) flush();
        else if (!timer) timer = setTimeout(flush, opts.waitMs);
      });
    },
  };
}
