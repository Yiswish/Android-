import type {
  FaceDetectionResult,
  DetectedFace,
  AnalysisLogEntry,
  ExpressionLabel,
  PoseLabel,
  BoundingBox,
  FacialLandmarks,
  MetricScores,
} from './types';
import { analyzeFaceGeometry, isValidFaceMesh, HARMONY_POWER, MOUTH_JAW_POWER, EXPRESSION_SIGMA_GAIN, type Vec3 } from './faceGeometry';
import { analyzeSkin } from './skin';
import { deriveMetrics, technicalQuality, type ScoringPixelStats } from './scoring';

/** Hard ceilings so a stalled network or model never freezes the app. */
export const IMAGE_TIMEOUT_MS = 10000;
export const MODEL_TIMEOUT_MS = 45000;

export function withTimeout<T>(p: Promise<T>, ms: number, what: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const t = setTimeout(() => reject(new Error(`${what} timed out after ${Math.round(ms / 1000)} s`)), ms);
    p.then((v) => { clearTimeout(t); resolve(v); }, (e) => { clearTimeout(t); reject(e); });
  });
}
import type { FaceLandmarker as FaceLandmarkerType } from '@mediapipe/tasks-vision';

// ============================================================================
// MediaPipe Face Landmarker (468 mesh + 10 iris landmarks, 3D)
// ============================================================================

// Android app build (mobile/): the WASM runtime and model ship inside the APK, so nothing is downloaded at start-up.
const IS_APP = import.meta.env.VITE_MOBILE === '1';
const WASM_URL = IS_APP ? '/mediapipe/wasm' : 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@1.2.2/wasm';
const MODEL_URL = IS_APP ? '/mediapipe/face_landmarker.task' : 'https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task';

let landmarkerPromise: Promise<FaceLandmarkerType> | null = null;
function getLandmarker(): Promise<FaceLandmarkerType> {
  if (!landmarkerPromise) {
    landmarkerPromise = (async () => {
      const { FaceLandmarker, FilesetResolver } = await import('@mediapipe/tasks-vision');
      const fileset = await FilesetResolver.forVisionTasks(WASM_URL);
      return FaceLandmarker.createFromOptions(fileset, {
        baseOptions: { modelAssetPath: MODEL_URL, delegate: 'CPU' },
        runningMode: 'IMAGE',
        numFaces: 4,
        outputFaceBlendshapes: true,
        outputFacialTransformationMatrixes: true,
      });
    })();
    landmarkerPromise = withTimeout(landmarkerPromise, MODEL_TIMEOUT_MS, 'Face Mesh model load').catch((e) => { landmarkerPromise = null; throw e; });
  }
  return landmarkerPromise;
}

interface LuminanceSource { source: HTMLImageElement | HTMLCanvasElement; luma?: Float32Array; w?: number; h?: number }

/**
 * The mesh model sees a luminance-only copy of the image, so colour cannot
 * influence landmarks or blendshapes (and hence no score). The SAME luminance
 * pixels are returned for the Skin & age measurement, so both see one image.
 * Falls back to the original element (no luma → skin group drops out) if the
 * canvas cannot be read.
 */
function toLuminanceSource(img: HTMLImageElement): LuminanceSource {
  try {
    const maxSide = 1536;
    const k = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
    const w = Math.max(1, Math.round(img.naturalWidth * k)), h = Math.max(1, Math.round(img.naturalHeight * k));
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const ctx = c.getContext('2d', { willReadFrequently: true })!;
    ctx.drawImage(img, 0, 0, w, h);
    const im = ctx.getImageData(0, 0, w, h);
    const d = im.data;
    const luma = new Float32Array(w * h);
    for (let i = 0; i < d.length; i += 4) {
      const y = 0.2126 * d[i] + 0.7152 * d[i + 1] + 0.0722 * d[i + 2];
      d[i] = d[i + 1] = d[i + 2] = y;
      luma[i / 4] = d[i]; // the quantised value the mesh model actually sees
    }
    ctx.putImageData(im, 0, 0);
    return { source: c, luma, w, h };
  } catch {
    return { source: img };
  }
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    const timer = setTimeout(() => { img.src = ''; reject(new Error('Image load timed out')); }, IMAGE_TIMEOUT_MS);
    img.onload = () => {
      clearTimeout(timer);
      if (!img.naturalWidth || !img.naturalHeight) reject(new Error('Image has no pixels'));
      else resolve(img);
    };
    img.onerror = () => { clearTimeout(timer); reject(new Error('Image failed to load')); };
    img.src = src;
  });
}

export async function loadPixelSafeImage(url: string): Promise<HTMLImageElement> {
  if (url.startsWith('blob:') || url.startsWith('data:') || url.startsWith(window.location.origin)) return loadImage(url);
  if (IS_APP) {
    // Android app: the phone's own HTTP client has no CORS rules, so read the bytes directly (replaces the server image relay).
    const http = (window as unknown as { Capacitor?: { Plugins?: { CapacitorHttp?: { get: (o: { url: string; responseType: string; headers?: Record<string, string> }) => Promise<{ status: number; data: string; headers: Record<string, string> }> } } } }).Capacitor?.Plugins?.CapacitorHttp;
    if (http) {
      try {
        const r = await http.get({ url, responseType: 'blob', headers: { Accept: 'image/avif,image/webp,image/*,*/*;q=0.8' } });
        const type = Object.entries(r.headers ?? {}).find(([k]) => k.toLowerCase() === 'content-type')?.[1] ?? 'image/jpeg';
        if (r.status >= 200 && r.status < 300 && typeof r.data === 'string' && r.data.length > 0) return await loadImage(`data:${type.split(';')[0]};base64,${r.data}`);
      } catch { /* fall through to a plain load */ }
    }
    return loadImage(url);
  }
  try {
    return await loadImage(`/api/public/image-proxy?url=${encodeURIComponent(url)}`);
  } catch {
    return loadImage(url);
  }
}

// ============================================================================
// Pixel statistics (all deterministic functions of RGB values)
// ============================================================================

type PixelStats = ScoringPixelStats;

function computePixelStats(img: HTMLImageElement, roi?: BoundingBox): { stats: PixelStats; roiSharpness?: number; roiOutsideSharpness?: number } {
  // 512 px keeps blur visible on large sources (256 px hid moderate blur).
  const S = 512;
  const ratio = img.naturalWidth / img.naturalHeight;
  const w = ratio >= 1 ? S : Math.round(S * ratio);
  const h = ratio >= 1 ? Math.round(S / ratio) : S;
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const ctx = c.getContext('2d', { willReadFrequently: true })!;
  ctx.drawImage(img, 0, 0, w, h);
  const d = ctx.getImageData(0, 0, w, h).data;
  const N = w * h;
  const L = new Float32Array(N);
  let sumL = 0, sumL2 = 0, clip = 0;
  let rL = 0, rL2 = 0, rCount = 0;
  for (let i = 0; i < N; i++) {
    const r = d[i * 4] / 255, g = d[i * 4 + 1] / 255, b = d[i * 4 + 2] / 255;
    const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    L[i] = lum; sumL += lum; sumL2 += lum * lum;
    if (lum < 0.02 || lum > 0.98) clip++;
    if (roi) {
      const nx = (i % w) / w, ny = Math.floor(i / w) / h;
      if (nx >= roi.x && nx <= roi.x + roi.width && ny >= roi.y && ny <= roi.y + roi.height) { rL += lum; rL2 += lum * lum; rCount++; }
    }
  }
  const meanLum = sumL / N;
  const stdLum = Math.sqrt(Math.max(0, sumL2 / N - meanLum * meanLum));

  let lapSum = 0, lapSum2 = 0, edges = 0, ex = 0, ey = 0, eSum = 0, mirrorErr = 0;
  let cS = 0, cN = 0, bS = 0, bN = 0, rS = 0, rN = 0, oS = 0, oN = 0;
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const i = y * w + x;
      const lap = 4 * L[i] - L[i - 1] - L[i + 1] - L[i - w] - L[i + w];
      lapSum += lap; lapSum2 += lap * lap;
      const gx = L[i + 1] - L[i - 1], gy = L[i + w] - L[i - w];
      const gm = Math.hypot(gx, gy);
      if (gm > 0.1) edges++;
      ex += x * gm; ey += y * gm; eSum += gm;
      const a = lap * lap;
      const nx = x / w, ny = y / h;
      if (nx > 0.25 && nx < 0.75 && ny > 0.25 && ny < 0.75) { cS += a; cN++; } else { bS += a; bN++; }
      if (roi) {
        if (nx >= roi.x && nx <= roi.x + roi.width && ny >= roi.y && ny <= roi.y + roi.height) { rS += a; rN++; } else { oS += a; oN++; }
      }
    }
  }
  let lH = 0, rH = 0, tH = 0, bH = 0;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const v = L[y * w + x];
    if (x < w / 2) { mirrorErr += Math.abs(v - L[y * w + (w - 1 - x)]); lH += v; } else rH += v;
    if (y < h / 2) tH += v; else bH += v;
  }
  const M = (w - 2) * (h - 2);
  const lapMean = lapSum / M;
  return {
    stats: {
      meanLum, stdLum, clipFraction: clip / N,
      laplacianVar: lapSum2 / M - lapMean * lapMean,
      edgeDensity: edges / M,
      mirrorSimilarity: 1 - mirrorErr / (N / 2),
      energyCentroid: { x: eSum ? ex / eSum / w : 0.5, y: eSum ? ey / eSum / h : 0.5 },
      centerSharpness: cN ? cS / cN : 0, borderSharpness: bN ? bS / bN : 0,
      leftRightLumDiff: (lH - rH) / (N / 2), topBottomLumDiff: (tH - bH) / (N / 2),
      width: img.naturalWidth, height: img.naturalHeight,
      ...(rCount > 16 ? { roiMeanLum: rL / rCount, roiStdLum: Math.sqrt(Math.max(0, rL2 / rCount - (rL / rCount) ** 2)) } : {}),
    },
    roiSharpness: rN ? rS / rN : undefined,
    roiOutsideSharpness: oN ? oS / oN : undefined,
  };
}

// ============================================================================
// Expression from blendshape coefficients
// ============================================================================

function classifyExpression(bs: Record<string, number>): { label: ExpressionLabel; confidence: number; detail: string } {
  const g = (k: string) => bs[k] ?? 0;
  const smile = (g('mouthSmileLeft') + g('mouthSmileRight')) / 2;
  const surprise = (g('eyeWideLeft') + g('eyeWideRight')) / 2 * 0.5 + g('browInnerUp') * 0.25 + g('jawOpen') * 0.25;
  const frown = (g('browDownLeft') + g('browDownRight')) / 2;
  const blink = (g('eyeBlinkLeft') + g('eyeBlinkRight')) / 2;
  const scores: Array<[ExpressionLabel, number]> = [
    ['happy', smile],
    ['surprised', surprise],
    ['thoughtful', frown],
    ['serene', Math.min(blink, 0.6) * (smile > 0.1 ? 1 : 0.5)],
  ];
  scores.sort((a, b) => b[1] - a[1]);
  const [label, v] = scores[0][1] >= 0.35 ? scores[0] : (['neutral', 1 - scores[0][1]] as [ExpressionLabel, number]);
  return {
    label, confidence: Math.max(0, Math.min(1, v)),
    detail: `Blendshapes — smile ${smile.toFixed(2)}, surprise ${surprise.toFixed(2)}, brow-down ${frown.toFixed(2)}, blink ${blink.toFixed(2)}. Highest activation ≥ 0.35 selects the label; otherwise neutral.`,
  };
}

function poseLabel(yaw: number, pitch: number): PoseLabel {
  if (yaw > 35) return 'profile-left';
  if (yaw < -35) return 'profile-right';
  if (pitch > 15) return 'tilted-up';
  if (pitch < -15) return 'tilted-down';
  if (yaw > 10) return 'slight-left';
  if (yaw < -10) return 'slight-right';
  return 'frontal';
}

function landmarksFromMesh(p: Vec3[]): FacialLandmarks {
  const P = (i: number) => ({ x: p[i].x, y: p[i].y });
  const avg = (a: number, b: number) => ({ x: (p[a].x + p[b].x) / 2, y: (p[a].y + p[b].y) / 2 });
  return {
    leftEye: p.length > 473 ? P(468) : avg(33, 133),
    rightEye: p.length > 473 ? P(473) : avg(263, 362),
    noseTip: P(1), noseBridge: P(168),
    mouthLeft: P(61), mouthRight: P(291),
    chin: P(152), forehead: P(10),
    leftCheek: P(234), rightCheek: P(454),
    leftBrow: P(105), rightBrow: P(334),
    leftEar: P(127), rightEar: P(356),
  };
}

function bboxOf(p: Vec3[]): BoundingBox {
  let x0 = 1, y0 = 1, x1 = 0, y1 = 0;
  for (const q of p.slice(0, 468)) { x0 = Math.min(x0, q.x); y0 = Math.min(y0, q.y); x1 = Math.max(x1, q.x); y1 = Math.max(y1, q.y); }
  return { x: x0, y: y0, width: x1 - x0, height: y1 - y0 };
}

// ============================================================================
// MAIN DETECTION FUNCTION
// ============================================================================

/** Number of extra zoomed passes (crop size = face size × factor). */
export const PRECISION_CROP_FACTORS = [1.5, 1.75, 2.0, 2.3, 2.6];

function refineByAveraging(
  lm: FaceLandmarkerType,
  src: HTMLImageElement | HTMLCanvasElement,
  base: Vec3[],
  baseBlend?: Array<{ categoryName: string; score: number }>,
): { points: Vec3[]; passes: number; blend?: Array<{ categoryName: string; score: number; index: number; displayName: string }> } {
  const W0 = src instanceof HTMLCanvasElement ? src.width : src.naturalWidth;
  const H0 = src instanceof HTMLCanvasElement ? src.height : src.naturalHeight;
  let minX = 1, minY = 1, maxX = 0, maxY = 0;
  for (const p of base) { minX = Math.min(minX, p.x); maxX = Math.max(maxX, p.x); minY = Math.min(minY, p.y); maxY = Math.max(maxY, p.y); }
  const cx = ((minX + maxX) / 2) * W0, cy = ((minY + maxY) / 2) * H0;
  const side = Math.max((maxX - minX) * W0, (maxY - minY) * H0);
  const n = base.length;
  const sum = base.map((p) => ({ x: p.x, y: p.y, z: p.z }));
  const bsum = new Map<string, number>((baseBlend ?? []).map((c) => [c.categoryName, c.score]));
  let passes = 1, bpasses = baseBlend?.length ? 1 : 0;
  for (const f of PRECISION_CROP_FACTORS) {
    const cs = Math.round(side * f);
    const x0 = Math.round(cx - cs / 2), y0 = Math.round(cy - cs / 2);
    const c = document.createElement('canvas');
    const scale = Math.min(4, 1024 / cs);
    c.width = c.height = Math.max(64, Math.round(cs * scale));
    const ctx = c.getContext('2d');
    if (!ctx) continue;
    ctx.fillStyle = '#808080'; ctx.fillRect(0, 0, c.width, c.height);
    ctx.drawImage(src, x0, y0, cs, cs, 0, 0, c.width, c.height);
    const r = lm.detect(c);
    if (!r?.faceLandmarks?.length) continue;
    // the face closest to the crop centre is ours
    let bi = -1, bd = Infinity;
    r.faceLandmarks.forEach((f2, i) => { if (!isValidFaceMesh(f2)) return; const d = Math.hypot(f2[1].x - 0.5, f2[1].y - 0.5); if (d < bd) { bd = d; bi = i; } });
    const pts = r.faceLandmarks[bi];
    if (!pts || pts.length !== n || bd > 0.25) continue;
    const mapped = pts.map((p) => ({ x: (x0 + p.x * cs) / W0, y: (y0 + p.y * cs) / H0, z: (p.z * cs) / W0 }));
    if (!isValidFaceMesh(mapped)) continue;
    // reject a pass that disagrees wildly with the first (wrong face / failed fit)
    let err = 0; for (let i = 0; i < n; i += 7) err += Math.hypot(mapped[i].x - base[i].x, mapped[i].y - base[i].y);
    if (err / Math.ceil(n / 7) > 0.08 * Math.max(maxX - minX, 1e-6)) continue;
    mapped.forEach((p, i) => { sum[i].x += p.x; sum[i].y += p.y; sum[i].z += p.z; });
    passes++;
    const cats = r.faceBlendshapes?.[bi]?.categories;
    if (cats?.length && bpasses) { cats.forEach((cat) => bsum.set(cat.categoryName, (bsum.get(cat.categoryName) ?? 0) + cat.score)); bpasses++; }
  }
  const points = sum.map((p) => ({ x: p.x / passes, y: p.y / passes, z: p.z / passes }));
  const blend = bpasses ? (baseBlend ?? []).map((cat, index) => ({ categoryName: cat.categoryName, displayName: cat.categoryName, index, score: (bsum.get(cat.categoryName) ?? 0) / bpasses })) : undefined;
  return { points, passes, blend };
}

export async function detectFaces(
  imageUrl: string,
  _imageId: string,
  onLog?: (entry: AnalysisLogEntry) => void,
): Promise<FaceDetectionResult> {
  const logs: AnalysisLogEntry[] = [];
  let step = 0;
  const log = (label: string, detail: string, category: AnalysisLogEntry['category'], value?: string, confidence?: number) => {
    const entry: AnalysisLogEntry = { step: ++step, label, detail, category, value, confidence };
    logs.push(entry); onLog?.(entry);
  };
  const empty = (extra: Partial<FaceDetectionResult> = {}): FaceDetectionResult => ({
    detected: false, faceCount: 0, faces: [], primaryFaceIndex: -1,
    expression: 'neutral', expressionConfidence: 0, pose: 'frontal', poseConfidence: 0, logs, ...extra,
  });

  let img: HTMLImageElement;
  try {
    img = await loadPixelSafeImage(imageUrl);
  } catch {
    log('Image Load', 'The image pixels could not be read (blocked or unavailable). No measurements were possible.', 'detection', 'Unreadable', 0);
    return empty();
  }
  log('Image Load', `Decoded ${img.naturalWidth}×${img.naturalHeight} px.`, 'detection', `${img.naturalWidth}×${img.naturalHeight}`, 1);

  let result: ReturnType<FaceLandmarkerType['detect']> | null = null;
  let lum: LuminanceSource = { source: img };
  try {
    const lm = await getLandmarker();
    lum = toLuminanceSource(img);
    result = lm.detect(lum.source);
    // The mesh model is short-range: a small face in a full-body / wide shot is
    // often missed. Retry on zoomed, overlapping crops (upper area first, where
    // heads usually are) and map landmarks back to full-image coordinates.
    if (!result?.faceLandmarks?.length) {
      const src = lum.source;
      const W0 = src instanceof HTMLCanvasElement ? src.width : src.naturalWidth;
      const H0 = src instanceof HTMLCanvasElement ? src.height : src.naturalHeight;
      const crops: Array<[number, number, number, number]> = [];
      for (const s of [0.6, 0.4]) {
        const step = s / 2;
        for (let y = 0; y + s <= 1.0001; y += step) for (let x = 0; x + s <= 1.0001; x += step) crops.push([x, y, s, s]);
      }
      for (const [cx, cy, cs] of crops) {
        const cw = Math.round(cs * W0), ch = Math.round(cs * H0);
        const x0 = Math.round(cx * W0), y0 = Math.round(cy * H0);
        const c = document.createElement('canvas');
        const scale = Math.min(4, 1024 / Math.max(cw, ch));
        c.width = Math.round(cw * scale); c.height = Math.round(ch * scale);
        c.getContext('2d')!.drawImage(src, x0, y0, cw, ch, 0, 0, c.width, c.height);
        const r = lm.detect(c);
        if (r?.faceLandmarks?.length) {
          r.faceLandmarks = r.faceLandmarks.map((f) => f.map((p) => ({ ...p, x: (x0 + p.x * cw) / W0, y: (y0 + p.y * ch) / H0, z: p.z * cw / W0 })));
          log('Face Mesh', `Face found on a zoomed crop (small face in a wide shot).`, 'detection', 'Zoomed', 1);
          result = r;
          break;
        }
      }
    }
  } catch (e) {
    log('Face Mesh', `Face Mesh model could not run: ${(e as Error).message}`, 'detection', 'Error', 0);
  }

  // Keep the original model indexes: filtering a damaged face must not attach
  // another person's expression or pose matrix to a surviving face.
  const validIndexes = (result?.faceLandmarks ?? []).flatMap((f, i) => isValidFaceMesh(f) ? [i] : []);
  const faces: Vec3[][] = validIndexes.map((i) => result?.faceLandmarks[i] ?? []);
  if (!faces.length) {
    const { stats } = computePixelStats(img);
    log('Face Mesh', 'MediaPipe Face Mesh found no face. Scores below are computed from pixel statistics only.', 'detection', 'No face', 1);
    logPixelStats(stats, log);
    return empty({ pixelStats: stats } as Partial<FaceDetectionResult>);
  }

  try {
    // Primary face = largest bounding-box area
    const boxes = faces.map(bboxOf);
    const order = boxes.map((b, i) => [b.width * b.height, i] as const).sort((a, b) => b[0] - a[0]).map(([, i]) => i);
    const primaryIdx = order[0];
    // Precision mode: re-measure the main face on several zoomed, slightly different crops
    // and average every one of the 478 points (and the expression readings). Single-pass
    // landmark jitter is the biggest noise source in symmetry / ratio numbers; averaging
    // N passes cuts it by ~1/√N. Costs a few extra seconds — owner's choice.
    try {
      const lm = await getLandmarker();
      const sourceIdx = validIndexes[primaryIdx];
      const refined = refineByAveraging(lm, lum.source, faces[primaryIdx], result?.faceBlendshapes?.[sourceIdx]?.categories);
      if (refined.passes > 1) {
        faces[primaryIdx] = refined.points;
        const shape = result?.faceBlendshapes?.[sourceIdx];
        if (shape && refined.blend) shape.categories = refined.blend as never;
        log('Precision', `Main face measured ${refined.passes}× on zoomed crops; all ${refined.points.length} points averaged for steadier numbers.`, 'detection', `${refined.passes} passes`, 1);
      }
    } catch { /* keep single pass */ }
    const W = img.naturalWidth, H = img.naturalHeight;

    log('Face Mesh', `${faces.length} face(s) located. Each carries ${faces[primaryIdx].length} 3D landmarks (468 mesh + ${faces[primaryIdx].length - 468} iris).`, 'detection', `${faces.length} face(s)`, 1);

    const matrices = (result as unknown as { facialTransformationMatrixes?: Array<{ data: number[] }> })?.facialTransformationMatrixes;
    const detectedFaces: DetectedFace[] = order.map((fi, rank) => {
      const sourceIdx = validIndexes[fi];
      const bs = Object.fromEntries((result?.faceBlendshapes?.[sourceIdx]?.categories ?? []).map((c) => [c.categoryName, c.score]));
      // Skin & age: pixels from the same luminance canvas the mesh model saw (undefined → group drops out).
      let skin: ReturnType<typeof analyzeSkin>;
      try { skin = lum.luma ? analyzeSkin(lum.luma, lum.w!, lum.h!, faces[fi]) : undefined; } catch { skin = undefined; }
      const geo = analyzeFaceGeometry(faces[fi], W, H, matrices?.[sourceIdx]?.data, bs, skin);
      const ex = classifyExpression(bs);
      return {
        index: rank,
        boundingBox: boxes[fi],
        landmarks: landmarksFromMesh(faces[fi]),
        meshLandmarks: faces[fi].map(({ x, y, z }) => ({ x, y, z })),
        expression: ex.label, expressionConfidence: ex.confidence,
        pose: poseLabel(geo.yaw, geo.pitch),
        poseConfidence: geo.confidence,
        isPrimary: rank === 0,
        geometry: geo,
      } as DetectedFace;
    });

    const primary = detectedFaces[0];
    const geo = primary.geometry!;
    const bs = Object.fromEntries((result?.faceBlendshapes?.[validIndexes[primaryIdx]]?.categories ?? []).map((c) => [c.categoryName, c.score]));
    const ex = classifyExpression(bs);

    log('Pose (3D mesh)', `Landmarks frontalised onto the fitted 3D symmetry plane before any 2D measurement. Yaw ${geo.yaw.toFixed(1)}°, pitch ${geo.pitch.toFixed(1)}°, roll ${geo.roll.toFixed(1)}°; measurement confidence ${(geo.confidence * 100).toFixed(0)}%.`, 'pose', primary.pose, primary.poseConfidence);
    log('Bilateral Symmetry', `${geo.pairsUsed} landmark pairs mirrored across the fitted midline: 3D offset ${(geo.pairAsymmetry * 100).toFixed(2)}% of IPD → ${geo.pairSymmetry.toFixed(1)}; frontalised 2D offset ${(geo.frontalAsymmetry * 100).toFixed(2)}% → ${geo.frontalSymmetry.toFixed(1)}. All ${geo.meshPointsUsed} mesh points mirror (Chamfer) distance ${(geo.meshMirrorDistance * 100).toFixed(2)}% IPD → ${geo.meshSymmetry.toFixed(1)}.`, 'landmarks', `${geo.symmetryPercent.toFixed(1)}%`, 1);
    for (const r of geo.ratios) {
      log(r.label, `${r.formula} = ${r.measured.toFixed(3)} (ideal ${r.ideal.toFixed(3)}, ${r.reference}). Deviation ${(r.deviation * 100).toFixed(1)}% (z ${r.z.toFixed(2)}σ) → score ${r.score.toFixed(1)}.`, 'landmarks', r.score.toFixed(0), 1);
    }
    const mj = geo.mouthJaw;
    log('Mouth & Jaw integrity', `${mj.terms.map((t) => `${t.label} ${(t.measured * 100).toFixed(1)}% → ${t.score.toFixed(0)} (w ${t.weight})`).join('; ')}. Weighted power mean (p = ${MOUTH_JAW_POWER}) = ${mj.score.toFixed(1)}. Mouth openness ${(mj.mouthOpenness * 100).toFixed(0)}% of mouth width is informational only.`, 'landmarks', mj.score.toFixed(1), 1);
    if (geo.skin) {
      const k = geo.skin;
      log('Skin & age', `Cheek detail ${k.skinDetail.toFixed(4)} ÷ eye detail ${k.eyeDetail.toFixed(4)} = ratio ${k.ratio.toFixed(3)} → raw ${k.rawScore.toFixed(1)}; IPD ${k.ipdPx.toFixed(0)} px, ${k.skinSamples} cheek samples (${(k.maskedFraction * 100).toFixed(0)}% masked as hair/shadow), confidence ${(k.confidence * 100).toFixed(0)}% → score ${k.score.toFixed(1)}.`, 'landmarks', k.score.toFixed(1), k.confidence);
    } else {
      log('Skin & age', 'Not measurable (pixels unavailable or the face is too small / out of frame). The skin group is left out and the other weights are renormalised.', 'landmarks', 'n/a', 0);
    }
    if (geo.expression) {
      const e = geo.expression;
      log('Expression', `Blendshape aggregate ${e.intensity.toFixed(2)}; left/right asymmetry ${e.asymmetry.toFixed(3)}. Scored in the harmony — extreme expressions lower the score and only slightly widen σ of ratios they physically move (load ${geo.expressionLoad.toFixed(2)} → σ × ${(1 + EXPRESSION_SIGMA_GAIN * geo.expressionLoad).toFixed(2)}).`, 'expression', e.score.toFixed(1), 1);
    } else {
      log('Expression Intensity', 'The model returned no blendshapes; expression is not shown (the expression group is left out of the score).', 'expression', 'n/a', 0);
    }
    log('Facial Harmony', `Weighted power mean (p = ${HARMONY_POWER}) of ${geo.groups.map((g) => `${g.weight.toFixed(2)}×${g.label.toLowerCase()} ${g.score.toFixed(1)}`).join(', ')} = ${geo.facialHarmony.toFixed(1)}.`, 'aesthetic', geo.facialHarmony.toFixed(1), 1);
    if (!geo.reliable) log('Reliability', geo.reliabilityNote!, 'pose', 'Reduced', 0.5);
    log('Expression', ex.detail, 'expression', ex.label, ex.confidence);

    const { stats, roiSharpness, roiOutsideSharpness } = computePixelStats(img, primary.boundingBox);
    logPixelStats(stats, log);

    const lightingDirection: FaceDetectionResult['lightingDirection'] =
      Math.abs(stats.leftRightLumDiff) > 0.08 ? 'side' : stats.topBottomLumDiff > 0.08 ? 'top' : stats.stdLum < 0.15 ? 'diffuse' : 'front';

    return {
      detected: true,
      faceCount: faces.length,
      faces: detectedFaces,
      primaryFaceIndex: 0,
      boundingBox: primary.boundingBox,
      landmarks: primary.landmarks,
      expression: ex.label, expressionConfidence: ex.confidence,
      pose: primary.pose, poseConfidence: primary.poseConfidence,
      lightingDirection,
      focusQuality: Math.min(1, Math.sqrt(stats.laplacianVar) / 0.08),
      geometry: geo,
      pixelStats: { ...stats, roiSharpness, roiOutsideSharpness },
      logs,
    } as FaceDetectionResult;
  } catch (e) {
    log('Face Mesh', `Landmark geometry could not be evaluated (${(e as Error).message}). Falling back to pixel statistics.`, 'detection', 'Fallback', 0.3);
    const { stats } = computePixelStats(img);
    logPixelStats(stats, log);
    return empty({ pixelStats: stats } as Partial<FaceDetectionResult>);
  }
}

function logPixelStats(s: PixelStats, log: (l: string, d: string, c: AnalysisLogEntry['category'], v?: string, conf?: number) => void) {
  log('Luminance', `Mean ${s.meanLum.toFixed(3)}, RMS contrast ${s.stdLum.toFixed(3)}, clipped ${(s.clipFraction * 100).toFixed(1)}%.`, 'lighting', s.meanLum.toFixed(2), 1);
    log('Sharpness', `Laplacian variance ${s.laplacianVar.toExponential(2)}, edge density ${(s.edgeDensity * 100).toFixed(1)}%.`, 'aesthetic', `${(s.edgeDensity * 100).toFixed(0)}% edges`, 1);
}

// ============================================================================
// METRIC DERIVATION — each metric is a closed-form function of measurements
// ============================================================================

export function deriveMetricsFromFace(face: FaceDetectionResult): MetricScores {
  const s = (face as FaceDetectionResult & { pixelStats?: PixelStats }).pixelStats;
  const g = face.geometry;
  return deriveMetrics({ stats: s, boundingBox: face.boundingBox, symmetry: g?.symmetryPercent, roll: g?.roll, goldenRatioIndex: g?.goldenRatioIndex, structuralBalanceIndex: g?.structuralBalanceIndex, alignmentIndex: g?.alignmentIndex, skinScore: g?.skin?.score });
}

/** Technical image quality (0–1) used by the overall score. */
export function imageQualityOf(face: FaceDetectionResult): number {
  return technicalQuality((face as FaceDetectionResult & { pixelStats?: PixelStats }).pixelStats);
}
