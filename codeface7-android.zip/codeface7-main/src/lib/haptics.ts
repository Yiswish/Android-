export function haptic(pattern: 'light' | 'medium' | 'heavy' | 'success' | 'error' | 'selection' = 'light') {
  if (typeof navigator === 'undefined' || !navigator.vibrate) return;
  const patterns: Record<string, number | number[]> = {
    light: 10,
    medium: 20,
    heavy: 40,
    success: [10, 30, 10],
    error: [40, 20, 40],
    selection: 8,
  };
  navigator.vibrate(patterns[pattern]);
}
