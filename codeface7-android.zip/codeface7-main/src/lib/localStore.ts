// Device-side copy of everything the user saves (IndexedDB). History survives closing the app
// even when the online store is unreachable; the online store is merged in when it answers.
const DB_NAME = 'aesthetics-local';
const STORES = ['analyses', 'ratings', 'favourites'] as const;
type StoreName = (typeof STORES)[number];

let dbPromise: Promise<IDBDatabase> | null = null;
function open(): Promise<IDBDatabase> {
  if (typeof indexedDB === 'undefined') return Promise.reject(new Error('no indexedDB'));
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => { STORES.forEach((s) => { if (!req.result.objectStoreNames.contains(s)) req.result.createObjectStore(s); }); };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => { dbPromise = null; reject(req.error); };
    });
    // Ask the browser not to evict our data under storage pressure.
    navigator.storage?.persist?.().catch(() => {});
  }
  return dbPromise;
}

function tx<T>(store: StoreName, mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T> | void): Promise<T | undefined> {
  return open().then((db) => new Promise<T | undefined>((resolve, reject) => {
    const t = db.transaction(store, mode);
    const r = fn(t.objectStore(store));
    t.oncomplete = () => resolve(r ? r.result : undefined);
    t.onerror = () => reject(t.error);
  }));
}

export async function localPut<T>(store: StoreName, key: string, value: T): Promise<void> {
  try { await tx(store, 'readwrite', (s) => s.put(value, key)); } catch (e) { console.warn('Local save failed:', e); }
}
export async function localGet<T>(store: StoreName, key: string): Promise<T | undefined> {
  try { return (await tx<T>(store, 'readonly', (s) => s.get(key) as IDBRequest<T>)) ?? undefined; } catch { return undefined; }
}
export async function localAll<T>(store: StoreName): Promise<T[]> {
  try { return ((await tx<T[]>(store, 'readonly', (s) => s.getAll() as IDBRequest<T[]>)) ?? []); } catch { return []; }
}
export async function localClear(store: StoreName): Promise<void> {
  try { await tx(store, 'readwrite', (s) => s.clear()); } catch { /* ignore */ }
}
