import { searchImagesServer } from './search.functions';
import type { SearchResultImage, SearchResponse, ImageSource, SearchFilters, CacheEntry, SearchStatus } from './types';
import { archetypes } from './archetypes';
import { personalSearchKeys, personalKeyRevision } from './personalKeys';
import { searchPhotoLabel } from './photoLabel';

// ============================================================================
// SEARCH CACHE — In-memory cache with TTL to prevent rate limits
// ============================================================================

const CACHE_TTL = 5 * 60 * 1000; // 5 minutes — primary provider (SerpAPI) results only
/** Fallback results (Openverse / Wikimedia / curated) are kept briefly so a restored key or quota is noticed quickly. */
const FALLBACK_CACHE_TTL = 20 * 1000;
const cache = new Map<string, CacheEntry>();

function cacheKey(query: string, source: ImageSource, page: number, perPage: number, portraitMode: 'young' | 'all-ages'): string {
  return `${source}:${query}:${page}:${perPage}:${portraitMode}:revision-${personalKeyRevision()}`;
}

function getCached(key: string): SearchResponse | null {
  const entry = cache.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    cache.delete(key);
    return null;
  }
  return { ...entry.response, cached: true };
}

function setCached(key: string, response: SearchResponse): void {
  const primary = response.status?.provider === 'serpapi';
  cache.set(key, {
    key,
    response,
    timestamp: Date.now(),
    expiresAt: Date.now() + (primary ? CACHE_TTL : FALLBACK_CACHE_TTL),
  });
}

export function clearSearchCache(): void {
  cache.clear();
}

export function getCacheStats(): { size: number; keys: string[] } {
  return { size: cache.size, keys: Array.from(cache.keys()) };
}

// ============================================================================
// CURATED FALLBACK POOL — Always available even without network
// ============================================================================

const curatedPool: SearchResultImage[] = [
  { id: 'cur-1', url: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800', thumbUrl: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=400', width: 800, height: 1200, alt: 'Minimalist architecture', source: 'curated', category: 'minimalist', orientation: 'portrait' },
  { id: 'cur-2', url: 'https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&cs=tinysrgb&w=800', thumbUrl: 'https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&cs=tinysrgb&w=400', width: 800, height: 1200, alt: 'Warm earth interior', source: 'curated', category: 'warm-earth', orientation: 'portrait' },
  { id: 'cur-3', url: 'https://images.pexels.com/photos/1693095/pexels-photo-1693095.jpeg?auto=compress&cs=tinysrgb&w=800', thumbUrl: 'https://images.pexels.com/photos/1693095/pexels-photo-1693095.jpeg?auto=compress&cs=tinysrgb&w=400', width: 800, height: 1200, alt: 'Moody portrait', source: 'curated', category: 'moody-noir', orientation: 'portrait' },
  { id: 'cur-4', url: 'https://images.pexels.com/photos/167964/pexels-photo-167964.jpeg?auto=compress&cs=tinysrgb&w=800', thumbUrl: 'https://images.pexels.com/photos/167964/pexels-photo-167964.jpeg?auto=compress&cs=tinysrgb&w=400', width: 800, height: 1200, alt: 'Vibrant pop colors', source: 'curated', category: 'vibrant-pop', orientation: 'portrait' },
  { id: 'cur-5', url: 'https://images.pexels.com/photos/326311/pexels-photo-326311.jpeg?auto=compress&cs=tinysrgb&w=800', thumbUrl: 'https://images.pexels.com/photos/326311/pexels-photo-326311.jpeg?auto=compress&cs=tinysrgb&w=400', width: 800, height: 1200, alt: 'Natural organic green', source: 'curated', category: 'natural-organic', orientation: 'portrait' },
  { id: 'cur-6', url: 'https://images.pexels.com/photos/1758144/pexels-photo-1758144.jpeg?auto=compress&cs=tinysrgb&w=800', thumbUrl: 'https://images.pexels.com/photos/1758144/pexels-photo-1758144.jpeg?auto=compress&cs=tinysrgb&w=400', width: 800, height: 1200, alt: 'Editorial chic fashion', source: 'curated', category: 'editorial-chic', orientation: 'portrait' },
  { id: 'cur-7', url: 'https://images.pexels.com/photos/2255701/pexels-photo-2255701.jpeg?auto=compress&cs=tinysrgb&w=800', thumbUrl: 'https://images.pexels.com/photos/2255701/pexels-photo-2255701.jpeg?auto=compress&cs=tinysrgb&w=400', width: 800, height: 1200, alt: 'Vintage film aesthetic', source: 'curated', category: 'vintage-film', orientation: 'portrait' },
  { id: 'cur-8', url: 'https://images.pexels.com/photos/302769/pexels-photo-302769.jpeg?auto=compress&cs=tinysrgb&w=800', thumbUrl: 'https://images.pexels.com/photos/302769/pexels-photo-302769.jpeg?auto=compress&cs=tinysrgb&w=400', width: 800, height: 1200, alt: 'Architectural structure', source: 'curated', category: 'architectural', orientation: 'portrait' },
  { id: 'cur-9', url: 'https://images.pexels.com/photos/1029604/pexels-photo-1029604.jpeg?auto=compress&cs=tinysrgb&w=800', thumbUrl: 'https://images.pexels.com/photos/1029604/pexels-photo-1029604.jpeg?auto=compress&cs=tinysrgb&w=400', width: 800, height: 1200, alt: 'Minimalist still life', source: 'curated', category: 'minimalist', orientation: 'portrait' },
  { id: 'cur-10', url: 'https://images.pexels.com/photos/2467558/pexels-photo-2467558.jpeg?auto=compress&cs=tinysrgb&w=800', thumbUrl: 'https://images.pexels.com/photos/2467558/pexels-photo-2467558.jpeg?auto=compress&cs=tinysrgb&w=400', width: 800, height: 1200, alt: 'Warm sunset tones', source: 'curated', category: 'warm-earth', orientation: 'portrait' },
  { id: 'cur-11', url: 'https://images.pexels.com/photos/1148998/pexels-photo-1148998.jpeg?auto=compress&cs=tinysrgb&w=800', thumbUrl: 'https://images.pexels.com/photos/1148998/pexels-photo-1148998.jpeg?auto=compress&cs=tinysrgb&w=400', width: 800, height: 1200, alt: 'Dark moody landscape', source: 'curated', category: 'moody-noir', orientation: 'portrait' },
  { id: 'cur-12', url: 'https://images.pexels.com/photos/158028/pexels-photo-158028.jpeg?auto=compress&cs=tinysrgb&w=800', thumbUrl: 'https://images.pexels.com/photos/158028/pexels-photo-158028.jpeg?auto=compress&cs=tinysrgb&w=400', width: 800, height: 1200, alt: 'Bold colorful pattern', source: 'curated', category: 'vibrant-pop', orientation: 'portrait' },
  { id: 'cur-13', url: 'https://images.pexels.com/photos/3617457/pexels-photo-3617457.jpeg?auto=compress&cs=tinysrgb&w=800', thumbUrl: 'https://images.pexels.com/photos/3617457/pexels-photo-3617457.jpeg?auto=compress&cs=tinysrgb&w=400', width: 800, height: 600, alt: 'Natural botanical scene', source: 'curated', category: 'natural-organic', orientation: 'landscape' },
  { id: 'cur-14', url: 'https://images.pexels.com/photos/3753938/pexels-photo-3753938.jpeg?auto=compress&cs=tinysrgb&w=800', thumbUrl: 'https://images.pexels.com/photos/3753938/pexels-photo-3753938.jpeg?auto=compress&cs=tinysrgb&w=400', width: 800, height: 1200, alt: 'Editorial fashion portrait', source: 'curated', category: 'editorial-chic', orientation: 'portrait' },
  { id: 'cur-15', url: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=800', thumbUrl: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=400', width: 800, height: 600, alt: 'Vintage retro scene', source: 'curated', category: 'vintage-film', orientation: 'landscape' },
  { id: 'cur-16', url: 'https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&w=800', thumbUrl: 'https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&w=400', width: 800, height: 1200, alt: 'Modern architecture', source: 'curated', category: 'architectural', orientation: 'portrait' },
];

// ============================================================================
// FILTER LOGIC
// ============================================================================

function matchCategory(query: string): string | null {
  const lower = query.toLowerCase();
  for (const archetype of archetypes) {
    if (archetype.keywords.some((kw) => lower.includes(kw))) {
      return archetype.id;
    }
  }
  return null;
}

function inferOrientation(width: number, height: number): 'landscape' | 'portrait' | 'square' {
  if (width > height * 1.15) return 'landscape';
  if (height > width * 1.15) return 'portrait';
  return 'square';
}

export function applyFilters(images: SearchResultImage[], filters: SearchFilters): SearchResultImage[] {
  return images.filter((img) => {
    if (filters.orientation !== 'all') {
      const orient = img.orientation ?? inferOrientation(img.width, img.height);
      if (orient !== filters.orientation) return false;
    }
    if (filters.category !== 'all') {
      const cat = img.category ?? matchCategory(img.alt) ?? '';
      if (cat !== filters.category) return false;
    }
    return true;
  });
}

export const defaultFilters: SearchFilters = {
  orientation: 'all',
  category: 'all',
};

// ============================================================================
// CURATED FALLBACK
// ============================================================================

function getCuratedImages(query: string, page: number, perPage: number): SearchResultImage[] {
  const cat = matchCategory(query);
  let pool = curatedPool;
  if (cat) {
    const filtered = curatedPool.filter((img) => img.category === cat);
    if (filtered.length > 0) pool = filtered;
  }
  const start = (page - 1) * perPage;
  const sliced = pool.slice(start, start + perPage);
  if (sliced.length < perPage && sliced.length > 0) {
    const remaining = perPage - sliced.length;
    const extra = pool.slice(0, remaining).map((img, i) => ({
      ...img,
      id: `${img.id}-p${page}-${i}`,
    }));
    return [...sliced, ...extra];
  }
  return sliced.length > 0 ? sliced : pool.slice(0, perPage);
}

// ============================================================================
// SEARCH API
// ============================================================================

export interface SearchOptions {
  query: string;
  portraitMode?: 'young' | 'all-ages';
  page?: number;
  perPage?: number;
  source?: ImageSource;
  filters?: SearchFilters;
}

export async function searchImages(opts: SearchOptions): Promise<SearchResponse> {
  const { query, page = 1, perPage = 12, source = 'google', portraitMode = 'young' } = opts;
  const key = cacheKey(query, source, page, perPage, portraitMode);

  // Check cache first
  // Personal requests must reach the server each time so owner locks take effect.
  const cached = Object.keys(personalSearchKeys()).length ? null : getCached(key);
  if (cached) return cached;

  let response: SearchResponse | null = null;
  let failure: SearchStatus | undefined;

  if (source !== 'upload' && source !== 'curated') {
    const r = await searchViaEdgeFunction(query, source, page, perPage, portraitMode);
    response = r.response;
    failure = r.failure;
  }

  if (!response) {
    // Never silent: the curated pool is returned together with the reason.
    const images = getCuratedImages(query, page, perPage);
    response = {
      images,
      totalCount: images.length,
      hasMore: true,
      nextPage: page + 1,
      source: 'curated',
      status: failure ?? { provider: 'curated', fallbackReason: 'network' },
    };
  }

  // Post-process: enrich images with inferred orientation/category if missing
  response.images = response.images.map((img) => ({
    ...img,
    searchLabel: searchPhotoLabel(img, query),
    orientation: img.orientation ?? inferOrientation(img.width, img.height),
    category: img.category ?? matchCategory(img.alt) ?? matchCategory(query) ?? undefined,
  }));

  // Display thumbnails go through the same-origin relay (no hotlink / CORS problems).
  response.images = response.images.map((img) => (img.source === 'upload' ? img : { ...img, thumbUrl: proxied(img.thumbUrl) }));

  setCached(key, response);
  return response;
}

const proxied = (url: string) => (import.meta.env.VITE_MOBILE !== '1' && /^https?:\/\//i.test(url) ? `/api/public/image-proxy?url=${encodeURIComponent(url)}` : url);

async function searchViaEdgeFunction(
  query: string,
  source: ImageSource,
  page: number,
  perPage: number,
  portraitMode: 'young' | 'all-ages',
): Promise<{ response: SearchResponse | null; failure?: SearchStatus }> {
  try {
    const data = await searchImagesServer({ data: { query, page, perPage, source, portraitMode, personalKeys: personalSearchKeys() } });
    const status = data?.status as SearchStatus | undefined;
    if (!data || !data.images || data.images.length === 0) {
      console.error('[search] no live provider returned images', status?.attempts);
      return { response: null, failure: status ?? { provider: 'curated', fallbackReason: 'empty' } };
    }
    return {
      response: {
        images: data.images as SearchResultImage[],
        totalCount: data.totalCount ?? data.images.length,
        hasMore: data.hasMore ?? true,
        nextPage: data.hasMore ? page + 1 : undefined,
        source: data.images[0].source as ImageSource,
        status,
      },
    };
  } catch {
    console.error('[search] server function failed');
    return { response: null, failure: { provider: 'curated', fallbackReason: 'network', attempts: [{ provider: 'server', reason: 'network', message: 'Search is unavailable. Check key settings and try again.' }] } };
  }
}

// Build an image from an uploaded file (object URL)
export function createUploadedImage(url: string, fileName: string): SearchResultImage {
  return {
    id: `upload-${Date.now()}-${Math.random().toString(36).slice(2)}`,
    url,
    thumbUrl: url,
    width: 800,
    height: 800,
    alt: fileName,
    source: 'upload',
    orientation: 'square',
  };
}
