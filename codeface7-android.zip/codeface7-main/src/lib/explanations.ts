import type { AnalysisResult, Archetype } from './types';
import { archetypes } from './archetypes';
import { scoreLabel, DISAGREEMENT_THRESHOLD } from './scoring';
import type { FaceGeometryReport, HarmonyGroupId } from './faceGeometry';

/** Plain-language driver of one harmony group, built from the numbers that produced it. */
function groupSentence(g: FaceGeometryReport, id: HarmonyGroupId, low: boolean): string {
  const f = (n: number, d = 1) => n.toFixed(d);
  switch (id) {
    case 'skin': {
      const k = g.skin;
      if (!k) return 'Skin & age could not be measured, so it is left out of the score.';
      return low
        ? `Skin detail was high relative to the eyes (ratio ${f(k.ratio, 2)}; cheek detail ${f(k.skinDetail, 3)} vs eye detail ${f(k.eyeDetail, 3)}), which lowered the Skin & age group to ${f(k.score, 0)}. Wrinkles, rough texture or visible grain all read this way.`
        : `Skin detail was low relative to the eyes (ratio ${f(k.ratio, 2)}), giving Skin & age ${f(k.score, 0)}. Note that heavy retouching also lowers this ratio.`;
    }
    case 'symmetry':
      return low
        ? `Left/right landmark residuals were large (3D ${f(g.pairAsymmetry * 100, 2)}% of IPD, 2D ${f(g.frontalAsymmetry * 100, 2)}%), lowering symmetry to ${f(g.symmetryPercent, 0)}.`
        : `The mesh found no notable left/right asymmetry (symmetry ${f(g.symmetryPercent, 0)}; mesh symmetry is a lower bound on real asymmetry).`;
    case 'structure': {
      const worst = [...g.ratios].filter((r) => r.group === 'structure').sort((a, b) => b.z - a.z)[0];
      return low && worst
        ? `Structural proportions deviate most in “${worst.label}” (${f(worst.measured, 2)} vs reference ${f(worst.ideal, 2)}, z ${f(worst.z, 1)}σ), giving structure ${f(g.structuralBalanceIndex, 0)}.`
        : `Structural proportions (thirds, fifths, jaw/cheek, fWHR) sit close to the reference ranges (${f(g.structuralBalanceIndex, 0)}).`;
    }
    case 'golden': {
      const worst = [...g.ratios].filter((r) => r.group === 'golden').sort((a, b) => b.z - a.z)[0];
      return low && worst
        ? `The golden-ratio group is held back by “${worst.label}” (${f(worst.measured, 2)} vs ${f(worst.ideal, 2)}, z ${f(worst.z, 1)}σ): ${f(g.goldenRatioIndex, 0)}.`
        : `Golden-ratio proportions are close to the reference (${f(g.goldenRatioIndex, 0)}).`;
    }
    case 'alignment':
      return low ? `Feature alignment (canthal tilt, nose midline, alar balance) is off by more than normal variation: ${f(g.alignmentIndex, 0)}.` : `Features are well aligned (${f(g.alignmentIndex, 0)}).`;
    case 'mouthJaw': {
      const worst = [...g.mouthJaw.terms].sort((a, b) => a.score - b.score)[0];
      return low ? `Mouth/jaw integrity is reduced mainly by ${worst.label.toLowerCase()} (score ${f(worst.score, 0)}).` : `Mouth, lip-contour and jaw outlines are bilaterally consistent (${f(g.mouthJawScore, 0)}).`;
    }
    default:
      return '';
  }
}

export function generateExplanation(result: AnalysisResult): string[] {
  const explanations: string[] = [];
  const { scores, faceDetection } = result;
  const g = faceDetection.geometry;

  // Overall: what the number is, and what actually drove it.
  explanations.push(
    `This image scores ${scores.overall}/100 (${scoreLabel(scores.overall)}): how closely the face matches the measured proportion, symmetry and skin-detail model, with photography as a ≤20% multiplier. It is not a verdict on a person.`,
  );

  if (g) {
    const scored = g.groups.filter((x) => x.weight > 0 && x.id !== 'expression');
    // Drag = how many points each group removes relative to a perfect score, weighted by its share.
    const ranked = [...scored].sort((a, b) => b.weight * (100 - b.score) - a.weight * (100 - a.score));
    const worst = ranked[0];
    const best = [...scored].sort((a, b) => b.score - a.score)[0];
    if (worst && worst.score < 82) explanations.push(`Biggest drag: ${groupSentence(g, worst.id, true)}`);
    if (ranked[1] && ranked[1].score < 72) explanations.push(groupSentence(g, ranked[1].id, true));
    if (best && best.score >= 85 && best.id !== worst?.id) explanations.push(`Strongest: ${groupSentence(g, best.id, false)}`);
    if (!g.skin) explanations.push(groupSentence(g, 'skin', true));
    if (!g.reliable) explanations.push(`Head pose reduced measurement confidence to ${(g.confidence * 100).toFixed(0)}%, which shrinks high scores part-way toward neutral.`);
  }


  if (!faceDetection.detected) {
    explanations.push('No face detected — the analysis focuses on photographic composition, light and form; no facial geometry was measurable.');
  }

  return explanations;
}

/**
 * One plain-words sentence on WHY the overall sits where it does — shown under
 * the score ring instead of the raw formula (owner's rule: no number spam).
 */
export function overallSummary(result: AnalysisResult): string | undefined {
  const b = result.scores.breakdown;
  if (!b || b.faceScore === undefined) return undefined;
  if (result.scores.finalAnalyst) return 'The final analyst set this overall after weighing the photo, the AI score and the measurements.';
  const parts: string[] = [];
  const ai = result.scores.aiLook?.attractiveness;
  if (ai !== undefined && Number.isFinite(ai)) {
    const gap = Math.abs(ai - b.faceScore);
    if (gap > DISAGREEMENT_THRESHOLD) {
      parts.push(ai < b.faceScore
        ? 'The AI look check rates this face well below the measurements, so the overall meets in the middle.'
        : 'The AI look check rates this face well above the measurements, so the overall meets in the middle.');
    } else {
      parts.push('The measurements and the AI look check roughly agree.');
    }
  }
  return parts.length ? parts.join(' ') : undefined;
}

export function generateComparisonSummary(results: AnalysisResult[]): string {
  if (results.length < 2) return 'Select at least two images to compare.';

  const top = [...results].sort((a, b) => b.scores.overall - a.scores.overall);
  const best = top[0];
  const worst = top[top.length - 1];
  const spread = best.scores.overall - worst.scores.overall;

  let summary = `The strongest image scores ${best.scores.overall}/100`;
  summary += `, while the weakest scores ${worst.scores.overall}/100`;
  summary += `. The aesthetic spread between them is ${spread} points`;

  if (spread < 10) summary += ' — they are fairly similar in aesthetic quality.';
  else if (spread < 25) summary += ' — there is a noticeable difference in execution.';
  else summary += ' — they occupy quite different aesthetic territory.';

  return summary;
}

export function getArchetypeSuggestions(results: AnalysisResult[]): Archetype[] {
  const archetypeScores: Record<string, number> = {};
  for (const r of results) {
    for (const ta of r.topArchetypes) {
      if (!archetypeScores[ta.archetype.id]) archetypeScores[ta.archetype.id] = 0;
      archetypeScores[ta.archetype.id] += ta.match;
    }
  }
  return archetypes
    .map((a) => ({ archetype: a, score: archetypeScores[a.id] ?? 0 }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .map((x) => x.archetype);
}
