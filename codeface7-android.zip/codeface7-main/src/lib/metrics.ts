import type { MetricKey, MetricScores, AestheticScores, Archetype } from './types';
import { archetypes } from './archetypes';
import type { FaceGeometryReport } from './faceGeometry';

// Strictly clamp a value between 0 and 100
export function clampScore(value: number): number {
  if (Number.isNaN(value) || !Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(100, Math.round(value)));
}

// Clamp every metric in a MetricScores object
export function clampMetricScores(scores: MetricScores): MetricScores {
  const result = {} as MetricScores;
  (Object.keys(scores) as MetricKey[]).forEach((key) => {
    result[key] = clampScore(scores[key]);
  });
  return result;
}

export function clampAestheticScores(scores: AestheticScores): AestheticScores {
  const clampedMatch: Record<string, number> = {};
  (Object.keys(scores.archetypeMatch) as string[]).forEach((key) => {
    clampedMatch[key] = clampScore(scores.archetypeMatch[key]);
  });
  return {
    ...scores,
    overall: clampScore(scores.overall),
    metrics: clampMetricScores(scores.metrics),
    archetypeMatch: clampedMatch,
  };
}

// Compute cosine similarity between a metric vector and an archetype profile (0–100)
function cosineSimilarity(a: MetricScores, b: MetricScores): number {
  const keys = Object.keys(a) as MetricKey[];
  let dot = 0;
  let normA = 0;
  let normB = 0;
  for (const key of keys) {
    dot += a[key] * b[key];
    normA += a[key] * a[key];
    normB += b[key] * b[key];
  }
  if (normA === 0 || normB === 0) return 0;
  return (dot / (Math.sqrt(normA) * Math.sqrt(normB))) * 100;
}

export function computeArchetypeMatch(metrics: MetricScores): Record<string, number> {
  const match: Record<string, number> = {};
  for (const archetype of archetypes) {
    match[archetype.id] = clampScore(cosineSimilarity(metrics, archetype.metricProfile));
  }
  return match;
}

export { METRIC_WEIGHTS, FACE_WEIGHT, FACE_SHARE, PHOTO_SHARE } from './scoring';
import { METRIC_LABELS } from './metricKeys';
import { METRIC_WEIGHTS, SCORING_VERSION, computeOverall, type OverallBreakdown } from './scoring';

export function computeOverallScore(metrics: MetricScores): number {
  return clampScore(computeOverall(metrics).overall);
}

/** Overall from metrics (+ optional facial harmony). Smooth power mean — no caps. */
export function computeStrictOverall(metrics: MetricScores, facialHarmony?: number, quality?: number, confidence?: number): number {
  return clampScore(computeOverall(metrics, { facialHarmony, quality, confidence }).overall);
}

export function computeAestheticScores(
  metrics: MetricScores,
  geometry?: FaceGeometryReport,
  quality?: number,
): AestheticScores & { breakdown: OverallBreakdown } {
  const clamped = clampMetricScores(metrics);
  const archetypeMatch = computeArchetypeMatch(clamped);
  void quality; // photography quality is already inside the ≤20% photo share
  const breakdown = computeOverall(clamped, {
    facialHarmony: geometry?.facialHarmony,
    confidence: geometry?.confidence ?? 1,
  });
  return { overall: clampScore(breakdown.overall), scoringVersion: SCORING_VERSION, metrics: clamped, archetypeMatch, breakdown };
}

// Get top N archetypes sorted by match score
export function getTopArchetypes(
  scores: AestheticScores,
  archetypesList: Archetype[],
  n: number = 3,
): Array<{ archetype: Archetype; match: number }> {
  return archetypesList
    .map((archetype) => ({
      archetype,
      match: scores.archetypeMatch[archetype.id] ?? 0,
    }))
    .sort((a, b) => b.match - a.match)
    .slice(0, n);
}

// Feature importance: which metrics contribute most to the overall score
export function computeFeatureImportance(metrics: MetricScores): Array<{ metric: MetricKey; label: string; importance: number; value: number }> {
  const weights = METRIC_WEIGHTS;
  const labels = METRIC_LABELS;
  return (Object.keys(weights) as MetricKey[])
    .map((key) => ({
      metric: key,
      label: labels[key],
      importance: Math.round(weights[key] * 1000) / 10,
      value: metrics[key],
    }))
    .sort((a, b) => b.importance - a.importance);
}
