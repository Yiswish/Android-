// Teaches the AI body rater the user's taste: the user's own 1-100 slider ratings are
// paired with what the AI said for the same photo and sent as examples with every new rating.
import type { AnalysisResult, BodyLook, UserBodyRating } from './types';

export const BODY_PARTS = ['proportions', 'physique', 'posture', 'presentation'] as const;
export type BodyPart = (typeof BODY_PARTS)[number];
export const BODY_KEYS = ['overall', ...BODY_PARTS] as const;
export type BodyKey = (typeof BODY_KEYS)[number];

export interface BodyExample {
  bodyType: string;
  ai: Record<BodyKey, number>;
  user: Record<BodyKey, number>;
}

export const MAX_BODY_EXAMPLES = 25;
const clamp100 = (n: number) => Math.max(1, Math.min(100, Math.round(n)));

/** Clamps every slider value to whole numbers 1-100. */
export function cleanUserBody(r: Record<BodyKey, number>, at = Date.now()): UserBodyRating {
  const out = { at } as UserBodyRating;
  for (const k of BODY_KEYS) out[k] = clamp100(Number.isFinite(r[k]) ? r[k] : 50);
  return out;
}

const pick = (b: BodyLook | UserBodyRating): Record<BodyKey, number> =>
  Object.fromEntries(BODY_KEYS.map((k) => [k, Math.round(b[k])])) as Record<BodyKey, number>;

/** Most recent photos the user rated that also have a visible AI body rating. */
export function bodyExamples(results: AnalysisResult[], max = MAX_BODY_EXAMPLES): BodyExample[] {
  const seen = new Set<string>();
  return results
    .filter((r) => r.scores.userBody && r.scores.bodyLook?.visible)
    .sort((a, b) => (b.scores.userBody!.at ?? 0) - (a.scores.userBody!.at ?? 0))
    .filter((r) => (seen.has(r.imageId) ? false : (seen.add(r.imageId), true)))
    .slice(0, max)
    .map((r) => ({ bodyType: r.scores.bodyLook!.bodyType || '', ai: pick(r.scores.bodyLook!), user: pick(r.scores.userBody!) }));
}

/** Average (user − AI) gap per section. */
export function bodyOffsets(examples: BodyExample[]): Record<BodyKey, number> {
  const out = Object.fromEntries(BODY_KEYS.map((k) => [k, 0])) as Record<BodyKey, number>;
  if (!examples.length) return out;
  for (const k of BODY_KEYS) out[k] = Math.round(examples.reduce((s, e) => s + (e.user[k] - e.ai[k]), 0) / examples.length);
  return out;
}

/** Prompt text appended to the body rater so it copies the user's scale. */
export function bodyExamplesPrompt(examples: BodyExample[]): string {
  if (!examples.length) return '';
  const off = bodyOffsets(examples);
  const lines = examples.map((e, i) =>
    `${i + 1}. type "${e.bodyType || '?'}": you said ${BODY_KEYS.map((k) => `${k} ${e.ai[k]}`).join(', ')} → the user's correct scores: ${BODY_KEYS.map((k) => `${k} ${e.user[k]}`).join(', ')}`);
  const guide = BODY_KEYS.map((k) => `- ${k}: ${BODY_GUIDE[k]}`).join('\n');
  return `\n\nThe user rates each section 1-100 with these meanings:\n${guide}\n\nTHE USER'S TASTE (most important). The user corrected your earlier ratings of other photos. Learn their scale, which body types they rate high or low, and score this photo the way THEY would. Pay most attention to examples with the same body type, and notice which sections they consistently push up or down:\n${lines.join('\n')}\nOn average the user's scores differ from yours by: ${BODY_KEYS.map((k) => `${k} ${off[k] >= 0 ? '+' : ''}${off[k]}`).join(', ')}.`;
}

/** Short plain explanation of each section, shown beside the sliders and sent to the AI so both use the same meaning. */
export const BODY_GUIDE: Record<BodyKey, string> = {
  overall: 'Your gut score for the whole body together, not an average.',
  proportions: 'Balance of shoulders, waist and hips, and leg length vs. torso.',
  physique: 'Muscle tone, firmness and fitness level.',
  posture: 'How straight and confidently the body is carried.',
  presentation: 'How well the pose and clothing fit show the body off.',
};

const norm = (t: string) => t.trim().toLowerCase();

/**
 * Corrects a fresh AI rating with what the user taught it. The prompt already shows the examples;
 * this nudges any remaining gap: half the average gap for photos of the same body type (when there
 * are 2+), plus a smaller share of the general gap, growing with how many ratings exist.
 */
export function calibrateBody<T extends Record<BodyKey, number> & { bodyType: string }>(ai: T, examples: BodyExample[]): { value: T; shift: number } {
  if (!examples.length) return { value: ai, shift: 0 };
  const same = examples.filter((e) => e.bodyType && norm(e.bodyType) === norm(ai.bodyType));
  const all = bodyOffsets(examples);
  const typed = same.length >= 2 ? bodyOffsets(same) : null;
  const trust = Math.min(1, examples.length / 10);
  const out = { ...ai };
  for (const k of BODY_KEYS) {
    const adj = (typed ? 0.5 * typed[k] : 0) + 0.25 * trust * all[k];
    out[k] = clamp100(ai[k] + adj) as T[typeof k];
  }
  return { value: out, shift: Math.round(out.overall - ai.overall) };
}
