import { findBody } from './bodyDetection';
// Browser side of the AI look check: shrink the photo, ask the server, blend into the overall.
import type { AestheticScores, BodyLook } from './types';
import type { BodyExample } from './bodyTeaching';
import type { FaceExample } from './faceTeaching';
import { loadPixelSafeImage, withTimeout } from './faceDetection';
import { judgeLookServer, judgeLookBatchServer, judgeFinalServer, judgeBodyServer } from './aiLook.functions';
import { createRateLimiter, createMicroBatcher } from './aiBatching';
import { takeKeyTurns } from './aiKeys';
import { blendOverall, SCORING_VERSION } from './scoring';
import { clampScore } from './metrics';
import { personalKeys } from './personalKeys';

const MAX_SIDE = 768;

const browserStorage = () => (typeof localStorage !== 'undefined' ? localStorage : undefined);

async function toDataUrl(url: string): Promise<string> {
  const img = await loadPixelSafeImage(url);
  const k = Math.min(1, MAX_SIDE / Math.max(img.naturalWidth, img.naturalHeight));
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(img.naturalWidth * k));
  c.height = Math.max(1, Math.round(img.naturalHeight * k));
  const context = c.getContext('2d');
  if (!context) throw new Error('Could not read the photo.');
  context.drawImage(img, 0, 0, c.width, c.height);
  return c.toDataURL('image/jpeg', 0.85);
}

/** Returns new scores with the AI look blended into `overall` (or an error note; never throws). */
type LookAnswer = Awaited<ReturnType<typeof judgeLookServer>>;

/** Free Gemini keys allow ~15 requests per minute; every AI look request from this tab waits its turn. */
export const AI_REQUESTS_PER_MINUTE = 15;
const lookLimiter = createRateLimiter(AI_REQUESTS_PER_MINUTE, 60_000);
/** Collects photos for a moment and sends up to 4 in one request (Best section). */
const lookBatcher = createMicroBatcher<string, LookAnswer>({
  maxSize: 4,
  waitMs: 400,
  run: async (images) => {
    await lookLimiter.take();
    const start = takeKeyTurns(browserStorage(), images.length);
    if (images.length === 1) return [await judgeLookServer({ data: { image: images[0], start, personalKeys: personalKeys().gemini, examples: faceTeach } })];
    const r = await judgeLookBatchServer({ data: { images, start, personalKeys: personalKeys().gemini, examples: faceTeach } });
    return r.ok ? (r.results as LookAnswer[]) : images.map(() => r as LookAnswer);
  },
});

/** History multi-select: up to 10 photos in ONE request (one AI use). */
export const HISTORY_BATCH_MAX = 10;
const historyBatcher = createMicroBatcher<string, LookAnswer>({
  maxSize: HISTORY_BATCH_MAX,
  waitMs: 1500,
  run: async (images) => {
    await lookLimiter.take();
    const start = takeKeyTurns(browserStorage(), images.length);
    if (images.length === 1) return [await judgeLookServer({ data: { image: images[0], start, personalKeys: personalKeys().gemini, examples: faceTeach } })];
    const r = await judgeLookBatchServer({ data: { images, start, personalKeys: personalKeys().gemini, examples: faceTeach } });
    return r.ok ? (r.results as LookAnswer[]) : images.map(() => r as LookAnswer);
  },
});

export async function applyAiLook(scores: AestheticScores, imageUrl: string, opts: { aiOnly?: boolean; batch?: boolean; bigBatch?: boolean } = {}): Promise<AestheticScores> {
  try {
    const image = await toDataUrl(imageUrl);
    const r = opts.bigBatch
      ? await withTimeout(historyBatcher.add(image), 180000, 'AI look check')
      : opts.batch
      ? await withTimeout(lookBatcher.add(image), 120000, 'AI look check')
      : await withTimeout(lookLimiter.take().then(() => judgeLookServer({ data: { image, start: takeKeyTurns(browserStorage()), personalKeys: personalKeys().gemini, examples: faceTeach } })), 90000, 'AI look check');
    if (!r.ok) return { ...scores, aiLookError: r.error };
    const geometryOverall = scores.overall;
    const b = scores.breakdown;
    // v2: AI 40% + geometry face 40%, photography a soft ≤20% multiplier (see scoring.ts).
    const blend = b?.faceScore !== undefined ? blendOverall(b.faceScore, r.attractiveness, b.photoScore) : undefined;
    // No face mesh (side profile, strong angle): the AI judgement alone is the score.
    const overall = clampScore(opts.aiOnly ? r.attractiveness : blend ? blend.overall : geometryOverall);
    const breakdown = opts.aiOnly ? (b ? { ...b, overall, formula: `AI ${Math.round(r.attractiveness)} (no face mesh — side/angled view, AI only)` } : b) : b && blend ? { ...b, overall, formula: blend.formula } : b;
    return {
      ...scores, overall, breakdown, scoringVersion: SCORING_VERSION,
      aiLook: { categories: r.categories, rawAttractiveness: r.rawAttractiveness, tasteRatingsUsed: r.tasteRatingsUsed, attractiveness: r.attractiveness, typeMatch: r.typeMatch, reasons: r.reasons, description: r.description, keyIndex: r.keyIndex, keyCount: r.keyCount, geometryOverall, faceScore: b?.faceScore, disagreementPenalty: blend?.penalty },
    };
  } catch (e) {
    return { ...scores, aiLookError: e instanceof Error && /timed out/i.test(e.message) ? 'The AI look check took too long.' : 'The AI look check could not read this photo.' };
  }
}

/** What the final analyst is told: AI score + notes and the measurement scores. */
export function finalAnalystInput(scores: AestheticScores) {
  const ai = scores.aiLook;
  if (!ai) return null;
  const metrics: Record<string, number> = {};
  for (const [k, v] of Object.entries(scores.metrics ?? {})) if (typeof v === 'number' && Number.isFinite(v)) metrics[k] = clampScore(v);
  const opt = (n: number | undefined) => (typeof n === 'number' && Number.isFinite(n) ? clampScore(n) : undefined);
  return {
    aiScore: clampScore(ai.attractiveness), aiReasons: ai.reasons.slice(0, 6),
    measurementOverall: clampScore(ai.geometryOverall), faceScore: opt(ai.faceScore ?? scores.breakdown?.faceScore), photoScore: opt(scores.breakdown?.photoScore), metrics,
  };
}

/** Puts the final analyst's verdict in place: only `overall` changes; the AI look score stays as it is. */
export function withFinalVerdict(scores: AestheticScores, v: { overall: number; passes: number[]; spread: number; reasons: string[]; keys: number[]; keyCount: number }): AestheticScores {
  const previousOverall = scores.finalAnalyst?.previousOverall ?? scores.overall;
  const overall = clampScore(v.overall);
  const formula = `final analyst ${v.passes.map((p) => Math.round(p)).join(' / ')} → median ${Math.round(v.overall)} (weighed AI ${Math.round(scores.aiLook?.attractiveness ?? 0)} + measurements)`;
  return {
    ...scores, overall, scoringVersion: SCORING_VERSION,
    breakdown: scores.breakdown ? { ...scores.breakdown, overall, formula } : scores.breakdown,
    finalAnalyst: { overall, passes: v.passes, spread: v.spread, reasons: v.reasons, keys: v.keys, keyCount: v.keyCount, previousOverall, at: Date.now() },
  };
}

/** "Way off": a separate final analyst weighs the AI look and the measurements; its verdict becomes the overall. */
export async function applyFinalAnalyst(scores: AestheticScores, imageUrl: string): Promise<{ scores: AestheticScores } | { error: string }> {
  const input = finalAnalystInput(scores);
  if (!input) return { error: 'The AI look check needs to work first — try again in a moment.' };
  try {
    const image = await toDataUrl(imageUrl);
    const start = takeKeyTurns(browserStorage(), 3);
    const r = await withTimeout(judgeFinalServer({ data: { image, start, ...input, personalKeys: personalKeys().gemini } }), 150000, 'Final analyst');
    if (!r.ok) return { error: r.error };
    return { scores: withFinalVerdict(scores, r) };
  } catch (e) {
    return { error: e instanceof Error && /timed out/i.test(e.message) ? 'The final analyst took too long.' : 'The final analyst could not read this photo.' };
  }
}

let bodyTeach: BodyExample[] = [];
let faceTeach: FaceExample[] = [];
/** The user's face slider ratings + category labels, sent as examples with every AI look check. */
export function setFaceExamples(examples: FaceExample[]): void { faceTeach = examples; }
/** The user's slider ratings (with the AI's own answers) sent as examples with every body rating. */
export function setBodyExamples(examples: BodyExample[]): void { bodyTeach = examples; }

/** Whole-body rating for a photo (never throws). Runs alongside the face check. */
export async function getBodyLook(imageUrl: string): Promise<{ bodyLook: BodyLook } | { bodyLookError: string }> {
  try {
    const image = await toDataUrl(imageUrl);
    let body;
    try { body = await findBody(image); } catch { return { bodyLookError: 'The body detector could not load. Check your connection and try again.' }; }
    if (!body.found) return { bodyLookError: body.reason };
    const r = await withTimeout(judgeBodyServer({ data: { image, start: takeKeyTurns(browserStorage()), personalKeys: personalKeys().gemini, examples: bodyTeach } }), 45000, 'Body rating');
    if (!r.ok) return { bodyLookError: r.error };
    const { ok: _ok, ...rest } = r;
    return { bodyLook: { ...rest, at: Date.now() } };
  } catch (e) {
    return { bodyLookError: e instanceof Error && /timed out/i.test(e.message) ? 'The body rating took too long.' : 'The body rating could not read this photo.' };
  }
}

/** Puts a body rating on the scores without touching the face overall. */
export function withBodyLook(scores: AestheticScores, b: { bodyLook: BodyLook } | { bodyLookError: string }): AestheticScores {
  const { bodyLook: _b, bodyLookError: _e, ...rest } = scores;
  return 'bodyLook' in b ? { ...rest, bodyLook: b.bodyLook } : { ...rest, ...(scores.bodyLook ? { bodyLook: scores.bodyLook } : {}), bodyLookError: b.bodyLookError };
}

/** Face + body together: the plain mean of the face overall and the body overall. */
export function fullLookScore(scores: AestheticScores): number | null {
  const b = scores.bodyLook;
  if (!b || !b.visible) return null;
  return clampScore((scores.overall + b.overall) / 2);
}
