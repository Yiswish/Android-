import type {
  AnalysisResult,
  PreferenceProfile,
  MetricKey,
  MetricScores,
  ExpressionLabel,
  PoseLabel,
  ImageSource,
  StarRating,
  TasteMatch,
  FavouriteRanking,
} from './types';
import { clampScore, clampMetricScores } from './metrics';
import { archetypes } from './archetypes';
import { METRIC_KEYS, FACE_METRICS, METRIC_LABELS, emptyMetrics, normalizeMetrics } from './metricKeys';

const metricLabels = METRIC_LABELS;

export function buildPreferenceProfile(results: AnalysisResult[]): PreferenceProfile {
  if (results.length === 0) {
    return {
      totalImagesAnalyzed: 0,
      averageScores: emptyMetrics(0),
      topArchetypes: [],
      preferredMetrics: [],
      preferredExpressions: [],
      preferredPoses: [],
      preferredSources: [],
      preferenceStrength: 0,
      lastUpdated: Date.now(),
    };
  }

  const sumMetrics: MetricScores = emptyMetrics(0);
  const counts: MetricScores = emptyMetrics(0);
  const archetypeTotals: Record<string, { sum: number; count: number }> = {};
  const expressionCounts: Partial<Record<ExpressionLabel, number>> = {};
  const poseCounts: Partial<Record<PoseLabel, number>> = {};
  const sourceCounts: Partial<Record<ImageSource, number>> = {};

  for (const result of results) {
    for (const key of METRIC_KEYS) {
      const v = result.scores.metrics[key];
      if (Number.isFinite(v)) { sumMetrics[key] += v; counts[key]++; }
    }
    for (const ta of result.topArchetypes) {
      if (!archetypeTotals[ta.archetype.id]) archetypeTotals[ta.archetype.id] = { sum: 0, count: 0 };
      archetypeTotals[ta.archetype.id].sum += ta.match;
      archetypeTotals[ta.archetype.id].count++;
    }
    if (result.faceDetection.detected) {
      const expr = result.faceDetection.expression;
      expressionCounts[expr] = (expressionCounts[expr] ?? 0) + 1;
      const pose = result.faceDetection.pose;
      poseCounts[pose] = (poseCounts[pose] ?? 0) + 1;
    }
    sourceCounts[result.source] = (sourceCounts[result.source] ?? 0) + 1;
  }

  const avgMetrics = clampMetricScores(
    Object.fromEntries(METRIC_KEYS.map((k) => [k, counts[k] ? sumMetrics[k] / counts[k] : 0])) as MetricScores,
  );

  const topArchetypes = Object.entries(archetypeTotals)
    .map(([id, { sum, count }]) => ({
      archetypeId: id,
      name: archetypes.find((a) => a.id === id)?.name ?? id,
      avgMatch: clampScore(sum / count),
    }))
    .sort((a, b) => b.avgMatch - a.avgMatch)
    .slice(0, 5);

  const preferredMetrics = METRIC_KEYS
    .map((key) => ({ metric: key, label: metricLabels[key], value: avgMetrics[key] }))
    .sort((a, b) => b.value - a.value);

  const preferredExpressions = (Object.entries(expressionCounts) as [ExpressionLabel, number][])
    .map(([label, count]) => ({ label, count }))
    .sort((a, b) => b.count - a.count);
  const preferredPoses = (Object.entries(poseCounts) as [PoseLabel, number][])
    .map(([label, count]) => ({ label, count }))
    .sort((a, b) => b.count - a.count);
  const preferredSources = (Object.entries(sourceCounts) as [ImageSource, number][])
    .map(([source, count]) => ({ source, count }))
    .sort((a, b) => b.count - a.count);

  const metricVariance = METRIC_KEYS.reduce((acc, k) => acc + Math.abs(avgMetrics[k] - 50), 0) / METRIC_KEYS.length;
  const preferenceStrength = clampScore(metricVariance * 2) / 100;

  return {
    totalImagesAnalyzed: results.length,
    averageScores: avgMetrics,
    topArchetypes,
    preferredMetrics,
    preferredExpressions,
    preferredPoses,
    preferredSources,
    preferenceStrength,
    lastUpdated: Date.now(),
  };
}

// ============================================================================
// TASTE MODEL v2 — learns from the user's star ratings
// ----------------------------------------------------------------------------
// Features: every metric + the overall score, standardised against the user's
// OWN rated images (so "high" means high for what you look at, not > 50).
// Relevance: each feature is weighted by its squared correlation with your
// stars, so metrics you don't care about stop diluting similarity.
// Prediction = blend of
//   • kernel regression over rated images (adaptive bandwidth), and
//   • a correlation-weighted linear trend,
// shrunk toward your average when few ratings exist.
// Score = where the prediction ranks among the images you've rated (0–100).
// Confidence = how much better than "always guess your average" the model is
// in leave-one-out tests — honest, measured, not a guess.
// The taste match is shown next to — never mixed into — the geometric score.
// ============================================================================
export const TASTE_MIN_RATINGS = 3;
/**
 * Extra face features without a metric key: geometry groups (expression, mouth & jaw, alignment)
 * and — v2 — the AI look check's whole-face appeal and "your type" scores, which carry far more
 * of what people actually rate on than the landmark ratios do.
 */
export type ExtraFeature = 'mouthJaw' | 'alignment' | 'aiLook' | 'aiType';
export type TasteExtras = Partial<Record<ExtraFeature, number>>;
const GEOMETRY_EXTRAS: ExtraFeature[] = ['mouthJaw', 'alignment'];
const EXTRA_FEATURES: ExtraFeature[] = [...GEOMETRY_EXTRAS, 'aiLook', 'aiType'];
const EXTRA_LABELS: Record<ExtraFeature, string> = { mouthJaw: 'Mouth & jaw', alignment: 'Alignment', aiLook: 'AI look', aiType: 'AI "your type"' };
type Feature = MetricKey | 'overall' | ExtraFeature;
// Taste learns from the FACE only (owner's rule): photo metrics (lighting, composition,
// sharpness, contrast, naturalness) and the photo-weighted overall are ignored, so
// "why you like her" is about her face numbers, never the photography.
const FEATURES: Feature[] = [...FACE_METRICS, ...EXTRA_FEATURES];
const featureLabel = (f: Feature) => (f === 'overall' ? 'Overall score' : (EXTRA_LABELS as Record<string, string>)[f] ?? METRIC_LABELS[f as MetricKey]);
/** Pull the extra face-group scores out of a saved analysis (missing → neutral in the model). */
export function tasteExtrasOf(a?: Pick<AnalysisResult, 'faceDetection'> & { scores?: Pick<AnalysisResult['scores'], 'aiLook'> }): TasteExtras {
  const groups = a?.faceDetection?.geometry?.groups ?? [];
  const out: TasteExtras = {};
  for (const g of groups) if ((GEOMETRY_EXTRAS as string[]).includes(g.id)) out[g.id as ExtraFeature] = g.score;
  const ai = a?.scores?.aiLook;
  if (ai && Number.isFinite(ai.attractiveness)) out.aiLook = ai.attractiveness;
  if (ai && Number.isFinite(ai.typeMatch)) out.aiType = ai.typeMatch;
  return out;
}

interface Sample { metrics: MetricScores; overall: number; stars: number; imageId: string; imageUrl?: string; extras?: TasteExtras; recency?: number; ts?: number; hidden?: boolean }
/**
 * Taste drifts. v2 recency is much stronger: a rating's weight halves every TASTE_HALF_LIFE
 * newer ratings AND every TASTE_HALF_LIFE_DAYS days, never below TASTE_RECENCY_FLOOR. GUESSED constants.
 */
export const TASTE_HALF_LIFE = 12;
export const TASTE_HALF_LIFE_DAYS = 21;
export const TASTE_RECENCY_FLOOR = 0.12;
/** Favourite-test winners pull their stars up (losers down) by at most this much. GUESS. */
export const FAVOURITE_STAR_NUDGE = 0.6;
export interface TasteModel {
  samples: Sample[];
  meanStars: number;
  sdStars: number;
  mean: Record<Feature, number>;
  sd: Record<Feature, number>;
  corr: Record<Feature, number>;
  weight: Record<Feature, number>;
  bandwidth: number;
  /** v3: ridge-regression weights on standardised features (stars per SD). */
  beta: Record<Feature, number>;
  /** v3: share of the kernel in the final blend (rest = ridge), picked by leave-one-out. */
  kernelShare: number;
  errorStars: number;
  baselineError: number;
  drivers: TasteMatch['drivers'];
}

const vec = (m: MetricScores, overall: number, extras: TasteExtras = {}) => ({ mouthJaw: NaN, alignment: NaN, aiLook: NaN, aiType: NaN, ...extras, ...normalizeMetrics(m), overall }) as Record<Feature, number>;

/** Recency-weighted statistics: recent ratings shape the correlations, not just the kernel. */
function fit(samples: Sample[]) {
  const n = samples.length;
  const rw = samples.map((x) => x.recency ?? 1);
  const W = rw.reduce((a, b) => a + b, 0) || 1;
  const wMean = (xs: number[]) => xs.reduce((a, x, i) => a + rw[i] * x, 0) / W;
  const stars = samples.map((x) => x.stars);
  const meanStars = n ? wMean(stars) : 3;
  const sdStars = n > 1 ? Math.sqrt((stars.reduce((a, x, i) => a + rw[i] * (x - meanStars) ** 2, 0) / W) * (n / (n - 1))) : 0;
  const mean = {} as Record<Feature, number>, sd = {} as Record<Feature, number>, corr = {} as Record<Feature, number>, weight = {} as Record<Feature, number>;
  const V = samples.map((x) => vec(x.metrics, x.overall, x.extras));
  for (const f of FEATURES) {
    const known = V.map((v) => v[f]).filter(Number.isFinite);
    const fill = known.length ? known.reduce((a, b) => a + b, 0) / known.length : 50;
    const xs = V.map((v) => (Number.isFinite(v[f]) ? v[f] : fill));
    const mx = n ? wMean(xs) : 50;
    const vx = xs.reduce((a, x, i) => a + rw[i] * (x - mx) ** 2, 0);
    mean[f] = mx; sd[f] = Math.max(4, n > 1 ? Math.sqrt((vx / W) * (n / (n - 1))) : 10);
    let cov = 0, vy = 0;
    xs.forEach((x, i) => { cov += rw[i] * (x - mx) * (stars[i] - meanStars); vy += rw[i] * (stars[i] - meanStars) ** 2; });
    const r = vx > 1e-9 && vy > 1e-9 ? cov / Math.sqrt(vx * vy) : 0;
    // small samples overstate correlation: shrink r toward 0 (v2: lighter shrink, n/(n+2), so ratings bite sooner)
    corr[f] = r * (n / (n + 2));
    // v2: |r|^1.5 instead of r² — moderately predictive features keep real weight.
    weight[f] = Math.abs(corr[f]) ** 1.5 + 0.005;
  }
  const wSum = FEATURES.reduce((a, f) => a + weight[f], 0);
  for (const f of FEATURES) weight[f] /= wSum;
  return { meanStars, sdStars, mean, sd, corr, weight };
}

type Fit = ReturnType<typeof fit>;
const zOf = (F: Fit, v: Record<Feature, number>) => Object.fromEntries(FEATURES.map((f) => [f, ((Number.isFinite(v[f]) ? v[f] : F.mean[f]) - F.mean[f]) / F.sd[f]])) as Record<Feature, number>;
const dist = (F: Fit, a: Record<Feature, number>, b: Record<Feature, number>) => Math.sqrt(FEATURES.reduce((s, f) => s + F.weight[f] * (a[f] - b[f]) ** 2, 0));

function bandwidthOf(F: Fit, Z: Record<Feature, number>[]) {
  const ds: number[] = [];
  for (let i = 0; i < Z.length; i++) for (let j = i + 1; j < Z.length; j++) ds.push(dist(F, Z[i], Z[j]));
  ds.sort((a, b) => a - b);
  const med = ds.length ? ds[Math.floor(ds.length / 2)] : 1;
  return Math.max(0.15, 0.45 * med); // v2: sharper kernel (was 0.6 × median) — closer neighbours decide
}

/** v3 ridge strength (in units of total recency weight). GUESSED. */
export const TASTE_RIDGE_LAMBDA = 2;
/** Kernel shares tried by leave-one-out; the one with the lowest error wins. */
const KERNEL_SHARES = [0, 0.25, 0.5, 0.75, 1];

/** Weighted ridge regression of (stars − mean) on z-features, solved by Gauss–Jordan. Skip index excluded. */
function ridgeFit(F: Fit, samples: Sample[], Z: Record<Feature, number>[], skip = -1): Record<Feature, number> {
  const d = FEATURES.length;
  const A = Array.from({ length: d }, (_, i) => Array.from({ length: d + 1 }, (_, j) => (i === j ? TASTE_RIDGE_LAMBDA : 0)));
  Z.forEach((z, k) => {
    if (k === skip) return;
    const w = samples[k].recency ?? 1, y = samples[k].stars - F.meanStars;
    for (let i = 0; i < d; i++) {
      const zi = z[FEATURES[i]];
      for (let j = 0; j < d; j++) A[i][j] += w * zi * z[FEATURES[j]];
      A[i][d] += w * zi * y;
    }
  });
  for (let c = 0; c < d; c++) {
    let p = c;
    for (let r = c + 1; r < d; r++) if (Math.abs(A[r][c]) > Math.abs(A[p][c])) p = r;
    [A[c], A[p]] = [A[p], A[c]];
    const piv = A[c][c] || 1e-9;
    for (let j = c; j <= d; j++) A[c][j] /= piv;
    for (let r = 0; r < d; r++) if (r !== c && A[r][c]) { const f = A[r][c]; for (let j = c; j <= d; j++) A[r][j] -= f * A[c][j]; }
  }
  return Object.fromEntries(FEATURES.map((f, i) => [f, Number.isFinite(A[i][d]) ? A[i][d] : 0])) as Record<Feature, number>;
}

function predict(F: Fit, h: number, samples: Sample[], Z: Record<Feature, number>[], z: Record<Feature, number>, skip = -1, beta?: Record<Feature, number>, kernelShare = 0.5) {
  let wSum = 0, sSum = 0;
  const ws: number[] = [];
  Z.forEach((zi, i) => {
    if (i === skip) { ws.push(0); return; }
    const w = Math.exp(-0.5 * (dist(F, z, zi) / h) ** 2) * (samples[i].recency ?? 1);
    ws.push(w); wSum += w; sSum += w * samples[i].stars;
  });
  const n = samples.length - (skip >= 0 ? 1 : 0);
  const kernel = wSum > 1e-9 ? sSum / wSum : F.meanStars;
  const b = beta ?? ridgeFit(F, samples, Z, skip);
  const lin = FEATURES.reduce((a, f) => a + b[f] * Math.max(-3, Math.min(3, z[f])), 0);
  const linear = F.meanStars + Math.max(-2.5, Math.min(2.5, lin));
  // Far from every rated photo the kernel knows nothing: lean on the ridge trend there.
  const coverage = wSum / (wSum + 0.3);
  const k = kernelShare * coverage;
  const raw = k * kernel + (1 - k) * linear;
  const lambda = n / (n + 1.5);
  const stars = Math.max(1, Math.min(5, F.meanStars + lambda * (raw - F.meanStars)));
  return { stars, ws, wSum };
}

export function recencyWeight(rank: number, ageMs: number): number {
  const days = Math.max(0, ageMs) / 86_400_000;
  return Math.max(TASTE_RECENCY_FLOOR, 0.5 ** (rank / TASTE_HALF_LIFE) * 0.5 ** (days / TASTE_HALF_LIFE_DAYS));
}

/** Star nudge from the favourite test: +FAVOURITE_STAR_NUDGE for a clear winner, − for a clear loser. */
export function favouriteNudge(f?: FavouriteRanking): number {
  if (!f || f.comparisons < 2) return 0;
  return Math.max(-FAVOURITE_STAR_NUDGE, Math.min(FAVOURITE_STAR_NUDGE, ((f.strength - 1500) / 200) * FAVOURITE_STAR_NUDGE));
}

export function buildTasteModel(results: AnalysisResult[], ratings: StarRating[], favourites: FavouriteRanking[] = []): TasteModel {
  const fav = new Map(favourites.map((f) => [f.imageId, f]));
  const latest = new Map<string, StarRating>();
  for (const r of ratings) {
    const prev = latest.get(r.imageId);
    if (!prev || r.timestamp > prev.timestamp) latest.set(r.imageId, r);
  }
  const byImage = new Map<string, AnalysisResult>();
  for (const a of results) if (!byImage.has(a.imageId)) byImage.set(a.imageId, a);
  const rated = [...latest.values()]
    .map((r) => ({ r, a: byImage.get(r.imageId) }))
    .filter((x): x is { r: StarRating; a: AnalysisResult } => !!x.a)
    .map(({ r, a }) => ({
      metrics: normalizeMetrics(a.scores?.metrics),
      overall: Number.isFinite(a.scores?.overall) ? a.scores.overall : 50,
      // v3: favourite-test wins lift any rating and losses lower it (was: only 4–5★ photos).
      stars: Math.max(1, Math.min(5, r.rating + favouriteNudge(fav.get(r.imageId)))),
      imageId: r.imageId, imageUrl: a.deletedAt ? undefined : a.thumbUrl ?? a.imageUrl, hidden: !!a.deletedAt,
      extras: tasteExtrasOf(a), ts: r.timestamp,
    }))
    .sort((x, y) => y.ts - x.ts);
  // Age is measured from the newest rating (not the clock), so a break from rating doesn't erase the past.
  const newest = rated[0]?.ts ?? 0;
  const samples: Sample[] = rated.map((s, rank) => ({ ...s, recency: recencyWeight(rank, newest - s.ts) }));
  const F = fit(samples);
  const Z = samples.map((s) => zOf(F, vec(s.metrics, s.overall, s.extras)));
  const bandwidth = bandwidthOf(F, Z);

  // leave-one-out: pick the kernel/ridge mix with the lowest error, and compare to "always guess your average"
  let err = 0, base = 0, kernelShare = 0.5;
  if (samples.length >= TASTE_MIN_RATINGS) {
    const looBetas = samples.map((_, i) => ridgeFit(F, samples, Z, i));
    const errs = KERNEL_SHARES.map(() => 0);
    samples.forEach((s, i) => {
      const looMean = (F.meanStars * samples.length - s.stars) / (samples.length - 1);
      base += Math.abs(looMean - s.stars);
      KERNEL_SHARES.forEach((ks, j) => { errs[j] += Math.abs(predict(F, bandwidth, samples, Z, Z[i], i, looBetas[i], ks).stars - s.stars); });
    });
    const best = errs.indexOf(Math.min(...errs));
    kernelShare = KERNEL_SHARES[best];
    err = errs[best] / samples.length; base /= samples.length;
  }
  const beta = ridgeFit(F, samples, Z);

  const drivers: TasteMatch['drivers'] = FACE_METRICS
    .filter((k) => Math.abs(F.corr[k]) >= 0.2)
    .map((k) => ({ metric: k, label: METRIC_LABELS[k], direction: F.corr[k] > 0 ? 'likes-high' as const : 'likes-low' as const, agreement: F.corr[k] }))
    .sort((a, b) => Math.abs(b.agreement) - Math.abs(a.agreement))
    .slice(0, 4);

  return { samples, ...F, bandwidth, beta, kernelShare, errorStars: err, baselineError: base, drivers };
}

export function verdictFor(stars: number) {
  if (stars >= 4.3) return 'You will probably love this';
  if (stars >= 3.7) return 'Likely your type';
  if (stars >= 3.0) return 'On the fence';
  if (stars >= 2.3) return 'Probably not your taste';
  return 'Not for you';
}

export function computeTasteMatch(rawMetrics: MetricScores, model: TasteModel, excludeImageId?: string, overall?: number, extras: TasteExtras = {}): TasteMatch | undefined {
  const keep = model.samples.map((s, i) => [s, i] as const).filter(([s]) => s.imageId !== excludeImageId);
  if (keep.length < TASTE_MIN_RATINGS) return undefined;
  const samples = keep.map(([s]) => s);
  // refit without the excluded image so the current photo never predicts itself
  const F: Fit = keep.length === model.samples.length ? model : fit(samples);
  const Z = samples.map((s) => zOf(F, vec(s.metrics, s.overall, s.extras)));
  const h = keep.length === model.samples.length ? model.bandwidth : bandwidthOf(F, Z);
  const metrics = normalizeMetrics(rawMetrics);
  const ov = Number.isFinite(overall) ? overall! : F.mean.overall;
  const z = zOf(F, vec(metrics, ov, extras));
  const same = keep.length === model.samples.length;
  const { stars: predictedStars, ws, wSum } = predict(F, h, samples, Z, z, -1, same ? model.beta : undefined, model.kernelShare);

  // rank among what the user rated
  const below = samples.filter((s) => s.stars < predictedStars - 0.25).length;
  const ties = samples.filter((s) => Math.abs(s.stars - predictedStars) <= 0.25).length;
  const score = clampScore(((below + 0.5 * ties) / samples.length) * 100);

  const n = samples.length;
  const skill = model.baselineError > 1e-6 ? Math.max(0, 1 - model.errorStars / model.baselineError) : 0;
  const coverage = wSum / (wSum + 0.5);
  const confidence = Math.max(0, Math.min(1, (0.25 + 0.75 * skill) * Math.min(1, n / 10) * coverage));

  const contribs = FEATURES
    .filter((f) => Math.abs(F.corr[f]) >= 0.15)
    .map((f) => ({ f, c: (same ? model.beta[f] : F.corr[f]) * z[f], z: z[f] }))
    .filter((x) => Math.abs(x.z) >= 0.4);
  // Name the driver in plain words; no extra numbers (owner's rule: the page stays lean).
  const rawV = vec(metrics, ov, extras);
  const phrase = (x: { f: Feature; z: number }) => {
    const label = featureLabel(x.f).toLowerCase();
    return Number.isFinite(rawV[x.f]) ? label : `${x.z > 0 ? 'higher' : 'lower'} ${label}`;
  };
  const pros = contribs.filter((x) => x.c > 0).sort((a, b) => b.c - a.c).slice(0, 3).map(phrase);
  const cons = contribs.filter((x) => x.c < 0).sort((a, b) => a.c - b.c).slice(0, 3).map(phrase);

  const neighbours = ws
    .map((w, i) => ({ imageId: samples[i].imageId, imageUrl: samples[i].imageUrl, stars: Math.round(samples[i].stars), similarity: Math.round(w * 100), hidden: samples[i].hidden }))
    .filter((x) => !x.hidden)
    .map(({ hidden: _h, ...x }) => x)
    .sort((a, b) => b.similarity - a.similarity)
    .slice(0, 3)
    .filter((x) => x.similarity >= 5);

  const drivers = model.drivers.map((d) => ({ ...d, agreement: Math.max(-1, Math.min(1, (d.direction === 'likes-high' ? 1 : -1) * z[d.metric] / 2)) }));
  const flat = F.sdStars < 0.3;
  const flatHigh = flat && F.meanStars >= 4;
  const summary = flat
    ? flatHigh
      ? `Fits your taste — you gave all ${n} rated images ${F.meanStars.toFixed(0)}★. Rate a few you like less to get sharper predictions.`
      : `Your ${n} ratings are almost all the same, so there is little to learn yet — try rating some images higher and some lower.`
    : [
        `Predicted ${predictedStars.toFixed(1)}★ from ${n} of your ratings.`,
        pros.length ? `It has ${pros.join(', ')} — things you reward.` : '',
        cons.length ? `But ${cons.join(', ')} usually costs it stars with you.` : '',
        !pros.length && !cons.length ? 'Nothing stands out against what you usually rate.' : '',
      ].filter(Boolean).join(' ');

  return {
    score: flat ? Math.max(score, Math.round(F.meanStars * 20)) : score,
    confidence, ratingsUsed: n, predictedStars, drivers, summary,
    verdict: flatHigh ? 'Matches what you love' : flat ? 'Not enough contrast in your ratings' : verdictFor(predictedStars),
    deltaStars: predictedStars - F.meanStars, meanStars: F.meanStars,
    neighbours, errorStars: model.errorStars, pros, cons,
  };
}

/**
 * Active learning: which analysed-but-unrated photos would teach the taste model most?
 * Picks the ones least covered by existing ratings (lowest kernel mass), skipping no-face scans.
 */
export function suggestNextToRate(model: TasteModel, results: AnalysisResult[], k = 4): { imageId: string; imageUrl: string; novelty: number }[] {
  const rated = new Set(model.samples.map((s) => s.imageId));
  const seen = new Set<string>();
  const pool = results.filter((r) => {
    if (rated.has(r.imageId) || seen.has(r.imageId) || !r.faceDetection?.detected) return false;
    seen.add(r.imageId);
    return true;
  });
  if (model.samples.length === 0) return pool.slice(0, k).map((r) => ({ imageId: r.imageId, imageUrl: r.imageUrl, novelty: 1 }));
  const Z = model.samples.map((s) => zOf(model, vec(s.metrics, s.overall, s.extras)));
  return pool
    .map((r) => {
      const z = zOf(model, vec(normalizeMetrics(r.scores?.metrics), Number.isFinite(r.scores?.overall) ? r.scores.overall : model.mean.overall, tasteExtrasOf(r)));
      const { wSum } = predict(model, model.bandwidth, model.samples, Z, z);
      return { imageId: r.imageId, imageUrl: r.imageUrl, novelty: 1 / (1 + wSum) };
    })
    .sort((a, b) => b.novelty - a.novelty)
    .slice(0, k);
}

/** How much better than "always guess your average" the model predicts held-out ratings (0–1). */
export function tasteSkill(model: TasteModel): number {
  return model.baselineError > 1e-6 ? Math.max(0, Math.min(1, 1 - model.errorStars / model.baselineError)) : 0;
}

// ---- What the model knows / doesn't know (v2) ---------------------------------
export interface TasteKnowledge {
  /** 0–1 overall confidence in the taste model */
  confidence: number;
  label: 'Not started' | 'Learning' | 'Taking shape' | 'Confident';
  ratings: number;
  /** Measured: share of held-out ratings predicted better than "always your average" */
  skill: number;
  /** Strongest learned signals, plain language */
  knows: string[];
  /** Concrete gaps — what to rate next to close them */
  unknowns: string[];
}

export function tasteKnowledge(model: TasteModel): TasteKnowledge {
  const n = model.samples.length;
  const skill = tasteSkill(model);
  const highs = model.samples.filter((s) => s.stars >= 4).length;
  const lows = model.samples.filter((s) => s.stars <= 2).length;
  const recentShare = n ? model.samples.filter((s) => (s.recency ?? 1) >= 0.5).length / n : 0;
  const confidence = n < TASTE_MIN_RATINGS ? 0 : Math.max(0, Math.min(1, (0.3 + 0.7 * skill) * Math.min(1, n / 15) * (0.6 + 0.4 * Math.min(1, Math.min(highs, lows) / 3))));
  const label: TasteKnowledge['label'] = n === 0 ? 'Not started' : confidence < 0.3 ? 'Learning' : confidence < 0.6 ? 'Taking shape' : 'Confident';

  const ranked = FEATURES.filter((f) => f !== 'overall').map((f) => ({ f, r: model.corr[f] ?? 0 })).sort((a, b) => Math.abs(b.r) - Math.abs(a.r));
  const knows = n < TASTE_MIN_RATINGS ? [] : ranked.filter((x) => Math.abs(x.r) >= 0.25).slice(0, 3)
    .map((x) => `You rate higher when ${featureLabel(x.f).toLowerCase()} is ${x.r > 0 ? 'higher' : 'lower'} (r = ${x.r.toFixed(2)}).`);

  const unknowns: string[] = [];
  if (n < TASTE_MIN_RATINGS) unknowns.push(`Rate ${TASTE_MIN_RATINGS - n} more photo${TASTE_MIN_RATINGS - n === 1 ? '' : 's'} before it can predict anything.`);
  if (n > 0 && lows < 2) unknowns.push('What you dislike — almost no 1–2★ ratings yet. Rate a few faces you don\'t like.');
  if (n > 0 && highs < 3) unknowns.push('What you love — fewer than three 4–5★ ratings so far.');
  if (n >= TASTE_MIN_RATINGS && model.sdStars < 0.6) unknowns.push('Your ratings are very similar to each other, so differences are hard to learn — use the full 1–5 range.');
  const aiKnown = model.samples.filter((s) => Number.isFinite(s.extras?.aiLook)).length;
  if (n >= TASTE_MIN_RATINGS && aiKnown < n / 2) unknowns.push('Many rated photos have no AI look check, so it can\'t tell how much whole-face appeal drives you.');
  const lowAi = model.samples.filter((s) => (s.extras?.aiLook ?? 100) < 55).length;
  if (n >= 5 && aiKnown >= 3 && lowAi === 0) unknowns.push('How you react to faces the AI rates as average — you have only rated faces it rates highly.');
  const flat = ranked.filter((x) => Math.abs(x.r) < 0.12 && (model.sd[x.f] ?? 0) < 6).slice(0, 2);
  for (const x of flat) if (n >= 5) unknowns.push(`Whether ${featureLabel(x.f).toLowerCase()} matters — it barely varies across what you rated.`);
  if (n >= 8 && recentShare < 0.4) unknowns.push('Your current taste — most ratings are older and now count less. A few fresh ratings will update it.');
  if (n >= TASTE_MIN_RATINGS && skill < 0.1) unknowns.push('A reliable pattern — so far it predicts your stars barely better than your average.');
  return { confidence, label, ratings: n, skill, knows, unknowns: unknowns.slice(0, 5) };
}
