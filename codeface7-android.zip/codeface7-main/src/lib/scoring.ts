import { softTop } from './faceTeaching';
// ============================================================================
// SCORING — image metrics and the overall score.
// ----------------------------------------------------------------------------
// Design rules
//  • Every metric is a smooth function of a measurement: no hard caps, no
//    plateaus at 0 or 100, no single-threshold cliffs.
//  • Metric outputs live in a soft band [FLOOR, CEIL] so a value of exactly
//    0 / 100 never appears just because a measurement saturated.
//  • The face score is a weighted power mean (p = −2, plus a broken-group penalty) over symmetry, structure,
//    golden, alignment, mouth/jaw integrity, expression and skin & age: a broken
//    group drags it down. Extreme expressions (wide-open mouth, grimace) are penalised.
//    The skin & age group is the only one that can see wrinkles / rough skin.
//  • Photography is a ≤20% multiplier; pose confidence shrinks the face score
//    smoothly toward a neutral prior (never up, never as a ceiling).
//  • Luminance + geometry only: no colour statistic enters any score.
// ============================================================================
import type { MetricKey, MetricScores } from './types';
import { HARMONY_WEIGHTS } from './faceGeometry';
import { SKIN_PARAMS } from './skin';

export const FLOOR = 4;
export const CEIL = 97;
const band = (u: number) => FLOOR + (CEIL - FLOOR) * Math.max(0, Math.min(1, Number.isFinite(u) ? u : 0));

/** Gaussian bell on a linear axis → [FLOOR, CEIL]. */
export const bell = (x: number, ideal: number, sigma: number) => band(Math.exp(-0.5 * ((x - ideal) / sigma) ** 2));
/** Asymmetric bell: different widths below / above the ideal. */
export const bell2 = (x: number, ideal: number, sigmaLo: number, sigmaHi: number) =>
  bell(x, ideal, x < ideal ? sigmaLo : sigmaHi);
/** Bell in log space — for scale-like quantities (sharpness, size ratios). */
export const logBell = (x: number, ideal: number, sigmaLn: number, sigmaLnHi = sigmaLn) => {
  const r = Math.log(Math.max(1e-9, x) / ideal);
  return band(Math.exp(-0.5 * (r / (r < 0 ? sigmaLn : sigmaLnHi)) ** 2));
};
const sigmoid = (x: number) => 1 / (1 + Math.exp(-x));

export interface ScoringPixelStats {
  meanLum: number; stdLum: number; clipFraction: number;
  laplacianVar: number; edgeDensity: number; mirrorSimilarity: number;
  energyCentroid: { x: number; y: number };
  centerSharpness: number; borderSharpness: number;
  leftRightLumDiff: number; topBottomLumDiff: number;
  /** Source resolution in px */
  width?: number; height?: number;
  roiSharpness?: number; roiOutsideSharpness?: number;
  roiMeanLum?: number; roiStdLum?: number;
}

export interface ScoringInput {
  stats?: ScoringPixelStats;
  boundingBox?: { x: number; y: number; width: number; height: number };
  symmetry?: number; // face symmetry % when a mesh exists
  roll?: number;
  /** Landmark indices from the face mesh (golden-ratio, structural balance + alignment) */
  goldenRatioIndex?: number;
  structuralBalanceIndex?: number;
  alignmentIndex?: number;
  /** Skin & age score (0–100) when it could be measured; otherwise the metric shows the neutral value and is excluded from the harmony. */
  skinScore?: number;
}

/** RMS Laplacian at the 512-px analysis scale for a crisp-but-not-noisy subject. */
export const SHARP_TARGET = 0.045;

export function deriveMetrics({ stats: s, boundingBox: bb, symmetry, roll, goldenRatioIndex, structuralBalanceIndex, alignmentIndex, skinScore }: ScoringInput): MetricScores {
  const skin = skinScore !== undefined && Number.isFinite(skinScore) ? skinScore : SKIN_PARAMS.neutral;
  if (!s) return { symmetry: symmetry ?? FLOOR, proportions: goldenRatioIndex ?? FLOOR, structure: structuralBalanceIndex ?? FLOOR, skin, composition: FLOOR, lighting: FLOOR, texture: FLOOR, contrast: FLOOR, naturalness: 50 };

  // ---- Composition: subject position + subject scale + level horizon -------
  const c = bb ? { x: bb.x + bb.width / 2, y: bb.y + bb.height / 2 } : s.energyCentroid;
  const anchors = [[1 / 3, 1 / 3], [2 / 3, 1 / 3], [1 / 3, 2 / 3], [2 / 3, 2 / 3], [0.5, 0.4], [0.5, 0.5]];
  const dmin = Math.min(...anchors.map(([ax, ay]) => Math.hypot(c.x - ax, c.y - ay)));
  const position = bell(dmin, 0, 0.14);
  const scaleScore = bb ? logBell(Math.max(bb.height, bb.width), 0.42, 0.75, 0.55) : 70;
  const edgeCut = bb ? Math.min(bb.x, bb.y, 1 - bb.x - bb.width, 1 - bb.y - bb.height) : 0.1;
  const framing = band(sigmoid((edgeCut + 0.02) / 0.025)); // face cut off by frame edge → lower
  const level = roll !== undefined ? bell(Math.abs(roll), 0, 14) : 80;
  const composition = 0.42 * position + 0.28 * scaleScore + 0.15 * framing + 0.15 * level;

  // ---- Lighting: exposure (subject preferred), clipping, tonal range -------
  const lum = s.roiMeanLum ?? s.meanLum;
  const exposure = bell2(lum, 0.5, 0.15, 0.17);
  const sceneExposure = bell2(s.meanLum, 0.45, 0.2, 0.2);
  const clipping = band(Math.exp(-s.clipFraction / 0.08));
  const range = bell2(s.stdLum, 0.2, 0.08, 0.14);
  // gentle directional modelling is fine; extreme one-sided light costs a little
  const evenness = bell(Math.abs(s.leftRightLumDiff), 0.03, 0.18);
  const lighting = 0.38 * exposure + 0.14 * sceneExposure + 0.2 * clipping + 0.16 * range + 0.12 * evenness;

  // ---- Image sharpness (key `texture`, formerly labelled "Texture"): subject focus in log
  // space. It says NOTHING about skin quality — wrinkles and brush-work are sharp too; the
  // Skin & age metric is the one that measures skin. Wide bell so soft studio retouching
  // and fine film grain both stay in a plausible mid/high band.
  const subjectSharp = Math.sqrt(Math.max(0, s.roiSharpness ?? s.centerSharpness ?? s.laplacianVar));
  const globalSharp = Math.sqrt(Math.max(0, s.laplacianVar));
  const texture = 0.75 * logBell(subjectSharp, SHARP_TARGET, 1.1, 1.4) + 0.25 * logBell(globalSharp, SHARP_TARGET * 0.8, 1.2, 1.5);

  // ---- Contrast: RMS luminance contrast (colour-independent) --------------
  const contrast = bell2(s.stdLum, 0.21, 0.09, 0.14);

  // ---- Photo processing (key `naturalness`): luminance-only — unclipped tones, no over-sharpening,
  // plausible local contrast. No saturation term (monochrome is natural).
  // Studio lighting (soft, even, low clipping) scores well by construction.
  const tonal = band(Math.exp(-s.clipFraction / 0.15));
  const processing = logBell(globalSharp, SHARP_TARGET, 3, 1);
  const tonalRange = bell2(s.stdLum, 0.2, 0.14, 0.12);
  const naturalness = Math.max(25, 0.4 * tonal + 0.4 * processing + 0.2 * tonalRange);

  const sym = symmetry ?? band(Math.max(0, (s.mirrorSimilarity - 0.6) / 0.38));
  const proportions = goldenRatioIndex ?? FLOOR;
  const structure = structuralBalanceIndex !== undefined
    ? (alignmentIndex !== undefined ? 0.7 * structuralBalanceIndex + 0.3 * alignmentIndex : structuralBalanceIndex)
    : FLOOR;

  return { symmetry: sym, proportions, structure, skin, composition, lighting, texture, contrast, naturalness };
}

/**
 * Technical image quality in [0, 1]: subject focus, exposure, clipping and
 * source resolution. Kept for logging / photo score; never multiplies the face.
 */
export function technicalQuality(s?: ScoringPixelStats): number {
  if (!s) return 0.4;
  const focus = (logBell(Math.sqrt(Math.max(0, s.roiSharpness ?? s.laplacianVar)), SHARP_TARGET, 0.7, 1.6) - FLOOR) / (CEIL - FLOOR);
  const exposure = (bell2(s.roiMeanLum ?? s.meanLum, 0.5, 0.2, 0.2) - FLOOR) / (CEIL - FLOOR);
  const clip = Math.exp(-s.clipFraction / 0.15);
  const px = Math.min(s.width ?? 1024, s.height ?? 1024);
  const resolution = sigmoid((px - 320) / 90);
  return Math.max(0, Math.min(1, 0.4 * focus + 0.2 * exposure + 0.15 * clip + 0.25 * resolution));
}

// ---- Overall (80 / 20 rule) --------------------------------------------------
/** Share of the overall carried by facial geometry. */
export const FACE_SHARE = 1;
/** Maximum share photography can ever contribute. */
export const PHOTO_SHARE = 0; // photography no longer counts (owner's decision)
/** Relative weights inside the photography share (sum = 1). */
export const PHOTO_WEIGHTS: Partial<Record<MetricKey, number>> = {
  // GUESS (uncalibrated). Simplicity and Depth were removed; their 0.15 was spread over the rest.
  lighting: 0.35, composition: 0.3, texture: 0.2, contrast: 0.075, naturalness: 0.075,
};
/** Effective weight of each metric in the overall (for feature importance). */
export const METRIC_WEIGHTS: Record<MetricKey, number> = {
  // Nominal harmony weights of the groups these metrics show. The remaining
  // face weight sits in the mouth/jaw integrity group and the expression group (see breakdown).
  symmetry: FACE_SHARE * HARMONY_WEIGHTS.symmetry,
  skin: FACE_SHARE * HARMONY_WEIGHTS.skin,
  proportions: FACE_SHARE * HARMONY_WEIGHTS.golden,
  structure: FACE_SHARE * (HARMONY_WEIGHTS.structure + HARMONY_WEIGHTS.alignment),
  lighting: PHOTO_SHARE * 0.35,
  composition: PHOTO_SHARE * 0.3,
  texture: PHOTO_SHARE * 0.2,
  contrast: PHOTO_SHARE * 0.075,
  naturalness: PHOTO_SHARE * 0.075,
};
/** Back-compat alias. */
export const FACE_WEIGHT = FACE_SHARE;
/** Without a face mesh there is no geometry; the photo score is halved. */
export const NO_FACE_FACTOR = 0.5;
/** Low-confidence measurements are shrunk toward this value (never pulled up). */
export const NEUTRAL_PRIOR = 58;
/** Fraction of the excess above NEUTRAL_PRIOR that low confidence removes at c = 0. */
export const SHRINK_STRENGTH = 0.5;
/** No forced reporting band: the overall is the product of the maths. */
export const SCORE_FLOOR = 0;

/** Presentation labels (not score bands — they never change the number). */
export const SCORE_LABELS: Array<[number, string]> = [[75, 'Excellent'], [62, 'Strong'], [48, 'Good'], [33, 'Fair'], [0, 'Weak']];
export const scoreLabel = (score: number) => (SCORE_LABELS.find(([t]) => score >= t) ?? SCORE_LABELS[SCORE_LABELS.length - 1])[1];

export function powerMean(parts: Array<[number, number]>, p = 0.5) {
  const wSum = parts.reduce((s, [, w]) => s + w, 0) || 1;
  const v = (x: number) => Math.max(1, Math.min(100, Number.isFinite(x) ? x : 1));
  if (p === 0) return Math.exp(parts.reduce((s, [x, w]) => s + w * Math.log(v(x)), 0) / wSum);
  return (parts.reduce((s, [x, w]) => s + w * v(x) ** p, 0) / wSum) ** (1 / p);
}

export interface OverallBreakdown {
  faceScore?: number;
  photoScore: number;
  faceShare: number;
  photoShare: number;
  confidence: number;
  overall: number;
  formula: string;
}

export function photoScoreOf(metrics: MetricScores) {
  let s = 0, w = 0;
  for (const [k, wk] of Object.entries(PHOTO_WEIGHTS) as Array<[MetricKey, number]>) {
    const v = metrics[k];
    if (Number.isFinite(v)) { s += v * wk; w += wk; }
  }
  return w ? s / w : 50;
}

/**
 * overall = face × (0.8 + 0.2 × photo / 100)
 * Photography is a multiplier on the face, not an addend: a perfect studio
 * shot can add at most 20% of the face score and can never lift a distorted
 * face above its own geometry. Low pose confidence shrinks the face score
 * smoothly toward NEUTRAL_PRIOR (only downward).
 */
export function computeOverall(metrics: MetricScores, opts: { facialHarmony?: number; confidence?: number; quality?: number } = {}): OverallBreakdown {
  const photoScore = photoScoreOf(metrics);
  const c = Math.max(0, Math.min(1, opts.confidence ?? 1));
  const hasFace = opts.facialHarmony !== undefined && Number.isFinite(opts.facialHarmony);
  if (!hasFace) {
    const overall = photoScore * NO_FACE_FACTOR;
    return { photoScore, faceShare: 0, photoShare: NO_FACE_FACTOR, confidence: c, overall, formula: `no face mesh → ${NO_FACE_FACTOR} × photo ${photoScore.toFixed(1)} = ${overall.toFixed(1)}` };
  }
  const rawFace = opts.facialHarmony!;
  // Shrink toward the prior only from above, and only part-way: the target
  // keeps slope 1 − SHRINK_STRENGTH > 0, so confidence never creates a ceiling.
  const target = rawFace > NEUTRAL_PRIOR ? NEUTRAL_PRIOR + (1 - SHRINK_STRENGTH) * (rawFace - NEUTRAL_PRIOR) : rawFace;
  const faceScore = c * rawFace + (1 - c) * target;
  // Soft ceiling (GUESS): mesh geometry alone cannot tell an elite face from a merely regular one, so the top is compressed.
  const overall = softTop(faceScore * (FACE_SHARE + PHOTO_SHARE * photoScore / 100));
  return {
    faceScore, photoScore, faceShare: FACE_SHARE, photoShare: PHOTO_SHARE, confidence: c, overall,
    formula: `face ${faceScore.toFixed(1)} × (${FACE_SHARE} + ${PHOTO_SHARE} × photo ${photoScore.toFixed(1)}/100) = ${overall.toFixed(1)}`,
  };
}

// ---- AI look blend (scoring v2) -------------------------------------------
/**
 * Version stamped on every new analysis. Old saves keep their stored scores (v1 = the
 * p = −6 harmony and the "lower value dominates" AI blend); new scans use v2.
 */
export const SCORING_VERSION = 2;
/**
 * v2 overall = core × (0.8 + 0.2 × photo / 100), with
 *   core = 0.5 × AI look + 0.5 × geometry face − DISAGREEMENT_PENALTY × max(0, |AI − face| − DISAGREEMENT_THRESHOLD)
 * so the AI look and the geometry face score each carry 40% of the overall and
 * photography stays a soft ≤20% multiplier. The old power mean (p = −4) let the lower
 * of the two dominate: an AI 85 face could finish in the 30s. Now only a large
 * disagreement (> 25 points) costs a mild extra penalty. GUESSED constants.
 */
export const AI_LOOK_WEIGHT = 0.4;
export const GEOMETRY_WEIGHT = 0.4;
export const DISAGREEMENT_THRESHOLD = 25;
export const DISAGREEMENT_PENALTY = 0.2;

export interface BlendResult { core: number; penalty: number; overall: number; formula: string }

export function blendOverall(faceScore: number, aiAttractiveness: number, photoScore: number): BlendResult {
  const mult = FACE_SHARE + PHOTO_SHARE * Math.max(0, Math.min(100, photoScore)) / 100;
  if (!Number.isFinite(aiAttractiveness)) {
    const overall = faceScore * mult;
    return { core: faceScore, penalty: 0, overall, formula: `face ${faceScore.toFixed(1)} × ${mult.toFixed(3)} = ${overall.toFixed(1)}` };
  }
  const share = AI_LOOK_WEIGHT / (AI_LOOK_WEIGHT + GEOMETRY_WEIGHT);
  const mean = share * aiAttractiveness + (1 - share) * faceScore;
  const penalty = DISAGREEMENT_PENALTY * Math.max(0, Math.abs(aiAttractiveness - faceScore) - DISAGREEMENT_THRESHOLD);
  const core = Math.max(0, mean - penalty);
  const overall = core * mult;
  return {
    core, penalty, overall,
    formula: `(0.5 × AI ${aiAttractiveness.toFixed(0)} + 0.5 × face ${faceScore.toFixed(1)}${penalty > 0 ? ` − ${penalty.toFixed(1)} disagreement` : ''}) × (${FACE_SHARE} + ${PHOTO_SHARE} × photo ${photoScore.toFixed(1)}/100) = ${overall.toFixed(1)}`,
  };
}

/** Back-compat helper: blend when only the geometry overall is known (photo assumed already inside it). */
export function blendWithAiLook(geometryOverall: number, aiAttractiveness: number): number {
  if (!Number.isFinite(aiAttractiveness)) return geometryOverall;
  const share = AI_LOOK_WEIGHT / (AI_LOOK_WEIGHT + GEOMETRY_WEIGHT);
  const penalty = DISAGREEMENT_PENALTY * Math.max(0, Math.abs(aiAttractiveness - geometryOverall) - DISAGREEMENT_THRESHOLD);
  return Math.max(0, share * aiAttractiveness + (1 - share) * geometryOverall - penalty);
}
