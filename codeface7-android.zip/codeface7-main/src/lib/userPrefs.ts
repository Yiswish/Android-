import { useSyncExternalStore } from 'react';
import type { AestheticScores, ImageSource } from './types';
import { FACE_TYPE_SEARCHES } from './faceType';

export type Accent = 'blue' | 'rose' | 'emerald' | 'amber' | 'violet';
export type TextSize = 'sm' | 'md' | 'lg';

export interface ScoreWeights { face: number; ai: number; photo: number }

export interface UserPrefs {
  accent: Accent;
  textSize: TextSize;
  reduceMotion: boolean;
  weights: ScoreWeights;
  defaultSource: ImageSource;
  quickSearches: string[];
  /** Folder names in display order. */
  folders: string[];
  /** analysis id → folder names it is saved in. */
  saved: Record<string, string[]>;
}

export const DEFAULT_PREFS: UserPrefs = {
  accent: 'blue',
  textSize: 'md',
  reduceMotion: false,
  weights: { face: 50, ai: 35, photo: 0 },
  defaultSource: 'google',
  quickSearches: [...FACE_TYPE_SEARCHES],
  folders: [],
  saved: {},
};

/**
 * "Your weighted score": a weighted mean of the face, AI look and photo parts
 * that exist for this analysis. Missing parts drop out and the rest renormalise.
 * Never replaces `scores.overall`.
 */
export interface WeightedPart { key: keyof ScoreWeights; label: string; value?: number; weight: number; share: number }

/** Each part's value and its effective share (%) after missing parts drop out. */
export function weightedParts(scores: AestheticScores, w: ScoreWeights): WeightedPart[] {
  const raw: Array<Omit<WeightedPart, 'share'>> = [
    { key: 'face', label: 'Face', value: scores.breakdown?.faceScore ?? scores.aiLook?.faceScore, weight: w.face },
    { key: 'ai', label: 'AI look', value: scores.aiLook?.attractiveness, weight: w.ai },
  ];
  const ok = (v?: number) => typeof v === 'number' && Number.isFinite(v);
  const wsum = raw.reduce((s, p) => s + (ok(p.value) && p.weight > 0 ? p.weight : 0), 0);
  return raw.map((p) => ({ ...p, value: ok(p.value) ? p.value : undefined, share: wsum > 0 && ok(p.value) && p.weight > 0 ? Math.round((p.weight / wsum) * 100) : 0 }));
}

export function weightedScore(scores: AestheticScores, w: ScoreWeights): number | undefined {
  let sum = 0, wsum = 0;
  for (const p of weightedParts(scores, w)) {
    if (p.value === undefined || p.weight <= 0) continue;
    sum += p.value * p.weight; wsum += p.weight;
  }
  return wsum > 0 ? Math.round(sum / wsum) : undefined;
}

/** Ids saved in a folder; `null` = all. */
export function filterByFolder<T extends { id: string }>(items: T[], saved: Record<string, string[]>, folder: string | null): T[] {
  if (!folder) return items;
  return items.filter((i) => saved[i.id]?.includes(folder));
}

const KEY = 'aesthetics.userPrefs.v1';
let state: UserPrefs = load();
const listeners = new Set<() => void>();

function load(): UserPrefs {
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(KEY) : null;
    if (raw) {
      const p = JSON.parse(raw) as Partial<UserPrefs>;
      return { ...DEFAULT_PREFS, ...p, weights: { ...DEFAULT_PREFS.weights, ...(p.weights ?? {}) } };
    }
  } catch { /* fall back */ }
  return { ...DEFAULT_PREFS };
}

export function getPrefs() { return state; }

export function updatePrefs(patch: Partial<UserPrefs> | ((p: UserPrefs) => Partial<UserPrefs>)) {
  const p = typeof patch === 'function' ? patch(state) : patch;
  state = { ...state, ...p };
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* ignore */ }
  listeners.forEach((l) => l());
}

export function toggleSaved(id: string, folder: string) {
  updatePrefs((p) => {
    const cur = p.saved[id] ?? [];
    const next = cur.includes(folder) ? cur.filter((f) => f !== folder) : [...cur, folder];
    return { saved: { ...p.saved, [id]: next } };
  });
}

export function addFolder(name: string) {
  const n = name.trim();
  if (!n) return;
  updatePrefs((p) => (p.folders.includes(n) ? {} : { folders: [...p.folders, n] }));
}

export function removeFolder(name: string) {
  updatePrefs((p) => {
    const saved: Record<string, string[]> = {};
    for (const [k, v] of Object.entries(p.saved)) saved[k] = v.filter((f) => f !== name);
    return { folders: p.folders.filter((f) => f !== name), saved };
  });
}

function subscribe(cb: () => void) { listeners.add(cb); return () => { listeners.delete(cb); }; }

export function useUserPrefs(): UserPrefs {
  return useSyncExternalStore(subscribe, getPrefs, () => DEFAULT_PREFS);
}

/** Apply look & theme to <html>. */
export function applyLook(p: UserPrefs) {
  const el = document.documentElement;
  if (p.accent === 'blue') el.removeAttribute('data-accent'); else el.setAttribute('data-accent', p.accent);
  if (p.textSize === 'md') el.removeAttribute('data-text'); else el.setAttribute('data-text', p.textSize);
  if (p.reduceMotion) el.setAttribute('data-motion', 'reduce'); else el.removeAttribute('data-motion');
}

/** Current theme colour as a concrete rgb()/rgba() string (for canvas and SVG attributes, which can't read CSS variables). */
export function accentColor(shade: 50 | 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900 = 500, alpha = 1): string {
  const fallback = '45 156 255';
  const raw = typeof document !== 'undefined'
    ? getComputedStyle(document.documentElement).getPropertyValue(`--p-${shade}`).trim() || fallback
    : fallback;
  const [r, g, b] = raw.split(/\s+/);
  return alpha >= 1 ? `rgb(${r}, ${g}, ${b})` : `rgba(${r}, ${g}, ${b}, ${alpha})`;
}
