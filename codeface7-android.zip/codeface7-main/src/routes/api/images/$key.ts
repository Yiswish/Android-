import { createFileRoute } from '@tanstack/react-router'

// Serves analysis thumbnails / uploaded photos stored in Cloud storage (private bucket).
export const Route = createFileRoute('/api/images/$key')({
  server: {
    handlers: {
      GET: async ({ params }) => {
        if (!/^[a-zA-Z0-9_-]{1,120}\.jpg$/.test(params.key)) return new Response('Not found', { status: 404 })
        const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
        const { data } = await supabaseAdmin.storage.from('analysis-images').download(params.key)
        if (!data) return new Response('Not found', { status: 404 })
        return new Response(await data.arrayBuffer(), {
          headers: { 'content-type': 'image/jpeg', 'cache-control': 'public, max-age=31536000, immutable' },
        })
      },
    },
  },
})
