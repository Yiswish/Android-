import { createFileRoute } from "@tanstack/react-router";

// Same-origin image relay so the browser can read pixels for landmark analysis.
// Only public http(s) image responses up to 10 MB are relayed.
const MAX_BYTES = 10 * 1024 * 1024;
const PRIVATE_HOST = /^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|169\.254\.|0\.|\[?::1\]?$)/i;

export const Route = createFileRoute("/api/public/image-proxy")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const target = new URL(request.url).searchParams.get("url");
        let url: URL;
        try {
          url = new URL(target ?? "");
        } catch {
          return new Response("Invalid url", { status: 400 });
        }
        if (!/^https?:$/.test(url.protocol) || PRIVATE_HOST.test(url.hostname)) {
          return new Response("Forbidden", { status: 403 });
        }
        // Hosts that require a logged-in session never relay; refuse fast instead of waiting on a timeout.
        if (/(^|\.)(tiktok\.com|tiktokcdn\.com|instagram\.com|cdninstagram\.com|facebook\.com|fbsbx\.com|fbcdn\.net)$/i.test(url.hostname)) {
          return new Response("This site does not allow its images to be loaded", { status: 422 });
        }
        // Many image hosts reject requests without a browser-like UA / same-site Referer (hotlink protection).
        const get = (u: string, referer?: string) => fetch(u, {
          headers: { Accept: "image/avif,image/webp,image/*,*/*;q=0.8", "User-Agent": "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36", ...(referer ? { Referer: referer } : {}) },
          signal: AbortSignal.timeout(8000),
          redirect: "follow",
        }).catch((e: Error) => { console.error(`[image-proxy] ${new URL(u).hostname} fetch failed: ${e.message}`); return null; });
        let upstream = await get(url.toString(), `${url.origin}/`);
        // Some hosts (e.g. Cloudflare-protected wallpaper sites) block server requests but let a public
        // image CDN relay through; retry once via that relay so the photo can still be analysed.
        if ((!upstream || !upstream.ok) && !url.search && /\.(jpe?g|png|gif|webp)$/i.test(url.pathname)) {
          const relay = `https://i0.wp.com/${url.hostname}${url.pathname}${url.protocol === "https:" ? "?ssl=1" : ""}`;
          const retry = await get(relay);
          if (retry?.ok && (retry.headers.get("content-type") ?? "").startsWith("image/")) upstream = retry;
        }
        if (!upstream || !upstream.ok) {
          if (upstream) console.error(`[image-proxy] ${url.hostname} HTTP ${upstream.status}`);
          return new Response(`Upstream error${upstream ? ` (HTTP ${upstream.status})` : " (network)"}`, { status: 422 });
        }
        const type = upstream.headers.get("content-type") ?? "";
        if (!type.startsWith("image/")) return new Response("Not an image", { status: 415 });
        const buf = await upstream.arrayBuffer();
        if (buf.byteLength > MAX_BYTES) return new Response("Too large", { status: 413 });
        return new Response(buf, {
          headers: { "Content-Type": type, "Cache-Control": "public, max-age=86400" },
        });
      },
    },
  },
});
