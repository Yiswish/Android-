import { createFileRoute, ClientOnly } from "@tanstack/react-router";
import AestheticsApp from "@/components/AestheticsApp";
import FingerprintLock from "@/components/FingerprintLock";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Personalized Aesthetics Analyzer" },
      {
        name: "description",
        content:
          "Explore facial analysis and Discover for You: personalized portrait recommendations guided by your ratings and AI observations.",
      },
      { property: "og:title", content: "Personalized Aesthetics Analyzer" },
      {
        property: "og:description",
        content: "Explore facial analysis and personal portrait discoveries guided by your ratings and AI observations.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <ClientOnly fallback={<div className="min-h-screen mesh-bg" />}>
      <FingerprintLock>
        <AestheticsApp />
      </FingerprintLock>
    </ClientOnly>
  );
}
