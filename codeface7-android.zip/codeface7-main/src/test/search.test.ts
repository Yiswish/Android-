// @vitest-environment node
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { searchChain, buildSerpQuery, youngPortraitQuery, portraitQuery, getSerpApiKey, redact, type SearchInput } from '@/lib/search.providers';

const KEY = 'unit-test-serp-key-0123456789';
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });
const serpOk = { images_results: [{ original: 'https://x/a.jpg', thumbnail: 'https://x/a_t.jpg', title: 'a', original_width: 600, original_height: 900 }, { original: 'https://x/b.jpg', thumbnail: 'https://x/b_t.jpg', title: 'b' }], search_information: { total_results: 99 } };
const ovOk = { results: [{ id: '1', url: 'https://ov/1.jpg', title: 'ov' }], result_count: 1, page_count: 1 };
const wmOk = { query: { pages: { 1: { pageid: 1, title: 'File:Face.jpg', index: 1, imageinfo: [{ url: 'https://wm/1.jpg', width: 800, height: 1000, mime: 'image/jpeg' }] } } } };

let fetchMock: ReturnType<typeof vi.fn>;
let errSpy: ReturnType<typeof vi.spyOn>;
const urlsCalled = () => fetchMock.mock.calls.map((c) => String(c[0]));
const q = (d: Partial<SearchInput> = {}): SearchInput => ({ query: 'woman with freckles', page: 1, perPage: 10, source: 'google', ...d });

/** Route by host so each test only describes what each provider answers. */
function route(h: { serp?: () => Response | Promise<Response>; ov?: () => Response; wm?: () => Response }) {
  fetchMock.mockImplementation(async (url: string) => {
    const u = String(url);
    if (u.includes('serpapi.com')) { if (!h.serp) throw new Error('serpapi must not be called'); return h.serp(); }
    if (u.includes('openverse')) return (h.ov ?? (() => json(ovOk)))();
    if (u.includes('wikimedia')) return (h.wm ?? (() => json(wmOk)))();
    throw new Error(`unexpected url ${u}`);
  });
}

beforeEach(() => {
  fetchMock = vi.fn();
  vi.stubGlobal('fetch', fetchMock);
  errSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
  process.env.SERPAPI_API_KEY = KEY;
  delete (globalThis as { Netlify?: unknown }).Netlify;
});
afterEach(() => { vi.unstubAllGlobals(); vi.restoreAllMocks(); delete process.env.SERPAPI_API_KEY; delete (globalThis as { Netlify?: unknown }).Netlify; });

describe('SerpAPI key lookup', () => {
  it('reads process.env, prefers Netlify.env, treats blank as missing', () => {
    expect(getSerpApiKey()).toBe(KEY);
    (globalThis as { Netlify?: unknown }).Netlify = { env: { get: (k: string) => (k === 'SERPAPI_API_KEY' ? 'from-netlify' : undefined) } };
    expect(getSerpApiKey()).toBe('from-netlify');
    delete (globalThis as { Netlify?: unknown }).Netlify;
    process.env.SERPAPI_API_KEY = '   ';
    expect(getSerpApiKey()).toBeUndefined();
  });
});

describe('provider chain (mocked fetch)', () => {
  it('success: SerpAPI answers, no banner reason, key never returned', async () => {
    route({ serp: () => json(serpOk) });
    const r = await searchChain(q());
    expect(r.status.provider).toBe('serpapi');
    expect(r.status.fallbackReason).toBeUndefined();
    expect(r.images).toHaveLength(2);
    expect(r.images[0].source).toBe('google');
    expect(r.status.diagnostics).toMatchObject({ serpapiKey: 'present', provider: 'serpapi' });
    expect(JSON.stringify(r)).not.toContain(KEY);
  });

  it('missing key: SerpAPI is never called, Openverse answers, reason is "missing key"', async () => {
    delete process.env.SERPAPI_API_KEY;
    route({});
    const r = await searchChain(q());
    expect(urlsCalled().some((u) => u.includes('serpapi.com'))).toBe(false);
    expect(r.status.provider).toBe('openverse');
    expect(r.status.fallbackReason).toBe('missing key');
    expect(r.status.diagnostics.serpapiKey).toBe('missing');
  });

  it.each([401, 429])('HTTP %i from SerpAPI: reason "quota", no retry, falls back to Openverse', async (status) => {
    route({ serp: () => json({ error: 'nope' }, status) });
    const r = await searchChain(q());
    expect(urlsCalled().filter((u) => u.includes('serpapi.com'))).toHaveLength(1);
    expect(r.status.provider).toBe('openverse');
    expect(r.status.fallbackReason).toBe('quota');
    expect(r.status.diagnostics.serpapiHttpStatus).toBe(status);
  });

  it('empty SerpAPI results: reason "empty", falls back', async () => {
    route({ serp: () => json({ images_results: [] }) });
    const r = await searchChain(q());
    expect(r.status.provider).toBe('openverse');
    expect(r.status.fallbackReason).toBe('empty');
  });

  it('SerpAPI plan error in a 200 body counts as quota', async () => {
    route({ serp: () => json({ error: 'Your account has run out of searches.' }) });
    expect((await searchChain(q())).status.fallbackReason).toBe('quota');
  });

  it('SerpAPI network failure retries once, then falls back with reason "network"', async () => {
    route({ serp: () => { throw new TypeError(`fetch failed for https://serpapi.com/search.json?api_key=${KEY}&q=x`); } });
    const r = await searchChain(q());
    expect(urlsCalled().filter((u) => u.includes('serpapi.com'))).toHaveLength(2);
    expect(r.status.fallbackReason).toBe('network');
    expect(JSON.stringify(r)).not.toContain(KEY);
    expect(errSpy.mock.calls.flat().join('\n')).not.toContain(KEY);
  });

  it('Openverse down → Wikimedia; everything down → curated with a reason', async () => {
    route({ serp: () => json({ error: 'x' }, 429), ov: () => json({}, 500) });
    expect((await searchChain(q())).status.provider).toBe('wikimedia');
    route({ serp: () => json({ error: 'x' }, 429), ov: () => json({}, 500), wm: () => json({}, 500) });
    const r = await searchChain(q());
    expect(r.images).toHaveLength(0);
    expect(r.status.provider).toBe('curated');
    expect(r.status.fallbackReason).toBe('quota');
    expect(r.status.attempts.map((a) => a.provider)).toEqual(['serpapi', 'openverse', 'wikimedia']);
  });
});

describe('searches are limited to young portrait photos', () => {
  const serpUrl = () => new URL(urlsCalled().find((u) => u.includes('serpapi.com'))!);
  it('Google: adds "young portrait photo" and the face image type', async () => {
    route({ serp: () => json(serpOk) });
    await searchChain(q({ query: 'woman with freckles' }));
    expect(serpUrl().searchParams.get('q')).toBe('woman with freckles young portrait photo');
    expect(serpUrl().searchParams.get('tbs')).toBe('itp:face');
  });
  it('only missing words are added', () => {
    expect(youngPortraitQuery('young woman portrait')).toBe('young woman portrait photo');
    expect(youngPortraitQuery('young portrait photos')).toBe('young portrait photos');
  });
  it('Pinterest keeps the site prefix', async () => {
    route({ serp: () => json(serpOk) });
    const r = await searchChain(q({ query: 'man', source: 'pinterest' }));
    expect(serpUrl().searchParams.get('q')).toBe('site:pinterest.com man young portrait photo');
    expect(r.images[0].source).toBe('pinterest');
    expect(buildSerpQuery('google', 'x')).toBe('x');
  });
  it('fallback providers get the same young portrait query', async () => {
    delete process.env.SERPAPI_API_KEY;
    route({});
    await searchChain(q({ query: 'woman' }));
    const ov = new URL(urlsCalled().find((u) => u.includes('openverse'))!);
    expect(ov.searchParams.get('q')).toBe('woman young portrait photo');
  });
});

describe('the key never leaks', () => {
  it('redact removes api_key fragments and the literal key', () => {
    expect(redact(`https://serpapi.com/search.json?engine=google_images&api_key=${KEY}&q=x`, KEY)).not.toContain(KEY);
    expect(redact(`oops ${KEY}`, KEY)).toBe('oops [redacted]');
  });
  it('no log line and no response contains the key across every failure mode', async () => {
    for (const serp of [() => json({ error: 'x' }, 401), () => json({ error: `bad key ${KEY}` }), () => json({ images_results: [] }), () => { throw new Error(`boom ${KEY}`); }]) {
      fetchMock.mockReset(); route({ serp });
      const r = await searchChain(q());
      expect(JSON.stringify(r)).not.toContain(KEY);
    }
    expect(errSpy.mock.calls.flat().map(String).join('\n')).not.toContain(KEY);
  });
});

describe('Best searches age-neutral portraits', () => {
  it('sends portraits without adding young to Google', async () => {
    route({ serp: () => json(serpOk) });
    const r = await searchChain(q({ query: 'Natalie Portman', portraitMode: 'all-ages' }));
    expect(r.status.diagnostics.query).toBe('Natalie Portman portrait photo');
    const url = urlsCalled().find((u) => u.includes('serpapi.com'));
    expect(url).toBeDefined();
    expect(new URL(url ?? '').searchParams.get('q')).toBe('Natalie Portman portrait photo');
    expect(new URL(url ?? '').searchParams.get('tbs')).toBe('itp:face');
  });
  it('uses the same age-neutral query on fallback providers', async () => {
    delete process.env.SERPAPI_API_KEY;
    route({});
    const r = await searchChain(q({ query: 'older woman', portraitMode: 'all-ages' }));
    expect(r.status.diagnostics.query).toBe('older woman portrait photo');
    const url = urlsCalled().find((u) => u.includes('openverse'));
    expect(new URL(url ?? '').searchParams.get('q')).toBe('older woman portrait photo');
  });
  it('does not duplicate portrait terms or remove explicitly requested ages', () => {
    expect(portraitQuery('young portraits')).toBe('young portraits photo');
    expect(portraitQuery('portrait photos')).toBe('portrait photos');
  });
  it('tries the selected Best service first', async () => {
    route({});
    const r = await searchChain(q({ source: 'openverse', portraitMode: 'all-ages' }));
    expect(r.status.provider).toBe('openverse');
    expect(urlsCalled()).toHaveLength(1);
    expect(urlsCalled()[0]).toContain('openverse');
  });
});

import { BLOCKED_IMAGE_HOST } from '@/lib/search.providers';
describe('blocked image hosts', () => {
  it('flags TikTok image URLs so the cached thumbnail is used', () => {
    expect(BLOCKED_IMAGE_HOST.test('https://www.tiktok.com/api/img/?itemId=1')).toBe(true);
    expect(BLOCKED_IMAGE_HOST.test('https://images.unsplash.com/a.jpg')).toBe(false);
  });
});
