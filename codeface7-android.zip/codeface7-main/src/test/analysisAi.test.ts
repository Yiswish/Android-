import { describe, expect, it, vi } from 'vitest';
import { checkAnalysisAi } from '@/lib/analysisAi';
import type { AnalysisResult, AestheticScores } from '@/lib/types';

const result = { id: 'outside-top-3', imageUrl: '/portrait.jpg', scores: { overall: 42, metrics: {} }, warnings: ['Measurement-only score — AI look check not run yet.', 'Geometry note'] } as AnalysisResult;

describe('Manual photo AI checks', () => {
  it('checks an unranked measurement-only photo and preserves its identity and geometry', async () => {
    const check = vi.fn(async (s: AestheticScores) => ({ ...s, overall: 60, aiLook: { attractiveness: 72 } }) as AestheticScores);
    const updated = await checkAnalysisAi(result, check);
    expect(check).toHaveBeenCalledWith(result.scores, '/portrait.jpg');
    expect(updated.id).toBe('outside-top-3');
    expect(updated.scores.overall).toBe(60);
    expect(updated.scores.metrics).toBe(result.scores.metrics);
    expect(updated.warnings).toEqual(['Geometry note']);
  });
  it('keeps the measurement-only score when AI fails so the photo can be retried', async () => {
    const updated = await checkAnalysisAi(result, async (s) => ({ ...s, aiLookError: 'quota' }));
    expect(updated.scores.overall).toBe(42);
    expect(updated.scores.aiLook).toBeUndefined();
    expect(updated.scores.aiLookError).toBe('quota');
  });
});