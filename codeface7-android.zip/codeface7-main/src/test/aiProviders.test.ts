import { afterEach, describe, expect, it, vi } from 'vitest';
import { judgeLook, judgeLookBatch } from '@/lib/aiLook.server';

const photo = 'data:image/jpeg;base64,ZmFrZQ==';
const answer = { attractiveness: 75, typeMatch: 65, reasons: ['Balanced proportions'], description: 'Portrait', categories: [], partialCategories: [] };
const geminiAnswer = () => Response.json({ candidates: [{ content: { parts: [{ text: JSON.stringify(answer) }] } }] });
const groqAnswer = () => Response.json({ choices: [{ message: { content: JSON.stringify(answer) } }] });

afterEach(() => { vi.unstubAllGlobals(); vi.unstubAllEnvs(); vi.useRealTimers(); });

describe('vision provider recovery', () => {
  it('uses a current vision model instead of the Groq model returning 404', async () => {
    const fetcher = vi.fn().mockResolvedValueOnce(groqAnswer());
    vi.stubGlobal('fetch', fetcher);
    const result = await judgeLook(photo, '', 0, ['gsk_test']);
    expect(result.ok).toBe(true);
    expect(JSON.parse(fetcher.mock.calls[0][1].body).model).toBe('qwen/qwen3.8-27b');
  });

  it('tries another Groq vision model on model-not-found', async () => {
    const fetcher = vi.fn().mockResolvedValueOnce(new Response('', { status: 404 })).mockResolvedValueOnce(groqAnswer());
    vi.stubGlobal('fetch', fetcher);
    expect((await judgeLook(photo, '', 0, ['gsk_test'])).ok).toBe(true);
    expect(JSON.parse(fetcher.mock.calls[1][1].body).model).toBe('meta-llama/llama-4-scout-17b-16e-instruct');
  });

  it('recovers from a Gemini server failure on the next model with compatible thinking settings', async () => {
    const fetcher = vi.fn().mockResolvedValueOnce(new Response('', { status: 503 })).mockResolvedValueOnce(geminiAnswer());
    vi.stubGlobal('fetch', fetcher);
    expect((await judgeLook(photo, '', 0, ['test-gemini'])).ok).toBe(true);
    expect(fetcher.mock.calls[1][0]).toContain('gemini-3.8-flash:generateContent');
    expect(JSON.parse(fetcher.mock.calls[1][1].body).generationConfig.thinkingConfig).toEqual({ thinkingLevel: 'MEDIUM' });
  });

  it('does not let one key change the starting Gemini model for other requests', async () => {
    const fetcher = vi.fn().mockResolvedValueOnce(new Response('', { status: 404 })).mockResolvedValueOnce(geminiAnswer()).mockResolvedValueOnce(geminiAnswer());
    vi.stubGlobal('fetch', fetcher);
    await judgeLook(photo, '', 0, ['first-test-key']);
    await judgeLook(photo, '', 0, ['second-test-key']);
    expect(fetcher.mock.calls[2][0]).toContain('gemini-flash-latest:generateContent');
  });

  it('retries temporary Gemini failures even when the backup has no credits', async () => {
    vi.useFakeTimers();
    vi.stubEnv('LOVABLE_API_KEY', 'test-backup');
    const fetcher = vi.fn().mockResolvedValueOnce(new Response('', { status: 503 })).mockResolvedValueOnce(new Response('', { status: 503 })).mockResolvedValueOnce(new Response('', { status: 503 })).mockResolvedValueOnce(new Response('', { status: 402 })).mockResolvedValueOnce(geminiAnswer());
    vi.stubGlobal('fetch', fetcher);
    const pending = judgeLook(photo, '', 0, ['test-gemini']);
    await vi.advanceTimersByTimeAsync(1500);
    expect((await pending).ok).toBe(true);
    expect(fetcher).toHaveBeenCalledTimes(5);
  });

  it('bounds single and batch provider calls with abort signals', async () => {
    const fetcher = vi.fn().mockResolvedValueOnce(geminiAnswer()).mockResolvedValueOnce(Response.json({ candidates: [{ content: { parts: [{ text: JSON.stringify({ results: [{ photo: 1, ...answer }, { photo: 2, ...answer }] }) }] } }] }));
    vi.stubGlobal('fetch', fetcher);
    await judgeLook(photo, '', 0, ['test-gemini']);
    const results = await judgeLookBatch([photo, photo], 0, ['test-gemini']);
    expect(results.every((r) => r.ok)).toBe(true);
    for (const call of fetcher.mock.calls) expect(call[1].signal).toBeInstanceOf(AbortSignal);
  });
});