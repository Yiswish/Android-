import { describe, it, expect } from 'vitest';
import { createRateLimiter, createMicroBatcher } from '@/lib/aiBatching';
import { providerOfKey, orderedAiKeys, findGeminiEnvKeys } from '@/lib/aiKeys';

describe('AI batching', () => {
  it('allows only 15 requests per minute, the 16th waits for the window', async () => {
    let t = 0; const waits: number[] = [];
    const lim = createRateLimiter(15, 60_000, () => t, async (ms) => { waits.push(ms); t += ms; });
    for (let i = 0; i < 15; i++) await lim.take();
    expect(waits).toEqual([]);
    await lim.take();
    expect(t).toBeGreaterThanOrEqual(60_000);
  });
  it('sends up to 4 photos in one request', async () => {
    const calls: number[][] = [];
    const b = createMicroBatcher<number, number>({ maxSize: 4, waitMs: 10, run: async (xs) => { calls.push(xs); return xs.map((x) => x * 2); } });
    const out = await Promise.all([1, 2, 3, 4, 5].map((x) => b.add(x)));
    expect(out).toEqual([2, 4, 6, 8, 10]);
    expect(calls).toEqual([[1, 2, 3, 4], [5]]);
  });
  it('tries Gemini keys before Groq keys', () => {
    expect(providerOfKey('gsk_abc')).toBe('groq');
    expect(providerOfKey('AIzaXYZ')).toBe('gemini');
    expect(orderedAiKeys(['g'], ['q']).map((k) => k.provider)).toEqual(['gemini', 'groq']);
    expect(findGeminiEnvKeys({ GEMINI_API_KEY_2: 'b', GEMINI_API_KEY: 'a', GROQ_API_KEY: 'x' })).toEqual(['a', 'b']);
  });
});
