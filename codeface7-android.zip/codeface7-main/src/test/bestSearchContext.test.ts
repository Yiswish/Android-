import { expect, it } from 'vitest';
import { bestSearchLabels, bestSearchQuery } from '@/lib/bestSearchContext';
import type { SearchResultImage } from '@/lib/types';

it('adds shared context to each separate name without changing names or injecting age', () => {
  expect(bestSearchQuery('Emma Watson', 'British actors\nsolo portrait -group')).toBe('Emma Watson British actors solo portrait -group');
  expect(bestSearchQuery('Natalie Portman', 'British actors\nsolo portrait -group')).toBe('Natalie Portman British actors solo portrait -group');
  expect(bestSearchQuery('Emma Watson', '  ')).toBe('Emma Watson');
});

it('retains original list labels rather than context and leaves fallback images unnamed', () => {
  const image = { id: 'one', url: 'https://example.com/photo.jpg', source: 'google', searchLabel: 'Emma Watson British actors' } as SearchResultImage;
  const result = bestSearchLabels([image, { ...image, source: 'curated' }, { ...image, source: 'upload' }], 'Emma Watson');
  expect(result.map((item) => item.searchLabel)).toEqual(['Emma Watson', undefined, undefined]);
  expect(image.searchLabel).toBe('Emma Watson British actors');
});