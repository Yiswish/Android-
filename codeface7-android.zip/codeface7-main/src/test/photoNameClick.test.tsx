import { fireEvent, render, screen } from '@testing-library/react';
import { expect, it, vi } from 'vitest';
import PhotoHeading, { PhotoNameSearchContext } from '@/components/PhotoHeading';
import { youngNameQuery } from '@/lib/photoLabel';

it('clicking a name searches young portraits without opening the photo', () => {
  const search = vi.fn();
  const open = vi.fn();
  render(<PhotoNameSearchContext.Provider value={(name) => search(youngNameQuery(name))}><div onClick={open}><PhotoHeading name="Emma Watson" /></div></PhotoNameSearchContext.Provider>);
  fireEvent.click(screen.getByRole('button', { name: 'Emma Watson' }));
  expect(search).toHaveBeenCalledExactlyOnceWith('Emma Watson young portraits');
  expect(open).not.toHaveBeenCalled();
});