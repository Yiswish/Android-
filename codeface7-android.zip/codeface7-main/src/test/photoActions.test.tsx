import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, expect, it, vi } from 'vitest';
import PhotoActions from '@/components/PhotoActions';

afterEach(cleanup);

it('shows attached-name search while preserving the original photo action', () => {
  const open = vi.fn();
  const search = vi.fn();
  render(<><PhotoActions names={new Map([['/photo.jpg', 'Emma Watson']])} onSearch={search} /><button onClick={open}><img src="/photo.jpg" alt="Photo" /></button></>);
  fireEvent.click(screen.getByAltText('Photo'));
  expect(open).toHaveBeenCalledTimes(1);
  expect(search).not.toHaveBeenCalled();
  fireEvent.click(screen.getByRole('button', { name: 'Search Emma Watson' }));
  expect(search).toHaveBeenCalledExactlyOnceWith('Emma Watson');
  expect(open).toHaveBeenCalledTimes(1);
});

it('never infers a name from alt text and searches only the name the user enters', () => {
  const search = vi.fn();
  render(<><PhotoActions names={new Map()} onSearch={search} /><img src="/unknown.jpg" alt="Emma Watson" /></>);
  fireEvent.click(screen.getByAltText('Emma Watson'));
  fireEvent.click(screen.getByRole('button', { name: 'Search by name' }));
  expect(screen.getByRole('textbox', { name: 'Name to search' })).toHaveValue('');
  expect(screen.getByRole('button', { name: 'Search entered name' })).toBeDisabled();
  fireEvent.change(screen.getByRole('textbox', { name: 'Name to search' }), { target: { value: 'Natalie Portman' } });
  fireEvent.click(screen.getByRole('button', { name: 'Search entered name' }));
  expect(search).toHaveBeenCalledExactlyOnceWith('Natalie Portman');
});