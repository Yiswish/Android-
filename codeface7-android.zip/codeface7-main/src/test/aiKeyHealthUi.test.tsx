import { afterEach, describe, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import AiKeyHealth, { healthLevel, lastHealth } from '@/components/AiKeyHealth';

const check = vi.hoisted(() => vi.fn());
vi.mock('@tanstack/react-start', () => ({ useServerFn: () => check }));
vi.mock('@/lib/aiLook.functions', () => ({ checkAiKeysServer: vi.fn() }));
vi.mock('@/lib/personalKeys', () => ({ personalKeys: () => ({}) }));
afterEach(() => { cleanup(); sessionStorage.clear(); vi.clearAllMocks(); });

describe('key health indicator', () => {
  it('is red when every personal key fails even if backup is configured', () => {
    expect(healthLevel({ personal: true, builtIn: 'set-up', keys: [{ provider: 'gemini', index: 1, status: 'rejected', detail: 'Rejected' }] })).toBe('bad');
  });
  it('stores green after a successful access check', async () => {
    check.mockResolvedValue({ ok: true, report: { personal: false, builtIn: 'missing', keys: [{ provider: 'gemini', index: 1, status: 'ok', detail: 'Working' }] } });
    render(<AiKeyHealth />);
    fireEvent.click(screen.getByRole('button', { name: 'Test keys' }));
    await screen.findByLabelText('AI keys: good');
    expect(lastHealth()).toBe('good');
    expect(check).toHaveBeenCalledTimes(1);
  });
});