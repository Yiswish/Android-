import { describe, it, expect } from 'vitest';
import { faceTypeMatch } from '@/lib/faceType';

const geo = (v: Record<string, number>) => ({ ratios: Object.entries(v).map(([id, measured]) => ({ id, measured })) }) as never;

describe('face type seed', () => {
  it('scores the preferred shape near 100', () => {
    const m = faceTypeMatch(geo({ 'eye-aspect': 0.36, fwhr: 1.95, 'face-length': 1.2, 'mouth-nose': 1.65 }), { skin: 100 });
    expect(m!.score).toBe(100);
  });
  it('scores a long narrow face with small eyes low', () => {
    const m = faceTypeMatch(geo({ 'eye-aspect': 0.24, fwhr: 1.6, 'face-length': 1.45, 'mouth-nose': 1.3 }), { skin: 40 });
    expect(m!.score).toBeLessThan(25);
  });
  it('returns nothing without measurements', () => {
    expect(faceTypeMatch(undefined)).toBeUndefined();
  });
});
