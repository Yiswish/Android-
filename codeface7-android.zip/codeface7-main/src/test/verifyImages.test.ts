import { describe, it, expect } from 'vitest';
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import jpeg from 'jpeg-js';
import { analyzeFaceGeometry, type Vec3, type FaceGeometryReport } from '@/lib/faceGeometry';
import { analyzeSkin, type SkinReport } from '@/lib/skin';
import { computeOverall } from '@/lib/scoring';

// ============================================================================
// REAL-LANDMARK CALIBRATION RUN on public/_verify
// ----------------------------------------------------------------------------
// Needs public/_verify/landmarks.json, produced by EITHER
//   • public/_verify/dump.html in a real browser (the app's own Face Landmarker; has blendshapes + pose matrix), OR
//   • tools/extract_landmarks.py (python FaceMesh, same mesh family; NO blendshapes / matrix).
// Pixels are decoded from the JPEGs here with the same luminance weights and the
// same ≤1536 px downscale as src/lib/faceDetection.ts, so the Skin & age metric
// sees what the app sees. The suite is skipped when landmarks.json is absent.
//
// Variants marked [synthetic] are generated from a real control by an image
// operation (gray conversion, down-scaling, smoothing, texture overlay). They are
// PROXIES: they check how the metric reacts, they are not real aged / retouched /
// low-resolution faces. Acceptance criteria that need real data that does not
// exist in this repo are reported as NOT TESTED, never as passed.
// ============================================================================
const dir = resolve(__dirname, '../../public/_verify');
const file = resolve(dir, 'landmarks.json');
type Entry = { width: number; height: number; landmarks: Vec3[]; blendshapes?: Record<string, number>; matrix?: number[]; source?: string };

interface Luma { luma: Float32Array; w: number; h: number }
const MAX_SIDE = 1536;

function resize(src: Float32Array, w: number, h: number, nw: number, nh: number): Float32Array {
  const out = new Float32Array(nw * nh);
  const sx = w / nw, sy = h / nh;
  for (let y = 0; y < nh; y++) {
    for (let x = 0; x < nw; x++) { // area average (box) for down-scaling
      const x0 = Math.floor(x * sx), x1 = Math.max(x0 + 1, Math.min(w, Math.ceil((x + 1) * sx)));
      const y0 = Math.floor(y * sy), y1 = Math.max(y0 + 1, Math.min(h, Math.ceil((y + 1) * sy)));
      let s = 0, n = 0;
      for (let yy = y0; yy < y1; yy++) for (let xx = x0; xx < x1; xx++) { s += src[yy * w + xx]; n++; }
      out[y * nw + x] = s / n;
    }
  }
  return out;
}

/** Same as faceDetection.toLuminanceSource: Rec.709 luminance, ≤1536 px, quantised to 8 bit. */
function loadLuma(name: string, weights: [number, number, number] = [0.2126, 0.7152, 0.0722]): Luma {
  const raw = jpeg.decode(readFileSync(resolve(dir, `${name}.jpg`)), { useTArray: true });
  let luma: Float32Array = new Float32Array(raw.width * raw.height);
  for (let i = 0; i < luma.length; i++) luma[i] = Math.round(weights[0] * raw.data[i * 4] + weights[1] * raw.data[i * 4 + 1] + weights[2] * raw.data[i * 4 + 2]);
  let w = raw.width, h = raw.height;
  const k = Math.min(1, MAX_SIDE / Math.max(w, h));
  if (k < 1) { const nw = Math.round(w * k), nh = Math.round(h * k); luma = resize(luma, w, h, nw, nh); w = nw; h = nh; }
  return { luma, w, h };
}

function blur(src: Float32Array, w: number, h: number, sigma: number): Float32Array {
  const r = Math.ceil(3 * sigma), k = Array.from({ length: 2 * r + 1 }, (_, i) => Math.exp(-((i - r) ** 2) / (2 * sigma * sigma)));
  const ks = k.reduce((a, b) => a + b, 0);
  const tmp = new Float32Array(w * h), out = new Float32Array(w * h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { let s = 0; for (let i = -r; i <= r; i++) s += k[i + r] * src[y * w + Math.min(w - 1, Math.max(0, x + i))]; tmp[y * w + x] = s / ks; }
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { let s = 0; for (let i = -r; i <= r; i++) s += k[i + r] * tmp[Math.min(h - 1, Math.max(0, y + i)) * w + x]; out[y * w + x] = s / ks; }
  return out;
}

const ipdPx = (lm: Vec3[], w: number, h: number) => Math.hypot((lm[468].x - lm[473].x) * w, (lm[468].y - lm[473].y) * h);

/** [synthetic] Skin smoothing: blur everything, keep the eyes sharp (what retouching does). */
function smoothSkin(l: Luma, lm: Vec3[]): Luma {
  const ipd = ipdPx(lm, l.w, l.h), b = blur(l.luma, l.w, l.h, Math.max(1.5, 0.035 * ipd));
  const out = Float32Array.from(b);
  for (const p of [lm[468], lm[473]]) {
    const cx = p.x * l.w, cy = p.y * l.h, r = 0.34 * ipd;
    for (let y = Math.max(0, Math.floor(cy - r)); y <= Math.min(l.h - 1, Math.ceil(cy + r)); y++) for (let x = Math.max(0, Math.floor(cx - r)); x <= Math.min(l.w - 1, Math.ceil(cx + r)); x++) if (Math.hypot(x - cx, y - cy) <= r) out[y * l.w + x] = l.luma[y * l.w + x];
  }
  return { ...l, luma: out };
}

/** [synthetic] Wrinkle-like ridged texture over the mid-face. A PROXY for ageing, not a real aged face. */
function addWrinkles(l: Luma, lm: Vec3[], amp = 0.2): Luma {
  const ipd = ipdPx(lm, l.w, l.h);
  let seed = 12345; const rnd = () => ((seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0) / 4294967296);
  const noise = new Float32Array(l.w * l.h); for (let i = 0; i < noise.length; i++) noise[i] = rnd() - 0.5;
  const f = blur(noise, l.w, l.h, 0.045 * ipd);
  let mx = 1e-9; for (const v of f) mx = Math.max(mx, Math.abs(v));
  const cx = ((lm[468].x + lm[473].x) / 2) * l.w, cy = (((lm[468].y + lm[473].y) / 2 + (lm[61].y + lm[291].y) / 2) / 2) * l.h;
  const out = Float32Array.from(l.luma);
  for (let y = 0; y < l.h; y++) for (let x = 0; x < l.w; x++) {
    const m = Math.exp(-(((x - cx) / (1.1 * ipd)) ** 2 + ((y - cy) / (1.0 * ipd)) ** 2));
    const ridge = 1 - Math.abs(f[y * l.w + x] / mx); // thin lines where the field crosses 0
    const eyeShield = Math.min(Math.hypot(x - lm[468].x * l.w, y - lm[468].y * l.h), Math.hypot(x - lm[473].x * l.w, y - lm[473].y * l.h)) > 0.34 * ipd ? 1 : 0;
    out[y * l.w + x] = l.luma[y * l.w + x] * (1 - amp * m * eyeShield * Math.pow(ridge, 6) * 2.2);
  }
  return { ...l, luma: out };
}

/** [synthetic] Down-scale by `k` (box filter): same face, fewer pixels. */
function lowRes(l: Luma, k: number): Luma {
  const nw = Math.round(l.w * k), nh = Math.round(l.h * k);
  return { luma: resize(l.luma, l.w, l.h, nw, nh), w: nw, h: nh };
}

// ---- rotate a real mesh in 3D (pixel space), to test head-pose invariance ----------------------
function rotateMesh(lm: Vec3[], w: number, h: number, yawDeg: number, rollDeg: number): Vec3[] {
  const a = (yawDeg * Math.PI) / 180, b = (rollDeg * Math.PI) / 180;
  const c = { x: 0, y: 0, z: 0 };
  for (const p of lm.slice(0, 468)) { c.x += p.x * w / 468; c.y += p.y * h / 468; c.z += p.z * w / 468; }
  return lm.map((p) => {
    let x = p.x * w - c.x, y = p.y * h - c.y, z = p.z * w - c.z;
    [x, z] = [x * Math.cos(a) + z * Math.sin(a), -x * Math.sin(a) + z * Math.cos(a)];
    [x, y] = [x * Math.cos(b) - y * Math.sin(b), x * Math.sin(b) + y * Math.cos(b)];
    return { x: (x + c.x) / w, y: (y + c.y) / h, z: (z + c.z) / w };
  });
}

// Photography is held constant (70) so the table isolates the FACE score.
const photo = { symmetry: 0, proportions: 0, structure: 0, skin: 0, composition: 70, lighting: 70, texture: 70, contrast: 70, naturalness: 70 };
const overallOf = (g: FaceGeometryReport) => computeOverall(photo, { facialHarmony: g.facialHarmony, confidence: g.confidence }).overall;

describe.skipIf(!existsSync(file))('public/_verify calibration (real landmarks)', () => {
  const data: Record<string, Entry> = existsSync(file) ? JSON.parse(readFileSync(file, 'utf8')) : {};
  const landmarkSource = Object.values(data)[0]?.source ?? 'browser Face Landmarker (dump.html)';

  interface Row { name: string; kind: string; sym: number; structure: number; golden: number; align: number; mouthJaw: number; skinRatio: number; skinScore: number; skinConf: number; face: number; overall: number; geo: FaceGeometryReport; skin?: SkinReport }
  const run = (name: string, lm: Vec3[], w: number, h: number, l: Luma | undefined, e: Entry, kind: string): Row => {
    const skin = l ? analyzeSkin(l.luma, l.w, l.h, lm) : undefined;
    const geo = analyzeFaceGeometry(lm, w, h, e.matrix?.length ? e.matrix : undefined, e.blendshapes && Object.keys(e.blendshapes).length ? e.blendshapes : undefined, skin);
    return { name, kind, sym: geo.symmetryPercent, structure: geo.structuralBalanceIndex, golden: geo.goldenRatioIndex, align: geo.alignmentIndex, mouthJaw: geo.mouthJawScore, skinRatio: skin?.ratio ?? NaN, skinScore: skin?.score ?? NaN, skinConf: skin?.confidence ?? NaN, face: geo.facialHarmony, overall: overallOf(geo), geo, skin };
  };

  const rows: Row[] = [];
  for (const [name, e] of Object.entries(data)) {
    if (!existsSync(resolve(dir, `${name}.jpg`))) continue;
    const l = loadLuma(name);
    rows.push(run(name, e.landmarks, e.width, e.height, l, e, name.startsWith('dist_') ? 'distorted' : name.startsWith('celeb_') ? 'celebrity' : name.startsWith('pro_photo') ? 'pro photo' : 'other'));
  }
  const real = rows.slice();
  const byName = (n: string) => real.find((r) => r.name === n)!;

  // ---- proxies built from real controls ----
  const bases = ['pro_photo-1507003211169-0a1dd7228f2d', 'pro_photo-1544005313-94ddf0286df2', 'celeb_Natalie_Portman', 'celeb_Adriana_Lima'].filter((n) => data[n]);
  for (const n of bases) {
    const e = data[n], l = loadLuma(n);
    rows.push(run(`${n}__gray601`, e.landmarks, e.width, e.height, loadLuma(n, [0.299, 0.587, 0.114]), e, 'gray (BT.601) [synthetic]'));
    rows.push(run(`${n}__lowres25`, e.landmarks, e.width, e.height, lowRes(l, 0.25), e, 'low-res ×0.25 [synthetic]'));
    rows.push(run(`${n}__lowres12`, e.landmarks, e.width, e.height, lowRes(l, 0.12), e, 'low-res ×0.12 [synthetic]'));
    rows.push(run(`${n}__retouched`, e.landmarks, e.width, e.height, smoothSkin(l, e.landmarks), e, 'retouched [synthetic]'));
    rows.push(run(`${n}__wrinkles`, e.landmarks, e.width, e.height, addWrinkles(l, e.landmarks), e, 'aged proxy [synthetic]'));
  }

  const fmt = (v: unknown) => (typeof v === 'number' ? (Number.isFinite(v) ? +v.toFixed(v < 1 && v !== 0 ? 3 : 1) : '—') : v);
  const avg = (xs: number[]) => xs.reduce((s, x) => s + x, 0) / (xs.length || 1);
  const avgOf = (pred: (r: Row) => boolean) => avg(real.filter(pred).map((r) => r.overall));

  it(`prints the table (landmarks: ${landmarkSource})`, () => {
    console.log(`\nLandmark source: ${landmarkSource}. Photography held at 70 so only the face varies.\n`);
    console.table(rows.map((r) => Object.fromEntries(Object.entries({ name: r.name.replace('pro_photo-', 'pro_'), kind: r.kind, symmetry: r.sym, structure: r.structure, golden: r.golden, align: r.align, 'mouth/jaw': r.mouthJaw, 'skin ratio': r.skinRatio, skin: r.skinScore, 'skin conf': r.skinConf, face: r.face, overall: r.overall }).map(([k, v]) => [k, fmt(v)]))));
    expect(rows.length).toBeGreaterThan(5);
  });

  it('[1] dist_* average ≥ 10 points below BOTH pro_photo_* and celeb_* averages', () => {
    const d = avgOf((r) => r.kind === 'distorted'), p = avgOf((r) => r.kind === 'pro photo'), c = avgOf((r) => r.kind === 'celebrity');
    console.log(`[1] dist ${d.toFixed(1)} | pro ${p.toFixed(1)} | celeb ${c.toFixed(1)} | gap to pro ${(p - d).toFixed(1)}, to celeb ${(c - d).toFixed(1)}`);
    expect(d + 10).toBeLessThan(Math.min(p, c));
  });

  it('[2] symmetry spread across the controls > 20 points', () => {
    const sym = real.map((r) => r.sym);
    console.log(`[2] symmetry min ${Math.min(...sym).toFixed(1)} max ${Math.max(...sym).toFixed(1)} spread ${(Math.max(...sym) - Math.min(...sym)).toFixed(1)}`);
    expect(Math.max(...sym) - Math.min(...sym)).toBeGreaterThan(20);
  });

  it('[3] aged / wrinkled face ≥ 15 below clean portraits — NOT VERIFIED (no real aged control); the synthetic proxy must at least move the right way', () => {
    // Only bases whose skin measurement is confident can show the effect (confidence-shrunk skin sits near 70).
    const usable = bases.filter((n) => (byName(n).skin?.confidence ?? 0) > 0.5);
    const lines = bases.map((n) => {
      const c = byName(n), w = rows.find((r) => r.name === `${n}__wrinkles`)!;
      return `${n}: skin ${c.skinScore.toFixed(1)} → ${w.skinScore.toFixed(1)} (ratio ${c.skinRatio.toFixed(3)} → ${w.skinRatio.toFixed(3)}), overall ${c.overall.toFixed(1)} → ${w.overall.toFixed(1)} (Δ ${(w.overall - c.overall).toFixed(1)}), clean-skin confidence ${(c.skin?.confidence ?? 0).toFixed(2)}`;
    });
    console.log(`[3] [synthetic proxy, NOT a real aged face; the ≥15-point criterion is NOT VERIFIED]\n  ${lines.join('\n  ')}`);
    expect(usable.length).toBeGreaterThan(0);
    for (const n of usable) {
      const c = byName(n), w = rows.find((r) => r.name === `${n}__wrinkles`)!;
      expect(w.skinRatio).toBeGreaterThan(c.skinRatio * 1.5);
      expect(w.skinScore).toBeLessThan(c.skinScore - 8); // the SKIN metric must respond; the overall may be dominated by another group (see README)
    }
  });

  it('[5] a grayscale (BT.601) conversion of a colour portrait scores within ±3 points', () => {
    for (const n of bases) {
      const a = byName(n).overall, b = rows.find((r) => r.name === `${n}__gray601`)!.overall;
      console.log(`[5] ${n}: colour→709 ${a.toFixed(2)} vs gray 601 ${b.toFixed(2)} (Δ ${(b - a).toFixed(2)})`);
      expect(Math.abs(a - b)).toBeLessThanOrEqual(3);
    }
  });

  it('[6] head rotation within ±15° (yaw / roll) moves the overall ≤ 9 points', () => {
    let worst = 0, worstName = '';
    for (const r of real.filter((x) => x.kind !== 'distorted')) {
      const e = data[r.name], l = loadLuma(r.name);
      for (const [yaw, roll] of [[15, 0], [-15, 0], [0, 15], [0, -15], [10, 10]]) {
        const lm = rotateMesh(e.landmarks, e.width, e.height, yaw, roll);
        const rr = run(r.name, lm, e.width, e.height, l, e, 'x');
        const d = Math.abs(rr.overall - r.overall);
        if (d > worst) { worst = d; worstName = `${r.name} (yaw ${yaw}, roll ${roll})`; }
      }
    }
    console.log(`[6] largest pose-induced change: ${worst.toFixed(2)} points — ${worstName}`);
    // Owner removed the turned-head penalty (which used to damp this swing); raw pose swing is now reported as measured (~7 points).
    // Photo quality no longer scales the face (×0.8–1.0), so the same swing reads ~10% larger (measured 8.59).
    expect(worst).toBeLessThanOrEqual(9);
  });

  it('[7] no VISIBLE metric pins at 0 or 100 (rounded, undistorted controls) and none is NaN', () => {
    // What the user sees: the symmetry / golden / structure / skin bars (structure bar = 0.7·structure + 0.3·alignment), the face score and the overall.
    const pins: string[] = [], saturatedInternals: string[] = [];
    for (const r of rows.filter((x) => x.kind !== 'distorted')) { // a deliberately destroyed face may legitimately reach ≈0 symmetry
      const vals: Record<string, number> = { symmetry: r.sym, golden: r.golden, 'structure bar': 0.7 * r.structure + 0.3 * r.align, face: r.face, overall: r.overall };
      if (Number.isFinite(r.skinScore)) vals.skin = r.skinScore;
      for (const [k, v] of Object.entries(vals)) { if (!Number.isFinite(v)) pins.push(`${r.name}.${k}=NaN`); else if (Math.round(v) <= 0 || Math.round(v) >= 100) pins.push(`${r.name}.${k}=${v.toFixed(2)}`); }
      if (r.kind !== 'distorted' && !r.name.includes('__')) for (const [k, v] of Object.entries({ structure: r.structure, mouthJaw: r.mouthJaw })) if (v >= 99.5) saturatedInternals.push(`${r.name.slice(0, 22)}.${k}=${v.toFixed(1)}`);
    }
    console.log(`[7] visible pins/NaN: ${pins.length ? pins.join(', ') : 'none'}\n[7] internal groups saturated ≥99.5 on clean faces (not shown as bars): ${saturatedInternals.join(', ') || 'none'}`);
    expect(pins).toEqual([]);
  });

  it('[4] smiling vs the neutral version of the same face — NOT TESTED: the repo has no real neutral/smiling pair', () => {
    console.log('[4] NOT TESTED on real data. Only the synthetic-mesh unit test (faceGeometry.test.ts) covers it. Add pairs named smile_<id>.jpg / neutral_<id>.jpg and extend this test.');
    expect(true).toBe(true);
  });
});
