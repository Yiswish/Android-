import { describe, expect, it } from 'vitest';
import { previousView } from '@/lib/viewNavigation';

describe('Back navigation', () => {
  it('returns from a saved result to history rather than search', () => {
    expect(previousView(['search', 'history'])).toEqual({ view: 'history', stack: ['search'] });
  });
  it('skips transient analysis screens', () => {
    expect(previousView(['history', 'analyzing'])).toEqual({ view: 'history', stack: [] });
  });
  it('stays inside the app when there is no earlier screen', () => {
    expect(previousView([])).toEqual({ view: 'search', stack: [] });
  });
});