import { describe, it, expect } from 'vitest';
import { rotateKeys, findGroqKeys, keyOrder, passStarts, takeKeyTurns } from '@/lib/aiKeys';

describe('Gemini key rotation', () => {
  const keys = ['k1', 'k2', 'k3', 'k4'];
  it('each new check starts on a different key', () => {
    expect([0, 1, 2, 3].map((n) => rotateKeys(keys, n)[0])).toEqual(['k1', 'k2', 'k3', 'k4']);
  });
  it('wraps around after the last key', () => {
    expect(rotateKeys(keys, 5)).toEqual(['k2', 'k3', 'k4', 'k1']);
  });
  it('still keeps every key as a fallback', () => {
    expect(keyOrder(4, 2)).toEqual([2, 3, 0, 1]);
  });
  it('finds keys even when named slightly differently', () => {
    expect(findGroqKeys({ GROQ_KEY_4: 'd', GROQ_API_KEY3: 'c', GROQ_API_KEY_2: 'b', GROQ_API_KEY: 'a', OTHER: 'x' })).toEqual(['a', 'b', 'c', 'd']);
  });
  it('Way off: 3 passes each start on a different key', () => {
    expect(passStarts(5, 3).map((s) => keyOrder(4, s)[0])).toEqual([1, 2, 3]);
  });
  it('the check counter survives a reload (stored)', () => {
    const mem = new Map<string, string>();
    const store = { getItem: (k: string) => mem.get(k) ?? null, setItem: (k: string, v: string) => void mem.set(k, v) };
    expect([takeKeyTurns(store), takeKeyTurns(store), takeKeyTurns(store, 3), takeKeyTurns(store)]).toEqual([0, 1, 2, 5]);
  });
});
