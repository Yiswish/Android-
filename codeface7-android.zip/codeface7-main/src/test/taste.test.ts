import { describe, it, expect } from 'vitest';
import { buildTasteModel, computeTasteMatch } from '@/lib/preferenceEngine';
import { normalizeMetrics } from '@/lib/metricKeys';
import type { AnalysisResult } from '@/lib/types';

const mk = (id: string, skin: number, lighting: number) =>
  ({ id, imageId: id, imageUrl: '', scores: { overall: 50, metrics: normalizeMetrics({ ...normalizeMetrics(null), skin, lighting }) } }) as unknown as AnalysisResult;

describe('taste model', () => {
  const results = Array.from({ length: 12 }, (_, i) => mk(`i${i}`, 30 + i * 5, 40 + ((i * 7) % 30)));
  const ratings = results.map((r, i) => ({ imageId: r.imageId, rating: 1 + Math.round((i / 11) * 4), timestamp: i }));
  const model = buildTasteModel(results, ratings);
  it('learns what the user rewards and ranks new images accordingly', () => {
    const hi = computeTasteMatch(mk('n1', 85, 55).scores.metrics, model, undefined, 50)!;
    const lo = computeTasteMatch(mk('n2', 32, 55).scores.metrics, model, undefined, 50)!;
    expect(hi.predictedStars - lo.predictedStars).toBeGreaterThan(1.5);
    expect(hi.score).toBeGreaterThan(70);
    expect(lo.score).toBeLessThan(30);
    expect(hi.confidence).toBeGreaterThan(0.5);
  });
  it('never predicts an image from its own rating', () => {
    const self = computeTasteMatch(results[11].scores.metrics, model, 'i11', 50)!;
    expect(self.neighbours?.some((n) => n.imageId === 'i11')).toBe(false);
  });
});

describe('expression never affects taste', () => {
  const flat = normalizeMetrics(null);
  const mkE = (id: string, expression: number) =>
    ({ id, imageId: id, imageUrl: '', scores: { overall: 50, metrics: flat },
       faceDetection: { geometry: { groups: [{ id: 'expression', score: expression }] } } }) as unknown as AnalysisResult;
  const results = Array.from({ length: 10 }, (_, i) => mkE(`e${i}`, 20 + i * 8));
  const ratings = results.map((r, i) => ({ imageId: r.imageId, rating: 1 + Math.round((i / 9) * 4), timestamp: i }));
  const model = buildTasteModel(results, ratings);
  it('gives the same prediction whatever the stored expression was', () => {
    const a = computeTasteMatch(flat, model, undefined, 50, {})!;
    const b = computeTasteMatch(flat, model, undefined, 50, { expression: 90 } as never)!;
    expect(a.predictedStars).toBeCloseTo(b.predictedStars, 6);
  });
});

describe('recency and active learning', () => {
  it('weights recent ratings more: newest rating has full weight, one half-life back has half', async () => {
    const { TASTE_HALF_LIFE } = await import('@/lib/preferenceEngine');
    const results = Array.from({ length: TASTE_HALF_LIFE + 1 }, (_, i) => mk(`r${i}`, 40 + (i % 5) * 10, 50));
    const ratings = results.map((r, i) => ({ imageId: r.imageId, rating: 1 + (i % 5), timestamp: i }));
    const m = buildTasteModel(results, ratings);
    expect(m.samples[0].imageId).toBe(`r${TASTE_HALF_LIFE}`);
    expect((m.samples[0] as { recency?: number }).recency).toBe(1);
    expect((m.samples[TASTE_HALF_LIFE] as { recency?: number }).recency).toBeCloseTo(0.5, 6);
  });
  it('suggests the unrated photo least like anything already rated', async () => {
    const { suggestNextToRate } = await import('@/lib/preferenceEngine');
    const det = (a: AnalysisResult) => ({ ...a, faceDetection: { detected: true } }) as unknown as AnalysisResult;
    const results = Array.from({ length: 6 }, (_, i) => det(mk(`s${i}`, 50 + i, 50)));
    const ratings = results.map((r, i) => ({ imageId: r.imageId, rating: 1 + (i % 5), timestamp: i }));
    const m = buildTasteModel(results, ratings);
    const near = det(mk('near', 52, 50)), far = det(mk('far', 99, 99));
    const out = suggestNextToRate(m, [...results, near, far]);
    expect(out.map((x) => x.imageId)).toEqual(['far', 'near']);
  });
});

describe('taste ignores the photography', () => {
  const flat = normalizeMetrics(null);
  const mkL = (id: string, lighting: number) => ({ id, imageId: id, imageUrl: '', scores: { overall: 50, metrics: { ...flat, lighting } } }) as unknown as AnalysisResult;
  const results = Array.from({ length: 10 }, (_, i) => mkL(`l${i}`, 10 + i * 9));
  const ratings = results.map((r, i) => ({ imageId: r.imageId, rating: 1 + Math.round((i / 9) * 4), timestamp: i }));
  const model = buildTasteModel(results, ratings);
  it('lighting does not change the prediction or appear as a reason', () => {
    const a = computeTasteMatch({ ...flat, lighting: 95 }, model, undefined, 50)!;
    const b = computeTasteMatch({ ...flat, lighting: 5 }, model, undefined, 50)!;
    expect(Math.abs(a.predictedStars - b.predictedStars)).toBeLessThan(0.01);
    expect([...(a.pros ?? []), ...(a.cons ?? [])].join(' ')).not.toMatch(/lighting/i);
  });
});

describe('taste v3', () => {
  it('favourite-test losses lower a low rating too', async () => {
    const { favouriteNudge, FAVOURITE_STAR_NUDGE } = await import('@/lib/preferenceEngine');
    expect(favouriteNudge({ imageId: 'x', strength: 1300, comparisons: 5, wins: 0 })).toBe(-FAVOURITE_STAR_NUDGE);
  });
});
