import { describe, expect, it } from 'vitest';
import { searchPhotoLabel, youngNameQuery } from '@/lib/photoLabel';
import type { SearchResultImage } from '@/lib/types';

const image = { source: 'google' } as SearchResultImage;
describe('Known searched photo labels', () => {
  it('searches the clicked name for young portraits without repeated suffixes', () => {
    expect(youngNameQuery('Emma Watson')).toBe('Emma Watson young portraits');
    expect(youngNameQuery(youngNameQuery('Emma Watson'))).toBe('Emma Watson young portraits');
  });
  it('retains the searched name independently of later searches', () => {
    const searchLabel = searchPhotoLabel(image, 'Emma Watson');
    expect(searchPhotoLabel({ ...image, searchLabel }, 'Natalie Portman')).toBe('Emma Watson');
  });
  it('does not assign a searched identity to an uploaded photo', () => {
    expect(searchPhotoLabel({ ...image, source: 'upload' }, 'Emma Watson')).toBeUndefined();
  });
  it('does not assign a searched identity to unrelated curated fallback photos', () => {
    expect(searchPhotoLabel({ ...image, source: 'curated' }, 'Emma Watson')).toBeUndefined();
  });
});