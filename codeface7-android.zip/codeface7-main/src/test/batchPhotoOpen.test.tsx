import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import BatchAnalysisPanel from '@/components/BatchAnalysisPanel';
import type { AnalysisResult, SearchResultImage } from '@/lib/types';

vi.mock('@/components/CollectionTools', () => ({ WeightedScore: () => null }));

const image: SearchResultImage = {
  id: 'uploaded-photo', url: '/photo.jpg', thumbUrl: '/photo.jpg',
  alt: 'portrait.jpg', source: 'upload', width: 300, height: 400,
};

describe('Opening batch photos', () => {
  it('opens the already completed result unchanged when the photo is clicked', () => {
    const result = { id: 'saved-analysis', scores: { overall: 64 } } as AnalysisResult;
    const onOpen = vi.fn();
    render(<BatchAnalysisPanel photos={[{ image, status: 'complete', result }]} busy={false} stopping={false} onStop={vi.fn()} onClose={vi.fn()} onOpen={onOpen} />);
    fireEvent.click(screen.getByRole('button', { name: 'Open analysis for portrait.jpg' }));
    expect(onOpen).toHaveBeenCalledExactlyOnceWith(result);
    expect(onOpen.mock.calls[0][0]).toBe(result);
  });

  it('does not open or start another scan for a photo without a result', () => {
    const onOpen = vi.fn();
    render(<BatchAnalysisPanel photos={[{ image, status: 'analyzing' }]} busy stopping={false} onStop={vi.fn()} onClose={vi.fn()} onOpen={onOpen} />);
    fireEvent.click(screen.getByRole('button', { name: 'Open analysis for portrait.jpg' }));
    expect(onOpen).not.toHaveBeenCalled();
  });
});