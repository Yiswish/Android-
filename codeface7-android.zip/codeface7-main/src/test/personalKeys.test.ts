import { afterEach, describe, expect, it } from 'vitest';
import { allowPersonalKeys, clearPersonalKeys, personalKeys, personalKeyRevision, savePersonalKeys } from '@/lib/personalKeys';

afterEach(clearPersonalKeys);
describe('personal key rules', () => {
  it('allows anyone to use personal keys while unlocked', () => { expect(allowPersonalKeys(false)).toBe(true); });
  it('rejects personal keys while locked by the owner', () => { expect(allowPersonalKeys(true)).toBe(false); });
  it('keeps the five Gemini keys and SerpAPI key separate', () => {
    savePersonalKeys({ gemini: ['1', '2', '3', '4', '5'] });
    savePersonalKeys({ serpapi: 'search-test' });
    expect(personalKeys()).toEqual({ gemini: ['1', '2', '3', '4', '5'], serpapi: 'search-test' });
  });
  it('invalidates cached identity on replacement and removal without key values', () => {
    const initial = personalKeyRevision();
    savePersonalKeys({ serpapi: 'test-only' });
    expect(personalKeyRevision()).toBe(initial + 1);
    clearPersonalKeys();
    expect(personalKeyRevision()).toBe(initial + 2);
    expect(personalKeys().serpapi).toBeUndefined();
  });
});