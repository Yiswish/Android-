import { describe, it, expect } from 'vitest';
import { bodyCheck, type PosePoint } from '@/lib/bodyDetection';
const pose = (vis: number) => Array.from({ length: 33 }, (): PosePoint => ({ x: 0.5, y: 0.5, visibility: vis }));
describe('bodyCheck', () => {
  it('rejects a photo with no person', () => expect(bodyCheck([]).found).toBe(false));
  it('rejects when hips are not visible', () => { const p = pose(0.9); p[23].visibility = 0.1; expect(bodyCheck([p]).found).toBe(false); });
  it('accepts shoulders and hips visible', () => expect(bodyCheck([pose(0.9)])).toEqual({ found: true, people: 1 }));
});
