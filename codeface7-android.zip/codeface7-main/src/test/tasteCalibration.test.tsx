import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import TasteCalibration from '@/components/TasteCalibration';
import { buildTasteModel } from '@/lib/preferenceEngine';
import { emptyMetrics } from '@/lib/metricKeys';
import type { AnalysisResult } from '@/lib/types';

afterEach(cleanup);
const results: AnalysisResult[] = Array.from({ length: 7 }, (_, i) => ({
  id: `scan-${i}`, imageId: `photo-${i}`, imageUrl: `/portrait-${i}.jpg`, source: 'upload', timestamp: i,
  faceDetection: { detected: true, faceCount: 1, faces: [], primaryFaceIndex: 0, pose: 'frontal', poseConfidence: 1, expression: 'neutral', expressionConfidence: 1, logs: [] },
  scores: { overall: 60 + i, metrics: emptyMetrics(60 + i), archetypeMatch: {} }, warnings: [], duration: 1, topArchetypes: [],
}));

describe('rapid taste calibration', () => {
  it('uses five existing photos and records the concrete 1–5 answers', () => {
    const onRate = vi.fn();
    render(<TasteCalibration results={results} tasteModel={buildTasteModel(results, [])} onRate={onRate} onGoRate={vi.fn()} />);
    fireEvent.click(screen.getByRole('button', { name: 'Start (5 faces)' }));
    for (const label of ['Not for me', 'Meh', 'Okay', 'Like', 'Love']) fireEvent.click(screen.getByRole('button', { name: label }));
    expect(onRate.mock.calls).toEqual(Array.from({ length: 5 }, (_, i) => [`photo-${i}`, i + 1]));
  });
  it('skips without recording a rating and excludes already-rated photos', () => {
    const onRate = vi.fn();
    render(<TasteCalibration results={results} tasteModel={buildTasteModel(results, [{ imageId: 'photo-0', rating: 5, timestamp: 1 }])} onRate={onRate} onGoRate={vi.fn()} />);
    fireEvent.click(screen.getByRole('button', { name: 'Start (5 faces)' }));
    fireEvent.click(screen.getByRole('button', { name: 'Skip' }));
    expect(onRate).not.toHaveBeenCalled();
    for (let i = 0; i < 4; i++) fireEvent.click(screen.getByRole('button', { name: 'Love' }));
    expect(onRate).toHaveBeenCalledTimes(4);
    expect(onRate.mock.calls.map(([id]) => id)).not.toContain('photo-0');
  });
});