import { describe, it, expect } from 'vitest';
import { expressionFromBlendshapes } from '@/lib/faceGeometry';

const neutral = { mouthSmileLeft: 0, mouthSmileRight: 0, eyeSquintLeft: 0.05, eyeSquintRight: 0.05 };
const smile = { mouthSmileLeft: 0.8, mouthSmileRight: 0.7, cheekSquintLeft: 0.6, cheekSquintRight: 0.5, eyeSquintLeft: 0.5, eyeSquintRight: 0.45, mouthUpperUpLeft: 0.4, mouthUpperUpRight: 0.35 };

describe('a smile is not a flaw', () => {
  it('a natural broad smile scores within 5 points of neutral', () => {
    const n = expressionFromBlendshapes(neutral).score;
    const s = expressionFromBlendshapes(smile).score;
    expect(n - s).toBeLessThan(5);
  });
  it('a grimace (no smile, sneer + brow down) still costs', () => {
    const g = expressionFromBlendshapes({ noseSneerLeft: 0.7, noseSneerRight: 0.7, browDownLeft: 0.7, browDownRight: 0.7 }).score;
    expect(g).toBeLessThan(expressionFromBlendshapes(neutral).score - 15);
  });
});
