import { describe, it, expect, vi } from 'vitest';
import { findBest, parseQueries, roundRobin, clampCap, FIND_BEST_MAX_CAP } from '../lib/findBest';
import { findBest as fb2 } from '@/lib/findBest';
import type { AestheticScores, SearchResponse, SearchResultImage } from '../lib/types';

const img = (q: string, i: number, tall = true): SearchResultImage => ({
  id: `${q}-${i}`, url: `https://x/${q}/${i}.jpg`, thumbUrl: '', width: tall ? 600 : 900, height: tall ? 900 : 600, alt: q, source: 'google',
});
const resp = (q: string, n: number, extra: Partial<SearchResponse> = {}): SearchResponse => ({
  images: Array.from({ length: n }, (_, i) => img(q, i)), totalCount: n, hasMore: false, source: 'google', ...extra,
});
const scores = (overall: number) => ({ overall, metrics: {} }) as unknown as AestheticScores;
const scoreOf = (im: SearchResultImage) => 50 + Number(im.id.split('-').pop()) + im.alt.length;

function deps(over: Partial<Parameters<typeof findBest>[2]> = {}) {
  const base = {
    search: vi.fn(async (q: string) => resp(q, 20)),
    measure: vi.fn(async (im: SearchResultImage) => ({ measured: im.id, scores: scores(scoreOf(im)) })),
    aiCheck: vi.fn(async (_im: SearchResultImage, s: AestheticScores) => ({ ...s, overall: s.overall - 1, aiLook: { attractiveness: 70 } }) as unknown as AestheticScores),
  };
  return { ...base, ...over } as typeof base & { concurrency?: number };
}

describe('find the best', () => {
  it('checks 10 photos per name rather than sharing 10 across names', async () => {
    const d = deps();
    const r = await findBest(['a', 'b', 'c'], { photosPerQuery: { a: 10, b: 10, c: 10 } }, d);
    expect(r.ranked.length).toBe(30);
    for (const query of ['a', 'b', 'c']) expect(r.ranked.filter((e) => e.query === query)).toHaveLength(10);
  });
  it('honours a different count for each name without borrowing spare places', async () => {
    const d = deps();
    const r = await findBest(['a', 'b'], { photosPerQuery: { a: 2, b: 7 } }, d);
    expect(r.ranked.filter((e) => e.query === 'a')).toHaveLength(2);
    expect(r.ranked.filter((e) => e.query === 'b')).toHaveLength(7);
  });
  it('AI-checks every measured picture in all mode even outside the top 3', async () => {
    const d = deps();
    const r = await findBest(['a', 'b'], { photosPerQuery: { a: 10, b: 10 }, topN: 3, aiMode: 'all' }, d);
    expect(d.aiCheck).toHaveBeenCalledTimes(20);
    expect(r.ranked.every((e) => e.aiChecked)).toBe(true);
  });
  it('caps the run at 300 photos', () => {
    expect(FIND_BEST_MAX_CAP).toBe(300);
    expect(clampCap(500)).toBe(300);
    expect(clampCap(299)).toBe(299);
  });

  it('never analyses more than the cap across all queries', async () => {
    const d = deps();
    const r = await findBest(['a', 'bb', 'ccc', 'dddd'], { cap: 7 }, d);
    expect(d.measure).toHaveBeenCalledTimes(7);
    expect(r.ranked.length).toBe(7);
    expect(r.progress.analysed).toBe(7);
  });

  it('gives each query a fair round-robin share of the cap', async () => {
    const d = deps();
    await findBest(['a', 'b', 'c'], { cap: 9 }, d);
    const perQuery = d.measure.mock.calls.reduce<Record<string, number>>((m, [im]) => ({ ...m, [im.alt]: (m[im.alt] ?? 0) + 1 }), {});
    expect(perQuery).toEqual({ a: 3, b: 3, c: 3 });
    expect(roundRobin([[1, 2, 3], [4], [5, 6]], 5)).toEqual([1, 4, 5, 2, 6]);
  });

  it('stops on a SerpAPI quota error and keeps what it has', async () => {
    const d = deps({
      search: vi.fn(async (q: string) => q === 'b'
        ? resp(q, 5, { status: { provider: 'openverse', fallbackReason: 'quota', attempts: [{ provider: 'serpapi', reason: 'quota', message: 'serpapi HTTP 429' }] } as never })
        : resp(q, 2)),
    });
    const r = await findBest(['a', 'b', 'c'], { cap: 10 }, d);
    expect(r.stopped?.provider).toBe('SerpAPI');
    expect(d.search).toHaveBeenCalledTimes(2);
    expect(d.measure).not.toHaveBeenCalled();
  });

  it('stops on a Gemini quota error and keeps measurement-only scores', async () => {
    const d = deps({ aiCheck: vi.fn(async (_im, s) => ({ ...s, aiLookError: 'key 1: out of quota' }) as AestheticScores), concurrency: 1, sleep: async () => {} });
    const r = await findBest(['a'], { cap: 5, topN: 3 }, d);
    expect(r.stopped?.provider).toBe('Groq');
    expect(d.aiCheck).toHaveBeenCalledTimes(1); // confirmed exhaustion cannot heal by retrying
    expect(r.ranked.length).toBe(5);
    expect(r.ranked.every((e) => !e.aiChecked)).toBe(true);
  });

  it('runs the AI check only on the top N by overall score', async () => {
    const d = deps();
    const r = await findBest(['a'], { cap: 10, topN: 3 }, d);
    expect(d.aiCheck).toHaveBeenCalledTimes(3);
    const checkedIds = d.aiCheck.mock.calls.map(([im]) => im.id).sort();
    expect(checkedIds).toEqual(['a-7', 'a-8', 'a-9']);
    expect(r.best?.image.id).toBe('a-9');
    expect(r.ranked.filter((e) => e.aiChecked).length).toBe(3);
  });

  it('sends each listed query (trimmed)', async () => {
    const d = deps();
    await findBest(parseQueries('  Gal Gadot red carpet 2019 \n\nportrait of a woman'), { cap: 4 }, d);
    expect(d.search.mock.calls.map(([q]) => q)).toEqual(['Gal Gadot red carpet 2019', 'portrait of a woman']);
  });
  it('splits a comma or numbered list into separate queries', () => {
    expect(parseQueries('Adele, Rihanna; Dua Lipa\n1. Billie Eilish\n- Adele')).toEqual(['Adele', 'Rihanna', 'Dua Lipa', 'Billie Eilish']);
  });
  it('searches the whole list and measures at least one photo per query', async () => {
    const d = deps();
    const qs = Array.from({ length: 8 }, (_, i) => `singer ${i}`);
    const r = await findBest(qs, { cap: 3 }, d);
    expect(d.search).toHaveBeenCalledTimes(8);
    expect(new Set(r.ranked.map((e) => e.query)).size).toBe(8);
  });
});

import { it as it2, expect as expect2 } from 'vitest';
it2('keeps every person even when providers reuse the same photo ids', async () => {
  const names = ['A', 'B', 'C'];
  const r = await fb2<number>(names, { cap: 3, topN: 1 }, {
    search: async (q) => ({ images: [{ id: 'serp-1-0', url: `https://x/${q}.jpg`, thumbUrl: '', width: 1, height: 1, alt: q, source: 'google' }] }) as never,
    measure: async () => ({ measured: 1, scores: { overall: 50 } as never }),
    aiCheck: async (_i, s) => s,
  });
  expect2(new Set(r.ranked.map((e) => e.query))).toEqual(new Set(names));
});

it2('replaces failed AI checks with the next photo until the chosen number succeed', async () => {
  let calls = 0;
  const r = await fb2<number>(['a'], { cap: 20, topN: 15 }, {
    search: async (q) => ({ images: Array.from({ length: 20 }, (_, i) => ({ id: `${q}-${i}`, url: `https://x/${i}.jpg`, thumbUrl: '', width: 6, height: 9, alt: q, source: 'google' })) }) as never,
    measure: async (im) => ({ measured: 1, scores: { overall: Number(im.id.split('-')[1]) } as never }),
    aiCheck: async (_i, s) => (++calls % 4 === 0 ? { ...s, aiLookError: 'timeout' } : { ...s, aiLook: { attractiveness: 70 } }) as never,
    concurrency: 1,
  });
  expect2(r.ranked.filter((e) => e.aiChecked)).toHaveLength(15);
});

it2('retries a rate-limited AI check instead of ending the run', async () => {
  let calls = 0;
  const r = await fb2<number>(['a'], { cap: 6, topN: 5 }, {
    search: async (q) => ({ images: Array.from({ length: 6 }, (_, i) => ({ id: `${q}-${i}`, url: `https://x/${i}.jpg`, thumbUrl: '', width: 6, height: 9, alt: q, source: 'google' })) }) as never,
    measure: async (im) => ({ measured: 1, scores: { overall: Number(im.id.split('-')[1]) } as never }),
    aiCheck: async (_i, s) => (++calls === 2 ? { ...s, aiLookError: 'the AI is busy right now, try again in a minute' } : { ...s, aiLook: { attractiveness: 70 } }) as never,
    concurrency: 1, sleep: async () => {},
  });
  expect2(r.stopped).toBeUndefined();
  expect2(r.ranked.filter((e) => e.aiChecked)).toHaveLength(5);
});

it('checks the requested 5 photos after one photo stays busy through every retry', async () => {
  const d = deps({
    aiCheck: vi.fn(async (im, s) => im.id === 'a-5'
      ? { ...s, aiLookError: 'key 1: out of quota; the AI is busy right now' } as AestheticScores
      : { ...s, aiLook: { attractiveness: 70 } } as AestheticScores),
    aiConcurrency: 2,
    sleep: async () => {},
  });
  const r = await findBest(['a'], { cap: 6, topN: 5 }, d);
  expect(r.stopped).toBeUndefined();
  expect(r.ranked.filter((e) => e.aiChecked)).toHaveLength(5);
  expect(r.progress.aiChecks).toBe(5);
  expect(d.aiCheck).toHaveBeenCalledTimes(9);
});

it('gives a failed AI check a second try on the same photo', async () => {
  const img = (i: number) => ({ id: `p${i}`, url: `u${i}` }) as never;
  let calls = 0;
  const r = await findBest(['a'], { photosPerQuery: { a: 1 }, topN: 1, aiMode: 'top' } as never, {
    search: async () => ({ images: [img(1)], hasMore: false }) as never,
    measure: async () => ({ measured: {}, scores: { overall: 50 } }) as never,
    aiCheck: async (_i: unknown, s: never) => (++calls === 1 ? { ...(s as object), aiLookError: 'unreadable answer' } : { ...(s as object), overall: 70, aiLook: { attractiveness: 70 } }) as never,
    concurrency: 1, sleep: async () => {},
  } as never);
  expect(calls).toBe(2);
  expect(r.ranked[0].aiChecked).toBe(true);
});

it('measures a photo again before skipping it', async () => {
  let tries = 0;
  const r = await findBest(['a'], { photosPerQuery: { a: 1 }, topN: 0, aiMode: 'top' } as never, {
    search: async () => ({ images: [{ id: 'p1', url: 'u1' }], hasMore: false }) as never,
    measure: async () => { if (++tries === 1) throw new Error('load failed'); return { measured: {}, scores: { overall: 40 } } as never; },
    aiCheck: async (_i: unknown, s: never) => s,
    concurrency: 1, sleep: async () => {},
  } as never);
  expect(tries).toBe(2);
  expect(r.ranked).toHaveLength(1);
});
