import { describe, it, expect } from 'vitest';
import { softTop, calibrateFace, liveFace } from '@/lib/faceTeaching';

describe('score ceiling', () => {
  it('leaves scores up to 85 unchanged', () => { expect(softTop(70)).toBe(70); expect(softTop(85)).toBe(85); });
  it('a raw 100 cannot reach 96', () => { expect(softTop(100)).toBeLessThan(96); });
  it('a raw 92 lands below 90', () => { expect(softTop(92)).toBeLessThan(90); });
});

describe('slider teaching', () => {
  it('one rating 20 points below the AI pulls a similar face down by at least 8', () => {
    const r = calibrateFace(80, 50, [{ ai: 80, user: 60, typeMatch: 50, categories: [], features: [] }]);
    expect(r.score).toBeLessThanOrEqual(72);
  });
  it('a photo is never calibrated by its own rating', () => {
    expect(liveFace(80, 50, 'a', [{ imageId: 'a', ai: 80, user: 20, typeMatch: 50, categories: [], features: [] }]).score).toBe(80);
  });
});
