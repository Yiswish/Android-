import { describe, it, expect } from 'vitest';
import { analyzeFaceGeometry, isValidFaceMesh, BILATERAL_PAIRS, MIDLINE, lineScore, softScore, type Vec3 } from '@/lib/faceGeometry';

// Build a perfectly mirror-symmetric synthetic mesh from the pair table.
function symmetricMesh(): Vec3[] {
  const pts: Vec3[] = Array.from({ length: 478 }, (_, i) => ({ x: 0.5, y: 0.2 + (i % 50) * 0.012, z: 0 }));
  MIDLINE.forEach((i, k) => { pts[i] = { x: 0.5, y: 0.2 + (k / (MIDLINE.length - 1)) * 0.6, z: -0.02 }; });
  BILATERAL_PAIRS.forEach(([r, l], k) => {
    const dx = 0.05 + (k % 9) * 0.02, y = 0.25 + (k % 13) * 0.04;
    pts[r] = { x: 0.5 - dx, y, z: 0 }; pts[l] = { x: 0.5 + dx, y, z: 0 };
  });
  pts[468] = { x: 0.42, y: 0.4, z: 0 }; pts[473] = { x: 0.58, y: 0.4, z: 0 };
  return pts;
}


/**
 * A mirror-symmetric mesh whose every classical ratio sits exactly on its ideal
 * (built in IPD units, 200 px per IPD on a 1000 px canvas). The generic
 * `symmetricMesh()` above is symmetric but anatomically meaningless, so its
 * proportion scores are ~0; this one lets harmony tests start from a sensible face.
 */
function idealMesh(opts: { mouthWiden?: number } = {}): Vec3[] {
  const m = symmetricMesh();
  const S = 200, cx = 500, cy = 600; // px per IPD, face centre x, chin y
  const put = (i: number, X: number, Y: number) => { m[i] = { x: (cx + X * S) / 1000, y: (cy - Y * S) / 1000, z: m[i].z }; };
  const pair = (r: number, l: number, X: number, Y: number) => { put(r, -X, Y); put(l, X, Y); };
  const cheekW = 1 / 0.465, eyeW = cheekW / 5, inter = eyeW / 0.8, noseW = 1.12 * inter, mouthW = 1.55 * noseW * (1 + (opts.mouthWiden ?? 0));
  const yEye = 1.5, a = 1.0;
  pair(468, 473, 0.5, yEye);
  pair(133, 362, inter / 2, yEye); pair(33, 263, inter / 2 + eyeW, yEye);
  pair(159, 386, 0.48, yEye + 0.31 * eyeW / 2); pair(145, 374, 0.48, yEye - 0.31 * eyeW / 2);
  pair(64, 294, noseW / 2, a);
  pair(61, 291, mouthW / 2, 0.7);
  pair(234, 454, cheekW / 2, yEye);
  pair(172, 397, (0.795 * cheekW) / 2, 0.3);
  const ys = (1.95 * a) / 2.95;
  put(152, 0, 0); put(10, 0, 1.23 * cheekW); put(9, 0, 1.95 * a); put(2, 0, a);
  put(0, 0, 1.95 * a - cheekW / 1.8); put(1, 0, 1.1); put(13, 0, ys); put(14, 0, ys);
  return m;
}

describe('face geometry', () => {
  it.each([[33, 'x', NaN], [152, 'y', Infinity], [468, 'z', -Infinity]] as const)('rejects damaged coordinate %s.%s', (index, axis, value) => {
    const mesh = symmetricMesh();
    mesh[index] = { ...mesh[index], [axis]: value };
    expect(isValidFaceMesh(mesh)).toBe(false);
    expect(() => analyzeFaceGeometry(mesh, 1000, 1000)).toThrow('missing or non-finite coordinates');
  });
  it('rejects a missing landmark instead of averaging a sparse mesh', () => {
    const mesh = symmetricMesh();
    delete mesh[10];
    expect(isValidFaceMesh(mesh)).toBe(false);
  });
  it.each([[0, 1000], [1000, NaN], [Infinity, 1000]])('rejects invalid image dimensions %s × %s', (w, h) => {
    expect(() => analyzeFaceGeometry(symmetricMesh(), w, h)).toThrow('positive finite image dimensions');
  });
  it('keeps valid mesh measurements finite', () => {
    const g = analyzeFaceGeometry(idealMesh(), 1000, 1000);
    expect(isValidFaceMesh(idealMesh())).toBe(true);
    for (const v of [g.facialHarmony, g.symmetryPercent, g.structuralBalanceIndex, g.goldenRatioIndex]) expect(Number.isFinite(v)).toBe(true);
  });
  it('scores linear deduction from deviation / tolerance', () => {
    expect(lineScore(0, 0.4)).toBe(100);
    expect(lineScore(0.2, 0.4)).toBe(50);
    expect(lineScore(1, 0.4)).toBe(0);
  });
  it('perfectly symmetric pairs give 100% pair symmetry', () => {
    const g = analyzeFaceGeometry(symmetricMesh(), 1000, 1000);
    expect(g.pairAsymmetry).toBeCloseTo(0, 6);
    expect(g.pairSymmetry).toBeCloseTo(100, 4);
  });
  it('distorting one side lowers symmetry', () => {
    const base = analyzeFaceGeometry(symmetricMesh(), 1000, 1000);
    const m = symmetricMesh();
    BILATERAL_PAIRS.slice(0, 40).forEach(([, l]) => { m[l] = { ...m[l], y: m[l].y + 0.03 }; });
    const g = analyzeFaceGeometry(m, 1000, 1000);
    expect(g.symmetryPercent).toBeLessThan(base.symmetryPercent - 10);
  });
});


// Rotate a mesh rigidly about its centre (yaw around Y, roll around Z).
function rotate(pts: Vec3[], yawDeg: number, rollDeg: number): Vec3[] {
  const a = (yawDeg * Math.PI) / 180, b = (rollDeg * Math.PI) / 180;
  return pts.map((p) => {
    let x = p.x - 0.5, y = p.y - 0.5, z = p.z;
    [x, z] = [x * Math.cos(a) + z * Math.sin(a), -x * Math.sin(a) + z * Math.cos(a)];
    [x, y] = [x * Math.cos(b) - y * Math.sin(b), x * Math.sin(b) + y * Math.cos(b)];
    return { x: x + 0.5, y: y + 0.5, z };
  });
}

describe('pose normalisation', () => {
  it('soft score is smooth and never hard-zero', () => {
    expect(softScore(0, 0.05)).toBe(100);
    expect(softScore(0.05, 0.05)).toBe(50);
    expect(softScore(0.5, 0.05)).toBeGreaterThan(0);
  });
  it('a rotated symmetric face stays symmetric (yaw 20°, roll 15°)', () => {
    const g = analyzeFaceGeometry(rotate(symmetricMesh(), 20, 15), 1000, 1000);
    expect(g.symmetryPercent).toBeGreaterThan(94);
    expect(Math.abs(g.roll)).toBeGreaterThan(10);
  });
  it('confidence decays smoothly with yaw instead of a hard gate', () => {
    const c10 = analyzeFaceGeometry(rotate(symmetricMesh(), 10, 0), 1000, 1000).confidence;
    const c20 = analyzeFaceGeometry(rotate(symmetricMesh(), 20, 0), 1000, 1000).confidence;
    const c35 = analyzeFaceGeometry(rotate(symmetricMesh(), 35, 0), 1000, 1000).confidence;
    // Owner's rule: a turned head is never penalised.
    expect(c10).toBe(1); expect(c20).toBe(1); expect(c35).toBe(1);
  });
});

import { computeOverall, deriveMetrics, type ScoringPixelStats } from '@/lib/scoring';
import { softTop } from '@/lib/faceTeaching';
const all = (v: number) => ({ symmetry: v, proportions: v, structure: v, skin: v, composition: v, lighting: v, texture: v, contrast: v, naturalness: v });
describe('overall score (80/20)', () => {
  it('photo metrics do not affect the overall', () => {
    expect(computeOverall(all(85), { facialHarmony: 92 }).overall).toBeCloseTo(softTop(92), 5);
    expect(computeOverall(all(10), { facialHarmony: 92 }).overall).toBeCloseTo(softTop(92), 5);
  });
  it('perfect photography can never rescue a distorted face', () => {
    const o = computeOverall(all(100), { facialHarmony: 30 }).overall;
    expect(o).toBeLessThanOrEqual(30 + 1e-9);
  });
  it('confidence shrink never raises a score and never acts as a ceiling', () => {
    const lo = computeOverall(all(85), { facialHarmony: 40, confidence: 0.2 }).faceScore!;
    expect(lo).toBeLessThanOrEqual(40 + 1e-9);
    const a = computeOverall(all(85), { facialHarmony: 80, confidence: 0 }).faceScore!;
    const b = computeOverall(all(85), { facialHarmony: 95, confidence: 0 }).faceScore!;
    expect(b).toBeGreaterThan(a + 5);
  });
  it('photography contributes at most 20%', () => {
    const lo = computeOverall(all(0), { facialHarmony: 80 }).overall;
    const hi = computeOverall(all(100), { facialHarmony: 80 }).overall;
    expect((hi - lo) / hi).toBeLessThanOrEqual(0.2 + 1e-9);
  });
  it('low confidence shrinks toward neutral without a hard cap', () => {
    const hi = computeOverall(all(85), { facialHarmony: 90, confidence: 1 }).overall;
    const mid = computeOverall(all(85), { facialHarmony: 90, confidence: 0.5 }).overall;
    expect(mid).toBeLessThan(hi);
    expect(mid).toBeGreaterThan(60);
  });
});

describe('metric calibration', () => {
  const studio: ScoringPixelStats = {
    meanLum: 0.48, stdLum: 0.12, clipFraction: 0.002,
    laplacianVar: 0.0008, edgeDensity: 0.04, mirrorSimilarity: 0.9, energyCentroid: { x: 0.5, y: 0.45 },
    centerSharpness: 0.002, borderSharpness: 0.0003, leftRightLumDiff: 0.02, topBottomLumDiff: 0.03,
    width: 2000, height: 2500, roiSharpness: 0.0018, roiOutsideSharpness: 0.0002, roiMeanLum: 0.55,
  };
  it('smooth studio light is not flagged unnatural, and no metric pins to 0/100', () => {
    const m = deriveMetrics({ stats: studio, boundingBox: { x: 0.3, y: 0.2, width: 0.4, height: 0.45 }, symmetry: 85, roll: 2, goldenRatioIndex: 80, structuralBalanceIndex: 82, alignmentIndex: 90 });
    expect(m.texture).toBeGreaterThan(30);
    expect(m.naturalness).toBeGreaterThan(65);
    for (const v of Object.values(m)) { expect(v).toBeGreaterThan(0); expect(v).toBeLessThan(100); }
  });
});


// ---- Expression, skin group, widened σ ------------------------------------
import {
  expressionFromBlendshapes, expressionLoad, weightedPowerMean, HARMONY_WEIGHTS, HARMONY_POWER, measurementConfidence,
  GOLDEN_SIGMA_SCALE, STRUCTURE_SIGMA_SCALE, EXPRESSION_SIGMA_GAIN, EXPRESSION_SENSITIVE_RATIOS, MOUTH_JAW_TERM_IDS,
} from '@/lib/faceGeometry';
import { SKIN_PARAMS, type SkinReport } from '@/lib/skin';

const fakeSkin = (score: number): SkinReport => ({
  score, rawScore: score, ratio: 0.1, skinDetail: 0.01, eyeDetail: 0.1, confidence: 1, ipdPx: 100, skinSamples: 500, eyeSamples: 500, maskedFraction: 0, patches: [],
});

describe('expression never affects the score', () => {
  const neutral = { jawOpen: 0.03, mouthSmileLeft: 0.05, mouthSmileRight: 0.05 };
  const smile = { jawOpen: 0.08, mouthSmileLeft: 0.8, mouthSmileRight: 0.78, cheekSquintLeft: 0.35, cheekSquintRight: 0.33, eyeSquintLeft: 0.25, eyeSquintRight: 0.25, mouthStretchLeft: 0.3, mouthStretchRight: 0.3 };
  const grimace = { jawOpen: 0.6, mouthStretchLeft: 0.5, mouthStretchRight: 0.5, eyeSquintLeft: 0.7, eyeSquintRight: 0.7, browDownLeft: 0.5, browDownRight: 0.5, cheekSquintLeft: 0.6, cheekSquintRight: 0.6, noseSneerLeft: 0.3, noseSneerRight: 0.3 };

  it('the expression report still computes intensity / asymmetry for display', () => {
    expect(expressionFromBlendshapes(neutral).intensity).toBeLessThan(0.1);
    expect(expressionFromBlendshapes(grimace).intensity).toBeGreaterThan(0.6);
  });
  it('harmony weights sum to 1; expression has zero weight; skin is still the largest group', () => {
    const sum = Object.values(HARMONY_WEIGHTS).reduce((a, b) => a + b, 0);
    expect(sum).toBeCloseTo(1, 9);
    expect(HARMONY_WEIGHTS.expression ?? 0).toBe(0);
    expect(HARMONY_WEIGHTS.skin).toBeCloseTo(0.24 / 0.86, 9);
    expect(Math.max(...Object.values(HARMONY_WEIGHTS))).toBe(HARMONY_WEIGHTS.skin);
  });
  it('a grimace or wide-open laugh scores the same harmony as a neutral face', () => {
    const wideOpen = { jawOpen: 0.85, mouthStretchLeft: 0.6, mouthStretchRight: 0.6, mouthSmileLeft: 0.7, mouthSmileRight: 0.7, eyeSquintLeft: 0.6, eyeSquintRight: 0.6, cheekSquintLeft: 0.6, cheekSquintRight: 0.6 };
    const n = analyzeFaceGeometry(idealMesh(), 1000, 1000, undefined, neutral, fakeSkin(90)).facialHarmony;
    const gm = analyzeFaceGeometry(idealMesh(), 1000, 1000, undefined, grimace, fakeSkin(90)).facialHarmony;
    const wo = analyzeFaceGeometry(idealMesh(), 1000, 1000, undefined, wideOpen, fakeSkin(90)).facialHarmony;
    // Owner's rule: expression doesn't affect beauty.
    expect(gm).toBeCloseTo(n, 6);
    expect(wo).toBeCloseTo(n, 6);
  });
  it('a gentle smile costs only a few points', () => {
    const gentle = { jawOpen: 0.05, mouthSmileLeft: 0.35, mouthSmileRight: 0.35 };
    const n = analyzeFaceGeometry(idealMesh(), 1000, 1000, undefined, neutral, fakeSkin(90)).facialHarmony;
    const g = analyzeFaceGeometry(idealMesh(), 1000, 1000, undefined, gentle, fakeSkin(90)).facialHarmony;
    expect(n - g).toBeLessThan(4);
  });
  it('mouth openness is informational and not a term of the mouth/jaw score', () => {
    expect(MOUTH_JAW_TERM_IDS).not.toContain('open');
    const base = analyzeFaceGeometry(symmetricMesh(), 1000, 1000);
    const open = symmetricMesh();
    // open the mouth symmetrically: lower-lip pairs drop together, the upper lip stays
    for (const [r, l] of [[14, 14], [17, 17], [84, 314], [87, 317], [88, 318], [91, 321], [95, 324], [146, 375], [178, 402]]) {
      open[r] = { ...open[r], y: open[r].y + 0.03 }; open[l] = { ...open[l], y: open[l].y + 0.03 };
    }
    const g = analyzeFaceGeometry(open, 1000, 1000);
    expect(g.mouthJaw.mouthOpenness).toBeGreaterThan(base.mouthJaw.mouthOpenness);
    expect(g.mouthJaw.terms.map((t) => t.id)).toEqual(MOUTH_JAW_TERM_IDS);
  });
  it('a crooked mouth (genuine distortion) still lowers mouth/jaw integrity', () => {
    const base = analyzeFaceGeometry(symmetricMesh(), 1000, 1000);
    const crooked = symmetricMesh(); crooked[291] = { ...crooked[291], y: crooked[291].y + 0.04 };
    const gc = analyzeFaceGeometry(crooked, 1000, 1000);
    expect(gc.mouthJawScore).toBeLessThan(base.mouthJawScore - 10);
  });
  it('expressionLoad = clamp(0.8·smile + 1.0·jawOpen + 0.5·mouthStretch + 0.3·cheekSquint, 0, 1)', () => {
    expect(expressionLoad({})).toBe(0);
    expect(expressionLoad({ mouthSmileLeft: 0.5, mouthSmileRight: 0.5 })).toBeCloseTo(0.4, 9);
    expect(expressionLoad({ jawOpen: 0.5, mouthStretchLeft: 0.4, mouthStretchRight: 0.4, cheekSquintLeft: 0.2, cheekSquintRight: 0.2 })).toBeCloseTo(0.5 + 0.2 + 0.06, 9);
    expect(expressionLoad({ jawOpen: 1, mouthSmileLeft: 1, mouthSmileRight: 1 })).toBe(1);
    expect(expressionLoad(undefined)).toBe(0);
  });
  it('expression load widens σ (× (1 + EXPRESSION_SIGMA_GAIN·load)) only for the ratios expression moves', () => {
    const load = expressionLoad(smile);
    expect(load).toBeGreaterThan(0.5);
    const a = analyzeFaceGeometry(symmetricMesh(), 1000, 1000, undefined, neutral);
    const b = analyzeFaceGeometry(symmetricMesh(), 1000, 1000, undefined, smile);
    const exp = expressionLoad(smile), expN = expressionLoad(neutral);
    for (const r of a.ratios) {
      const rb = b.ratios.find((x) => x.id === r.id)!;
      const want = EXPRESSION_SENSITIVE_RATIOS.includes(r.id) ? (1 + EXPRESSION_SIGMA_GAIN * exp) / (1 + EXPRESSION_SIGMA_GAIN * expN) : 1;
      expect(rb.tolerance / r.tolerance).toBeCloseTo(want, 9);
    }
    expect(b.expressionLoad).toBeCloseTo(exp, 9);
  });
  it('proportion σ is strict: golden ×0.95, structure ×1.25, alignment unchanged', () => {
    expect(GOLDEN_SIGMA_SCALE).toBe(0.95);
    expect(STRUCTURE_SIGMA_SCALE).toBe(1.25);
    const g = analyzeFaceGeometry(symmetricMesh(), 1000, 1000);
    const jaw = g.ratios.find((r) => r.id === 'jaw-cheek')!;
    expect(jaw.tolerance).toBeCloseTo(0.03 * 1.25, 9);
    expect(g.ratios.find((r) => r.id === 'nose-midline')!.tolerance).toBeCloseTo(0.025, 9);
  });
  it('the ideal synthetic face scores high, and every ratio sits on its ideal', () => {
    const g = analyzeFaceGeometry(idealMesh(), 1000, 1000, undefined, neutral, fakeSkin(90));
    for (const r of g.ratios) expect(r.z, r.id).toBeLessThan(0.05);
    expect(g.symmetryPercent).toBeGreaterThan(96);
    expect(g.facialHarmony).toBeGreaterThan(88);
  });
  it('a broad smile (mouth 8% wider) still costs ≤ 5 points vs neutral', () => {
    const neutralFace = analyzeFaceGeometry(idealMesh(), 1000, 1000, undefined, neutral, fakeSkin(90)).facialHarmony;
    const smiling = analyzeFaceGeometry(idealMesh({ mouthWiden: 0.08 }), 1000, 1000, undefined, smile, fakeSkin(90)).facialHarmony;
    expect(neutralFace - smiling).toBeLessThan(5);
  });
});

describe('harmony with the skin group', () => {
  const w = HARMONY_WEIGHTS;
  const mean = (skin: number) => weightedPowerMean([[93, w.symmetry], [88, w.structure], [90, w.golden], [92, w.alignment], [94, w.mouthJaw], [skin, w.skin]], HARMONY_POWER);
  it('clean skin keeps harmony high; heavy skin detail pulls it down without a cliff', () => {
    expect(mean(92)).toBeGreaterThan(88);
    // v2 (p = −2): a weak group costs points without collapsing the face score.
    expect(mean(50)).toBeLessThan(mean(92) - 15);
    expect(mean(50)).toBeGreaterThan(mean(20));
    expect(weightedPowerMean([[100, 1], [100, 1]], HARMONY_POWER)).toBeCloseTo(100, 6);
  });
  it('the skin group enters analyzeFaceGeometry and drops out (renormalising) when absent', () => {
    const withSkin = analyzeFaceGeometry(idealMesh(), 1000, 1000, undefined, undefined, fakeSkin(40));
    const without = analyzeFaceGeometry(idealMesh(), 1000, 1000);
    expect(withSkin.groups.find((x) => x.id === 'skin')!.score).toBe(40);
    expect(without.groups.find((x) => x.id === 'skin')).toBeUndefined();
    for (const g of [withSkin, without]) expect(g.groups.reduce((s, x) => s + x.weight, 0)).toBeCloseTo(1, 9);
    expect(withSkin.facialHarmony).toBeLessThan(without.facialHarmony - 10);
  });
  it('confidence uses head pose only', () => {
    expect(measurementConfidence(0, 0)).toBe(1);
    expect(measurementConfidence.length).toBe(2);
  });
  it('no colour field exists in the pixel statistics', () => {
    const keys: string[] = Object.keys(({} as unknown as ScoringPixelStats));
    expect(keys.some((k) => /sat|warm|hue/i.test(k))).toBe(false);
  });
  it('the neutral skin value is the documented 70', () => { expect(SKIN_PARAMS.neutral).toBe(70); });
});

import { normalizeMetrics, METRIC_KEYS, METRIC_LABELS } from '@/lib/metricKeys';
import { computeArchetypeMatch, computeAestheticScores } from '@/lib/metrics';
import { buildTasteModel, computeTasteMatch } from '@/lib/preferenceEngine';
import type { AnalysisResult, MetricScores } from '@/lib/types';

describe('old analyses without metrics.skin', () => {
  const legacy = { symmetry: 80, proportions: 70, structure: 75, composition: 60, lighting: 60, texture: 60, contrast: 60, naturalness: 70 } as unknown as MetricScores;
  it('migration defaults skin and leaves nothing NaN', () => {
    const m = normalizeMetrics(legacy);
    expect(m.skin).toBe(70);
    for (const k of METRIC_KEYS) expect(Number.isFinite(m[k])).toBe(true);
    expect(Number.isFinite(normalizeMetrics(null).skin)).toBe(true);
  });
  it('cosine archetype match and taste kernel stay finite', () => {
    const match = computeArchetypeMatch(normalizeMetrics(legacy));
    for (const v of Object.values(match)) expect(Number.isFinite(v)).toBe(true);
    const mk = (id: string, metrics: MetricScores) => ({ id, imageId: id, scores: { metrics } }) as unknown as AnalysisResult;
    const model = buildTasteModel([mk('a', legacy), mk('b', normalizeMetrics(legacy)), mk('c', legacy)], ['a', 'b', 'c'].map((imageId, i) => ({ imageId, rating: 3 + (i % 2), timestamp: i })));
    const tm = computeTasteMatch(legacy, model);
    expect(tm).toBeDefined();
    expect(Number.isFinite(tm!.score)).toBe(true);
    expect(Number.isFinite(tm!.confidence)).toBe(true);
  });
  it('the texture photo metric is labelled Image sharpness; skin is Skin & age', () => {
    expect(METRIC_LABELS.texture).toBe('Image sharpness');
    expect(METRIC_LABELS.skin).toBe('Skin & age');
    const s = computeAestheticScores(normalizeMetrics(legacy));
    expect(Number.isFinite(s.overall)).toBe(true);
  });
});

import { metricRawErrors, ipdPercent, rawMeasurementRows, rowsToCsv, ratioErrorText, symmetryErrorIpd } from '@/lib/rawError';

describe('raw error exposure', () => {
  it('reports ~0% asymmetry for a perfectly symmetric mesh', () => {
    const g = analyzeFaceGeometry(symmetricMesh(), 1000, 1000);
    expect(symmetryErrorIpd(g)).toBeLessThan(0.001);
    expect(metricRawErrors(g).symmetry?.short).toMatch(/% of eye distance$/);
  });
  it('formats landmark offsets as a percentage of eye distance', () => {
    expect(ipdPercent(0.014)).toBe('1.4% of eye distance');
  });
  it('exposes a signed error per proportion and a CSV with one row each', () => {
    const g = analyzeFaceGeometry(symmetricMesh(), 1000, 1000);
    const rows = rawMeasurementRows(g);
    expect(rows.length).toBe(3 + g.ratios.length + g.mouthJaw.terms.length);
    expect(ratioErrorText(g.ratios[0], 'ideal')).toMatch(/^[+−]\d+\.\d% of ideal$/);
    expect(rowsToCsv(rows).split('\n').length).toBe(rows.length + 1);
  });
});

describe('angled faces', () => {
  it('scores a 3/4 view on the visible side: symmetry, alignment and mouth/jaw drop out', () => {
    const g = analyzeFaceGeometry(rotate(symmetricMesh(), 40, 0), 1000, 1000);
    expect(g.viewMode).toBe('angled');
    expect(g.groups.map((x) => x.id)).not.toContain('symmetry');
    expect(g.groups.map((x) => x.id)).not.toContain('alignment');
    expect(g.groups.map((x) => x.id)).not.toContain('mouthJaw');
  });
  it('keeps every group for a frontal face', () => {
    const g = analyzeFaceGeometry(rotate(symmetricMesh(), 0, 0), 1000, 1000);
    expect(g.viewMode).toBe('frontal');
    expect(g.groups.map((x) => x.id)).toContain('symmetry');
  });
});
