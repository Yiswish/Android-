import { afterEach, describe, expect, it, vi } from 'vitest';
import { searchChain } from '@/lib/search.providers';
import { clearPersonalKeys, personalKeys, savePersonalKeys } from '@/lib/personalKeys';

afterEach(() => { vi.unstubAllGlobals(); clearPersonalKeys(); });

describe('owner search rules', () => {
  it('uses Serper first when both Serper and SerpAPI keys exist', async () => {
    const calls: string[] = [];
    vi.stubGlobal('fetch', vi.fn(async (u: string) => {
      calls.push(String(u));
      return new Response(JSON.stringify({ images: [{ imageUrl: 'https://x.com/a.jpg', thumbnailUrl: 'https://x.com/t.jpg' }] }), { status: 200 });
    }));
    const r = await searchChain({ query: 'anna', page: 1, perPage: 10, source: 'google' }, { serper: 'k1', serpapi: 'k2' });
    expect(r.status.provider).toBe('serper');
    expect(calls[0]).toContain('serper.dev');
  });

  it('reads elitebabes images when that source is chosen', async () => {
    const html = '<img src="https://cdn.elitebabes.com/content/250701/1178480_masonry_400.jpg"><img src="https://cdn.elitebabes.com/content/250701/1178480_masonry_800.jpg">';
    vi.stubGlobal('fetch', vi.fn(async () => new Response(html, { status: 200 })));
    const r = await searchChain({ query: 'lana', page: 1, perPage: 10, source: 'elitebabes' }, {});
    expect(r.status.provider).toBe('elitebabes');
    expect(r.images.map((i) => i.url)).toEqual(['https://cdn.elitebabes.com/content/250701/1178480_masonry_1200.jpg']);
  });

  it('saves personal keys to device storage', () => {
    savePersonalKeys({ serper: 'abc123' });
    expect(JSON.parse(localStorage.getItem('getsclose.personalKeys.v1') ?? '{}').serper).toBe('abc123');
    expect(personalKeys().serper).toBe('abc123');
  });
});
