// @vitest-environment node
import { describe, expect, it, vi } from 'vitest';

vi.mock('@tanstack/react-start', () => ({ createServerFn: () => {
  const builder = { middleware: () => builder, inputValidator: () => builder, handler: (handler: unknown) => handler };
  return builder;
} }));
vi.mock('@/integrations/supabase/auth-middleware', () => ({ requireSupabaseAuth: {} }));
vi.mock('@/lib/keySettings.server', () => ({ personalKeysAllowed: vi.fn() }));
import { setKeyLock } from '@/lib/keySettings.functions';

// Exercise the server handler with an authenticated client role lookup.
const handler = setKeyLock as unknown as (input: unknown) => Promise<{ ok: boolean }>;
function context(role: 'owner' | null, error: unknown = null) {
  const upsert = vi.fn().mockResolvedValue({ error: null });
  const query = { select: () => query, eq: () => query, maybeSingle: async () => ({ data: role ? { role } : null, error }) };
  return { upsert, value: { userId: 'test-user', supabase: { from: (table: string) => table === 'user_roles' ? query : { upsert } } } };
}
describe('owner-only key locks', () => {
  it('rejects an authenticated visitor without an owner role', async () => {
    const c = context(null);
    await expect(handler({ data: { provider: 'gemini', locked: true }, context: c.value })).rejects.toThrow('Only the owner');
    expect(c.upsert).not.toHaveBeenCalled();
  });
  it('allows the owner to lock Gemini keys', async () => {
    const c = context('owner');
    await handler({ data: { provider: 'gemini', locked: true }, context: c.value });
    expect(c.upsert).toHaveBeenCalledWith({ provider: 'gemini', locked: true });
  });
  it('allows the owner to unlock SerpAPI keys', async () => {
    const c = context('owner');
    await handler({ data: { provider: 'serpapi', locked: false }, context: c.value });
    expect(c.upsert).toHaveBeenCalledWith({ provider: 'serpapi', locked: false });
  });
  it('fails closed when the role lookup fails', async () => {
    const c = context('owner', new Error('unavailable'));
    await expect(handler({ data: { provider: 'gemini', locked: false }, context: c.value })).rejects.toThrow('Only the owner');
    expect(c.upsert).not.toHaveBeenCalled();
  });
});