import { act, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import BestResultRow from '@/components/BestResultRow';

function row() {
  const onDelete = vi.fn(), onRate = vi.fn(), onOpen = vi.fn();
  render(<ul><BestResultRow first={false} onDelete={onDelete} onRate={onRate}><button onClick={onOpen}>Photo</button></BestResultRow></ul>);
  return { element: screen.getByRole('listitem'), onDelete, onRate, onOpen };
}
function pointer(element: HTMLElement, type: string, x: number, y: number) {
  const event = new Event(type, { bubbles: true });
  Object.assign(event, { clientX: x, clientY: y, button: 0, isPrimary: true });
  fireEvent(element, event);
}
afterEach(() => vi.useRealTimers());
describe('Best photo quick gestures', () => {
  it('right swipe deletes exactly this photo without opening it', () => {
    const r = row();
    pointer(r.element, 'pointerdown', 20, 100); pointer(r.element, 'pointermove', 140, 102); pointer(r.element, 'pointerup', 140, 102);
    fireEvent.click(screen.getByRole('button'));
    expect(r.onDelete).toHaveBeenCalledTimes(1); expect(r.onRate).not.toHaveBeenCalled(); expect(r.onOpen).not.toHaveBeenCalled();
  });
  it('holding opens rating once without opening or deleting the photo', () => {
    vi.useFakeTimers(); const r = row();
    pointer(r.element, 'pointerdown', 20, 100);
    act(() => vi.advanceTimersByTime(500));
    pointer(r.element, 'pointerup', 20, 100); fireEvent.click(screen.getByRole('button'));
    expect(r.onRate).toHaveBeenCalledTimes(1); expect(r.onDelete).not.toHaveBeenCalled(); expect(r.onOpen).not.toHaveBeenCalled();
  });
  it('vertical scroll cancels rating and never deletes', () => {
    vi.useFakeTimers(); const r = row();
    pointer(r.element, 'pointerdown', 20, 100); pointer(r.element, 'pointermove', 35, 200);
    vi.advanceTimersByTime(600); pointer(r.element, 'pointerup', 35, 200);
    expect(r.onDelete).not.toHaveBeenCalled(); expect(r.onRate).not.toHaveBeenCalled();
  });
  it('left swipe does not delete and pointer cancellation stops rating', () => {
    vi.useFakeTimers(); const r = row();
    pointer(r.element, 'pointerdown', 160, 100); pointer(r.element, 'pointermove', 20, 100); pointer(r.element, 'pointercancel', 20, 100);
    vi.advanceTimersByTime(600);
    expect(r.onDelete).not.toHaveBeenCalled(); expect(r.onRate).not.toHaveBeenCalled();
  });
});