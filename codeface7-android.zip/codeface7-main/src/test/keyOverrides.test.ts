// @vitest-environment node
import { beforeEach, describe, expect, it, vi } from 'vitest';
vi.mock('@tanstack/react-start', () => ({ createServerFn: () => {
  const builder = { inputValidator: () => builder, handler: (handler: unknown) => handler };
  return builder;
} }));
vi.mock('@/lib/keySettings.server', () => ({ personalKeysAllowed: vi.fn() }));
vi.mock('@/lib/aiLook.server', () => ({ judgeLook: vi.fn(), judgeFinal: vi.fn() }));
vi.mock('@/lib/search.providers', () => ({ searchChain: vi.fn(), isFaceQuery: vi.fn() }));
import { personalKeysAllowed } from '@/lib/keySettings.server';
import { judgeLook, judgeFinal } from '@/lib/aiLook.server';
import { searchChain } from '@/lib/search.providers';
import { judgeLookServer, judgeFinalServer } from '@/lib/aiLook.functions';
import { searchImagesServer } from '@/lib/search.functions';
type Handler = (input: { data: unknown }) => Promise<unknown>;
const look = judgeLookServer as unknown as Handler;
const final = judgeFinalServer as unknown as Handler;
const search = searchImagesServer as unknown as Handler;
beforeEach(() => { vi.clearAllMocks(); vi.mocked(personalKeysAllowed).mockResolvedValue(true); });
describe('personal request overrides', () => {
  it('forwards all five AI keys while unlocked', async () => {
    const keys = ['one', 'two', 'three', 'four', 'five'];
    await look({ data: { image: 'data:image/jpeg;base64,AA', start: 2, personalKeys: keys } });
    expect(judgeLook).toHaveBeenCalledWith('data:image/jpeg;base64,AA', '', 2, keys, undefined);
  });
  it('blocks locked AI keys before contacting Gemini', async () => {
    vi.mocked(personalKeysAllowed).mockResolvedValue(false);
    expect(await look({ data: { image: 'image', start: 0, personalKeys: ['one'] } })).toMatchObject({ ok: false });
    expect(judgeLook).not.toHaveBeenCalled();
  });
  it('blocks locked personal keys for Way off too', async () => {
    vi.mocked(personalKeysAllowed).mockResolvedValue(false);
    expect(await final({ data: { image: 'image', start: 0, personalKeys: ['one'], aiScore: 50 } })).toMatchObject({ ok: false });
    expect(judgeFinal).not.toHaveBeenCalled();
  });
  it('forwards unlocked personal search keys', async () => {
    await search({ data: { query: 'woman', source: 'google', page: 1, perPage: 12, personalKey: 'search-test' } });
    expect(searchChain).toHaveBeenCalledWith({ query: 'woman', source: 'google', page: 1, perPage: 12 }, { serpapi: 'search-test' });
  });
  it('blocks locked personal search keys before contacting SerpAPI', async () => {
    vi.mocked(personalKeysAllowed).mockResolvedValue(false);
    await expect(search({ data: { query: 'woman', personalKey: 'search-test' } })).rejects.toThrow('locked by the owner');
    expect(searchChain).not.toHaveBeenCalled();
  });
});