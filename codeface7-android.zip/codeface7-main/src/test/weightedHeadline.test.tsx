import { cleanup, render, screen, act } from '@testing-library/react';
import { afterEach, describe, expect, it } from 'vitest';
import ScoreDisplay from '@/components/ScoreDisplay';
import { DEFAULT_PREFS, updatePrefs } from '@/lib/userPrefs';
import type { AestheticScores } from '@/lib/types';

const scores = {
  overall: 66,
  breakdown: { faceScore: 92, photoScore: 77 },
  aiLook: { attractiveness: 52 },
} as AestheticScores;

afterEach(() => { cleanup(); updatePrefs(DEFAULT_PREFS); });

describe('Personal weighted headline', () => {
  it('shows the weighted result instead of the stored overall and reacts to new weights', () => {
    updatePrefs({ weights: { face: 56, ai: 41, photo: 3 } });
    render(<ScoreDisplay scores={scores} weighted animated={false} size="lg" />);
    const meter = screen.getByRole('meter');
    expect(Number(meter.getAttribute('aria-valuenow'))).toBe(75);
    act(() => updatePrefs({ weights: { face: 0, ai: 100, photo: 0 } }));
    expect(Number(meter.getAttribute('aria-valuenow'))).toBe(52);
    expect(scores.overall).toBe(66);
  });

  it('does not substitute the original overall when every weight is zero', () => {
    updatePrefs({ weights: { face: 0, ai: 0, photo: 0 } });
    render(<ScoreDisplay scores={scores} weighted animated={false} />);
    expect(screen.getByRole('meter').getAttribute('aria-valuenow')).toBeNull();
  });
});