import { describe, it, expect } from 'vitest';
import { blendOverall, blendWithAiLook } from '@/lib/scoring';

describe('AI look blend (v2: AI 40% + face 40%, photo ≤20% multiplier)', () => {
  it('an attractive face (face 82, AI 85, photo 70) stays in the high 70s / 80s', () => {
    const v = blendOverall(82, 85, 70).overall;
    expect(v).toBeGreaterThan(75);
    expect(v).toBeLessThan(85);
  });
  it('a face the AI rates 80+ never collapses to the 30s when geometry is ordinary', () => {
    expect(blendOverall(60, 82, 60).overall).toBeGreaterThan(60);
  });
  it('small disagreements are a plain average; large ones add a mild penalty', () => {
    expect(blendOverall(70, 90, 100).penalty).toBe(0);
    const big = blendOverall(30, 90, 100);
    expect(big.penalty).toBeGreaterThan(0);
    expect(big.overall).toBeLessThan(60);
    expect(big.overall).toBeGreaterThan(45);
  });
  it('a face the AI rates 28 cannot stay high even if measurements say 84', () => {
    expect(blendWithAiLook(84, 28)).toBeLessThan(55);
  });
  it('photo quality no longer changes the overall', () => {
    expect(blendOverall(80, 80, 0).overall).toBeCloseTo(80, 5);
    expect(blendOverall(80, 80, 100).overall).toBeCloseTo(80, 5);
  });
});
