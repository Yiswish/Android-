import { describe, it, expect, vi, beforeEach } from 'vitest';
let row: { locked: boolean } | null = null;
vi.mock('@supabase/supabase-js', () => ({
  createClient: () => { const q: any = { from: () => q, select: () => q, eq: () => q, maybeSingle: async () => ({ data: row, error: null }) }; return q; },
}));
import { personalKeysAllowed } from '@/lib/keySettings.server';
beforeEach(() => { process.env.SUPABASE_URL = 'http://x'; process.env.SUPABASE_PUBLISHABLE_KEY = 'k'; });
describe('personal key locks', () => {
  it('allows personal keys when the owner never set a lock', async () => { row = null; expect(await personalKeysAllowed('gemini')).toBe(true); });
  it('blocks personal keys only when the owner locked them', async () => { row = { locked: true }; expect(await personalKeysAllowed('serpapi')).toBe(false); });
});
