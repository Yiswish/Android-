import { describe, it, expect, vi, afterEach } from 'vitest';
import { checkAiKeyHealth } from '@/lib/aiLook.server';

afterEach(() => vi.unstubAllGlobals());

describe('AI key health', () => {
  it('reports a working Gemini key, a rejected Groq key, and never returns keys', async () => {
    vi.stubGlobal('fetch', vi.fn(async (url: string) => url.includes('googleapis')
      ? new Response(JSON.stringify({ models: [{ name: 'models/gemini-flash-latest' }] }), { status: 200 })
      : new Response('no', { status: 401 })));
    const r = await checkAiKeyHealth(['AIzaTESTKEY123', 'gsk_TESTKEY456']);
    expect(r.keys.map((k) => [k.provider, k.status])).toEqual([['gemini', 'ok'], ['groq', 'rejected']]);
    expect(JSON.stringify(r)).not.toMatch(/TESTKEY/);
  });
  it('flags quota and missing vision models', async () => {
    vi.stubGlobal('fetch', vi.fn(async (url: string) => url.includes('googleapis')
      ? new Response('', { status: 429 })
      : new Response(JSON.stringify({ data: [{ id: 'llama-3.1-8b-instant' }] }), { status: 200 })));
    const r = await checkAiKeyHealth(['AIzaA', 'gsk_B']);
    expect(r.keys.map((k) => k.status)).toEqual(['quota', 'no-model']);
  });
});
