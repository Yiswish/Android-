import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi, beforeAll } from 'vitest';
import ComparisonView from '@/components/ComparisonView';
import type { AnalysisResult, ComparisonItem } from '@/lib/types';

vi.mock('@/components/ScoreDisplay', () => ({ default: () => null }));
vi.mock('@/components/MetricsPanel', () => ({ default: () => null }));

beforeAll(() => {
  // jsdom has no ResizeObserver; the slider only needs it not to crash.
  (globalThis as Record<string, unknown>).ResizeObserver ??= class {
    observe() {}
    unobserve() {}
    disconnect() {}
  };
});

function item(id: string, overall: number, label: string): ComparisonItem {
  return {
    label,
    result: {
      id,
      imageUrl: `/${id}.jpg`,
      source: 'upload',
      scores: { overall, metrics: {} },
      faceDetection: { detected: false },
    } as unknown as AnalysisResult,
  };
}

describe('Comparison view controls', () => {
  it('offers a way back to search when empty', () => {
    const onAddMore = vi.fn();
    render(<ComparisonView items={[]} onRemove={vi.fn()} onAddMore={onAddMore} onClear={vi.fn()} />);
    fireEvent.click(screen.getByRole('button', { name: /find images to compare/i }));
    expect(onAddMore).toHaveBeenCalledOnce();
  });

  it('disables the slider mode until two images are selected', () => {
    render(<ComparisonView items={[item('a', 60, 'upload · 60')]} onRemove={vi.fn()} onAddMore={vi.fn()} onClear={vi.fn()} />);
    expect(screen.getByRole('button', { name: 'Slider' })).toBeDisabled();
  });

  it('clears the whole comparison from one button', () => {
    const onClear = vi.fn();
    render(<ComparisonView items={[item('a', 60, 'upload · 60'), item('b', 70, 'upload · 70')]} onRemove={vi.fn()} onAddMore={vi.fn()} onClear={onClear} />);
    fireEvent.click(screen.getByRole('button', { name: /clear/i }));
    expect(onClear).toHaveBeenCalledOnce();
  });

  it('moves the slider with arrow keys', () => {
    render(<ComparisonView items={[item('a', 60, 'upload · 60'), item('b', 70, 'upload · 70')]} onRemove={vi.fn()} onAddMore={vi.fn()} onClear={vi.fn()} />);
    fireEvent.click(screen.getByRole('button', { name: 'Slider' }));
    const slider = screen.getByRole('slider', { name: 'Comparison slider' });
    expect(slider).toHaveAttribute('aria-valuenow', '50');
    fireEvent.keyDown(slider, { key: 'ArrowRight' });
    expect(slider).toHaveAttribute('aria-valuenow', '52');
    fireEvent.keyDown(slider, { key: 'ArrowLeft', shiftKey: true });
    expect(slider).toHaveAttribute('aria-valuenow', '42');
  });

  it('marks the active mode accessibly', () => {
    render(<ComparisonView items={[item('a', 60, 'upload · 60')]} onRemove={vi.fn()} onAddMore={vi.fn()} onClear={vi.fn()} />);
    expect(screen.getByRole('button', { name: 'Cards' })).toHaveAttribute('aria-pressed', 'true');
    expect(screen.getByRole('button', { name: 'Matrix' })).toHaveAttribute('aria-pressed', 'false');
  });
});
