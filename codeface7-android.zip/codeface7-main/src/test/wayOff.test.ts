import { describe, it, expect } from 'vitest';
import { withFinalVerdict, finalAnalystInput } from '@/lib/aiLookClient';
import { CAREFUL_PASSES, finalPrompt } from '@/lib/aiLook.server';
import type { AestheticScores } from '@/lib/types';

const scores = {
  overall: 80,
  aiLook: { attractiveness: 95, typeMatch: 70, reasons: ['clear skin'], geometryOverall: 62, faceScore: 64 },
  metrics: { symmetry: 70 },
  archetypeMatch: {},
} as unknown as AestheticScores;

const verdict = { overall: 88, passes: [86, 88, 90], spread: 4, reasons: ['ok'], keys: [2, 3, 4], keyCount: 4 };

describe('Way off final analyst', () => {
  it('sets only the overall score', () => {
    expect(withFinalVerdict(scores, verdict).overall).toBe(88);
  });
  it('keeps the AI score as it is', () => {
    expect(withFinalVerdict(scores, verdict).aiLook?.attractiveness).toBe(95);
  });
  it('remembers what the overall was before', () => {
    const once = withFinalVerdict(scores, verdict);
    expect(withFinalVerdict(once, { ...verdict, overall: 70 }).finalAnalyst?.previousOverall).toBe(80);
  });
  it('is told the AI score, its notes and the measurement scores', () => {
    const p = finalPrompt(finalAnalystInput(scores)!, CAREFUL_PASSES[0]);
    expect(p).toContain('95/100');
    expect(p).toContain('clear skin');
    expect(p).toContain('overall 62/100');
  });
  it('makes 3 passes', () => {
    expect(CAREFUL_PASSES.length).toBe(3);
  });
});
