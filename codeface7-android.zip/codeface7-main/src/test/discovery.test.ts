import { describe, it, expect, vi } from 'vitest';
import { buildDiscoveryProfile, predictDiscovery, discoverPortraits } from '../lib/discovery';
import { scoreToRating } from '../lib/faceTeaching';
import { emptyMetrics } from '../lib/metricKeys';
import type { AnalysisResult, SearchResponse, SearchResultImage } from '../lib/types';

const result = (id: string, notes: string, ai = 75, overall = 50): AnalysisResult => ({
  id, imageId: id, imageUrl: `https://photos.test/${id}.jpg`, source: 'google', timestamp: 1,
  faceDetection: { detected: false, faceCount: 0, faces: [], primaryFaceIndex: 0, expression: 'neutral', expressionConfidence: 0, pose: 'profile-left', poseConfidence: 0.2, logs: [] },
  scores: { overall, metrics: emptyMetrics(overall), archetypeMatch: {}, aiLook: { attractiveness: ai, geometryOverall: overall, typeMatch: 50, description: notes, reasons: [notes], categories: notes.includes('soft') ? ['Cute'] : ['Attractive'] } },
  topArchetypes: [], warnings: [], duration: 1,
});
const references = [result('a', 'soft jaw almond eyes warm expression'), result('b', 'soft jaw almond eyes'), result('c', 'strong jaw angular features')];
const ratings = [95, 85, 20].map((score, i) => ({ imageId: references[i].imageId, rating: scoreToRating(score), timestamp: 1 }));
const profile = buildDiscoveryProfile(references, ratings);
const image = (id: string): SearchResultImage => ({ id, url: `https://photos.test/${id}.jpg`, thumbUrl: '', alt: '', source: 'google', width: 600, height: 800 });
const response = (images: SearchResultImage[]): SearchResponse => ({ images, totalCount: images.length, hasMore: false, source: 'google' });

describe('AI-first discovery', () => {
  it('uses 80+ ratings as its strongest references', () => {
    expect(profile.top.map((r) => r.rating)).toEqual([95, 85]);
    expect(profile.traits).toContain('soft jaw');
    expect(profile.queries.some((q) => q.includes('soft jaw'))).toBe(true);
  });
  it('requires three different rated AI references and a high rating', () => {
    expect(buildDiscoveryProfile(references.slice(0, 2), ratings).ready).toBe(false);
    expect(buildDiscoveryProfile(references, ratings.map((r) => ({ ...r, rating: scoreToRating(79) }))).ready).toBe(false);
    expect(profile.ready).toBe(true);
  });
  it('uses the latest rating once, not repeated high ratings', () => {
    const p = buildDiscoveryProfile(references, [...ratings, { imageId: 'a', rating: scoreToRating(10), timestamp: 2 }]);
    expect(p.references).toHaveLength(3);
    expect(p.top.map((r) => r.result.imageId)).toEqual(['b']);
  });
  it('ranks qualitative reference similarity above geometry or generic AI appeal', () => {
    const match = predictDiscovery(result('new', 'soft jaw almond eyes warm expression', 65, 1), profile);
    const mismatch = predictDiscovery(result('other', 'strong jaw angular features', 90, 99), profile);
    expect(match?.score).toBeGreaterThan(mismatch?.score ?? 100);
  });
  it('ignores geometry when pose confidence is low or no mesh exists', () => {
    expect(predictDiscovery(result('new', 'soft jaw', 75, 1), profile)?.score).toBe(predictDiscovery(result('new', 'soft jaw', 75, 100), profile)?.score);
    expect(predictDiscovery(result('new', 'soft jaw'), profile)?.geometryWeight).toBe(0);
  });
  it('never predicts a measurement-only candidate', () => {
    const r = result('new', 'soft jaw'); delete r.scores.aiLook;
    expect(predictDiscovery(r, profile)).toBeUndefined();
  });
  it('excludes rated IDs and known URLs before checking every remaining candidate', async () => {
    const analyze = vi.fn(async (im: SearchResultImage) => result(im.id, 'soft jaw'));
    const out = await discoverPortraits(profile, { ids: new Set(['rated']), urls: new Set([image('known').url]) }, {
      search: async () => response([image('rated'), image('known'), image('new1'), image('new2')]), analyze,
      shouldStop: () => false, onResult: vi.fn(), onProgress: vi.fn(),
    });
    expect(analyze).toHaveBeenCalledTimes(2);
    expect(out.results).toHaveLength(2);
    expect(analyze.mock.calls.every(([im]) => im.url.includes('new'))).toBe(true);
  });
  it('keeps AI-only candidates without a detected mesh', async () => {
    const out = await discoverPortraits(profile, { ids: new Set(), urls: new Set() }, { search: async () => response([image('new')]), analyze: async () => result('new', 'soft jaw'), shouldStop: () => false, onResult: vi.fn(), onProgress: vi.fn() });
    expect(out.results).toHaveLength(1);
    expect(out.results[0].faceDetection.detected).toBe(false);
  });
  it('does not pretend curated fallback photos are new personalized searches', async () => {
    const analyze = vi.fn();
    const out = await discoverPortraits(profile, { ids: new Set(), urls: new Set() }, { search: async () => ({ ...response([image('new')]), status: { provider: 'curated' } }), analyze, shouldStop: () => false, onResult: vi.fn(), onProgress: vi.fn() });
    expect(analyze).not.toHaveBeenCalled(); expect(out.results).toHaveLength(0); expect(out.errors).toHaveLength(1);
  });
  it('stops queued AI work when quota is exhausted', async () => {
    const analyze = vi.fn(async () => { const r = result('fail', ''); delete r.scores.aiLook; r.scores.aiLookError = 'AI credits have run out'; return r; });
    const out = await discoverPortraits(profile, { ids: new Set(), urls: new Set() }, { search: async () => response(Array.from({ length: 12 }, (_, i) => image(`new${i}`))), analyze, shouldStop: () => false, onResult: vi.fn(), onProgress: vi.fn() });
    expect(analyze.mock.calls.length).toBeLessThanOrEqual(2); expect(out.results).toHaveLength(0);
  });
});