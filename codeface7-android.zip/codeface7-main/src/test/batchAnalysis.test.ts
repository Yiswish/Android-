import { describe, it, expect } from 'vitest';
import { analyzeInParallel, type BatchStatus } from '../lib/batchAnalysis';

describe('simultaneous photo analysis', () => {
  it('starts two pictures before either completes and returns separate results', async () => {
    const releases: Array<() => void> = [];
    const started: number[] = [];
    const job = analyzeInParallel({ items: [1, 2, 3], shouldStop: () => false,
      analyze: async (picture) => { started.push(picture); await new Promise<void>((resolve) => releases.push(resolve)); return picture * 10; },
      onUpdate: () => {},
    });
    expect(started).toEqual([1, 2]);
    releases[0](); releases[1]();
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(started).toEqual([1, 2, 3]);
    releases[2]();
    expect((await job).sort()).toEqual([10, 20, 30]);
  });

  it('keeps other results when one picture fails', async () => {
    const states = new Map<number, BatchStatus>();
    const results = await analyzeInParallel({ items: ['broken', 'good'], shouldStop: () => false,
      analyze: async (picture) => { if (picture === 'broken') throw new Error('Unreadable'); return picture; },
      onUpdate: (index, status) => states.set(index, status),
    });
    expect(results).toEqual(['good']);
    expect(states.get(0)).toBe('failed');
    expect(states.get(1)).toBe('complete');
  });

  it('stops queued pictures without dropping active results', async () => {
    let stop = false;
    const states = new Map<number, BatchStatus>();
    const results = await analyzeInParallel({ items: [1, 2, 3, 4], shouldStop: () => stop,
      analyze: async (picture) => { stop = true; return picture; },
      onUpdate: (index, status) => states.set(index, status),
    });
    expect(results).toEqual([1]);
    expect(states.get(0)).toBe('complete');
    expect(states.get(1)).toBe('cancelled');
    expect(states.get(3)).toBe('cancelled');
  });
});