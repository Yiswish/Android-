// @vitest-environment node
import { describe, it, expect, vi, afterEach } from 'vitest';
import { searchChain } from '@/lib/search.providers';

const json = (b: unknown, status = 200) => new Response(JSON.stringify(b), { status, headers: { 'Content-Type': 'application/json' } });
afterEach(() => { vi.unstubAllGlobals(); vi.restoreAllMocks(); delete process.env.SERPAPI_API_KEY; delete process.env.SERPER_API_KEY; });

describe('Serper search key', () => {
  it('is used when SerpAPI has no key, sending the key only in the X-API-KEY header', async () => {
    vi.spyOn(console, 'error').mockImplementation(() => {});
    const fetchMock = vi.fn(async (url: string, init?: RequestInit) => {
      if (String(url).includes('google.serper.dev')) {
        expect(new Headers(init?.headers).get('X-API-KEY')).toBe('serper-test');
        return json({ images: [{ imageUrl: 'https://x/a.jpg', thumbnailUrl: 'https://x/a_t.jpg', title: 'a', imageWidth: 600, imageHeight: 900 }] });
      }
      throw new Error(`unexpected ${url}`);
    });
    vi.stubGlobal('fetch', fetchMock);
    const r = await searchChain({ query: 'woman', page: 1, perPage: 10, source: 'google' }, { serper: 'serper-test' });
    expect(r.status.provider).toBe('serper');
    expect(r.images).toHaveLength(1);
    expect(fetchMock.mock.calls.every((c) => !String(c[0]).includes('serper-test'))).toBe(true);
  });
  it('is skipped quietly when no Serper key exists', async () => {
    vi.spyOn(console, 'error').mockImplementation(() => {});
    vi.stubGlobal('fetch', vi.fn(async (url: string) => String(url).includes('openverse') ? json({ results: [{ id: '1', url: 'https://ov/1.jpg' }], result_count: 1, page_count: 1 }) : (() => { throw new Error(`unexpected ${url}`); })()));
    const r = await searchChain({ query: 'woman', page: 1, perPage: 10, source: 'google' });
    expect(r.status.provider).toBe('openverse');
    expect(r.status.attempts.map((a) => a.provider)).toEqual(['serpapi']);
  });
});
