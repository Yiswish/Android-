import { act, cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import HeldFacePhoto from '@/components/HeldFacePhoto';
import type { DetectedFace } from '@/lib/types';

beforeEach(() => vi.stubGlobal('PointerEvent', MouseEvent));
afterEach(() => { cleanup(); vi.useRealTimers(); vi.unstubAllGlobals(); });

function photo(faces: DetectedFace[], onClick = vi.fn()) {
  const rendered = render(<HeldFacePhoto src="/portrait.jpg" alt="Portrait" faces={faces} onClick={onClick} />);
  const image = screen.getByAltText('Portrait');
  Object.defineProperty(image, 'naturalWidth', { value: 800 });
  Object.defineProperty(image, 'naturalHeight', { value: 1200 });
  fireEvent.load(image);
  return { ...rendered, image, onClick };
}

const face = { meshLandmarks: Array.from({ length: 478 }, (_, i) => ({ x: i / 478, y: 0.25, z: 0 })) } as DetectedFace;

it('holds all 478 measured points in original coordinates and removes them on release without opening the viewer', () => {
  vi.useFakeTimers();
  const { image, container, onClick } = photo([face]);
  fireEvent.pointerDown(image, { button: 0 });
  act(() => vi.advanceTimersByTime(349));
  expect(container.querySelectorAll('circle')).toHaveLength(0);
  act(() => vi.advanceTimersByTime(1));
  const dots = container.querySelectorAll('circle');
  expect(dots).toHaveLength(478);
  expect(Number(dots[100].getAttribute('cx'))).toBeCloseTo(100 / 478 * 800);
  expect(Number(dots[100].getAttribute('cy'))).toBe(300);
  fireEvent.pointerUp(window);
  expect(container.querySelectorAll('circle')).toHaveLength(0);
  fireEvent.click(image);
  expect(onClick).not.toHaveBeenCalled();
});

it('a short tap still opens the photo, and cancelled holds never leave dots behind', () => {
  vi.useFakeTimers();
  const { image, container, onClick } = photo([face]);
  fireEvent.pointerDown(image, { button: 0 });
  act(() => vi.advanceTimersByTime(150));
  fireEvent.pointerUp(image);
  fireEvent.click(image);
  expect(onClick).toHaveBeenCalledTimes(1);
  fireEvent.pointerDown(image, { button: 0 });
  fireEvent.pointerCancel(image);
  act(() => vi.advanceTimersByTime(500));
  expect(container.querySelectorAll('circle')).toHaveLength(0);
});

it('old scans without original mesh coordinates never display invented dots', () => {
  vi.useFakeTimers();
  const { image, container } = photo([{} as DetectedFace]);
  fireEvent.pointerDown(image, { button: 0 });
  act(() => vi.advanceTimersByTime(500));
  expect(container.querySelectorAll('circle')).toHaveLength(0);
});