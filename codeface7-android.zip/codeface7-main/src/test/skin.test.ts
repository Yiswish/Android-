import { describe, it, expect } from 'vitest';
import { analyzeSkin, madSigma, median, percentile, skinRawScore, skinSoftScore, cheekCentre, SKIN_PARAMS, lumaFromRGBA, type SkinLandmark } from '@/lib/skin';

// ---- synthetic face: bright skin + cheek noise, eyes with a strong iris edge ----------------
const W = 400, H = 400;
function lcg(seed: number) { let s = seed >>> 0; return () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296); }

function landmarks(ipdFrac = 0.28): SkinLandmark[] {
  const lm: SkinLandmark[] = Array.from({ length: 478 }, () => ({ x: 0.5, y: 0.5 }));
  lm[468] = { x: 0.5 - ipdFrac / 2, y: 0.4 }; lm[473] = { x: 0.5 + ipdFrac / 2, y: 0.4 };
  lm[61] = { x: 0.4, y: 0.7 }; lm[291] = { x: 0.6, y: 0.7 };
  return lm;
}

/** noise = amplitude of white cheek noise (luminance units, 0–255 scale). */
function makeImage(lm: SkinLandmark[], noise: number, opts: { gain?: number; hair?: boolean; seed?: number } = {}) {
  const rnd = lcg(opts.seed ?? 7);
  const ipd = Math.hypot((lm[468].x - lm[473].x) * W, (lm[468].y - lm[473].y) * H);
  const luma = new Float32Array(W * H);
  for (let i = 0; i < luma.length; i++) luma[i] = 180 + (rnd() - 0.5) * 2 * noise * 1.7;
  for (const p of [lm[468], lm[473]]) {
    const cx = p.x * W, cy = p.y * H;
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const d = Math.hypot(x - cx, y - cy);
      if (d < 0.36 * ipd) luma[y * W + x] = d < 0.14 * ipd ? 40 : 225; // iris on sclera: the sharp reference
    }
  }
  if (opts.hair) { // dark hair band across the whole left-cheek region
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (x > 0.5 * W && y > 0.45 * H && y < 0.72 * H && x % 9 < 6) luma[y * W + x] = 35;
  }
  if (opts.gain) for (let i = 0; i < luma.length; i++) luma[i] *= opts.gain;
  return luma;
}

describe('robust statistics', () => {
  it('MAD-σ ignores a single extreme pixel; the mean/RMS would not', () => {
    const a = [1, 2, 3, 4, 5, 6, 7, 8, 9];
    const withOutlier = [...a, 100000];
    expect(Math.abs(madSigma(withOutlier) - madSigma(a))).toBeLessThan(1);
    expect(median([3, 1, 2])).toBe(2);
    expect(percentile([0, 10], 0.5)).toBe(5);
  });
});

describe('skin score curve', () => {
  it('is strictly decreasing in the ratio and never pins to 0 / 100 after the soft band', () => {
    let prev = Infinity;
    for (const r of [0, 0.02, 0.05, 0.1, 0.19, 0.25, 0.34, 0.6, 1.2]) {
      const s = skinSoftScore(skinRawScore(r));
      expect(s).toBeLessThan(prev); prev = s;
      expect(s).toBeGreaterThan(0); expect(s).toBeLessThan(100);
    }
    expect(skinRawScore(0.25)).toBeCloseTo(100 * Math.exp(-1), 9); // ratio = τ → e⁻¹
  });
  it('reproduces the quoted measurements: portraits (ratio 0.03–0.07) score high, the aged painting (0.19–0.34) low', () => {
    expect(skinRawScore(0.03)).toBeGreaterThan(94);
    expect(skinRawScore(0.07)).toBeGreaterThan(85);
    expect(skinRawScore(0.19)).toBeLessThan(55);
    expect(skinRawScore(0.34)).toBeLessThan(25); // NOTE: the brief quoted ≈46–51 here; the stated formula gives ≈20
  });
});

describe('analyzeSkin on synthetic faces', () => {
  const lm = landmarks();
  it('detail ratio rises, score falls, as cheek texture grows', () => {
    const reports = [0, 2, 6, 15, 30].map((n) => analyzeSkin(makeImage(lm, n), W, H, lm)!);
    for (const r of reports) expect(r).toBeDefined();
    for (let i = 1; i < reports.length; i++) {
      expect(reports[i].ratio).toBeGreaterThan(reports[i - 1].ratio);
      expect(reports[i].score).toBeLessThan(reports[i - 1].score);
    }
    expect(reports[0].score).toBeGreaterThan(85);
    expect(reports[4].score).toBeLessThan(reports[0].score - 25);
  });
  it('is independent of exposure (gain) — a measure relative to the face’s own eyes', () => {
    const a = analyzeSkin(makeImage(lm, 8), W, H, lm)!;
    const b = analyzeSkin(makeImage(lm, 8, { gain: 0.55 }), W, H, lm)!;
    expect(b.ratio).toBeCloseTo(a.ratio, 2);
  });
  it('returns undefined for a tiny face (too few samples) and for missing iris landmarks', () => {
    const tiny = landmarks(0.05); // IPD = 20 px
    expect(analyzeSkin(makeImage(tiny, 5), W, H, tiny)).toBeUndefined();
    expect(analyzeSkin(makeImage(lm, 5), W, H, lm.slice(0, 468))).toBeUndefined();
  });
  it('low-resolution faces lose confidence and shrink toward the neutral 70', () => {
    const small = landmarks(0.11); // IPD = 44 px
    const r = analyzeSkin(makeImage(small, 0), W, H, small);
    const big = analyzeSkin(makeImage(lm, 0), W, H, lm)!;
    if (r) { expect(r.confidence).toBeLessThan(big.confidence); expect(Math.abs(r.score - SKIN_PARAMS.neutral)).toBeLessThan(Math.abs(big.score - SKIN_PARAMS.neutral)); }
  });
  it('hair over a cheek patch is masked out and lowers confidence', () => {
    const clean = analyzeSkin(makeImage(lm, 4), W, H, lm)!;
    const hairy = analyzeSkin(makeImage(lm, 4, { hair: true }), W, H, lm);
    expect(clean.maskedFraction).toBeLessThan(0.02);
    if (hairy) { expect(hairy.maskedFraction).toBeGreaterThan(0.1); expect(hairy.confidence).toBeLessThan(clean.confidence * 0.7); }
  });
  it('reports patch geometry from the documented formula', () => {
    const r = analyzeSkin(makeImage(lm, 3), W, H, lm)!;
    const ipd = 0.28 * W;
    const c = cheekCentre({ x: lm[468].x * W, y: lm[468].y * H }, { x: lm[473].x * W, y: lm[473].y * H }, { x: lm[61].x * W, y: lm[61].y * H }, ipd);
    expect(r.patches[0].x).toBeCloseTo(c.x, 9);
    expect(r.patches[0].r).toBeCloseTo(0.2 * ipd, 9);
    // right-side cheek centre lies outward (image-left) of the pupil-to-mouth line
    expect(c.x).toBeLessThan(lm[468].x * W + 0.65 * (lm[61].x - lm[468].x) * W);
    expect(r.ipdPx).toBeCloseTo(ipd, 6);
  });
  it('is deterministic and RGBA → luma uses Rec. 709 weights', () => {
    expect(analyzeSkin(makeImage(lm, 5), W, H, lm)!.score).toBe(analyzeSkin(makeImage(lm, 5), W, H, lm)!.score);
    const l = lumaFromRGBA([255, 0, 0, 255, 0, 255, 0, 255], 2, 1);
    expect(l[0]).toBeCloseTo(0.2126 * 255, 3); expect(l[1]).toBeCloseTo(0.7152 * 255, 3);
  });
  it('a grayscale copy of the same luminance gives an identical measurement (no colour is read)', () => {
    const rgba = new Uint8ClampedArray(W * H * 4);
    const base = makeImage(lm, 6);
    for (let i = 0; i < W * H; i++) { rgba[i * 4] = rgba[i * 4 + 1] = rgba[i * 4 + 2] = base[i]; rgba[i * 4 + 3] = 255; }
    const a = analyzeSkin(lumaFromRGBA(rgba, W, H), W, H, lm)!;
    const b = analyzeSkin(lumaFromRGBA(rgba, W, H), W, H, lm)!;
    expect(a.score).toBe(b.score);
  });
});
