import { describe, it, expect } from 'vitest';
import { calibrateBody, type BodyExample } from '@/lib/bodyTeaching';
const r = (n: number) => ({ overall: n, proportions: n, physique: n, posture: n, presentation: n });
describe('calibrateBody', () => {
  it('leaves scores unchanged with no ratings', () => {
    expect(calibrateBody({ ...r(60), bodyType: 'slim' }, []).value.overall).toBe(60);
  });
  it('moves toward the user when they rate a body type higher', () => {
    const ex: BodyExample[] = Array.from({ length: 10 }, () => ({ bodyType: 'curvy', ai: r(50), user: r(70) }));
    const out = calibrateBody({ ...r(50), bodyType: 'Curvy' }, ex).value;
    expect(out.overall).toBe(65); // 0.5*20 + 0.25*20
  });
  it('stays within 1-100', () => {
    const ex: BodyExample[] = Array.from({ length: 10 }, () => ({ bodyType: 'slim', ai: r(10), user: r(100) }));
    expect(calibrateBody({ ...r(95), bodyType: 'slim' }, ex).value.overall).toBe(100);
  });
});
