import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { useState } from 'react';
import { describe, expect, it, vi } from 'vitest';
import type { AnalysisResult, StarRating } from '../lib/types';
import { scoreToRating } from '../lib/faceTeaching';
import { emptyMetrics } from '../lib/metricKeys';
import { buildTasteModel } from '../lib/preferenceEngine';
import DiscoverForYou from '../components/DiscoverForYou';

vi.mock('../lib/search', () => ({ searchImages: async () => ({ images: [{ id: 'new', url: '/_verify/celeb_Gal_Gadot.jpg?new', thumbUrl: '/_verify/celeb_Gal_Gadot.jpg?new', width: 600, height: 800, source: 'google' }], hasMore: false }) }));
vi.mock('../lib/faceDetection', () => ({ detectFaces: async () => ({ detected: false, faceCount: 0, faces: [], primaryFaceIndex: 0, pose: 'profile-left', poseConfidence: 0.2, expression: 'neutral', logs: [] }), deriveMetricsFromFace: () => emptyMetrics(50), imageQualityOf: () => undefined }));
vi.mock('../lib/aiLookClient', () => ({ applyAiLook: async (scores: AnalysisResult['scores']) => ({ ...scores, overall: 85, aiLook: { attractiveness: 85, typeMatch: 75, geometryOverall: 50, description: 'soft jaw almond eyes', reasons: ['soft jaw almond eyes'], categories: ['Cute'] } }) }));

describe('discovery rating flow with injected services', () => {
  it('checks a new portrait, rates it in place, and opens the same result without scanning again', async () => {
    const base: AnalysisResult[] = Array.from({ length: 3 }, (_, i) => ({ id: `ref${i}`, imageId: `ref${i}`, imageUrl: '/_verify/celeb_Gal_Gadot.jpg', source: 'google', timestamp: 1, faceDetection: { detected: false, faceCount: 0, faces: [], primaryFaceIndex: 0, pose: 'frontal', poseConfidence: 0, expression: 'neutral', expressionConfidence: 0, logs: [] }, scores: { overall: 80, metrics: emptyMetrics(50), archetypeMatch: {}, aiLook: { attractiveness: 80, typeMatch: 75, geometryOverall: 50, description: 'soft jaw almond eyes', reasons: ['soft jaw almond eyes'], categories: ['Cute'] } }, warnings: [], duration: 1, topArchetypes: [] }));
    const rate = vi.fn(); const open = vi.fn();
    function Harness() {
      const [candidates, setCandidates] = useState<AnalysisResult[]>([]);
      const [ratings, setRatings] = useState<StarRating[]>(base.map((r) => ({ imageId: r.imageId, rating: scoreToRating(90), timestamp: 1 })));
      const results = [...base, ...candidates];
      return <DiscoverForYou results={results} ratings={ratings} tasteModel={buildTasteModel(results, ratings)} candidates={candidates}
        onCandidate={(r) => setCandidates((v) => [...v, r])} onOpen={open} onGoRate={vi.fn()}
        onRate={(imageId, rating) => { rate(imageId, rating); setRatings((v) => [...v, { imageId, rating, timestamp: 2 }]); }} />;
    }
    render(<Harness />);
    fireEvent.click(screen.getByRole('button', { name: 'Find faces for me' }));
    const slider = await screen.findByRole('slider', { name: 'Your face rating' });
    fireEvent.keyDown(slider, { key: 'End' });
    await waitFor(() => expect(rate).toHaveBeenCalledWith(expect.stringContaining('discover-'), 5));
    fireEvent.click(screen.getByRole('button', { name: 'Open discovered portrait' }));
    expect(open).toHaveBeenCalledWith(expect.objectContaining({ imageId: rate.mock.calls[0][0], scores: expect.objectContaining({ aiLook: expect.objectContaining({ attractiveness: 85 }) }) }));
  });
});