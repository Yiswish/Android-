import { describe, it, expect } from 'vitest';
import { weightedScore, filterByFolder } from '@/lib/userPrefs';
import type { AestheticScores } from '@/lib/types';

const scores = (face?: number, ai?: number, photo?: number) => ({
  overall: 70,
  metrics: {},
  archetypeMatch: {},
  breakdown: photo === undefined ? undefined : { faceScore: face, photoScore: photo, faceShare: 0.8, photoShare: 0.2, confidence: 1, overall: 70, formula: '' },
  aiLook: ai === undefined ? undefined : { attractiveness: ai, typeMatch: 50, reasons: [], geometryOverall: 70 },
}) as unknown as AestheticScores;

describe('weighted score', () => {
  it('ignores photo quality even if an old saved weight exists', () => {
    expect(weightedScore(scores(80, 60, 40), { face: 50, ai: 25, photo: 25 })).toBe(73);
  });
  it('only the face counts when the other weights are zero', () => {
    expect(weightedScore(scores(80, 60, 40), { face: 10, ai: 0, photo: 0 })).toBe(80);
  });
  it('drops a missing AI look and renormalises', () => {
    expect(weightedScore(scores(80, undefined, 40), { face: 50, ai: 50, photo: 50 })).toBe(80);
  });
  it('does not change the normal score', () => {
    const s = scores(80, 60, 40);
    weightedScore(s, { face: 0, ai: 100, photo: 0 });
    expect(s.overall).toBe(70);
  });
});

describe('folders', () => {
  const items = [{ id: 'a' }, { id: 'b' }, { id: 'c' }];
  it('shows only items saved in the chosen folder', () => {
    expect(filterByFolder(items, { a: ['Faves'], b: ['Other'] }, 'Faves').map((i) => i.id)).toEqual(['a']);
  });
  it('shows everything when no folder is chosen', () => {
    expect(filterByFolder(items, {}, null)).toHaveLength(3);
  });
});

import { weightedScore as ws2, weightedParts as wp2 } from '@/lib/userPrefs';
describe('weight sliders change the weighted score', () => {
  const s = { overall: 60, metrics: {}, breakdown: { faceScore: 40, photoScore: 80, faceShare: 1, photoShare: 0, confidence: 1, overall: 60, formula: '' }, aiLook: { attractiveness: 90 } } as never;
  it('face 5 / ai 65 / photo 0 is mostly the AI look', () => {
    expect(ws2(s, { face: 5, ai: 65, photo: 0 })).toBe(Math.round((40 * 5 + 90 * 65) / 70));
  });
  it('different weights give a different score', () => {
    expect(ws2(s, { face: 100, ai: 0, photo: 0 })).toBe(40);
    expect(ws2(s, { face: 0, ai: 100, photo: 0 })).toBe(90);
  });
  it('missing AI look gets 0% share', () => {
    const noAi = { ...(s as object), aiLook: undefined } as never;
    expect(wp2(noAi, { face: 5, ai: 65, photo: 0 }).find((p) => p.key === 'ai')!.share).toBe(0);
  });
});
